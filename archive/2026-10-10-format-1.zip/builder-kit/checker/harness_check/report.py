"""Stdlib-only output, including incomplete runs without parser dependencies."""
import importlib.metadata
import json
import platform

DEPENDENCIES = ('PyYAML','jsonschema','attrs','jsonschema-specifications','referencing','rpds-py','typing-extensions')
LIMITATIONS = [
    'Read-only installation checks; no configured command, adapter, download or runtime transition is executed.',
    'Exit 0 describes covered checks only; semantic review, execution and activation remain separate obligations.',
    'IS-03.separation permits review only; IS-08.assessment aggregation is report logic, not an automated criterion claim.',
    'Historical installation assessments never replace current profile assessments. Prose receipt semantics require whole-obligation review.',
    'External references are never opened; reviewed access claims remain attributable to the supplied reviewer.',
    'Native Windows and Linux validation is PENDING; a run reports only its actual host/runtime.',
]


def new_report():
    dependencies = {}
    for name in DEPENDENCIES:
        try:
            dependencies[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            dependencies[name] = 'UNAVAILABLE'
    return dict(schema_version='1.0.0',record_type='CheckerReport',checker='reference-checker',checker_version='1.0.0',
                assessed_configuration_id=None,platform=dict(os=platform.system(),architecture=platform.machine(),
                runtime='Python '+platform.python_version(),dependencies=dependencies),checked_assessments=[],
                uncovered_ids=[],diagnostics=[],limitations=list(LIMITATIONS),exit_code=0,
                structure_assessment='INCOMPLETE',integration_assessment='NOT_ASSESSED',extensions={'profiles':{}})


def emit(report, format):
    if format == 'json':
        print(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
    else:
        print(f"{report['checker']} {report['checker_version']} | {report['platform']['runtime']} | {report['platform']['os']}")
        print('Configuration:', report['assessed_configuration_id'] or 'UNAVAILABLE')
        print('Structure:',report['structure_assessment'],'| Integration:',report['integration_assessment'],'| Exit:',report['exit_code'])
        for pid,status in report['extensions'].get('profiles',{}).items():
            print(f'Profile {pid}: {status}')
        print('Dependencies:',json.dumps(report['platform']['dependencies'],sort_keys=True))
        for a in report['checked_assessments']:
            print(a['criterion_id'],a['result'],a['reason'])
        print('Uncovered:',', '.join(report['uncovered_ids']))
        for d in report['diagnostics']:
            print(d['code'],d['path'],d['message'])
        for limitation in report['limitations']:
            print('Limitation:',limitation)
