"""Explicit roots, stdout reports, no implicit dependency installation."""
import argparse
from pathlib import Path
import sys
from .report import emit, new_report


class InvocationError(ValueError):
    pass


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise InvocationError(message)


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    output_format = 'text' if '--format' in argv and argv[argv.index('--format')+1:][:1] == ['text'] else 'json'
    report = new_report()
    try:
        parser = Parser(description='Optional read-only harness installation checker (Python 3.11+)')
        parser.add_argument('--repo-root', required=True)
        parser.add_argument('--harness-root', required=True)
        parser.add_argument('--legacy-layout', action='store_true', help='Read-only inspection of retained layout 1; never migrates records')
        parser.add_argument('--record', default='artifacts/installation/installation-record.yaml')
        parser.add_argument('--catalogue', default='framework/workflows/verification-criteria.yaml')
        parser.add_argument('--format', choices=('json','text'), default='text')
        args = parser.parse_args(argv)
        output_format = args.format
        if sys.version_info < (3,11):
            raise InvocationError('Python 3.11 or later is required')
        repo = Path(args.repo_root)
        if not repo.is_absolute() or not repo.is_dir():
            raise InvocationError('--repo-root must identify an existing absolute directory')
        try:
            from .loader import relative_path, DocumentError
            from .checks import check_installation
            from .layout import legacy_path, check_layout
        except ImportError as exc:
            report['exit_code'] = 2
            report['diagnostics'].append(dict(code='PREREQUISITE_DEPENDENCY',path='checker',reference=None,
                message=f'Parser/schema dependency unavailable: {exc}. Use permitted review; no download attempted.'))
        else:
            try:
                repo = repo.resolve(strict=True)
                harness = relative_path(args.harness_root, repo, directory=True)
                check_layout(harness, args.legacy_layout)
                record = relative_path(legacy_path(args.record) if args.legacy_layout else args.record, harness)
                catalogue = relative_path(legacy_path(args.catalogue) if args.legacy_layout else args.catalogue, harness)
                report = check_installation(repo,harness,record,catalogue,legacy=args.legacy_layout)
            except DocumentError as exc:
                report['exit_code'] = exc.exit_code
                report['diagnostics'].append(dict(exc.diagnostic(),reference=None))
    except InvocationError as exc:
        report['exit_code'] = 2
        report['diagnostics'].append(dict(code='PREREQUISITE_INVOCATION',path='arguments',reference=None,message=str(exc)))
    except Exception as exc:
        report['exit_code'] = 2
        report['diagnostics'].append(dict(code='PREREQUISITE_INTERNAL',path='checker',reference=None,message=f'{type(exc).__name__}: {exc}'))
    emit(report,output_format)
    return report['exit_code']
