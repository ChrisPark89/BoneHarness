"""Pure assessment joins and R-07 aggregation; filesystem evidence is checked by checks."""
from collections import Counter
import re

SATISFIED = {'PASS', 'NOT_APPLICABLE'}
IDENTITY = re.compile(r'sha256:[0-9a-f]{64}\Z')


def integration_id(profile_id, capability_id, target_id):
    return 'II-' + '-'.join('x' + value.encode('utf-8').hex() for value in (profile_id, capability_id, target_id))


def summarize(catalogue: dict, assessments: list[dict], profile: dict) -> dict:
    diagnostics = []
    def issue(code, cid, message):
        diagnostics.append(dict(code=code,path='assessments',criterion_id=cid,message=message))
    definitions = {d['id']: d for d in catalogue.get('criteria', [])}
    duplicate_definitions = {cid for cid,n in Counter(d['id'] for d in catalogue.get('criteria', [])).items() if n > 1}
    for cid,count in Counter(d['id'] for d in catalogue.get('criteria', [])).items():
        if count > 1:
            issue('REFERENCE_DUPLICATE', cid, 'Duplicate criterion definition')
    counts = Counter(a.get('criterion_id') for a in assessments)
    valid = {}
    for a in assessments:
        cid = a.get('criterion_id', '<missing>')
        d = definitions.get(cid)
        errors = []
        if cid in duplicate_definitions:
            errors.append('Criterion definition is duplicated')
        if not d:
            issue('REFERENCE_UNKNOWN', cid, 'Assessment has no matching criterion'); continue
        if counts[cid] != 1:
            errors.append('Duplicate assessment claim')
        if a.get('catalogue_version') != catalogue.get('catalogue_version'):
            errors.append('Catalogue version does not match')
        if a.get('assessed_configuration_id') != profile.get('configuration_id'):
            errors.append('Assessment configuration is stale')
        result = a.get('result')
        if result not in ('PASS', 'NOT_APPLICABLE', 'PENDING', 'BLOCKED', 'FAIL'):
            errors.append('Unknown criterion result')
        if a.get('method') is not None and a.get('method') not in d['allowed_methods']:
            errors.append('Method is not allowed for this criterion')
        if result != 'PENDING' and (a.get('method') not in d['allowed_methods'] or not a.get('actor')):
            errors.append('Assessed result requires actual permitted method and actor')
        evidence = a.get('evidence_refs', [])
        if result in SATISFIED:
            if not evidence:
                errors.append('Satisfied result requires evidence')
            for e in evidence:
                ref = e.get('reference', {})
                if not IDENTITY.fullmatch(e.get('identity', '')) or not e.get('summary'):
                    errors.append('Evidence requires content identity and summary')
                if ref.get('kind') == 'EXTERNAL' and (ref.get('accessibility') != 'AVAILABLE' or a.get('method') == 'AUTOMATED'):
                    errors.append('External evidence requires an actual access review')
                if ref.get('kind') not in ('EXTERNAL', 'LOCAL'):
                    errors.append('Evidence reference kind is invalid')
                required = d.get('extensions', {}).get('required_provenance')
                if required == 'EXECUTION' and e.get('provenance') != 'EXECUTION':
                    errors.append('Execution obligation requires real execution evidence')
            if result == 'NOT_APPLICABLE' and not d.get('applicability_rule'):
                errors.append('Unconditional criterion cannot be waived')
        if not a.get('reason'):
            errors.append('Assessment requires a reason')
        if errors:
            issue('REFERENCE_ASSESSMENT', cid, '; '.join(errors))
        else:
            valid[cid] = a

    instances = catalogue.get('extensions', {}).get('integration_instances', [])
    tuples = {}
    for item in instances:
        key = tuple(item.get(k) for k in ('profile_id', 'capability_id', 'target_id'))
        cid = item.get('criterion_id', '<missing>')
        if (not all(isinstance(k, str) for k in key) or cid != integration_id(*key) or
                key in tuples or cid not in definitions or definitions[cid]['category'] != 'INTEGRATION'):
            issue('REGISTRY_INTEGRATION', cid, 'Invalid, duplicate or ambiguous integration tuple/definition')
            valid.pop(cid, None)
        else:
            tuples[key] = item

    profiles = {}
    for p in profile.get('workflow_profiles', []):
        pid = p['id']
        targets = p.get('required_targets')
        required = p.get('required_capabilities', [])
        current = []
        complete = isinstance(targets, list) and bool(targets)
        if isinstance(targets, list):
            target_ids = [t['target_id'] for t in targets]
            if len(set(target_ids)) != len(target_ids):
                complete = False
                issue('REGISTRY_TARGET', pid, 'Target IDs must be unique within each profile')
            for cap in required:
                binding = profile.get('capabilities', {}).get(cap)
                if binding is None:
                    complete = False
                    issue('REGISTRY_CAPABILITY', pid, 'Required capability is not registered: ' + cap)
                for target in targets:
                    key = (pid, cap, target['target_id'])
                    item = tuples.get(key)
                    a = valid.get(item['criterion_id']) if item else None
                    if item and item['environment'] != target['environment']:
                        issue('REGISTRY_TARGET', item['criterion_id'], 'Tuple environment differs from required target')
                        a = None
                    if a:
                        current.append(a)
                    if not a or a['result'] not in SATISFIED:
                        complete = False
                    if a and a['result'] == 'NOT_APPLICABLE':
                        applicability = p.get('applicability', {})
                        binding_app = (binding or {}).get('applicability', {})
                        if not any(x.get('rule') and x.get('evidence_refs') for x in (applicability,binding_app)):
                            complete = False
                            issue('REFERENCE_APPLICABILITY', a['criterion_id'], 'Tuple waiver lacks scoped profile/binding authority')
                    elif not binding or binding.get('configuration_status') != 'CONFIGURED' or binding.get('compatibility') != 'COMPATIBLE':
                        complete = False
        # A known current BLOCKED tuple outranks missing/unassessed tuples.
        scoped = [a for key,item in tuples.items() if key[0] == pid and key[1] in required and (not isinstance(targets,list) or any(t['target_id']==key[2] for t in targets)) for a in [valid.get(item['criterion_id'])] if a]
        current.extend(a for a in scoped if a not in current)
        if any(a['result'] == 'BLOCKED' for a in current):
            status = 'BLOCKED'
        elif not current:
            status = 'NOT_ASSESSED'
        elif not complete:
            status = 'PARTIAL'
        else:
            status = 'READY'
        profiles[pid] = status
    values = list(profiles.values())
    if 'BLOCKED' in values:
        integration = 'BLOCKED'
    elif not values or all(s == 'NOT_ASSESSED' for s in values):
        integration = 'NOT_ASSESSED'
    elif any(s in ('PARTIAL', 'NOT_ASSESSED') for s in values):
        integration = 'PARTIAL'
    else:
        integration = 'READY'
    required_structure = [d['id'] for d in definitions.values() if d['required'] and d['category'] == 'STRUCTURE']
    satisfied = {cid for cid,a in valid.items() if a['result'] in SATISFIED}
    structure = 'STRUCTURE_COMPLETE' if required_structure and all(cid in satisfied for cid in required_structure) else 'INCOMPLETE'
    return dict(structure_assessment=structure,integration_assessment=integration,
                profiles=profiles,diagnostics=diagnostics,satisfied_ids=sorted(satisfied),
                assessed_ids=sorted(valid))
