# Optional installation checker

Use Python 3.11 or newer with the exact dependencies in [requirements.lock](requirements.lock). Dependency provisioning is an explicit environment-management step; neither this checker nor the installer installs packages or downloads anything. The lock records PyYAML 6.0.3, jsonschema 4.26.0 and their fixed dependencies. Python below 3.13 also requires typing-extensions 4.15.0.

From any working directory:

```text
python3 /absolute/path/to/repository/.harness/framework/tools/check.py --repo-root /absolute/path/to/repository --harness-root .harness --format json
```

The public options are:

| Option | Meaning/default |
| --- | --- |
| `--repo-root` | Required absolute repository directory |
| `--harness-root` | Required repository-relative installed root, using `/` |
| `--record` | Harness-relative path; `artifacts/installation/installation-record.yaml` |
| `--catalogue` | Harness-relative path; `framework/workflows/verification-criteria.yaml` |
| `--legacy-layout` | Explicit read-only layout 1 inspection; rejects mixed layout roots and never migrates records |
| `--format` | `json` or `text`; default `text` |

Reports go to stdout. Redirect them **outside the inspected repository** when retaining evidence. There is no report-file option. The entry point disables import bytecode writes before importing its package, including when the checker itself is inside the inspected repository. Use the documented entry point for that guarantee.

| Exit | Meaning |
| --- | --- |
| `0` | All covered checks passed; uncovered criteria may remain pending |
| `1` | Diagnosed invalid/unsafe input or a covered check failed |
| `2` | Bad invocation, unavailable dependencies, unreadable input, or an internal error prevented completion |

Exit 2 takes precedence and retains diagnostics already collected. Unknown configuration identity is `null` only in nonzero reports. A completed exit-0 report always identifies the assessed configuration. Reports include checker/platform/runtime/dependency versions, exact checked assessments and evidence identities, uncovered IDs, limitations, per-profile integration status and separate structure/integration aggregates. Diagnostics contain `code`, `path`, `message`, `reference` (nullable), and `criterion_id` when applicable.

If Python or a dependency is unavailable, record checker `NOT_RUN`/unavailability in the installation record and use the criterion's permitted actual review or equivalent tooling. A missing checker does not itself make an integration incompatible. Do not replace pending review evidence with a claimed checker PASS.

## Claims and boundaries

For the installed version 1.0.0 obligations the checker can cover:

- `IS-01.files`: required, distinct, safely scoped artifacts.
- `IS-01.schemas`: offline schema definitions and current supplied machine records.
- `IS-02.local_refs`: active typed local references, runtime Markdown links and local schema refs.
- `IS-03.registry`: canonical capability selections and distinct maintenance selectors.
- `IS-04.graph`: state/edge/rule/selector membership and deterministic routing.
- `IS-05.result_schema`: positive and negative synthetic probes, all four outcomes, mandatory identities, conditional lineage and evidence-bearing assessment shapes.
- `IS-06.records`: the ten installed durable record templates.
- `IS-07.sequence`: the exact default sequence, failure/repair edges, explicit alternative selectors and disabled default repair budgets.
- `IS-08.inventory`: the whole inventory obligation when its baseline can be checked; see the maintenance boundary below.

Eligibility is decided before running obligation-specific predicates: changed criterion text or methods that exclude AUTOMATED leave the whole obligation uncovered. Independent input checks still diagnose malformed records, invalid repair-policy types/budgets, unsafe paths, local/offline schema failures and invalid supplied assessment claims; those are not suppressed by changing a criterion. Additional required criteria always participate in final aggregation. `IS-03.separation` permits review only. `IS-08.assessment` is validated and aggregated as report logic but receives no automated criterion assessment from this checker. Semantic procedure text never becomes an automated PASS.

Schema/reference checks include the required current definitions, selected installation record/catalogue, additional machine records explicitly supplied in installation inventory, named machine records under `artifacts/development` and `artifacts/maintenance`, and their active typed references. Raw evidence and captured historical `configuration/` are not scanned as implicit current records. Local evidence identities are compared with bytes; external references are never opened. Declared templates have inert sample references until instantiated; negative-case strings remain literals. The project conformance catalogue is not installed or required. Small synthetic result probes check the installed record schema without adapters or runtime transitions. This is the harness saved-record format; native tool output may be interpreted by the LLM under the binding procedure. The checker does not assess that interpretation or tool quality.

Current `profile.assessments` are authoritative. Historical installation claims are never used as current satisfaction. Results are joined by catalogue/criterion/configuration, permitted method, actual actor, applicability and evidence. Local evidence with changed bytes is diagnosed. Retaining historical evidence across a configuration publication without an explicit new dependency-revalidation REVIEW reference leaves the claim PENDING. The new evidence summary must identify the current configuration and explicitly describe dependency revalidation. This is an attributable reviewer declaration whose bytes are checked; automation does not certify its semantic truth. Execution obligations still require EXECUTION provenance; FIXTURE and review assertions do not become executed outcomes.

Readiness follows R-07: a current required access/policy blocker first; no current assessments next; missing, unknown or incompatible requirements produce PARTIAL; otherwise READY. Optional unused capabilities do not lower a supported profile's readiness. Overall BLOCKED precedes unassessed/partial/ready aggregation. No supported profiles or unknown targets can establish READY. Structure requires satisfaction of every required structural definition, including extensions. Activation eligibility is a separate procedural decision; provenance cannot pass before actual activation and reread evidence.

### Default and adapted repair policy

The shipped build/test repair policies are disabled with zero attempts, full PREFLIGHT and no shortcut. IS-07.sequence automation covers that default configuration. Disabled-by-default does not prohibit maintenance from adopting an enabled bounded policy under installed RULE-08/09 and repository authority.

Any deviation from those defaults makes the **whole IS-07.sequence obligation uncovered**, even when its catalogue description is unchanged. An enabled, well-typed positive budget produces neither an automated sequence PASS nor a disabled-default failure. Shape validation still requires explicit enabled booleans, nonnegative integer limits, the PREFLIGHT route and a null or declared shortcut rule. Zero remaining permission or an enabled flag never grants dispatch authority.

A permitted current LLM_REVIEW/HUMAN_REVIEW assessment with an actual actor and REVIEW evidence can supply whole-obligation satisfaction. That review must inspect the original defaults and adopted policy, sequence/repair routes, configuration identity, applicability, budget-increase authority and any shortcut's dependency/artifact validity. The checker checks attribution, permitted method, current identity and evidence bytes; it cannot certify the review's truth. A supplied AUTOMATED claim or a claim lacking REVIEW provenance stays PENDING for adapted repair. Invalid or stale claims still diagnose; supplied FAIL/BLOCKED findings remain unsatisfied. Actual repair dispatch still requires the installed per-invocation policy, scope, evidence, progress and budget guards.

### Inventory after maintenance

Installation hashes remain historical. Only the exact `HARNESS:artifacts/installation/installation-record.yaml` GENERATED owned/generated entry has the mutable-ledger null-hash exemption. Definition bytes must match accepted endpoints. Owned entries must be identical members of generated inventory; duplicate scoped or physical paths are rejected.

Maintenance reconciliation checks committed PROMOTED versus ASSESSMENT_PUBLISHED snapshots, promotion/base/prospective identity consistency, ownership and before/after hash continuity to the current configuration. A RECONCILED recovery is not another publication. Missing ancestry leaves the whole criterion uncovered; a proven mismatch is diagnosed. Even a matching chain remains **wholly uncovered** when immutable baseline/write-receipt acceptance and attempt/writer/manifest semantics require review. There is no partial inventory PASS for checking only baseline hashes or typed publication fields. A permitted, current whole-obligation review may supply the missing satisfaction. This checker deliberately supplies no universal receipt schema or runtime engine.

The status Markdown is derived from canonical assessments and may need regeneration. A stale view never authorizes rewriting the profile or rolling back a successful publication. The checker performs no writes or repairs.

## Verification scope

Task 5 authoring evidence records native macOS arm64 runs on Python 3.14 and 3.11, adversarial subprocess tests, and before/after content-tree hashes. Native Windows and Linux remain PENDING until run on those hosts. Spaces/Unicode, LF/CRLF, alternate working directories and exact case are exercised locally; these do not substitute for another operating system.

The builder project's authoring tests are maintained outside this installation package. Those tests establish checker and definition behavior. To inspect a newly installed harness, use `check.py` with its explicit repository and harness roots as described above, then assess uncovered criteria using their permitted review methods. Real task success still requires repository-specific execution evidence.

## Task reporting integration

Inventory/schema/local-reference checks include the required runtime files, the report schema and immutable legacy descriptor. IS-04.graph checks the explicit PhaseMap, exact state partition, profile/criterion joins and the sixteen built-in RULE-06 entries as a required subset. Extra declared phases and criteria are allowed; custom stage policy leaves the whole graph obligation uncovered for an equivalent permitted review. These checks do not execute the reporter or establish availability, task completion, semantic review truth or positive source-content support.

Every declared RULE-06 table criterion must join the reporting catalogue. The supported-policy identity includes the full RULE-06 section, including Minimum evidence cells and custom rows; unparsed policy changes leave the whole obligation uncovered and cannot inherit a supplied automated PASS. Missing or mismatched table joins are diagnosed separately.

New installation ledgers record reporting_generator discovery separately from structure and checker coverage; old ledgers may omit that field. Missing Python/dependencies may leave the reporter unavailable in a structurally complete installation. The reporter checks local source inventories against accepted scope; tasks with opaque or missing inventories retain an unchecked source obligation. Scoped N/A authority remains pending. User-skip coverage checks graph metadata and required specification phases; runtime reporting checks scoped disposition evidence, while original-message meaning/authorship stays an attributed review obligation. Native platform coverage is established only by runs on that platform; installation checks never establish original-user authorship.

The fresh scaffolder copies this optional checker into `framework/tools/`. Builder-side `checker/check.py` also works. The checker binds only its colocated installed harness_io utilities or the package runtime template. It does not search repository ancestors for executable helpers. For an active reference with entry_id, the checker validates the journal chain, resolves that exact entry and compares its canonical payload identity. Full journal record/report semantics and recovery are checked by the journal tool/reporter; installation checking does not grant runtime transition authority.
