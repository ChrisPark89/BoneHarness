# Installed adapter interface

## Use a tool's normal output

A skill/tool does not have to emit harness JSON. The coordinating LLM may read its logs, exit status, reports or generated files and record the outcome using the binding's documented interpretation procedure. That procedure can be instructions for the LLM; a wrapper script is optional.

Keep the original evidence and identify the LLM's interpretation in the result summary. Take run, configuration and source identities from the recorded invocation; never guess them. For example, a test command's exit status and report may support PASS when they satisfy the declared test criteria. A message saying “done” alone may leave the outcome UNKNOWN.

The common Result below is the harness's saved record, not a required native tool response. Native validation, when available, is evidence; the LLM still checks the specification criteria separately. Recording an interpretation does not itself authorize a state change.

## Saved result and invocation requirements

Interface version: "1.0.0". Capability IDs are stable; active identity/version/content identity and readiness belong only to [repo-profile.yaml](../config/repo-profile.yaml). [Result schema](../templates/schemas/result.schema.json), [profile binding schema](../templates/schemas/profile.schema.json) and [record schemas](../templates/schemas/records.schema.json) are the machine contracts. No vendor command or external service is implied.

A binding declares adapter identity, exact input schema and environment, optional native validator, side effects, current permission procedure, invocation/reconciliation procedure, resolved absolute deadline policy and call budget, normalization and evidence. Pending settings block dispatch. Define nonzero exit, service failure, partial output, warnings, cancellation, timeout, stale inputs and credentials failure explicitly. Skills/adapters return evidence; the recorded state writer owns all transitions.

Every usable Result requires `schema_version: "1.0.0"`, `record_type: Result`, `interface_version: "1.0.0"`, `capability`, structured `adapter` identity/version/content_identity, `run_id`, `task_id`, source content `revision`, `status: PASS|FAIL|BLOCKED|UNKNOWN`, `evidence: {reference, summary}`, `provenance: FIXTURE|EXECUTION|REVIEW`, `configuration_id`, `adapter_definition_id`, and required target/environment set. Evidence references use typed LOCAL scope/path or EXTERNAL URI/accessibility. Capability additions belong in schema-declared `extensions`, never replace core fields.

Artifact/test-source fields are conditional on the pinned normalization binding. A successful build consumed downstream returns `{identity, reference}` artifact. A test binding may require separate test-source `{identity, reference}` and `artifact_identity`, matching both product and test repositories and consumed artifact. Result selector booleans are declarations: absent/false cannot waive a binding requirement, contradictions block. A source-only profile needs source identity without counterfeit build evidence. Preserve each required child result/diagnostic; apply RULE-04 running/deadline and terminal precedence.

Persist intent before dispatch and handle immediately afterward; use request ID idempotency when supplied by the service. Publish immutable invocation/result payloads with content identities. Reconcile an uncertain submit by request ID or documented evidence; stop when unresolved. All submit/poll/query/cancel calls and downtime consume persisted budgets. Do not claim exactly-once external execution or that cancellation reverses effects.

Plain output is valid input to the documented interpretation procedure. If it cannot support an outcome, preserve it as an Observation with UNKNOWN interpretation and diagnostics. An invalid structured response cannot be silently repaired or treated as success; retain the error and use only a previously declared alternative evidence method. A valid FAIL cannot be upgraded by LLM review. Optional absent native validation is recorded absent. A Result grounded in an actual invocation uses EXECUTION provenance, with its summary identifying any LLM interpretation; the separate criterion review uses REVIEW. Hypothetical examples always use FIXTURE. Compatibility checks whether usable evidence can be recorded and routed safely. Compatibility does not prove tool quality. [RULE-02–RULE-10](../workflows/verification-rules.md) define the comparisons and safe routes.

A replacement adapter is accepted only through maintenance with applicable compatibility, current policy and configuration publication checks. Existing tasks retain captured bindings until explicit adoption and affected-evidence reevaluation.
