#!/usr/bin/env python3
"""Append/read journal storage or project saved state; does not validate workflow gates."""
import argparse
from pathlib import Path
import sys
sys.dont_write_bytecode = True


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['append', 'read', 'state'])
    parser.add_argument('--history', required=True, type=Path)
    parser.add_argument('--task-id', required=True)
    parser.add_argument('--entry-id')
    parser.add_argument('--payload', type=Path)
    args = parser.parse_args(argv)
    try:
        from harness_io.journal import append_record, read_history, publish_state, canonical_json
        from harness_io.loader import read_bytes, parse_document
        if args.operation == 'append':
            if not args.entry_id or not args.payload:
                parser.error('append needs --entry-id and --payload')
            payload = parse_document(read_bytes(args.payload.resolve(), args.payload.resolve().parent), args.payload)
            value = append_record(args.history, args.task_id, args.entry_id, payload,
                                  Path(__file__).resolve().parent.parent / 'templates/schemas')
        elif args.operation == 'state':
            value = publish_state(args.history, args.task_id)
        else:
            value = read_history(args.history, args.task_id,
                                 Path(__file__).resolve().parent.parent / 'templates/schemas')
        print(canonical_json(value).decode('utf-8'))
        return 0
    except (ImportError, ValueError, OSError, RuntimeError, TypeError, KeyError) as exc:
        print('JOURNAL_UNAVAILABLE: ' + str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
