"""Versioned append-only storage. This module is not a workflow state controller."""
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile

from .loader import DocumentError, parse_document, read_bytes, scoped_path
from .schemas import validate_document, local_validator

VERSION = '1.0.0'
FIELDS = {'journal_version', 'task_id', 'sequence', 'entry_id', 'previous_hash',
          'payload_identity', 'payload', 'entry_hash'}
ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}\Z')
TYPES = {'ConfigSnapshot', 'TaskSpec', 'SourceInventory', 'TransitionRequest', 'GateDecision',
         'Invocation', 'Result', 'CriterionReview', 'PhaseDisposition', 'Observation', 'Event'}


def canonical_json(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'),
                      allow_nan=False).encode('utf-8')


def content_identity(raw):
    return 'sha256:' + hashlib.sha256(raw).hexdigest()


def make_entry(payload, task_id, entry_id, previous=None):
    entry = dict(journal_version=VERSION, task_id=task_id,
                 sequence=previous['sequence'] + 1 if previous else 1, entry_id=entry_id,
                 previous_hash=previous['entry_hash'] if previous else None,
                 payload_identity=content_identity(canonical_json(payload)), payload=payload)
    entry['entry_hash'] = content_identity(canonical_json(entry))
    return entry


def _fail(message):
    raise DocumentError('JOURNAL_INVALID', 'history.jsonl', message)


def _walk(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from _walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk(child)


def parse_history(raw, task_id):
    """All-or-nothing parsing. A missing final LF is a torn write, never ignored."""
    if raw and not raw.endswith(b'\n'):
        _fail('Incomplete final line; reconcile the original bytes before any further action')
    entries, seen, logical = [], set(), set()
    previous_state = None
    invocations = {}
    for line in raw.splitlines():
        if not line:
            _fail('Blank journal line')
        entry = parse_document(line, Path('entry.json'))
        if not isinstance(entry, dict) or set(entry) != FIELDS:
            _fail('Invalid envelope fields')
        payload = entry.get('payload')
        if (entry['journal_version'] != VERSION or entry['task_id'] != task_id
                or type(entry['sequence']) is not int or entry['sequence'] != len(entries) + 1
                or not isinstance(entry['entry_id'], str) or not ID.fullmatch(entry['entry_id'])
                or entry['entry_id'] in seen or not isinstance(payload, dict)
                or payload.get('record_type') not in TYPES or payload.get('schema_version', payload.get('interface_version')) != VERSION):
            _fail('Unsupported version, task, sequence, entry ID or payload type')
        expected = make_entry(payload, task_id, entry['entry_id'], entries[-1] if entries else None)
        if entry != expected:
            _fail('Journal hash chain or canonical payload identity mismatch')
        for node in _walk(payload):
            if ('task_id' in node and node['task_id'] != task_id
                    or 'subject_id' in node and (node['subject_id'] != task_id or node.get('subject_kind') != 'TASK')):
                _fail('Cross-task record is forbidden')
            if node.get('kind') == 'LOCAL':
                path = node.get('path')
                if (not isinstance(path, str) or not path or path.startswith('/') or '\\' in path or ':' in path
                        or any(p in ('', '.', '..') for p in path.split('/'))):
                    _fail('Unsafe local reference')
                if 'entry_id' in node:
                    if (node.get('scope') != 'HARNESS' or path != 'artifacts/development/' + task_id + '/history.jsonl'
                            or not isinstance(node['entry_id'], str) or not ID.fullmatch(node['entry_id'])):
                        _fail('Entry references must select the owning task journal and a stable entry ID')
                    if node['entry_id'] not in seen:
                        _fail('Entry reference must select an earlier retained payload')
        kind = payload['record_type']
        field = {'TransitionRequest': 'request_id', 'GateDecision': 'request_id', 'Event': 'request_id',
                 'Result': 'run_id', 'ConfigSnapshot': 'configuration_id', 'SourceInventory': 'revision',
                 'PhaseDisposition': 'disposition_id'}.get(kind)
        logical_id = (kind, payload.get(field)) if field else (kind, entry['payload_identity'])
        if logical_id in logical:
            _fail('Duplicate or conflicting logical record')
        if kind == 'Invocation':
            intent = payload.get('intent_id')
            prior = invocations.get(intent)
            if prior:
                fields = ('intent_id', 'request_id', 'run_id', 'task_id', 'capability',
                          'expected_identities', 'inputs', 'deadline')
                if any(payload.get(field) != prior.get(field) for field in fields):
                    _fail('Invocation revision changes stable intent inputs')
                before, after = prior.get('counters', {}), payload.get('counters', {})
                if (any(after.get(field) != before.get(field) for field in ('call_budget', 'time_budget_seconds'))
                        or any(after.get(field, -1) < before.get(field, 0) for field in ('calls', 'elapsed_seconds'))):
                    _fail('Invocation revision resets counters or changes budget')
                if (prior.get('dispatch_status') in ('COMPLETED', 'CANCELLED', 'RECONCILED')
                        and payload.get('dispatch_status') not in (prior['dispatch_status'], 'RECONCILED')):
                    _fail('Invocation revision reopens a terminal operation')
            elif payload.get('dispatch_status') != 'INTENT_RECORDED':
                _fail('First invocation revision must persist pre-dispatch intent')
            invocations[intent] = payload
        if kind == 'Result' and not any(p.get('run_id') == payload.get('run_id') for p in invocations.values()):
            _fail('Result has no prior invocation intent')
        if kind == 'ConfigSnapshot' and entries:
            _fail('Pinned configuration must be the first and only configuration record')
        if not entries and kind != 'ConfigSnapshot':
            _fail('First journal entry must pin ConfigSnapshot')
        if kind == 'Event':
            post = payload.get('post_state', {})
            version = previous_state['version'] if previous_state else 0
            state = previous_state['state'] if previous_state else None
            if (payload.get('previous_version') != version or payload.get('next_version') != version + 1
                    or payload.get('previous_state') != state or post.get('version') != version + 1
                    or post.get('state') != payload.get('next_state')):
                _fail('Committed event version/state chain mismatch')
            previous_state = post
        logical.add(logical_id)
        seen.add(entry['entry_id'])
        entries.append(entry)
    return entries


def read_history(history_path, task_id, schemas_root):
    """Read the entire journal and validate each typed payload against local schemas."""
    path = Path(history_path)
    root = path.parent.resolve(strict=True)
    _ordinary(path, root)
    entries = parse_history(read_bytes(path, root), task_id)
    validators = {}
    schemas = Path(schemas_root)
    base = local_validator(schemas / 'records.schema.json')
    for entry in entries:
        kind = entry['payload']['record_type']
        if kind not in validators:
            schema = schemas / ('result.schema.json' if kind == 'Result' else 'records.schema.json')
            reference = schema.resolve().as_uri() + ('' if kind == 'Result' else '#/$defs/' + kind)
            validators[kind] = base.evolve(schema={'$ref': reference})
        error = next(validators[kind].iter_errors(entry['payload']), None)
        if error:
            _fail('Malformed ' + kind + ' payload at ' + entry['entry_id'] + ': ' + error.message)
    return entries


def _ordinary(path, root, *, missing=False):
    # No symlink or hard-link alias is an allowed writable journal/state path.
    path = Path(path)
    scoped_path(path.parent, root, directory=True)
    for parent in [path, *path.parents]:
        if parent == root:
            break
        if parent.is_symlink():
            _fail('Symlink storage path forbidden')
    if path.exists():
        scoped_path(path, root)
        if path.stat().st_nlink != 1:
            _fail('Hard-linked storage path forbidden')
    elif not missing:
        _fail('Storage file missing')
    return path


@contextmanager
def _lock(history_path):
    path = Path(history_path)
    if path.name != 'history.jsonl':
        _fail('Canonical journal filename required')
    lock = path.parent / '.journal.lock'
    descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    identity = os.fstat(descriptor)
    try:
        yield
    finally:
        os.close(descriptor)
        current = lock.lstat()
        if (current.st_dev, current.st_ino) == (identity.st_dev, identity.st_ino):
            lock.unlink()


def append_record(history_path, task_id, entry_id, payload, schemas_root):
    """Serialize one storage append; validate shape, never decide a gate or dispatch."""
    path = Path(history_path)
    root = path.parent.resolve(strict=True)
    _ordinary(path, root, missing=True)
    with _lock(path):
        raw = read_bytes(path, root) if path.exists() else b''
        entries = read_history(path, task_id, schemas_root) if path.exists() else []
        prior = [entry for entry in entries if entry['entry_id'] == entry_id]
        if prior:
            if prior[0]['payload'] == payload:
                return prior[0]
            _fail('Entry ID reused with conflicting payload')
        if not isinstance(payload, dict):
            _fail('Payload must be a typed JSON object')
        kind = payload.get('record_type')
        schema = Path(schemas_root) / ('result.schema.json' if kind == 'Result' else 'records.schema.json')
        errors = validate_document(payload, schema, None if kind == 'Result' else kind)
        if errors:
            _fail('Payload schema validation failed: ' + str(errors[0]))
        candidate = make_entry(payload, task_id, entry_id, entries[-1] if entries else None)
        serialized = canonical_json(candidate) + b'\n'
        parse_history(raw + serialized, task_id)
        descriptor = os.open(path, os.O_CREAT | os.O_APPEND | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(descriptor, 'a+b') as stream:
            opened, current = os.fstat(stream.fileno()), path.lstat()
            if (not stat.S_ISREG(opened.st_mode) or opened.st_nlink != 1
                    or (opened.st_dev, opened.st_ino) != (current.st_dev, current.st_ino)):
                _fail('Journal changed or became hard linked')
            stream.seek(0)
            if stream.read() != raw:
                _fail('Journal changed before append; reconcile writer conflict')
            stream.write(serialized)
            stream.flush()
            os.fsync(stream.fileno())
        return candidate


def publish_state(history_path, task_id, schemas_root=None):
    """Publish the last recorded Event.post_state. No semantic gate approval implied."""
    path = Path(history_path)
    root = path.parent.resolve(strict=True)
    _ordinary(path, root)
    with _lock(path):
        schemas = Path(schemas_root) if schemas_root else Path(__file__).resolve().parents[2] / 'templates/schemas'
        entries = read_history(path, task_id, schemas)
        events = [e['payload'] for e in entries if e['payload']['record_type'] == 'Event']
        if not events:
            _fail('No committed event to project')
        destination = _ordinary(root / 'state.json', root, missing=True)
        if root.parent.name != 'development' or root.parent.parent.name != 'artifacts':
            _fail('State publication requires artifacts/development/<task-id>')
        staging = root.parent.parent / 'tmp'
        staging.mkdir(exist_ok=True)
        _ordinary(staging / '.unused', root.parent.parent, missing=True)
        descriptor, name = tempfile.mkstemp(prefix='.state-', dir=staging)
        try:
            with os.fdopen(descriptor, 'wb') as stream:
                stream.write(canonical_json(events[-1]['post_state']) + b'\n')
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(name, destination)
        finally:
            if os.path.exists(name):
                os.unlink(name)
        return events[-1]['post_state']
