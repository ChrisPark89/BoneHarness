"""Installed strict document and offline schema utilities."""

__version__ = '1.0.0'
