#!/usr/bin/env python3
"""Publish derived reports from one captured input set; never mutate task records."""
import argparse
from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path, PureWindowsPath
import stat
import sys
import tempfile

_OUTPUTS = ('report.json', 'report.md')
_PRIOR_MESSAGE = 'Existing report outputs have missing or mismatched generation IDs or JSON hash.'


class PublicationError(ValueError):
    pass


class CaptureChanged(PublicationError):
    pass


def _task_id(value):
    reserved = {'CON', 'PRN', 'AUX', 'NUL'} | {'COM' + str(n) for n in range(1, 10)} | {'LPT' + str(n) for n in range(1, 10)}
    if (not value or value in ('.', '..') or value.endswith(('.', ' '))
            or any(char in value for char in '/\\:<>"|?*') or PureWindowsPath(value).drive
            or any(ord(char) < 32 or ord(char) == 127 for char in value)
            or value.split('.')[0].upper() in reserved):
        raise argparse.ArgumentTypeError('task-id must be one safe directory name')
    return value


def _hash(content):
    return hashlib.sha256(content).hexdigest()


def _identity(info):
    return info.st_dev, info.st_ino


def _owned(path, identity):
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and _identity(info) == identity


def _read_output(path, scoped_path, run):
    """Read an ordinary exact-case output without retaining Windows file handles."""
    try:
        info = path.lstat()
    except FileNotFoundError:
        # Reject an existing wrong-case spelling even on case-sensitive systems.
        if any(child.name.casefold() == path.name.casefold() for child in run.iterdir()):
            raise PublicationError('Output filename has incorrect case.')
        return None
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise PublicationError('Output must be a regular file without symlinks or hard links.')
    scoped_path(path, run)
    descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
    with os.fdopen(descriptor, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        if _identity(opened) != _identity(info) or not stat.S_ISREG(opened.st_mode) or opened.st_nlink != 1:
            raise PublicationError('Output changed while being inspected.')
        content = stream.read()
        if not _owned(path, _identity(opened)):
            raise PublicationError('Output was replaced while being inspected.')
    return dict(content=content, identity=_identity(info), digest=_hash(content))


def _same_output(path, prior, scoped_path, run):
    current = _read_output(path, scoped_path, run)
    return current is None if prior is None else bool(current and current['identity'] == prior['identity']
                                                     and current['digest'] == prior['digest'])


def _pair_diagnostics(previous, parse_document, inspect_pair_metadata):
    data, markdown = previous['report.json'], previous['report.md']
    if data is None and markdown is None:
        return []
    valid = False
    if data and markdown:
        try:
            document = parse_document(data['content'], Path('report.json'))
            marker = inspect_pair_metadata(markdown['content'].decode('utf-8'))
            valid = bool(isinstance(document, dict) and document.get('record_type') == 'TaskReport'
                         and marker and marker[0] == document.get('generation_id') and marker[1] == data['digest'])
        except (ValueError, UnicodeError):
            pass
    return [] if valid else [dict(code='REPORT_PRIOR_OUTPUT_MISMATCH', severity='WARNING', message=_PRIOR_MESSAGE)]


class _Temporary:
    """Exclusive same-run staging, checked identity and invocation-only cleanup."""
    def __init__(self, run, owned, capture, scoped_path):
        self.capture, self.scoped_path = capture, scoped_path
        descriptor, filename = tempfile.mkstemp(prefix='.task-report-', suffix='.tmp', dir=run)
        self.path, self.descriptor = Path(filename), descriptor
        self.identity = _identity(os.fstat(descriptor))
        self.digest = None
        owned.append(self)

    def write(self, content):
        if not _owned(self.path, self.identity) or self.descriptor is None:
            raise PublicationError('Staging ownership was lost before writing.')
        descriptor, self.descriptor = self.descriptor, None
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        self.digest = _hash(content)

    def check(self):
        if not _owned(self.path, self.identity):
            raise PublicationError('Staging ownership was lost before publication.')
        descriptor = os.open(self.path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
        with os.fdopen(descriptor, 'rb') as stream:
            if _identity(os.fstat(stream.fileno())) != self.identity or _hash(stream.read()) != self.digest:
                raise PublicationError('Staging bytes changed before publication.')
        if not _owned(self.path, self.identity):
            raise PublicationError('Staging path was replaced before publication.')

    def replace(self, destination):
        # All descriptors are closed before replacement, including on Windows.
        self.check()
        os.replace(self.path, destination)

    def cleanup(self):
        if self.descriptor is not None:
            descriptor, self.descriptor = self.descriptor, None
            os.close(descriptor)
        # Close our descriptor even when the path can no longer be safely used.
        # Do not follow a redirected run to inspect/delete its replacement files.
        _check_run_scope(self.capture, self.scoped_path)
        if _owned(self.path, self.identity):
            self.path.unlink()


def _capture_template(capture, read_bytes, content_identity):
    roots = capture['roots']
    ref = dict(kind='LOCAL', scope='HARNESS', path='framework/templates/development/task-report.md')
    key = 'HARNESS:' + ref['path']
    raw = read_bytes(Path(roots['harness_root']) / ref['path'], Path(roots['harness_root']))
    identity = content_identity(raw)
    # A template already referenced as task evidence must match that capture too.
    existing = roots['inspected_inputs'].get(key)
    if existing and (existing['identity'] != identity or existing['error'] is not None):
        raise CaptureChanged('Installed template changed during capture.')
    if not existing:
        roots['inspected_inputs'][key] = dict(reference=ref, identity=identity, error=None)
        capture['source_manifest'].append(dict(scope='HARNESS', path=ref['path'], identity=identity))
        capture['source_manifest'].sort(key=lambda item: (item['scope'], item['path']))
    return dict(template_text=raw.decode('utf-8'), template_identity=identity, template_reference=ref,
                repo_root=roots['repo_root'], harness_root=roots['harness_root'], run_root=roots['run_root'],
                specification_refs=[], publication_diagnostics=[],
                human_spec_reference=roots.get('human_spec_reference'))


def _specification_refs(capture, identity):
    refs = []
    for rows in capture['record_index'].get('TaskSpec', {}).values():
        for row in rows:
            if row['value'].get('specification_identity') == identity and row.get('committed'):
                if row['reference'] not in refs:
                    refs.append(row['reference'])
    return refs


def _evidence_roles(capture):
    """Label typed Result fields, without interpreting prose or evidence quality."""
    roles = []
    for rows in capture['record_index'].get('Result', {}).values():
        for row in rows:
            value = row['value']
            for field, label in (('evidence', 'execution log' if value.get('provenance') == 'EXECUTION'
                                 else 'review basis' if value.get('provenance') == 'REVIEW' else 'fixture evidence'),
                                 ('artifact', 'artefact'), ('test_source', 'test source')):
                holder = value.get(field)
                ref = holder.get('reference') if isinstance(holder, dict) else None
                if isinstance(ref, dict):
                    item = dict(record_reference=row['reference'], reference=ref, label=label)
                    if item not in roles:
                        roles.append(item)
    return roles


def _cleanup_owned(owned):
    failures = []
    for item in reversed(owned):
        try:
            item.cleanup()
        except (OSError, ValueError, RuntimeError):
            failures.append(item.path.name)
    if failures:
        raise PublicationError('Owned temporary cleanup failed: ' + ', '.join(failures))


def _restore(capture, run, previous, published, backups, scoped_path):
    """Best effort rollback, preserving concurrent replacements or in-place edits."""
    failures = []
    for name in reversed(_OUTPUTS):
        if name not in published:
            continue
        try:
            _check_run_scope(capture, scoped_path)
            destination = Path(capture['roots']['output_paths'][name])
            current = _read_output(destination, scoped_path, destination.parent)
            staging = published[name]
            if not current or current['identity'] != staging.identity or current['digest'] != staging.digest:
                failures.append(name + ': concurrent output preserved')
                continue
            if previous[name] is None:
                destination.unlink()
            else:
                backups[name].replace(destination)
        except (OSError, ValueError, RuntimeError):
            failures.append(name + ': prior output restoration failed')
    return failures


def _stage(capture, run, owned, register, scoped_path, content):
    # Registration happens after exclusive creation; scope must gate creation.
    _check_run_scope(capture, scoped_path)
    staging = Path(capture['roots']['staging_root'])
    item = _Temporary(staging, owned, capture, scoped_path)
    item.write(content)
    return item


def _check_run_scope(capture, scoped_path):
    roots = capture['roots']
    repo = Path(roots['repo_root'])
    if repo.resolve(strict=True) != repo:
        raise PublicationError('Captured repository root was redirected before publication.')
    harness, run = Path(roots['harness_root']), Path(roots['run_root'])
    scoped_path(harness, repo, directory=True)
    scoped_path(run, harness, directory=True)
    if run.resolve(strict=True) != run:
        raise PublicationError('Captured run directory was redirected before publication.')
    for label in ('report_root', 'staging_root'):
        directory = Path(roots[label])
        scoped_path(directory, harness, directory=True)
        if directory.resolve(strict=True) != directory:
            raise PublicationError('Output/staging directory was redirected.')


def _generate(args, api):
    capture_task, check_unchanged, register, content_identity, canonical_json = api['capture']
    derive_report, invalidate_changed_capture, validate_report = api['summary']
    render_markdown, template_parts, inspect_pair_metadata = api['render']
    scoped_path, read_bytes, parse_document = api['loader']
    generated_at = datetime.now(timezone.utc).isoformat(timespec='microseconds').replace('+00:00', 'Z')
    for attempt in range(2):
        owned, published, backups = [], {}, {}
        previous, run = None, None
        try:
            capture = capture_task(Path(args.repo_root), Path(args.harness_root), args.task_id)
            run = Path(capture['roots']['run_root'])
            if not capture['roots']['run_path'].startswith('artifacts/development/'):
                raise PublicationError('Legacy records were read without migration; use their preserved legacy reporter or an approved layout migration for publication.')
            if Path(capture['roots']['harness_root']) != Path(__file__).resolve().parents[2]:
                raise PublicationError('Requested harness root differs from this installed generator.')
            harness = Path(capture['roots']['harness_root'])
            report_root = harness / 'docs/development' / args.task_id
            # Parents must already exist as a task's human spec directory.
            scoped_path(report_root, harness, directory=True)
            staging_root = harness / 'artifacts/tmp'
            if not staging_root.exists():
                scoped_path(staging_root.parent, harness, directory=True)
                staging_root.mkdir()
            scoped_path(staging_root, harness, directory=True)
            capture['roots'].update(report_root=str(report_root), staging_root=str(staging_root),
                                    output_paths={'report.json': str(run / 'report.json'),
                                                  'report.md': str(report_root / 'report.md')})
            destinations = {name: Path(path) for name, path in capture['roots']['output_paths'].items()}
            context = _capture_template(capture, read_bytes, content_identity)
            context['report_root'] = str(report_root)
            template_parts(context['template_text'])
            previous = {name: _read_output(destinations[name], scoped_path, destinations[name].parent) for name in _OUTPUTS}
            context['publication_diagnostics'] = _pair_diagnostics(previous, parse_document, inspect_pair_metadata)
            if context['publication_diagnostics']:
                print('REPORT_PRIOR_OUTPUT_MISMATCH: ' + _PRIOR_MESSAGE, file=sys.stderr)
            report = derive_report(capture, generated_at=generated_at)
            context['specification_refs'] = _specification_refs(capture, report['scope']['specification_identity'])
            context['evidence_roles'] = _evidence_roles(capture)
            report['extensions']['reporting']['presentation'] = context
            validate_report(report, capture)
            _check_run_scope(capture, scoped_path)
            for name in _OUTPUTS:
                if previous[name] is not None:
                    backups[name] = _stage(capture, run, owned, register, scoped_path, previous[name]['content'])
            staging = {
                'report.json': _stage(capture, run, owned, register, scoped_path, canonical_json(report) + b'\n'),
                'report.md': _stage(capture, run, owned, register, scoped_path, render_markdown(report, run_root=run).encode('utf-8')),
            }
            for item in owned:
                item.check()
            if any(not _same_output(destinations[name], previous[name], scoped_path, destinations[name].parent) for name in _OUTPUTS):
                raise PublicationError('Existing report outputs changed before replacement.')
            changes = check_unchanged(capture)
            for item in capture['diagnostics']:
                if item['code'] == 'REPORT_SOURCE_CHANGED' and item not in changes:
                    changes.append(item)
            if changes:
                if attempt == 0:
                    print('REPORT_SOURCE_CHANGED: retrying capture once.', file=sys.stderr)
                    _cleanup_owned(owned)
                    owned = []
                    continue  # No owned temporary remains when recapturing.
                report = invalidate_changed_capture(report, capture, changes)
                # Keep the originally captured template and roots for inconsistency rendering.
                _check_run_scope(capture, scoped_path)
                for item in staging.values():
                    item.cleanup()
                staging = {
                    'report.json': _stage(capture, run, owned, register, scoped_path, canonical_json(report) + b'\n'),
                    'report.md': _stage(capture, run, owned, register, scoped_path, render_markdown(report, run_root=run).encode('utf-8')),
                }
                print('REPORT_SOURCE_CHANGED: publishing captured-before-change inconsistency report.', file=sys.stderr)
            # Nothing reads task evidence between the final comparison and publication.
            for name in _OUTPUTS:
                _check_run_scope(capture, scoped_path)
                if not _same_output(destinations[name], previous[name], scoped_path, destinations[name].parent):
                    raise PublicationError('Existing report output changed before replacement.')
                staging[name].replace(destinations[name])
                published[name] = staging[name]
            actual = {name: _read_output(destinations[name], scoped_path, destinations[name].parent) for name in _OUTPUTS}
            if (any(not actual[name] or actual[name]['identity'] != published[name].identity
                    or actual[name]['digest'] != published[name].digest for name in _OUTPUTS)
                    or _pair_diagnostics(actual, parse_document, inspect_pair_metadata)):
                raise PublicationError('Published report pair changed or mismatched on inspection.')
            _cleanup_owned(owned)
            owned = []
            code = 0 if report['record_checks'] == 'CONSISTENT' else 1
            print(str(destinations['report.md']))
            print(str(run / 'report.json'))
            print('Record checks: ' + report['record_checks'] + '. Exit ' + str(code) + ': '
                  + ('declared checks consistent; task completion is separate.' if code == 0
                     else 'missing, unsupported, mismatched or inconsistent records.'))
            return code
        except CaptureChanged as exc:
            if attempt == 0:
                _cleanup_owned(owned)
                owned = []
                print('REPORT_SOURCE_CHANGED: retrying capture once.', file=sys.stderr)
                continue
            print('REPORT_UNAVAILABLE: ' + str(exc) + ' Cannot capture a safe installed template; prior reports may be stale.', file=sys.stderr)
            return 2
        except (OSError, ValueError, RuntimeError, KeyError, TypeError) as exc:
            failures = _restore(capture, run, previous, published, backups, scoped_path) if published else []
            message = str(exc).replace('\n', ' ').replace('\r', ' ')
            print('REPORT_UNAVAILABLE: ' + message + ' Prior reports may be stale.', file=sys.stderr)
            if failures:
                print('REPORT_UNAVAILABLE: prior report preservation incomplete; pair may be stale or mismatched. '
                      + '; '.join(failures), file=sys.stderr)
            return 2
        finally:
            for item in reversed(owned):
                try:
                    item.cleanup()
                except (OSError, ValueError, RuntimeError) as exc:
                    print('REPORT_UNAVAILABLE: owned temporary cleanup failed; ' + str(exc), file=sys.stderr)
    return 2


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo-root', required=True)
    parser.add_argument('--harness-root', required=True)
    parser.add_argument('--task-id', required=True, type=_task_id)
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        if exc.code:
            print('REPORT_UNAVAILABLE: invalid command arguments. Prior reports may be stale.', file=sys.stderr)
        return int(exc.code)
    if not Path(args.repo_root).is_absolute():
        print('REPORT_UNAVAILABLE: repo-root must be absolute. Prior reports may be stale.', file=sys.stderr)
        return 2
    # No optional dependency imports happen before --help/argument validation.
    # Reporting owns derived outputs only: local imports must not create pyc
    # files in the installed source tree, including on a failed invocation.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    try:
        from harness_io.loader import parse_document, read_bytes, scoped_path
        from reporting.evidence import capture_task, check_unchanged, register_publication_temporary, content_identity, canonical_json
        from reporting.summary import derive_report, invalidate_changed_capture, validate_report
        from reporting.render import render_markdown, template_parts, inspect_pair_metadata
    except (ImportError, OSError, ValueError, RuntimeError) as exc:
        print('REPORT_UNAVAILABLE: installed Python prerequisites unavailable (' + str(exc)
              + '). Prior reports may be stale.', file=sys.stderr)
        return 2
    return _generate(args, dict(capture=(capture_task, check_unchanged, register_publication_temporary, content_identity, canonical_json),
                               summary=(derive_report, invalidate_changed_capture, validate_report),
                               render=(render_markdown, template_parts, inspect_pair_metadata),
                               loader=(scoped_path, read_bytes, parse_document)))


if __name__ == '__main__':
    raise SystemExit(main())
