"""Read-only context selection. Importable by a future CLI; no printing or writes.

Results describe recorded state and applicable definitions, never gate approval.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path, PureWindowsPath
import re

from harness_io.loader import DocumentError, read_bytes, relative_path
from harness_io.schemas import local_validator
from reporting.evidence import capture_task, check_unchanged, reference_key

RULES = 'framework/workflows/verification-rules.md'
GUIDES = {'development': 'framework/workflows/development/HARNESS.md',
          'recovery': 'framework/workflows/recovery.md',
          'maintenance': 'framework/workflows/maintenance/harness-maintenance.md',
          'setup': 'framework/workflows/setup.md'}


def _identity(value):
    return 'sha256:' + hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _name(value):
    reserved = {'CON', 'PRN', 'AUX', 'NUL'} | {f'{p}{n}' for p in ('COM', 'LPT') for n in range(1, 10)}
    if (not isinstance(value, str) or not value or value in ('.', '..') or value.endswith(('.', ' '))
            or any(c in value for c in '/\\:<>"|?*') or PureWindowsPath(value).drive
            or any(ord(c) < 32 or ord(c) == 127 for c in value)
            or value.split('.')[0].upper() in reserved):
        raise ValueError('Task/update ID must be one portable directory name')
    return value


def _sections(text):
    """Keep exact heading sections, rejecting ambiguous selectors."""
    result = {}
    matches = list(re.finditer(r'^#{2,3} (.+)$', text, re.M))
    for i, match in enumerate(matches):
        key = match.group(1).strip()
        if key in result:
            raise ValueError('Duplicate section: ' + key)
        result[key] = text[match.end():matches[i + 1].start() if i + 1 < len(matches) else len(text)].strip()
    return result


def _rows(capture, kind):
    return [r for group in capture['record_index'].get(kind, {}).values() for r in group]


def extract_context(repo_root, harness_root='.harness', *, situation='development', task_id=None,
                    update_id=None, transition=None, criterion=None, section=None, contract=None, record_id=None):
    """Return {context_id, situation, state, items, diagnostics, ...} without writes.

    No ID means a start/setup view, not an invented active task. A transition ID
    narrows obligations to a declared outgoing edge; it does not authorize it.
    Section selectors return exact reference sections and are never action views.
    """
    result = dict(situation=situation, subject=None, state=None, configuration_id=None,
                  purpose='READ_ONLY_GUIDANCE', items=[], diagnostics=[], required_sections=[])
    tracked = {}
    capture = None

    def add(kind, value, source):
        result['items'].append(dict(kind=kind, source=source, value=deepcopy(value)))

    def issue(code, message, source=None):
        result['diagnostics'].append(dict(code=code, message=message, source=source))

    try:
        if situation not in GUIDES:
            raise ValueError('Unknown situation')
        if task_id and (update_id or situation not in ('development', 'recovery')):
            raise ValueError('task-id applies only to development/recovery')
        if update_id and situation not in ('maintenance', 'recovery'):
            raise ValueError('update-id applies only to maintenance/recovery')
        if situation == 'recovery' and not (task_id or update_id):
            raise ValueError('Recovery requires task-id or update-id')
        if sum(x is not None for x in (transition, criterion, section, contract, record_id)) > 1:
            raise ValueError('Choose one transition, criterion, section, contract or record selector')
        if record_id and not task_id:
            raise ValueError('record requires a task ID')
        if (criterion or contract) and situation != 'setup':
            raise ValueError('criterion applies only to setup')
        repo = Path(repo_root)
        if not repo.is_absolute():
            raise ValueError('repo-root must be absolute')
        repo = repo.resolve(strict=True)
        harness_arg = Path(harness_root)
        if harness_arg.is_absolute():
            harness_arg = harness_arg.relative_to(repo)
        harness = relative_path(harness_arg.as_posix(), repo, directory=True)

        def read(path, *, document=False, schema=None, definition=None):
            safe = relative_path(path, harness)
            raw = read_bytes(safe, harness)
            tracked[path] = hashlib.sha256(raw).hexdigest()
            if not document:
                return raw.decode('utf-8')
            from harness_io.loader import parse_document
            value = parse_document(raw, safe)
            if schema:
                validator = local_validator(relative_path('framework/templates/schemas/' + schema, harness), definition)
                errors = list(validator.iter_errors(value))
                if errors:
                    raise ValueError(f'{path}: {errors[0].message}')
            return value

        guide = GUIDES[situation]
        if not task_id:
            add('procedure', read(guide), guide)
        workflow = profile = state = None
        rules_path = RULES
        task_specs = []
        if task_id:
            _name(task_id)
            capture = capture_task(repo, harness, task_id)
            if capture['roots']['run_path'] != f'artifacts/development/{task_id}':
                raise ValueError('Legacy task: use its matching installed tools or an approved migration')
            for diag in capture['diagnostics']:
                issue(diag['code'], diag['message'], diag.get('references'))
            history = capture['history']
            if not history['snapshot_consistent'] or not history['complete'] or not history['last_post_state']:
                raise ValueError('History/state is incomplete or inconsistent; reconcile it before selecting a next action')
            if any(not r['identity_valid'] for rows in capture['roots']['definitions'].values() for r in rows):
                raise ValueError('Captured definitions have missing or changed identities')
            guide_rows = [row for rows in capture['roots']['definitions'].values() for row in rows
                          if row['declared'].get('reference', {}).get('path') == guide]
            if len(guide_rows) != 1:
                raise ValueError('Task has no captured guide; use its matching tools or an approved migration')
            guide = guide_rows[0]['reference']['path']
            guide_text = read(guide)
            if 'sha256:' + tracked[guide] != guide_rows[0]['declared']['identity']:
                raise ValueError('Captured guide identity mismatch')
            add('procedure', guide_text, guide)
            state = history['last_post_state']
            result.update(subject=task_id, state=state['state'], configuration_id=state['configuration_id'])
            add('recorded_state', {k: state[k] for k in ('state','version','profile_id','configuration_id','stop_reason','stopped_from_state','pending_invocation_refs','repair_counters','invocation_counters','accepted_identities','selected_targets','input_snapshot') if k in state}, f'artifacts/development/{task_id}/state.json')
            profile_key, workflow_key = capture['phase_map']['profile'], capture['phase_map']['workflow']
            profile, workflow = (capture['documents'].get(k) for k in (profile_key, workflow_key))
            if not profile or not workflow:
                raise ValueError('Captured profile/workflow is missing or invalid')
            profile_source, workflow_source = profile_key[8:], workflow_key[8:]
            rule_rows = capture['roots']['definitions'].get('RULES', [])
            if len(rule_rows) != 1:
                raise ValueError('Exactly one captured rules definition is required')
            rules_path = rule_rows[0]['reference']['path']
            rules_text = read(rules_path)
            if 'sha256:' + tracked[rules_path] != rule_rows[0]['declared']['identity']:
                raise ValueError('Captured rules changed during extraction')
            accepted = state['accepted_identities']
            task_specs = [r for r in _rows(capture, 'TaskSpec')
                          if r['schema_valid'] and r['value']['specification_identity'] == accepted.get('specification')]
            if len(task_specs) > 1:
                raise ValueError('Conflicting accepted specification records')
            if accepted.get('specification') and not task_specs:
                raise ValueError('Accepted specification record is missing or invalid')
            for row in task_specs:
                spec = row['value']
                if len({c['id'] for c in spec['criteria']}) != len(spec['criteria']):
                    raise ValueError('Duplicate specification criterion ID')
                if (spec['request_identity'] != accepted['request'] or spec['design_identity'] != accepted['design']
                        or spec['profile_id'] != state['profile_id'] or spec['targets'] != state['selected_targets']):
                    raise ValueError('Specification request/design/profile/targets disagree with recorded state')
            if not accepted.get('specification') and state['state'] not in ('NEW','BASELINED','RESEARCHED','PATTERN_VERIFIED'):
                issue('SPEC_UNAVAILABLE', 'No accepted specification identity is recorded; resolve this before advancement')
            def refs(values):
                return {reference_key(v.get('reference', v)) for v in values}
            pending = refs(state['pending_invocation_refs'])
            verdicts = refs(state['criterion_verdict_refs'])
            latest = {}
            for row in _rows(capture, 'Invocation'):
                latest[row['value']['intent_id']] = row
            results = _rows(capture, 'Result')
            completed = {r['value']['run_id'] for r in results if r['schema_valid']}
            invocations = list(latest.values())
            selected_actions = [r for r in invocations if r is invocations[-1]
                or reference_key(r['reference']) in pending
                or (r['value']['run_id'] not in completed and r['value']['dispatch_status'] != 'CANCELLED')]
            run_ids = {r['value']['run_id'] for r in selected_actions}
            evidence_rows = selected_actions + [r for r in results if r['value']['run_id'] in run_ids]
            evidence_rows += _rows(capture, 'Observation')[-1:] + _rows(capture, 'GateDecision')[-1:]
            evidence_rows += [r for r in _rows(capture, 'CriterionReview') if reference_key(r['reference']) in verdicts]
            if situation == 'recovery':
                for row in evidence_rows:
                    value = row['value']
                    if value['record_type'] == 'Invocation':
                        # Include exact reconciliation handles, deadlines, budgets and input identities.
                        add('saved_action', value, row['reference'])
                    else:
                        add('saved_evidence', dict(type=value['record_type'], reference=row['reference'],
                            schema_valid=row['schema_valid'], findings={k: value[k] for k in
                            ('run_id','status','decision','interpreted_outcome','diagnostics','criteria') if k in value}), row['reference'])
            add('history_access', 'Current/pending actions are selected for recovery. Older evidence remains in the journal; use --record <entry-id> from an evidence reference to read it.', f'artifacts/development/{task_id}/history.jsonl')
            selector = state['profile_id']
        else:
            profile_source = 'framework/config/repo-profile.yaml'
            profile = read(profile_source, document=True, schema='profile.schema.json')
            result['configuration_id'] = profile['configuration_id']
            rules_text = read(RULES)
            maintenance = situation == 'maintenance' or bool(update_id)
            workflow_source = 'framework/workflows/' + ('maintenance/maintenance-workflow.yaml' if maintenance else 'development/workflow.yaml')
            workflow = read(workflow_source, document=True, schema='workflow.schema.json')
            selector = None
            if update_id:
                _name(update_id)
                path = f'artifacts/maintenance/{update_id}/update.yaml'
                update = read(path, document=True, schema='records.schema.json', definition='UpdateRecord')
                if update['update_id'] != update_id:
                    raise ValueError('Update identity mismatch')
                current = update['current']
                events = update['events']
                if not events or events[-1]['post_state'] != current:
                    raise ValueError('Update snapshot does not match saved history')
                previous = None
                seen = set()
                for event in events:
                    if (event['subject_id'] != update_id or event['subject_kind'] != 'UPDATE'
                            or event['request_id'] in seen or event['previous_version'] != (previous['version'] if previous else 0)
                            or event['previous_state'] != (previous['state'] if previous else None)
                            or event['next_version'] != event['previous_version'] + 1
                            or event['post_state']['version'] != event['next_version']
                            or event['post_state']['state'] != event['next_state']):
                        raise ValueError('Update history is inconsistent')
                    previous = event['post_state']; seen.add(event['request_id'])
                result.update(subject=update_id, state=current['state'])
                add('recorded_update', current, path + '#/current')
                selector = workflow['extensions']['request_type_profiles'][update['request_type']]
                # A stale base may be a completed publication or a conflict, never
                # silently rebase it or present current policy as its accepted pin.
                if current['inspected_configuration_id'] != profile['configuration_id']:
                    issue('UPDATE_BASE_DIFFERS', 'Current configuration differs from the inspected update base; reconcile publication or restage before action', path)
                    if transition:
                        raise ValueError('Update base changed; reconcile publication before selecting an action under current definitions')
            elif situation == 'development':
                result['state'] = workflow['initial_state']
                issue('START_VIEW', 'No task exists in this view. Select an evidenced profile and capture configuration before advancing.')
            if situation == 'setup':
                catalogue_path = 'framework/workflows/verification-criteria.yaml'
                catalogue = read(catalogue_path, document=True, schema='criteria.schema.json', definition='Catalogue')
                definitions = catalogue['criteria']
                if criterion:
                    definitions = [c for c in definitions if c['id'] == criterion]
                    if len(definitions) != 1:
                        raise ValueError('Unknown or duplicate setup criterion')
                if criterion:
                    for item in definitions:
                        add('setup_criterion', item, catalogue_path + '#' + item['id'])
                    extension = catalogue.get('extensions', {})
                    mapping = extension.get('context_contracts', {})
                    keys = mapping.get('criteria', {}).get(criterion)
                    if keys is None and definitions[0]['category'] == 'INTEGRATION':
                        keys = mapping.get('integration')
                    if keys is None:
                        raise ValueError('No setup contract mapping for this criterion; configure it before assessment')
                    for key in dict.fromkeys(mapping.get('shared', []) + keys):
                        if key not in extension:
                            raise ValueError('Missing mapped setup contract: ' + key)
                        add('setup_contract', {key: extension[key]}, catalogue_path + '#/extensions/' + key)
                    add('setup_assessments', [a for a in profile.get('assessments', []) if a.get('criterion_id') == criterion], profile_source + '#/assessments')
                else:
                    result['purpose'] = 'OVERVIEW'
                    add('setup_index', [{'id': c['id'], 'required': c['required'], 'category': c['category']} for c in definitions], catalogue_path)
                    add('next_step', 'Select --criterion <id> to read the complete obligation and setup contracts before assessing it.', catalogue_path)
        sections = _sections(rules_text)
        if contract:
            if contract not in catalogue.get('extensions', {}):
                raise ValueError('Unknown setup contract')
            result['items'] = []
            add('setup_contract', {contract: catalogue['extensions'][contract]}, catalogue_path + '#/extensions/' + contract)
            result['purpose'] = 'REFERENCE_ONLY'
        elif record_id:
            matches = [r for kind in capture['record_index'] for r in _rows(capture, kind)
                       if r['reference'].get('entry_id') == record_id]
            if len(matches) != 1:
                raise ValueError('Unknown or ambiguous journal entry ID')
            result['items'] = []
            add('saved_record', matches[0]['value'], matches[0]['reference'])
            result['purpose'] = 'REFERENCE_ONLY'
        elif section:
            if section not in sections:
                raise ValueError('Unknown rules section: ' + section)
            result['items'] = []
            add('reference_section', sections[section], rules_path + '#' + section)
            result['purpose'] = 'REFERENCE_ONLY'
        elif situation != 'setup':
            if task_id and selector not in {p['id'] for p in profile['workflow_profiles']}:
                raise ValueError('Task profile is not in captured configuration')
            if result['state'] is not None and result['state'] not in {s['id'] for s in workflow['states']}:
                raise ValueError('Unknown recorded workflow state')
            edges = [e for e in workflow['transitions'] if e['from'] == result['state']
                     and (selector is None or selector in e['profiles'])]
            routes = [dict(r, route_kind='resolution') for r in workflow.get('resolution_routes', []) if r['from'] == result['state']]
            edges += routes
            if len({e['id'] for e in edges}) != len(edges):
                raise ValueError('Duplicate outgoing transition/route ID')
            add('candidate_transitions', [{'id': e['id'], 'to': e['to'], 'trigger': e.get('trigger', 'RESOLUTION')} for e in edges], workflow_source + '#/transitions')
            selected = [e for e in edges if e['id'] == transition] if transition else edges
            if transition and len(selected) != 1:
                raise ValueError('Transition is not a unique outgoing edge for this state/profile')
            if situation == 'maintenance' and not update_id:
                add('request_types', workflow['extensions']['request_type_profiles'], workflow_source)
                issue('START_VIEW', 'Create an update with an explicit request type; no active update was selected.')
            destinations = {e['to'] for e in selected} if transition else set()
            if transition:
                add('selected_transition', selected[0], workflow_source)
            metadata = workflow.get('extensions', {}).get('reporting', {})
            if workflow.get('extensions', {}).get('user_skips'):
                add('phase_disposition_contract', workflow['extensions']['user_skips'], workflow_source)
                if capture:
                    for row in _rows(capture, 'PhaseDisposition'):
                        add('phase_disposition', row['value'], row['reference'])
            stage_criteria = metadata.get('stage_criteria', [])
            if workflow['workflow_id'] == 'development' and not stage_criteria:
                raise ValueError('Missing stage criteria; use an explicit supported migration')
            if len({c['id'] for c in stage_criteria}) != len(stage_criteria):
                raise ValueError('Duplicate stage criteria')
            criteria = [c for c in stage_criteria if c['due_state'] in destinations]
            # RULE-06 owns the minimum-evidence prose; use exact rows, not a second summary.
            minimums = {}
            for line in sections.get('RULE-06', '').splitlines():
                if line.startswith('|'):
                    parts = [p.strip() for p in line.strip('|').split('|')]
                    if parts[0] == 'ID' or set(parts[0]) <= {'-', ':'}:
                        continue
                    if len(parts) != 4 or parts[0] in minimums:
                        raise ValueError('Ambiguous RULE-06 criterion table')
                    minimums[parts[0]] = parts
            if workflow['workflow_id'] == 'development':
                due_table_ids = {key for key, row in minimums.items() if row[1] in destinations}
                if not due_table_ids.issubset({c['id'] for c in criteria}):
                    raise ValueError('Workflow omits a due RULE-06 criterion')
            for c in criteria:
                if c['id'] in minimums:
                    if (minimums[c['id']][1] != c['due_state'] or
                            set(minimums[c['id']][2].split(' + ')) != set(c['allowed_methods'])):
                        raise ValueError('Criterion/table due-state mismatch')
                    c = dict(c, minimum_evidence=minimums[c['id']][3])
                else:
                    issue('CRITERION_REFERENCE', 'No minimum-evidence table row for ' + c['id'], rules_path)
                add('stage_criterion', c, workflow_source + '#/extensions/reporting/stage_criteria')
            for spec in task_specs:
                for c in spec['value']['criteria']:
                    if c['due_state'] in destinations or 'SPEC_VERIFIED' in destinations:
                        add('task_criterion', c, spec['reference'])
            for key in ('permissions', 'completion_policy', 'state_writer'):
                add('policy', {key: profile[key]}, profile_source + '#/' + key)
            stages = destinations | {result['state']} if transition or situation == 'recovery' else set()
            caps = workflow.get('extensions', {}).get('stage_capabilities', {})
            capability_ids = {cap for stage, cap in caps.items() if stage in stages}
            for stage, cap in (('PREFLIGHT', 'preflight'), ('BUILDING', 'build'), ('TESTING', 'test')):
                if stage in stages: capability_ids.add(cap)
            for cap in sorted(capability_ids):
                if cap not in profile['capabilities']:
                    raise ValueError('Missing capability: ' + cap)
                add('binding', {cap: profile['capabilities'][cap]}, profile_source + '#/capabilities/' + cap)
            rule_ids = sorted({rid for e in selected for rid in e['rule_ids']})
            # Shared admission and recording constraints apply to every action.
            headers = ['Finite triggers and resolution routes', 'Destination-aware safe-stop admission', 'Records and writer protocol']
            if situation == 'recovery':
                recovery_rules = {'RULE-10', 'RULE-11', 'RULE-12'} if task_id else {'RULE-11','RULE-14','RULE-15','RULE-16'}
                rule_ids = sorted((set(rule_ids) if transition else set()) | recovery_rules)
            result['required_sections'] = headers + rule_ids
            for key in result['required_sections']:
                if key not in sections:
                    raise ValueError('Missing required rules section: ' + key)
                body = sections[key]
                if key == 'RULE-06':
                    body = '\n'.join(line for line in body.splitlines() if not line.startswith('|'))
                if transition or situation == 'recovery':
                    add('required_rule', body, rules_path + '#' + key)
            if not transition and situation != 'recovery':
                result['purpose'] = 'OVERVIEW'
                add('required_reading', result['required_sections'], rules_path)
                add('next_step', 'Choose --transition <outgoing ID> and read all resulting pages before action. Overview is navigation only.', workflow_source)

        if capture and check_unchanged(capture):
            raise ValueError('Task inputs changed during extraction; read again')
        for path, digest in tracked.items():
            if hashlib.sha256(read_bytes(relative_path(path, harness), harness)).hexdigest() != digest:
                raise ValueError('Inputs changed during extraction; read again')
    except (DocumentError, ValueError, OSError, RuntimeError, KeyError, TypeError, UnicodeError) as exc:
        result['items'] = []
        result['required_sections'] = []
        issue(getattr(exc, 'code', 'CONTEXT_UNAVAILABLE'), str(exc), getattr(exc, 'path', None))
        result['purpose'] = 'UNAVAILABLE'
    if result['purpose'] not in ('UNAVAILABLE', 'REFERENCE_ONLY') and result['diagnostics']:
        result['purpose'] = 'INPUT_ISSUES'
    result['inputs'] = tracked
    if capture:
        result['captured_inputs'] = capture['source_manifest']
    result['context_id'] = _identity(result)
    return result


def context_page(context, page=1, *, expected_context_id=None, word_limit=250):
    """Bound the display, never silently omit content. No stored cache or files.

    Each page repeats the source and labels continuation. A context ID supplied
    on follow-up prevents combining pages from different input snapshots.
    """
    if expected_context_id and expected_context_id != context['context_id']:
        raise ValueError('Context changed; restart from page 1')
    if type(page) is not int or page < 1 or word_limit < 50:
        raise ValueError('Invalid page or word limit')
    blocks = context['items'][:1] + [dict(kind='diagnostic', source=d.get('source'), value=d) for d in context['diagnostics']] + context['items'][1:]
    bounded_blocks, source_ids = [], set()
    for block in blocks:
        source_text = block['source'] if isinstance(block['source'], str) else json.dumps(block['source'], ensure_ascii=False)
        if len(source_text) > 512:
            source_id = _identity(block['source'])
            if source_id not in source_ids:
                bounded_blocks.append(dict(kind='source_reference ' + source_id, source=None, value=block['source']))
                source_ids.add(source_id)
            block = dict(block, source=source_id)
        bounded_blocks.append(block)
    pieces_out = []
    for block in bounded_blocks:
        value = block['value']
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)
        # Preserve characters, including long single-token logs/fields. Pages are
        # display chunks; consumers needing structured values call extract_context.
        pieces = re.findall(r'\S+\s*', text)
        chunks, chunk, size = [], '', 0
        for piece in pieces:
            while len(piece) > 1600:
                if chunk: chunks.append(chunk); chunk=''; size=0
                chunks.append(piece[:1600]); piece=piece[1600:]
            if size >= word_limit or len(chunk) + len(piece) > 2400:
                chunks.append(chunk); chunk=''; size=0
            chunk += piece; size += 1
        if chunk: chunks.append(chunk)
        for i, chunk in enumerate(chunks):
            pieces_out.append(dict(kind=block['kind'], source=block['source'], part=i+1, parts=len(chunks), text=chunk))
    pages, current, words, chars = [], [], 0, 0
    for block in pieces_out:
        cost = len(block['text'].split()) + 10
        length = len(block['text']) + len(str(block['source']))
        if current and (words + cost > word_limit or chars + length > 3000):
            pages.append(current); current=[]; words=0; chars=0
        current.append(block); words += cost; chars += length
    if current: pages.append(current)
    pages = pages or [[dict(kind='notice', source=None, part=1, parts=1, text='No selected content.')]]
    if page > len(pages):
        raise ValueError('Page exceeds available content')
    return dict(context_id=context['context_id'], situation=context['situation'], subject=context['subject'],
                state=context['state'], configuration_id=context['configuration_id'], purpose=context['purpose'],
                page=page, pages=len(pages), next_page=page+1 if page < len(pages) else None,
                content=pages[page-1], notice='Read all pages for this selection before action. This is not gate approval.')


def render_text(page):
    lines = [f"{page['situation']} | {page['subject'] or 'start'} | {page['state'] or 'unselected'} | {page['purpose']}",
             f"Context: {page['context_id']}", f"Page {page['page']}/{page['pages']}"]
    for row in page['content']:
        source = row['source'] if isinstance(row['source'], str) else json.dumps(row['source'], ensure_ascii=False)
        lines += [f"\n{row['kind']} ({row['part']}/{row['parts']}) — {source}", row['text']]
    lines += ['', page['notice'],
              (f"Continue: --page {page['next_page']} --context-id {page['context_id']}" if page['next_page'] else 'End of selection.')]
    return '\n'.join(lines) + '\n'
