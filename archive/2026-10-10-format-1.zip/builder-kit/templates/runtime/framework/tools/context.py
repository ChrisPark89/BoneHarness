#!/usr/bin/env python3
"""Select concise harness context without executing tools or changing records."""
import argparse
import json
import sys
sys.dont_write_bytecode = True


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo-root', required=True)
    parser.add_argument('--harness-root', default='.harness')
    parser.add_argument('--situation', choices=['development', 'recovery', 'setup', 'maintenance'], default='development')
    ids = parser.add_mutually_exclusive_group()
    ids.add_argument('--task-id')
    ids.add_argument('--update-id')
    parser.add_argument('--transition', help='Declared outgoing edge ID; selection grants no approval')
    parser.add_argument('--criterion', help='Setup criterion ID')
    parser.add_argument('--section', help='Exact heading in verification-rules.md; reference-only view')
    parser.add_argument('--contract', help='Exact setup contract name; reference-only view')
    parser.add_argument('--record', help='Exact task journal entry ID; reference-only view')
    parser.add_argument('--page', type=int, default=1)
    parser.add_argument('--context-id', help='Require the same context on continuation pages')
    parser.add_argument('--format', choices=['text', 'json'], default='text')
    args = parser.parse_args(argv)
    try:
        from context_reader import extract_context, context_page, render_text
        context = extract_context(args.repo_root, args.harness_root, situation=args.situation,
                                  task_id=args.task_id, update_id=args.update_id,
                                  transition=args.transition, criterion=args.criterion, section=args.section,
                                  contract=args.contract, record_id=args.record)
        page = context_page(context, args.page, expected_context_id=args.context_id)
        print(json.dumps(page, ensure_ascii=False, indent=2) if args.format == 'json' else render_text(page))
        return 2 if context['purpose'] == 'UNAVAILABLE' else 1 if context['diagnostics'] else 0
    except (ImportError, ValueError, OSError) as exc:
        error = {'code': 'CONTEXT_UNAVAILABLE', 'message': str(exc),
                 'action': 'Provide the declared parser dependencies or an equivalent local parser; do not dump raw files.'}
        print(json.dumps(error, ensure_ascii=False) if args.format == 'json' else error['code'] + ': ' + error['message'])
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
