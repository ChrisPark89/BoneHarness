# Development journal storage, version 1.0.0

Start with [development](HARNESS.md) or [recovery](../recovery.md). Read only the relevant section below. The full journal is parsed by tools; do not paste it into the LLM.

Kit 1.1.0/layout 2 stores each task's machine records in `artifacts/development/<task-id>/history.jsonl`, derived `state.json`, and derived `report.json`. Human files are `docs/development/<task-id>/spec.md` and `report.md`. These five files are the default budget; add only evidence actually needed (execution logs, native results, consumed artifacts). Do not create placeholder request/spec/design text or per-request, decision, result, or review files. Typed records remain schema version 1.0.0. Layout and journal versions are independent of typed payload versions. Old readers do not understand the new layout; use this installed reader or explicitly retain the legacy installation until migration is approved.

## Envelope and identities

Each UTF-8 JSONL line is one object with exactly:

- `journal_version`: `1.0.0`.
- `task_id`: the owning task, never another task/update.
- `sequence`: contiguous integer starting at 1.
- `entry_id`: unique stable ID (letters/digits first, then letters/digits/underscore/dot/colon/hyphen; at most 200 characters).
- `previous_hash`: preceding `entry_hash`, or null on the first line.
- `payload_identity`: SHA-256 of canonical payload JSON.
- `payload`: unchanged typed ConfigSnapshot, TaskSpec, SourceInventory, TransitionRequest, GateDecision, Invocation, Result, CriterionReview, Observation, or Event.
- `entry_hash`: SHA-256 of canonical envelope excluding `entry_hash`.

Canonical JSON sorts keys, uses compact comma/colon separators, preserves Unicode as UTF-8, and refuses non-finite numbers. Hash strings start `sha256:`. Each line ends LF. Line bytes need not use canonical whitespace; hashes identify canonical payload/envelope values. JSON duplicate keys, corrupt hash chains, duplicate IDs, duplicate/conflicting logical request/decision/event/result records, cross-task records and incomplete final lines are rejected. An exact `append` retry using the same entry ID and payload returns its recorded envelope without appending. Reusing that ID with different payload is denied.

A LOCAL Reference can include `entry_id` only on a `history.jsonl` path. Its Evidence identity hashes the selected canonical payload, not the journal file bytes. Entry references must select an earlier retained payload in the current task's journal; missing, self, forward and cross-task selectors are refused. Whole-file references hash actual bytes. Changing later entries cannot change an earlier referenced payload; changing earlier entries breaks the hash chain. Entry IDs are explicit selectors, not Markdown line numbers or workflow authority.

## Configuration and ordered records

The first and only ConfigSnapshot payload pins the task configuration. `captured_definitions[].captured_path` is HARNESS-relative `artifacts/configurations/<bundle-hash>/<relative-path>`. Preserve schema sibling paths so their local references resolve. Bundle hash is SHA-256 of canonical JSON mapping every relative path to its declared per-file identity; each file is independently byte-hash checked. The same immutable bundle can serve many tasks. In-task configuration adoption is not supported by this reference reader: keep the task pinned and stop for an approved migration or create a linked new task. Do not append another ConfigSnapshot or silently replace the first. A changed configuration can create a new bundle, potentially duplicating unchanged files; this is bundle sharing, not global per-file deduplication. No extra bundle manifest file is required.

Append a [SourceInventory](../source-evidence.md) before any state or operation using its revision. Its scope must match the accepted TaskSpec. This adds a journal record, not another default task file.

Record intent before dispatch. Append immutable Invocation revisions for dispatch handles, reconciliation and completion using the same `intent_id`, fresh entry IDs and exact selected payload references. The reporter retains and validates the existing invocation revision invariants; a changed stable input or ambiguous selected revision cannot satisfy a gate. Denied requests and GateDecisions remain history without an Event. Append each Event only after the designated state writer has validated its gate. Events retain the existing request, decision, evidence, previous/next version/state, counters, actor and post-state fields. Requests and reviews alone never advance state. A changed spec is a new retained record keyed by specification identity; exact accepted identities and committed references select the version. Conflicting records for the same specification identity remain unsupported. Existing invalidation and repair rules still apply; journal storage grants no skips, source-inventory authority, or completion support.

`state.json` is exactly the latest Event.post_state, even when later entries are requests, denied decisions, observations or reviews. The reporter compares this projection against validated committed history and remains read-only. It never repairs a snapshot or dispatches tools. The storage helper verifies envelope integrity and record shape; its read/state commands validate the complete typed journal, and append validates both the prior typed prefix and each new payload; it is not a configured workflow state controller and does not approve gates or certify evidence.

## Storage commands and recovery

Use the installed Python prerequisites. Run `framework/tools/journal.py read --history <absolute-history-path> --task-id <id>` to inspect; `append` additionally accepts `--entry-id` and `--payload <actual-temporary-json>`; `state` publishes the derived snapshot. Helpers are also importable from `harness_io.journal`. Append serializes cooperating writers with an exclusive task-local `.journal.lock`, flushes and fsyncs each line, and removes its owned lock on normal completion. State/report publication stages under `artifacts/tmp` and cleans only owned temporary files. Lock and temporary files are transient, outside the five durable-file budget. Directory-fsync durability depends on the host filesystem; do not claim exactly-once external execution.

## Interrupted storage

After interruption, stop on a stale lock, incomplete final line, corrupt chain or snapshot mismatch. Preserve original bytes as recovery evidence and reconcile external operations by request ID. Never silently truncate, skip a corrupt line, read past a torn suffix, reset IDs, or blindly resubmit. A designated writer may remove a stale lock only after proving no writer remains and recording the reconciliation. Recovery of a torn append requires comparing the saved complete prefix and exact intended final payload against independent dispatch/decision evidence; restore a separately reviewed complete journal or reappend the proven missing bytes. Retain the original damaged bytes and explicit recovery evidence. The helper deliberately has no automatic truncation/recovery command.

## Legacy compatibility

The internal evidence-capture API explicitly detects legacy `development/runs/<id>`, retains its typed validation, and refuses ambiguous installations containing both layouts for the same task. This is read compatibility only: the layout 2 reporting CLI refuses legacy publication. Preserve the original installation's reporter/checker for its reports until an approved migration installs matching tools, layout and schemas. Legacy records are never rewritten by the new reader. Migration must preserve original journal/legacy bytes, pin matching schemas, rewrite references and identities explicitly, and verify equivalence before switching. No generated expanded legacy tree is used.

## Report publication

Report publication writes machine JSON and human Markdown in different directories. Their shared generation ID and exact JSON hash detect stale/mixed pairs; replacement failures attempt owned rollback, preserving concurrent edits. These two writes are not a filesystem-wide atomic transaction. Source bytes are captured and rechecked before publication. A source change triggers one recapture; persistent changes produce explicit unverified diagnostics. Reports contain all phases, concise recorded results, linked evidence, earlier failure/repair counts, and full machine diagnostics. Tool result claims shown in a phase row do not establish phase success. Source enumeration is supported for journal inventories matching accepted scope; opaque historical snapshots remain unchecked. Typed user skips require the declared route and attributed instruction review.

Append `PhaseDisposition` before its skip request/event; store scope reconciliation as a new entry referencing its predecessor. Follow the [skip protocol](../verification-rules.md#finite-triggers-and-resolution-routes).
