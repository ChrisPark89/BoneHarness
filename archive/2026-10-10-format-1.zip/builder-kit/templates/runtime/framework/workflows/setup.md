# Inspect harness setup

1. **Locate.** Read [setup status](../../docs/setup.md). It describes harness readiness, not a development task's progress. Respect repository instructions and use the canonical current profile.
2. **Select.** Run the [context command](context.md) with `--situation setup`. Choose a listed `--criterion <id>` and read all resulting pages before assessing it.
3. **Check.** Use the optional installation checker where available. Its uncovered obligations still need a permitted evidence-backed review. File presence and schema validity do not establish tool quality or completed work. Parsing large structured inputs remains required even if this checker is unavailable.
4. **Record.** Use the installation procedure for a new harness; existing harness changes use [maintenance](maintenance/harness-maintenance.md). Preserve the actual method, actor, inspected configuration and evidence. Keep unknown facts pending.
5. **Report.** Derive setup status from recorded assessments. Distinguish structural completeness, capability readiness and unavailable helpers. A missing tool affects its dependent stages; it does not erase earlier valid work.

The builder project's regression catalogue is not needed here. Repeat affected setup checks after configuration updates.
