# Recover interrupted work

1. **Locate.** Respect repository instructions. Run the [context command](context.md) with `--situation recovery` and either `--task-id <id>` or `--update-id <id>`. Read every page. Invalid history or conflicting state requires reconciliation before a next action is selected.
2. **Inspect.** Follow saved action/evidence references. Check relevant input identities, captured configuration, current permissions, deadlines and budgets. A recorded stage alone does not identify the unfinished step.
3. **Resolve the operation.** Use the table below. Preserve original damaged bytes and uncertainty. Never silently truncate history or remove a lock while its owner may still run.
4. **Continue.** Independently verify due criteria, record the supported result and select a permitted transition. Changed inputs use invalidation/review. Recovery grants no new success or approval.

| Saved evidence | Next step |
|---|---|
| Intent exists; dispatch uncertain | Reconcile by request ID or other evidence before retrying. |
| Operation is running | Reconnect to the same operation within its original budgets. |
| Output is saved | Verify that output against the matching inputs and criteria. |
| Transition was committed | Continue from that recorded destination. |
| Maintenance publication is partial | Reconcile owned writes and receipts; preserve newer edits. |

Missing completion evidence does not prove an action never ran. Use existing records; no per-step checkpoints are needed.
