# Record which files the evidence covers

1. **Choose scope.** Inspect repository instructions and dependencies. Record literal repository-relative `roots` and `exclude` lists in the accepted TaskSpec's `extensions.source_scope`. Roots may be files or directories; directories include all descendant files, including untracked files. Exclusions remove named files/subtrees, never glob patterns. Include relevant source, tests and build configuration. Exclude `.harness/` and generated outputs if selecting the repository root (`.`). Scope completeness needs review.
2. **Capture before use.** Run the installed helper with the same scope. For example:

```text
python .harness/framework/tools/source.py --repo-root <absolute-repo> --task-id <id> --root src --root test --root scripts --root package.json
```

3. **Save and identify.** Parse stdout as JSON; do not paste the file list into the LLM. Append the SourceInventory through the existing journal writer after ConfigSnapshot and before any Event, invocation or review using it. Reuse an existing identical inventory. Its `revision` identifies canonical `{scope, files}` contents. Use it as `input_snapshot` and the corresponding invocation/result/review source identity. The helper changes no records or state.
4. **Handle changes.** After source changes, capture again and follow existing invalidation/transition rules. Repeat affected work; never relabel earlier results with the new revision. Verify source stability around execution.
5. **Report.** The reporter compares the saved inventory with current files and rechecks before publication. Missing inventories or unaccepted scopes remain unverified. Hashes establish content identity, not tool execution or correctness.

Existing programs may be scoped as files when the specification permits. Remote sources remain unsupported. Older harnesses need matching tools/schemas through maintenance; preserve historical records.
