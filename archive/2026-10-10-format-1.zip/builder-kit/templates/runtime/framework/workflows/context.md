# Read selected context

1. Run from any directory, using absolute repository and script paths when needed:

```text
python3 .harness/framework/tools/context.py --repo-root <absolute-repo> --task-id <id>
```

2. The overview identifies recorded state and candidate transitions. Choose `--transition <id>` to retrieve that action's obligations. Selection does not approve it.
3. Follow `--page` and `--context-id` printed in the output, retaining the other arguments. Read every page before acting. A changed context requires restarting at page 1. No required data is silently truncated.
4. Follow evidence references and independently verify the criteria. Exit 0 means selection completed; 1 means diagnostics need attention; 2 means unavailable. None means a stage passed.

| Need | Arguments |
|---|---|
| Start development | Omit task ID; capture a task before advancing. |
| Resume a task | `--situation recovery --task-id <id>` |
| Inspect setup | `--situation setup`, then `--criterion <id>` |
| Start/update maintenance | `--situation maintenance`, optionally `--update-id <id>` |
| Resume maintenance | `--situation recovery --update-id <id>` |
| Read one exact rules section | `--section RULE-02` with the same task/update context |
| Read a referenced journal entry | `--record <entry-id> --task-id <id>` |
| Read an additional setup contract | `--situation setup --contract <name>` |
| Machine-readable page | `--format json` |

Python 3.11+ and the provisioned [dependencies](../tools/requirements.lock) are required. No automatic installation occurs. An equivalent local parser may select the same authoritative records and references. If parsing is unavailable, record the limitation and withhold dependent conclusions; never dump whole structured files into the LLM.

The importable `context_reader` functions separate extraction, pagination and rendering. They perform no writes or tool execution.
