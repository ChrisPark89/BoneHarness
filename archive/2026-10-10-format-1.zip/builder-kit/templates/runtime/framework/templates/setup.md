# Harness setup status

Described configuration: `cfg-1`, revision `1`. Discovery template; regenerate from canonical [repo-profile.yaml](../config/repo-profile.yaml) assessments after publication. It contains no assessed execution readiness. Repository identity/root are example values awaiting verified discovery; all six capability bindings, target selection, permissions and completion policy remain pending. The active profile is `default`, readiness `NOT_ASSESSED`; source-only/docs are adaptation examples awaiting explicit installation and policy acceptance.

Structure status: `INCOMPLETE` (required structural assessments are pending). Integration status: `NOT_ASSESSED`. No native platform or real task execution is claimed by this template. Required execution gates stop until configured. Optional checker coverage is distinct from complete semantic review.

State writer: `LLM_PROTOCOL`/`coordinator`; enforcement is procedural, with no tool binding. Build/test automatic repair: disabled, zero attempts. See [rules](../workflows/verification-rules.md) for durable records and stop/resume obligations.

This report is a view, never authority. Compare its configuration ID/revision to the canonical profile before use. A mismatch or changed assessment input makes it stale: regenerate or label stale; do not overwrite canonical facts from this Markdown view.
