# Install a repository harness

Use this ordered guide with the target repository and this builder package. Detailed obligations are in the [installation reference](installer/installation-reference.md); read the named section when its step is reached.

1. **Discover.** Read repository instructions and inspect sources, tools and existing harness records. Classify fresh, interrupted or existing installation. Record sourced facts and unresolved decisions; follow [section 1](installer/installation-reference.md#1-discover-and-classify-before-writing). Existing live installations use installed maintenance.
2. **Stage.** Follow [section 2](installer/installation-reference.md#2-stage-a-recoverable-candidate). The optional `python3 installer/install.py --repo-root <absolute-repo>` scaffolds only a fresh `.harness/`. It does not assess or activate it. Keep unknown settings pending and record each actual write.
3. **Assess.** Use the installed context command's setup view and optional checker. Review every required criterion, with the actual actor and evidence. Follow [section 4](installer/installation-reference.md#4-assess-the-staged-prospective-configuration) and the [checklist](installer/installation-checklist.md). Parse large records before selecting relevant content.
4. **Publish and reread.** Follow reference sections 3, 5 and 6 for entry-point scope, activation eligibility, final byte checks and provenance. Record failures and recovery data. Never infer completion from scaffolding or a checker's exit code.
5. **Hand off.** Follow sections 7 and 8 for setup/test separation and reporter availability. Link `.harness/README.md`, setup status and unresolved requirements. Runtime work uses installed guides only.

Installation must work on Windows, macOS and Linux with explicit prerequisites. Missing dependencies remain visible; no implicit downloads or repository-root instruction edits.

User-skip integration is within existing workflow, record schemas, journal, context and reporting files; it adds no runtime file. Install these definitions together through maintenance/new configuration capture. Preserve prior captured schemas/workflows and task pins. Check USER_SKIP routes and mandatory phases; instruction origin/meaning still requires attributed LLM review of the original user message.
