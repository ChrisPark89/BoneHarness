# Agent Harness Builder Kit


Version **1.1.0** (layout 2). Give the LLM this package and access to the target repository, then use the [bootstrap prompt](installer/bootstrap-prompt.md). That is the single installation entry point.

The installer inspects repository instructions, commands, targets and permissions; stages adapted files; verifies the required criteria; and hands off explicitly loaded `.harness` entry points; repository instruction files stay untouched. Unknown facts stay pending. Installation verification is required. The optional [read-only Python checker](checker/README.md) is recommended when its prerequisites are already available; permitted review can satisfy its applicable criteria without Python.

After installation, start at `.harness/README.md` to choose a short guide. The [context command](templates/runtime/framework/workflows/context.md) parses saved records and returns selected obligations in bounded pages. It requires Python 3.11+ and the existing dependencies, or an equivalent local parser; it does not change state.

Use the generated `<harness-root>/framework/workflows/development/HARNESS.md` for tasks and `<harness-root>/framework/workflows/maintenance/harness-maintenance.md` for harness updates. The installed definitions work without this builder. Human pages live in `docs/`; definitions in `framework/`; records and evidence in `artifacts/`.

Skills may return their normal output. The LLM interprets the evidence and saves a harness result using the declared procedure; a special native output format is not required.

Structure completeness, profile integration readiness and real build/test success have separate assessments. This kit supplies a procedural protocol. It provides no runtime state engine and gives no guarantee of tool accuracy or mechanical enforcement.

## Package guide

| Path | Purpose |
|---|---|
| [INSTALLER_SPEC.md](INSTALLER_SPEC.md), [reference](installer/installation-reference.md), [checklist](installer/installation-checklist.md) | Short installation procedure, detail by section and verification checklist. |
| [Runtime templates](templates/runtime/) | Development, maintenance, shared definitions and installation provenance to adapt into the target. |
| [Checker](checker/README.md) | Optional installation verification; explicit dependencies and bounded coverage. |
| [Examples](examples/README.md) | Disposable synthetic examples for authoring checks; FIXTURE results cannot prove production execution. |

Kit **1.1.0**, layout **2**, and schema/interface/catalogue/journal **1.0.0** are separately versioned. Configuration revisions identify repository adaptations independently. This package contains the installation instructions, runtime templates, optional installation checker and examples. The builder project's own tests, full conformance catalogue and retained verification evidence stay outside this package. Installation and maintenance use the installed setup criteria/checker; development tasks use the repository's tools and specification criteria. Native Windows/Linux validation remains PENDING.

## Read a task report

At each task handoff, open `<harness-root>/docs/development/<task-id>/report.md`. Its phase table links to logs, reviews and artefacts; history links retain earlier failures. `artifacts/development/<task-id>/report.json` holds full diagnostics, checked coverage and source identities. Recorded COMPLETE is separate from evidence support.

The installed reference reporter uses Python 3.11+ and provisioned dependencies in `framework/tools/requirements.lock`; a conforming repository replacement is allowed. Installation records availability separately from harness setup status. If it cannot generate a report, the LLM reports REPORT_UNAVAILABLE; earlier outputs may be stale. Run the command documented in installed HARNESS.md to regenerate after evidence changes.

The canonical inventory includes required journal and reporting definitions. The reporter checks a saved SourceInventory against accepted local scope. Scoped NOT_APPLICABLE claims remain unresolved. User-approved skips require typed PhaseDisposition records and declared routes; user origin and meaning remain attributed reviewer judgments. Completion still requires accepted task criteria and both specification phases. Existing harnesses receive reporting through maintenance with a new configuration revision, preserving old task pins and records.

Fresh scaffold: `python3 installer/install.py --repo-root <absolute-repository>`. It creates only `.harness/`, leaves discovery and activation pending, and refuses existing installations. Existing installations use the recorded maintenance migration.
