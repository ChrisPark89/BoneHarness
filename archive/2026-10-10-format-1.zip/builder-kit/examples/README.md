# Disposable synthetic examples

Use Python 3.11 or newer with the explicitly provisioned dependencies in [the checker lock](../checker/requirements.lock). Nothing downloads dependencies or runs production tools.

```text
python builder-kit/examples/make_examples.py --destination "/absolute/empty/examples café"
```

The destination must be absent or empty. Existing content and symlink destinations are refused before writes. Four repositories are created:

| Repository | Installed root | Selected profile | Deliberate distinction |
| --- | --- | --- | --- |
| compiled | `.harness` | default | Build configured; test remains typed pending discovery |
| source-only | `.harness` | source-only | Source-based test; no consumed build artifact |
| docs | `.harness` | docs | Documentation scope and replacement checks required |
| multi-target | `.harness` | default | Both app and library required; separate test-source snapshot |

Every repository contains the complete runtime layout, target-local adapter procedure and schemas, source snapshot, exact installation inventory, candidate entry point and four fixture envelopes. Generated profiles start **NOT_ASSESSED**, structure **INCOMPLETE**, and entry points **STAGED**. Generation does not pretend to conduct semantic review or activate instructions. Configured fixture bindings become compatible/ready only after actual scoped review; the retained walkthrough demonstrates that publication.

`fixture-request.json` is JSON input for the fixture adapter. Pass its contents as the `--request` argument (an argument array avoids shell escaping). `--outcome` is exactly `PASS`, `FAIL`, `BLOCKED` or `UNKNOWN`. Valid requests exit 0 and print one JSON envelope; invalid input exits 2 with diagnostics on stderr and no envelope. Result status does not change the CLI exit code. The adapter always sets `provenance: FIXTURE`, emits stdout only, and rejects command fields. It requires caller-supplied artifact/test-source identities when consumption or lineage requires them. It never fabricates a missing artifact and never executes a production command.

For example, from a Python session:

```python
import pathlib, subprocess, sys
request = pathlib.Path("/absolute/empty/examples café/multi-target/fixture-request.json").read_text(encoding="utf-8")
subprocess.run([sys.executable, "builder-kit/examples/synthetic_adapter.py",
                "--request", request, "--outcome", "PASS"], check=True)
```

Validate the generated installations from any other working directory with the [optional checker](../checker/README.md). Keep stdout outside the inspected repository. An exit of zero does not complete the uncovered semantic reviews.

The builder project's separately retained walkthrough demonstrates activation, development refusal, binding replacement, explicit adoption and migration in disposable repositories. These examples provide synthetic inputs for inspecting the installation structure. Private repository facts, actual human approval and real tool execution must be discovered separately.

The copied runtime includes the task reporter and its expanded configuration template. Reporter discovery remains NOT_CHECKED/validation NOT_RUN until actually assessed; example generation does not create task reports. For an instantiated task, use its installed framework/workflows/development/HARNESS.md command and inspect docs/development/<task-id>/report.md plus artifacts/development/<task-id>/report.json. FIXTURE evidence cannot support a real task, and these example source snapshots are not a supported source enumeration protocol. Mandatory source_content_inventory therefore remains unchecked. Preserve those limits when exploring incomplete tasks or earlier failures.
