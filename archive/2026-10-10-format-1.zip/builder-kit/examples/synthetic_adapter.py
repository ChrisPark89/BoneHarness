"""Fixture-only adapter. No subprocesses, command evaluation, downloads or file writes."""
import argparse
from copy import deepcopy
import json
import math
import re

IDENTITY = re.compile(r'sha256:[0-9a-f]{64}\Z')
REQUIRED = {'capability', 'adapter', 'run_id', 'task_id', 'revision', 'configuration_id',
            'adapter_definition_id', 'targets', 'evidence', 'requirements'}
OPTIONAL = {'artifact', 'test_source'}


def unique_object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError('duplicate JSON key: '+key)
        obj[key] = value
    return obj


def parse_request(text):
    def reject(value):
        raise ValueError('non-finite JSON value: '+value)
    def finite(value):
        number=float(value)
        if not math.isfinite(number):raise ValueError('non-finite JSON number')
        return number
    return json.loads(text, object_pairs_hook=unique_object, parse_constant=reject, parse_float=finite)


def local_reference(ref):
    if not isinstance(ref,dict) or set(ref)!={'kind','scope','path'} or ref['kind']!='LOCAL' or ref['scope'] not in ('REPOSITORY','HARNESS'):
        raise ValueError('fixture reference must declare local scope and path')
    path=ref['path']
    if not isinstance(path,str) or not path or path.startswith('/') or '\\' in path or ':' in path or any(ord(c)<32 for c in path) or any(part in ('','..','.') for part in path.split('/')):
        raise ValueError('fixture reference path must be safe and relative')


def emit(request, outcome):
    """Normalize a supplied fixture, retaining actual caller input identities."""
    if not isinstance(request, dict) or not REQUIRED <= request.keys() or request.keys() - REQUIRED - OPTIONAL:
        raise ValueError('request must contain only the documented fixture fields')
    if outcome not in ('PASS', 'FAIL', 'BLOCKED', 'UNKNOWN'):
        raise ValueError('unsupported outcome')
    for key in ('revision', 'adapter_definition_id'):
        if not isinstance(request[key], str) or not IDENTITY.fullmatch(request[key]):
            raise ValueError('invalid '+key)
    for key in ('capability', 'run_id', 'task_id', 'configuration_id'):
        if not isinstance(request[key], str) or not request[key]:
            raise ValueError('missing '+key)
    adapter=request['adapter']
    if not isinstance(adapter,dict) or set(adapter) != {'identity','version','content_identity'} or not all(isinstance(v,str) and v for v in adapter.values()) or not IDENTITY.fullmatch(adapter['content_identity']):
        raise ValueError('invalid adapter identity')
    if not re.fullmatch(r'cfg-[1-9][0-9]*',request['configuration_id']):
        raise ValueError('invalid configuration_id')
    targets=request['targets']
    if not isinstance(targets,list) or not targets or any(not isinstance(t,dict) or set(t)!={'target_id','environment'} or not all(isinstance(v,str) and v for v in t.values()) for t in targets):
        raise ValueError('targets require explicit target_id/environment')
    if len({t['target_id'] for t in targets}) != len(targets):
        raise ValueError('duplicate target')
    evidence=request['evidence']
    if not isinstance(evidence,dict) or set(evidence)!={'reference','summary'} or not isinstance(evidence['summary'],str) or not evidence['summary']:
        raise ValueError('invalid evidence')
    local_reference(evidence['reference'])
    requirements=request['requirements']
    if not isinstance(requirements,dict) or set(requirements) != {'artifact_consumed_downstream','test_source_required','artifact_lineage_required'} or any(type(v) is not bool for v in requirements.values()):
        raise ValueError('requirements must be three explicit booleans')
    need_artifact = (outcome=='PASS' and request['capability']=='build' and requirements['artifact_consumed_downstream']) or requirements['artifact_lineage_required']
    need_test = requirements['test_source_required'] or requirements['artifact_lineage_required']
    if need_artifact and not request.get('artifact'):
        raise ValueError('consumed artifact is required; never invent one')
    if need_test and not request.get('test_source'):
        raise ValueError('test source is required; never invent one')
    for key, fields in [('artifact', {'identity','reference'}), ('test_source', {'identity','reference'})]:
        if not request.get(key):
            continue
        value=request[key]
        permitted=fields | ({'artifact_identity'} if key=='test_source' else set())
        if not isinstance(value,dict) or not fields<=value.keys() or value.keys()-permitted:
            raise ValueError('invalid '+key)
        local_reference(value['reference'])
        if 'artifact_identity' in value and (not isinstance(value['artifact_identity'],str) or not IDENTITY.fullmatch(value['artifact_identity'])):
            raise ValueError('invalid test-source artifact identity')
        for field in ('identity',):
            if not isinstance(value[field],str) or not IDENTITY.fullmatch(value[field]):
                raise ValueError('invalid '+key+' '+field)
    if requirements['artifact_lineage_required'] and request['test_source'].get('artifact_identity') != request['artifact']['identity']:
        raise ValueError('consumed artifact lineage mismatch')
    result={'schema_version':'1.0.0','record_type':'Result','interface_version':'1.0.0',
            **deepcopy({k:request[k] for k in REQUIRED-{'requirements'}}),
            'status':outcome,'provenance':'FIXTURE','extensions':deepcopy(requirements)}
    result['evidence']['summary']='SYNTHETIC FIXTURE: '+result['evidence']['summary']
    if need_artifact:
        result['artifact']=deepcopy(request['artifact'])
    if need_test:
        result['test_source']=deepcopy(request['test_source'])
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request',required=True,help='JSON text, not a path or command')
    parser.add_argument('--outcome',required=True,choices=['PASS','FAIL','BLOCKED','UNKNOWN'])
    args=parser.parse_args()
    try:
        result=emit(parse_request(args.request),args.outcome)
    except (ValueError,TypeError,KeyError) as exc:
        parser.error(str(exc))
    print(json.dumps(result,ensure_ascii=False,allow_nan=False,sort_keys=True))


if __name__=='__main__':
    main()
