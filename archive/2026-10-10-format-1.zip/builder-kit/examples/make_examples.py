"""Create four disposable synthetic installed skeletons in an explicit empty destination."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
import yaml
from synthetic_adapter import emit

KIT = Path(__file__).resolve().parents[1]
NAMES = ('compiled', 'source-only', 'docs', 'multi-target')


def digest(path):
    return 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()


def identity(value):
    return 'sha256:'+hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def ref(path, scope='HARNESS'):
    return dict(kind='LOCAL',scope=scope,path=path)


def evidence(harness, path, summary, provenance='FIXTURE'):
    return dict(reference=ref(path),identity=digest(harness/path),summary=summary,provenance=provenance)


def inventory(repo, harness, record):
    """Capture exact baseline bytes; only the named mutable ledger is exempt."""
    entries=[]
    for p in sorted(harness.rglob('*')):
        if not p.is_file() or p.is_relative_to(harness/'artifacts/installation/evidence'):
            continue
        name=p.relative_to(harness).as_posix()
        entries.append(dict(scope='HARNESS',path=name,ownership='GENERATED',before_identity=None,
            after_identity=None if name=='artifacts/installation/installation-record.yaml' else digest(p)))
    ledger='artifacts/installation/installation-record.yaml'
    if not any(item['path']==ledger for item in entries):
        entries.append(dict(scope='HARNESS',path=ledger,ownership='GENERATED',before_identity=None,after_identity=None))
    record['generated_paths']=entries
    record['owned_paths']=deepcopy(entries)
    write(harness/'artifacts/installation/installation-record.yaml',record)


def make_one(destination, definition):
    name=definition['name']; repo=destination/name; repo.mkdir()
    h=repo/definition['harness_root']; shutil.copytree(KIT/'templates/runtime',h)
    (h/'docs').mkdir(); (h/'artifacts/maintenance').mkdir(parents=True); (h/'artifacts/development').mkdir()
    source=repo/definition['source_path'];source.parent.mkdir(parents=True);source.write_text(definition['source_content'],encoding='utf-8')
    (repo/'USER-NOTES.txt').write_text('SYNTHETIC user-owned note; preserve on resume.\n',encoding='utf-8')
    snapshot={'kind':'NON_GIT_CONTENT_SNAPSHOT','files':{definition['source_path']:digest(source),'USER-NOTES.txt':digest(repo/'USER-NOTES.txt')}}
    write(h/'artifacts/installation/evidence/source-snapshot.json',snapshot)
    source_id=identity(snapshot)
    write(h/'artifacts/installation/fixture-definition.txt',definition)
    source_e=evidence(h,'artifacts/installation/evidence/source-snapshot.json','Observed synthetic non-Git source bytes')
    fixture_e=evidence(h,'artifacts/installation/fixture-definition.txt','Explicit synthetic scope, target and policy premise')
    adapter_dir=h/'framework/adapters';adapter_dir.mkdir(exist_ok=True)
    shutil.copyfile(Path(__file__).with_name('synthetic_adapter.py'),adapter_dir/'synthetic_adapter.py')
    schema={'$schema':'https://json-schema.org/draft/2020-12/schema','type':'object',
            'description':'Fixture JSON request; synthetic adapter enforces its documented required fields.',
            'required':['capability','adapter','run_id','task_id','revision','configuration_id','adapter_definition_id','targets','evidence','requirements']}
    write(h/'framework/templates/schemas/fixture-request.schema.json',schema)
    procedure=adapter_dir/'procedure.md'
    procedure.write_text('# SYNTHETIC fixture procedure\n\nUse the local synthetic_adapter.py with --request JSON --outcome PASS|FAIL|BLOCKED|UNKNOWN. '
        'It emits stdout only and never executes production commands or writes files. '
        'Capture its stdout outside an inspected repository. Treat all output as FIXTURE. '
        'Allowed policy: fixture emission and disposable installed-record writes only; no credentials or external actions. '
        'At most one call per persisted intent, 60 second deadline. After uncertainty inspect retained stdout; do not resubmit blindly. '
        'The selected result must match source/config/run/adapter/target and consumed lineage. '
        'PASS goes to the declared success edge only for compatibility inspection; RULE-05 rejects it for actual execution. '
        'FAIL uses its failure edge; BLOCKED/UNKNOWN use stop/reconciliation. '
        'Native validation is optional and absent. Approved synthetic migrations must identify exact candidate/base/scope.\n',encoding='utf-8')
    permissions={'filesystem_scopes':[{'scope':'HARNESS','path':'.','access':'WRITE'}],
        'external_actions':[],'secrets_policy':'No credentials. Synthetic stdout and disposable records only.',
        'approval_policy':{'mode':'RECORDED_POLICY','procedure':ref('framework/adapters/procedure.md')}}
    # Explicit schemas determine the allowed scope representation; no implicit shell policy.
    permissions['filesystem_scopes']=[]
    profile=yaml.safe_load((h/'framework/config/repo-profile.yaml').read_text())
    profile['repository']={'name':'SYNTHETIC '+name,'identity':source_id,'instruction_files':[], 'harness_root':definition['harness_root']}
    profile['permissions']=permissions
    profile['completion_policy']={'terminal_state':'COMPLETE','required_criteria':['D-FINAL-REVIEW'],'execution_required_capabilities':['preflight'] if definition['profile_id']=='docs' else ['preflight','test'] if definition['profile_id']=='source-only' else ['preflight','build','test'],'acceptance_authority':'SYNTHETIC example policy author','evidence_refs':[fixture_e]}
    profile['extensions']['repository_discovery_complete']=True
    for cap,binding in profile['capabilities'].items():
        if cap in definition['pending_capabilities']:
            continue
        if cap in definition['not_applicable']:
            binding['configuration_status']='NOT_APPLICABLE'
            binding['applicability']={'rule':'RULE-07','evidence_refs':[fixture_e]}
            continue
        adapter={'identity':'SYNTHETIC-'+cap+'-A','version':'1.0.0','content_identity':digest(adapter_dir/'synthetic_adapter.py')}
        binding.update(configuration_status='CONFIGURED',compatibility='NOT_ASSESSED',adapter=adapter,
            input_schema=ref('framework/templates/schemas/fixture-request.schema.json'),
            execution_environment={'id':'fixture-local','description':'Synthetic stdout only; no production tool dependency','native_platforms':['Windows','macOS','Linux'],'evidence_refs':[fixture_e]},
            permissions=deepcopy(permissions),
            invocation={'procedure':ref('framework/adapters/procedure.md'),'reconciliation':ref('framework/adapters/procedure.md'),'deadline_seconds':60,'call_budget':1},
            normalization={'procedure':ref('framework/adapters/procedure.md'),'interface_version':'1.0.0',
                'artifact_consumed_downstream':cap=='build' and definition['artifact_consumed_downstream'],
                'test_source_required':cap=='test','artifact_lineage_required':cap=='test' and definition['separate_test_source'],'extensions_schema':None},
            evidence_refs=[fixture_e])
    profile['workflow_profiles']=[{'id':definition['profile_id'],'workflow_id':'development','required_capabilities':definition['required_capabilities'],
        'required_targets':definition['targets'],'applicability':{'rule':'RULE-07','evidence_refs':[fixture_e]},'readiness':'NOT_ASSESSED','evidence_refs':[]}]
    write(h/'framework/config/repo-profile.yaml',profile)
    catalogue=yaml.safe_load((h/'framework/workflows/verification-criteria.yaml').read_text())
    for cap in definition['required_capabilities']:
        for target in definition['targets']:
            cid='II-'+'-'.join('x'+v.encode().hex() for v in [definition['profile_id'],cap,target['target_id']])
            catalogue['criteria'].append({'id':cid,'category':'INTEGRATION','required':True,
                'description':catalogue['extensions']['integration_obligation'],'allowed_methods':['AUTOMATED','LLM_REVIEW','HUMAN_REVIEW'],
                'applicability_rule':None,'scenario_ids':['S-01','S-09','S-30','S-34']})
            catalogue['extensions']['integration_instances'].append({'criterion_id':cid,'profile_id':definition['profile_id'],'capability_id':cap,**target})
    write(h/'framework/workflows/verification-criteria.yaml',catalogue)
    (h/'docs/setup.md').write_text('# Synthetic installation status\n\nConfiguration: cfg-1; revision: 1. Structure INCOMPLETE; integration NOT_ASSESSED.\nSemantic reviews and activation are pending; no production result exists.\n',encoding='utf-8')
    raw=h/'artifacts/installation/evidence/fixture-input.txt';raw.write_text('SYNTHETIC fixture premise only, not execution.\n',encoding='utf-8')
    artifact=h/'artifacts/installation/evidence/toy-artifact.txt';artifact.write_text('SYNTHETIC unexecuted artifact fixture\n',encoding='utf-8')
    request={'capability':'build','adapter':profile['capabilities']['build']['adapter'] or {'identity':'SYNTHETIC-unused-build','version':'1.0.0','content_identity':digest(adapter_dir/'synthetic_adapter.py')},
        'run_id':'SYNTHETIC-run-1','task_id':'SYNTHETIC-task-1','revision':source_id,'configuration_id':'cfg-1',
        'adapter_definition_id':digest(adapter_dir/'synthetic_adapter.py'),'targets':definition['targets'],
        'evidence':{'reference':ref('artifacts/installation/evidence/fixture-input.txt'),'summary':'Unexecuted fixture premise'},
        'requirements':{'artifact_consumed_downstream':definition['artifact_consumed_downstream'],'test_source_required':False,'artifact_lineage_required':False},
        'artifact':{'identity':digest(artifact),'reference':ref('artifacts/installation/evidence/toy-artifact.txt')}}
    if definition['separate_test_source']:
        tests=repo/'separate-tests/check.txt';tests.parent.mkdir();tests.write_text('SYNTHETIC independently versioned test source\n',encoding='utf-8')
        write(repo/'test-source-snapshot.json',{'files':{'check.txt':digest(tests)},'repository_identity':identity('SYNTHETIC separate test repo')})
        test_request=deepcopy(request);test_request.update(capability='test',adapter=profile['capabilities']['test']['adapter'])
        test_request['requirements'].update(artifact_consumed_downstream=False,test_source_required=True,artifact_lineage_required=True)
        test_request['test_source']={'identity':digest(tests),'reference':ref('separate-tests/check.txt','REPOSITORY'),'artifact_identity':digest(artifact)}
        write(repo/'fixture-test-request.json',test_request)
    write(repo/'fixture-request.json',request)
    for outcome in ('PASS','FAIL','BLOCKED','UNKNOWN'):
        write(h/f'artifacts/installation/evidence/fixture-{outcome}.json',emit(request,outcome))
    record=yaml.safe_load((h/'framework/templates/installation/installation-record.yaml').read_text())
    stamp=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
    record.update(installation_id='SYNTHETIC-install-'+name,target_identity=source_id,harness_root=definition['harness_root'],
        discovered_facts=[{'id':'source-snapshot','claim':'Synthetic source bytes captured in a non-Git content snapshot.','classification':'FACT','evidence_refs':[source_e]}],
        decisions=[{'id':'scope','value':{'status':'RESOLVED','value':definition['applicability']},'reason':'Declared synthetic example; not a private repository fact','evidence_refs':[fixture_e]}],
        started_at=stamp,updated_at=stamp)
    record['entry_point']['candidate']={'path':definition['harness_root']+'/README.md','content_identity':digest(h/'README.md'),'before_identity':None}
    record['entry_point']['activation_state']='STAGED'
    record['extensions'].pop('template_only',None)
    inventory(repo,h,record)
    return {'name':name,'repository':str(repo),'harness_root':definition['harness_root'],'source_identity':source_id}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination',required=True,type=Path)
    args=parser.parse_args();destination=args.destination.expanduser().absolute()
    if destination.is_symlink() or (destination.exists() and (not destination.is_dir() or any(destination.iterdir()))):
        parser.error('destination must be an empty directory; existing user content is never overwritten')
    # Read all fixed definitions before creating any repository.
    definitions=[yaml.safe_load((Path(__file__).parent/'definitions'/f'{name}.yaml').read_text(encoding='utf-8')) for name in NAMES]
    destination.mkdir(parents=True,exist_ok=True)
    outputs=[make_one(destination,d) for d in definitions]
    print(json.dumps({'provenance':'FIXTURE','examples':outputs},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
