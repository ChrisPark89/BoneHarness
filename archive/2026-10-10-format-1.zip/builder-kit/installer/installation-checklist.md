# Installation assessment view

Read the installed **canonical catalogue**, `framework/workflows/verification-criteria.yaml`; join definitions to the installation/current profile assessment by version and ID. Derive this view from records. These rows are navigation labels, not a second mutable criterion catalogue or evidence of PASS.

| Required base IDs | Locate assessment evidence |
|---|---|
| IS-01.files, IS-01.schemas | Inventory and typed definitions |
| IS-02.local_refs, IS-02.ownership | Target references and scoped instruction decision |
| IS-03.registry, IS-03.separation | Canonical configuration and record locations |
| IS-04.graph, IS-04.routing | Graph diagnostics and outcome traces |
| IS-05.result_schema, IS-05.evidence | Saved-result schema and evidence/identity review; native tool output may be plain text |
| IS-06.records, IS-06.recovery | Durable templates and concrete restart/update traces |
| IS-07.sequence, IS-07.applicability | Default sequence and evidenced adaptations |
| IS-08.inventory, IS-08.assessment | Recoverable ownership and current assessment joins |

Include every additional required catalogue subcriterion, currently IS-01.discovery and IS-08.provenance. Include instantiated II tuple criteria for each supported profile's required targets/capabilities. Do not create IDs for unknown targets; record their pending consequence.

Render columns: ID, category, required, description, allowed methods, result, actual method/actor, evidence refs, reason, assessed configuration ID. Missing assessment is PENDING. Record checker status, exact covered/uncovered IDs and report refs independently. A checked box or exit 0 cannot override a missing/failed required criterion.

Before activation, structure is INCOMPLETE while required IS-08.provenance is PENDING. Derive ACTIVATION_ELIGIBLE separately using the catalogue activation_contract: all other required structural IDs satisfied, available provenance reviewed, scope conflicts resolved and current base/candidate hashes matching. This is no final completeness claim. Activation explicitly loads `.harness` entry points and writes no root instruction file. After activation, reread from the target entry point; failure leaves completion withheld. Record observed evidence, revalidate retained dependencies, publish final assessments under a new configuration revision, and compare actual final bytes to the assessed candidate before STRUCTURE_COMPLETE/completed_at. Preserve the staged snapshot and final publication receipt. Preserve historical installation snapshots after later maintenance; current profile assessments remain authoritative.

Reporting navigation: IS-01.files includes all journal/reporting additions listed in the canonical inventory; IS-01.schemas/IS-02.local_refs include the local report schema and immutable legacy descriptor. IS-04.graph includes PhaseMap partition/profile/criterion joins and exact built-in RULE-06 parity. Record reporting_generator prerequisites, availability and actual validation separately. Structure completeness does not imply reporter availability or task completion. Local source enumeration requires a saved inventory and accepted source scope; old opaque snapshots stay UNCHECKED. Scoped N/A authority remains unsupported. Explicit skips require the installed disposition/route checks and attributed user-instruction review. An unchecked mandatory obligation prevents supported completion.

- Check installed user-skip states/routes, PhaseDisposition schema and context/report support together. Exactly specification and final specification verification are mandatory; keep previous configuration captures unchanged. A skip never repairs missing setup capability.
