#!/usr/bin/env python3
"""Create a fresh .harness scaffold; discovery, assessment and activation stay pending."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
KIT = Path(__file__).resolve().parents[1]
KIT_VERSION = '1.1.0'


def digest(data):
    return 'sha256:' + hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def install(repo):
    """Copy a complete scaffold without modifying existing repository instructions."""
    repo = Path(repo)
    if not repo.is_absolute() or not repo.is_dir():
        raise ValueError('--repo-root must be an existing absolute directory')
    repo = repo.resolve(strict=True)
    harness = repo / '.harness'
    if harness.exists() or harness.is_symlink():
        raise ValueError('.harness already exists; use recorded resume or maintenance, never overwrite')
    source = KIT / 'templates/runtime'
    # Read required package inputs before the first target write.
    record = json.loads((source / 'framework/templates/installation/installation-record.yaml').read_text(encoding='utf-8'))
    snapshot = {'files': {}, 'symlinks': {}, 'limitations': ['Filesystem snapshot only; Git metadata excluded. Semantic discovery remains pending.']}
    for path in sorted(repo.rglob('*')):
        relative = path.relative_to(repo)
        if '.git' in relative.parts:
            continue
        if path.is_symlink():
            snapshot['symlinks'][relative.as_posix()] = str(path.readlink())
        elif path.is_file():
            snapshot['files'][relative.as_posix()] = digest(path.read_bytes())
    snapshot_bytes = (json.dumps(snapshot, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8')
    stamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    # A failed copy intentionally remains a visible incomplete scaffold for guided recovery.
    shutil.copytree(source, harness, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for directory in ('docs/development', 'docs/maintenance', 'artifacts/installation/evidence',
                      'artifacts/configurations', 'artifacts/development', 'artifacts/maintenance'):
        (harness / directory).mkdir(parents=True, exist_ok=True)
    shutil.copyfile(KIT / 'checker/check.py', harness / 'framework/tools/check.py')
    shutil.copytree(KIT / 'checker/harness_check', harness / 'framework/tools/harness_check',
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    snapshot_path = 'artifacts/installation/evidence/source-snapshot.json'
    (harness / snapshot_path).write_bytes(snapshot_bytes)
    profile = harness / 'framework/config/repo-profile.yaml'
    profile_text = profile.read_text(encoding='utf-8')
    profile_text = profile_text.replace('"name": "example-repository"', '"name": ' + json.dumps(repo.name, ensure_ascii=False), 1)
    profile_text = profile_text.replace('sha256:' + 'a' * 64, digest(snapshot_bytes), 1)
    profile.write_text(profile_text, encoding='utf-8')
    (harness / 'docs/setup.md').write_text(
        '# Harness setup\n\nDescribed configuration: `cfg-1`, revision `1`. Kit: `1.1.0`; layout: `2`.\n\n'
        'Structure status: `INCOMPLETE`. Integration status: `NOT_ASSESSED`. Discovery, policy, bindings, targets and activation remain pending. '
        'Scaffolding creates files; it performs no semantic assessment.\n\n'
        'Reporter: **NOT_CHECKED**. Checker: **NOT_RUN**. No dependencies were installed. '
        'Both reference tools require Python 3.11+ and the provisioned [dependencies](../framework/tools/requirements.lock).\n\n'
        'Read the [profile](../framework/config/repo-profile.yaml), '
        '[installation record](../artifacts/installation/installation-record.yaml), '
        '[development](../framework/workflows/development/HARNESS.md) and '
        '[maintenance](../framework/workflows/maintenance/harness-maintenance.md). '
        'Follow the installer assessment procedure before activation.\n\n'
        'State writing is procedural. Automatic repair is disabled. Source inventory, skip authority '
        'and scoped applicability checks remain unsupported by the reference reporter.\n', encoding='utf-8')
    record.update(installation_id='install-' + stamp.replace(':', '').replace('.', '-'), kit_version=KIT_VERSION,
                  target_identity=digest(snapshot_bytes), harness_root='.harness', started_at=stamp, updated_at=stamp,
                  completed_at=None)
    record['extensions'].pop('template_only', None)
    record['extensions']['layout_version'] = '2'
    record['discovered_facts'] = [{'id': 'source-snapshot', 'claim': 'Captured existing repository file bytes before scaffolding; semantic discovery remains pending.',
        'classification': 'FACT', 'evidence_refs': [{'reference': {'kind': 'LOCAL', 'scope': 'HARNESS', 'path': snapshot_path},
        'identity': digest(snapshot_bytes), 'provenance': 'REVIEW', 'summary': 'Observed filesystem snapshot; no execution or readiness claim.'}]}]
    record['entry_point'] = {'candidate': {'path': '.harness/README.md', 'content_identity': digest((harness/'README.md').read_bytes()), 'before_identity': None},
                             'activation_state': 'STAGED', 'evidence_refs': []}
    ledger = 'artifacts/installation/installation-record.yaml'
    write_json(harness / ledger, record)
    inventory = [{'scope': 'HARNESS', 'path': p.relative_to(harness).as_posix(), 'ownership': 'GENERATED',
                  'before_identity': None, 'after_identity': None if p.relative_to(harness).as_posix() == ledger else digest(p.read_bytes())}
                 for p in sorted(harness.rglob('*')) if p.is_file()]
    record['generated_paths'] = inventory
    record['owned_paths'] = deepcopy(inventory)
    write_json(harness / ledger, record)
    return {'harness_root': str(harness), 'kit_version': KIT_VERSION, 'layout_version': '2',
            'structure': 'INCOMPLETE', 'activation': 'STAGED', 'entry_point': str(harness / 'README.md')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo-root', required=True, type=Path)
    args = parser.parse_args()
    try:
        result = install(args.repo_root)
    except (ValueError, OSError) as exc:
        parser.exit(2, str(exc) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
