# Portable Harness Builder Implementation Plan

## Current update: user-approved skipping

**Completed:** implementation, independent review and both regression suites. See [verification](verification.md) for evidence and limits.

Implement the approved [phase-skipping design](specification.md#12-planned-update-user-approved-phase-skipping) using the ordered [reporting plan](reporting-implementation-plan.md#current-update-user-approved-phase-skipping). Add explicit routes and evidence-backed dispositions to the existing state machine. Keep specification acceptance and final verification mandatory, retain task requirements and preserve old histories. Review the implementation, then run focused and full regression checks. The next separate step is a realistic LLM walkthrough.

## Next: focused LLM guidance

**Status:** source implementation, independent source review and bounded execution checks completed; see [verification](verification.md) for actual coverage and limits. Follow [specification section 15](specification.md#15-planned-update-focused-llm-guidance) and [acceptance checks G-01–G-06](acceptance-scenarios.md#focused-guidance-acceptance-checks).

Use existing files and loaders. Keep one authoritative source, the current state machine and the five-file default task budget. Do not add a second runtime controller or duplicate summaries.

**CLI preparation:** follow the [idea note](cli-idea.md). Separate extraction functions from argument parsing, text/JSON formatting and exit handling. Functions take explicit inputs and return structured results/diagnostics, so a future CLI can reuse them directly. Broader commands and packaging remain outside this implementation.

1. [x] **Route by situation.** Update `templates/runtime/README.md` within 200 words. Route development, maintenance, setup and recovery; keep installation routing in `builder-kit/README.md` and `installer/bootstrap-prompt.md`.
2. [x] **Make instructions sequential.** Shorten `INSTALLER_SPEC.md` and runtime `HARNESS.md`, `harness-maintenance.md`, `verification-rules.md`, `journal-protocol.md` and adapter guidance. Use locate/check/act/verify/record/continue sections, aiming for 200–300 words per procedure. Preserve stable rule IDs and mandatory evidence requirements; group detail rather than creating one file per rule.
3. [x] **Extract relevant context.** Add one read-only command under `framework/tools/`, reusing `harness_io` parsing, schema and journal utilities. Select by task/stage or setup/update situation; return complete applicable criteria, transitions, bindings, unresolved issues and procedure references. Respect captured configuration, show missing/unsupported inputs and explicit continuation. Document equivalent parsing when Python is unavailable.
4. [x] **Add the recovery guide.** Place a short shared guide under `framework/workflows/` and link it from both entry points. Use saved state, invocation and evidence to determine the next safe action. Cover uncertain dispatch, running operations, saved output, committed transitions and changed inputs without extra checkpoint files.
5. [x] **Integrate and review.** Update inventory, configuration capture, checker/reporting references and user guidance affected by the changed definitions. Review mandatory-rule coverage and preserve historical task pins; existing harness updates follow maintenance. Document the extraction command's exact interface alongside its implementation.
6. [x] **Verify when authorized.** Check G-01–G-06, including captured-versus-current configuration, missing parsers, malformed records, large criteria sets and interrupted execution. Keep project regression checks in `tests/`; report actual coverage and pending limitations without expanding the two-scenario demo unnecessarily.

### Implementation notes

- `context.py` handles arguments/output/exits; `context_reader.py` exposes reusable extraction, pagination and rendering. Overview, transition/resolution, criterion, rules-section, setup-contract and journal-entry selectors share one reader.
- Canonical detailed rules retain their existing identities where required by checker/reporting policy. Short guides and selected sections replace whole-reference loading; the long installer procedure moved to `installer/installation-reference.md`.
- Extraction uses captured task guides/configuration, exact accepted specification identities and pending/current recovery evidence. Missing legacy guide captures are explicit. Setup contract selection lives in the canonical criteria catalogue.
- This workspace has no Git repository; edits were made in place with a temporary backup. No repository metadata or new project ledger was created.
- Source review corrected specification selection, recovery route selection, guide pinning and inventory access. Syntax/source review is separate from runtime tests and demo execution. After test authorization, added 12 focused context tests and ran the regression suite plus a fresh two-scenario demo. Checks cover parsing, configuration pins, stale update bases, uncertain invocation selection, pagination and read-only CLI execution. Live external-operation reconnection and native Windows/Linux execution remain unverified.

## Setup checks and project tests (2026-10-08)

- [x] Keep the full conformance catalogue and its schema in `tests/`; remove them from runtime inventory, snapshots and checker requirements.
- [x] Update existing authoring tests and documentation for the new locations. Keep historical evidence and installed demo records unchanged.
- [x] Clarify that the LLM may interpret native tool output into an evidence-backed saved Result. Retain the existing schemas, unknown-outcome handling and separate specification review.
- [x] Reuse affected setup checks during maintenance; require focused verification only for changed core behaviour.
- Tests and a fresh temporary demo were rerun after authorization; see [verification](verification.md). Earlier records remain historical.

The historical baseline tasks below describe their original file layout; this section and the current specification supersede their requirement to install a conformance catalogue.

## Layout implementation

**Implementation complete; final validation is recorded in [status](implementation-status.md).** Follow the [layout guide](artifact-layout.md), [specification sections 2 and 14](specification.md#14-proposed-update-fewer-artefacts-and-clear-audiences) and acceptance checks A-01–A-10. These steps cover kit 1.1.0/layout 2. Historical baseline tasks below remain separate.

| Destination inside `.harness/` | Responsibility |
|---|---|
| `README.md`, `docs/` | Human index, setup status, task specification/report and maintenance summary. |
| `framework/config/` | Repository profile and skill bindings. |
| `framework/workflows/` | Separate development/maintenance entry points, state machines, rules and criteria. |
| `framework/adapters/` | Skill interfaces and normalizers. |
| `framework/templates/` | Document/record templates and schemas. |
| `framework/tools/` | Checker/reporter code and declared dependencies. |
| `artifacts/` | Installation, shared configuration snapshots, development and maintenance records with their evidence. Temporary staging is `artifacts/tmp/`, only when needed. |

### Delivery sequence

- [x] **Define migration interfaces.** Specify version/path mapping, stable journal-entry references, integrity checks, incomplete-write recovery and shared snapshot identity. Preserve earlier histories and pinned configurations. Resolve these details before changing readers/writers.
- [x] **Adapt installed definitions.** Reorganize templates and local dependencies into `framework/`; keep development and maintenance entry points separate. Workflows use capability IDs and normalized outcomes; replaceable tools do not own workflow policy.
- [x] **Consolidate generated records.** Put state, history, report data and supporting evidence under the owning `artifacts/` task/update. Reuse immutable bytes where valid. Remove mandatory per-decision files, placeholders and routine reporter console logs while preserving recovery and evidence requirements.
- [x] **Adapt human reporting.** Produce short pages in `docs/`, with direct links to `artifacts/`. Keep every configured phase visible, evidence-derived summaries and unsupported outcomes explicit. Follow the [reporting migration notes](reporting-implementation-plan.md#layout-implementation).
- [x] **Update installation and maintenance together.** Adapt inventory, schemas, checker paths, publication/recovery rules and entry-point handoff. Keep all harness-owned writes inside `.harness/`; create no repository-root pointer or instruction edit. Update user/package guidance when the runtime actually supports the layout.
- [x] **Review and validate the migrated kit.** Assess A-01–A-10 and affected baseline cases, five default task files plus necessary evidence, 200-word human pages, record/report consistency, repair/resume and missing-tool behavior. Use the [reusable demo](../tests/demo/README.md): use the single app rooted at `tests/demo/`, install the kit into `tests/demo/.harness/`, and run only success plus test-failure/repair scenarios initially. Confirm that replacing the harness leaves the app reusable. App-only checks do not satisfy this step. Run implementation tests only when authorized; native platform claims need actual evidence.

The five default task files are `docs/development/<task>/spec.md`, `report.md`, and `artifacts/development/<task>/state.json`, `history.jsonl`, `report.json`. Create them when needed. Necessary evidence and shared snapshots are additional; hiding duplicate files does not satisfy the reduction requirement.

Skip authority remains pending. The source-inventory implementation and focused checks are described in the current reporting plan and verification summary. This migration cannot advertise either feature or positive completion support without its required implementation and evidence.

## Package scope update

The optional pilot guide and report template are retired. The installation prompt and installed development/maintenance flows cover normal use; `tests/demo/` remains the reusable example. Historical pilot tasks below record earlier work and are not current delivery requirements.

## Evidence cleanup

**Goal:** remove the mixed root evidence folder without losing test inputs or recorded results.

**Layout:** `tests/fixtures/` holds immutable inputs; `archive/verification/` holds historical records; `docs/verification.md` is the short human summary.

- [x] Identify direct test reads and referenced evidence; preserve their bytes and recorded path aliases.
- [x] Move required inputs to fixtures. Archive remaining logs/reviews together; retain the last full verification record separately.
- [x] Update test lookups and document links. Keep original recorded paths and results inside historical data.
- [x] Check every moved file against its original hash and review remaining references. Do not claim new test execution from this cleanup.

Scope: project organization only. Installed harnesses, demo history and builder behavior remain unchanged. No new tests or suite runs are part of this request.

## Historical baseline plan

The document checker now lives at `tests/check-documents.py`. Older commands below retain their original paths.

The remainder preserves the delivered baseline's paths, commands, approvals and results. Its execution instructions apply to that historical work, not the layout implementation above.

Layout note, 2026-10-05: this completed plan retains historical paths and commands. Use [the current test instructions](../tests/README.md) and [verification summary](verification.md) for current locations.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a portable installer kit that produces self-contained development and maintenance instructions, with explicit evidence records and an optional read-only installation checker.

**Architecture:** Adapt the useful earlier candidate into `builder-kit/`, then define installed schemas and procedural workflows before completing the installer and checker. The default writer is `LLM_PROTOCOL`; `TOOL` describes an interface that a target repository may bind and verify. The kit does not provide a universal runtime engine, production executor, or scheduler.

**Tech Stack:** Markdown, JSON-compatible safe YAML, JSON Schema Draft 2020-12, optional Python 3.11+, `unittest`, PyYAML, and jsonschema.

**Spec:** [specification.md](specification.md), approved by the user; [acceptance-scenarios.md](acceptance-scenarios.md) supplies R-01–R-24 and S-01–S-48 coverage.

## Execution status

Updated 2026-10-05: Tasks 1–7 accepted after their separate reviews/fixes; [review digest](reviews/implementation-review.md). Final whole-kit I-1 was corrected in `7db46b0` and accepted by [independent scoped re-review](reviews/final-rereview.md). The first reviewed transfer to the original workspace completed; [decision/transfer record](reviews/review-decisions.md). The final task checkbox is now complete from those actual actions. Fresh post-transfer controller full suites passed 120 tests on each local interpreter; [status](implementation-status.md) links their actual records. Actual native Windows/Linux, TOOL, absent-interpreter host and private-pilot obligations remain pending; authoring task completion does not satisfy them. See [release assessment](../archive/verification/history.zip#evidence/release-assessment.md).

## Global constraints

- User authorization covers writing/reviewing/fixing this plan and then implementing with subagents; no additional plan approval round is required. Use `docs/implementation-plan.md`, without a new `superpowers` documentation directory.
- Work sequentially in the controller's isolated scratch checkout. Review each task before starting its successor. Commit bounded tasks there; do not initialize or commit the original workspace. Copy only accepted delivery files back.
- Reuse `/private/tmp/harness-maintenance-sdd-20261003/work/agent_harness_builder_kit` deliberately; its recorded HEAD is `a280bd1276f7aa8f2ab3501717a1840d765c3166`, with additional installer edits. Compare current contents, not just HEAD. `archive/2026-10-04-design-audit/candidate` is frozen evidence, never a replacement source. Do not modify `archive/` or `docs/research/`.
- The installation host must be supported on Windows, macOS, and Linux. Native evidence now exists for macOS Python 3.11/3.14; Windows/Linux stay `PENDING` unless actually run on those hosts. The available host is macOS 15.6 arm64 with Python 3.14.0 and an existing native Python 3.11 interpreter; exercise both locally.
- Runtime operation must not require builder paths, private authoring notes, or this design document. A Git commit is not required: accept a documented content snapshot of non-Git or dirty repositories.
- `repo-profile.yaml` owns active adapters, capability readiness, workflow-profile selection, permissions, configured state writer, and source references. Every canonical profile change advances the configuration revision, including readiness publication.
- Capability configuration is `CONFIGURED`, `PENDING_DISCOVERY`, `UNAVAILABLE`, or `NOT_APPLICABLE`; compatibility is `NOT_ASSESSED`, `COMPATIBLE`, `INCOMPATIBLE`, or `NEEDS_REVIEW`. Adapter status is exactly `PASS`, `FAIL`, `BLOCKED`, or `UNKNOWN`.
- Criterion results are `PENDING`, `PASS`, `FAIL`, `BLOCKED`, or `NOT_APPLICABLE`; methods are `AUTOMATED`, `LLM_REVIEW`, or `HUMAN_REVIEW`. Provenance is `FIXTURE`, `EXECUTION`, or `REVIEW`. Every `PASS` and permitted `NOT_APPLICABLE` has evidence; fixture evidence never proves real task execution.
- Machine YAML uses string keys, explicit booleans, quoted string-like dates/identifiers, and JSON-compatible values. Reject merge keys, custom tags, non-finite numbers, duplicate keys, and cyclic aliases; JSON also rejects duplicate keys and non-finite numbers.
- No arbitrary YAML constructors, expression evaluation, remote schema downloads, production-command execution, implicit dependency download, or checker writes to the inspected repository. Paths use `/`, explicit scopes, exact casing, and resolution within the declared root before reads.
- Keep public entry points short. Installation verification is required; Python is optional. Procedural enforcement, actual tool execution, schema checks, and untested behavior must remain distinguishable in all reports.

## Review focus

1. A syntactically valid pending value must block its execution gate without preventing a complete scaffold: Task 1 schema tests and Task 4 installation walkthrough.
2. Matching Git commits with different dirty content must fail identity matching: Task 2 S-15/S-27 walkthrough variants and Task 6 retained evidence.
3. Replayed requests, partial writes, and competing writers must preserve history and budgets without claiming atomicity: Tasks 2–3 S-17/S-28/S-37–S-39 walkthroughs.
4. A valid fixture `PASS` must never satisfy execution; mixed missing/running/failed child outcomes must not enter repair: Task 2 S-42/S-47 walkthroughs and Task 6 evidence.
5. Case-insensitive hosts, escaping symlinks, duplicate keys, and unavailable prerequisites must produce specific bounded checker results: Task 5 adversarial tests and Task 6 native matrix.

## Delivery paths and shared interfaces

All package paths below are relative to `builder-kit/`; tests are package authoring checks, not installed runtime tools. The installed root is chosen during discovery and recorded as a repository-relative path.

| Path | Responsibility |
|---|---|
| `README.md`, `INSTALLER_SPEC.md`, `installer/bootstrap-prompt.md`, `installer/installation-checklist.md` | One installation entry point, discovery/activation/resume procedure, derived checklist |
| `templates/runtime/development/{HARNESS.md,workflow.yaml,task-spec.md,templates/}` | Development entry point, transitions, accepted-spec and durable-record templates |
| `templates/runtime/maintenance/{harness-maintenance.md,maintenance-workflow.yaml,templates/harness-update-record.yaml}` | Maintenance entry point, transitions, append-only update history |
| `templates/runtime/shared/{repo-profile.yaml,harness-status.md,adapter-interface.md,verification-rules.md,verification-criteria.yaml,conformance-cases.yaml,schemas/}` | Canonical bindings and installed definitions; no run results |
| `templates/runtime/installation/installation-record.yaml` | Installation provenance and assessed results; no installer instructions |
| `checker/{check.py,harness_check/,requirements.lock,README.md}` | Optional read-only reference checker and explicit prerequisites |
| `tests/`, `examples/`, `evidence/`, `pilot/` | Executable checks, disposable synthetic examples, actual results, internal pilot instructions |

Use version `1.0.0` for the initial kit, schema, adapter interface, criteria catalogue, and case catalogue. Keep those versions as separate named fields. A profile has `configuration_revision` (integer starting at 1) and `configuration_id` (for example `cfg-1`); every canonical mutation advances both. Task `config-snapshot.yaml` records that ID plus a manifest of SHA-256 identities for captured profile, workflows, rules, schemas, and adapter definitions. The manifest lives outside the hashed files, avoiding self-hashing. Captured definitions live under the task's `configuration/`; changing external definitions requires explicit adoption or a stop.

For every profile publication, including readiness-only changes, retain `inspected_configuration_id` as the base and assess the staged prospective configuration using its new ID. Assessments published with cfg-2 identify cfg-2, never cfg-1. Revalidate retained assessments against unchanged dependencies and record that carry-forward decision, or leave them PENDING; merely relabelling an old assessment is insufficient. Compare the active base before publication. This prevents assessment publication from immediately invalidating its own evidence.

### Fixed machine contracts

Task 1 defines these contracts; later tasks may tighten constraints only through an explicit, reviewed amendment applied to all consumers. Schema files use local relative `$ref` values exclusively. Every record has `schema_version: "1.0.0"` and a `record_type` discriminator; timestamps are UTC ISO-8601 strings. Use `additionalProperties: false` except a named `extensions` object whose declared schema cannot weaken core fields.

- `shared/schemas/common.schema.json`: `$defs.Reference` is either `{kind: LOCAL, scope: REPOSITORY|HARNESS, path: string}` or `{kind: EXTERNAL, uri: string, accessibility: AVAILABLE|UNAVAILABLE|NOT_ASSESSED}`. Evidence adds `provenance`, `summary`, and `identity` to a `reference`. External references are never opened by the checker. `$defs.PendingValue` is `{status: PENDING_DISCOVERY, value: null, reason: string, stop_state: BLOCKED|HUMAN_REQUIRED}` and is allowed only in explicitly declared discovery/policy/deadline/target fields; free-form sentinel strings are not pending configuration.
- `profile.schema.json`: `repository`, `configuration_revision`, `configuration_id`, `capabilities`, `workflow_profiles`, `permissions`, `completion_policy`, `state_writer`, `watched_sources`, and `assessments`. Capability IDs are stable keys. Each binding records `configuration_status`, `compatibility`, `adapter` (identity/version/content identity or null), `input_schema`, `execution_environment`, `native_validation`, `side_effects`, `permissions`, `invocation`, `normalization`, `evidence_refs`, and `applicability`. Invocation declares procedure/reconciliation references, deadline, and call budget, with explicit pending alternatives. Profiles record required capability/target sets and applicability evidence. `state_writer` is `{mode: LLM_PROTOCOL|TOOL, identity, binding, enforcement_evidence_refs}`; default binding is null and mode is procedural.
- `workflow.schema.json`: `workflow_id`, `states`, `initial_state`, `terminal_states`, `stop_states`, `transitions`, and `resolution_routes`. Each transition is `{id, from, to, profiles, trigger, rule_ids}`. IDs are `DEV-001` onward or `MNT-001` onward, unique within their workflow. Triggers are finite outcome labels, never expressions. Every `(from, profile, trigger)` resolves to at most one edge; every nonterminal state declares its unresolved/stop/resume behavior. No adapter definitions or mutable capability registry appear here.
- `result.schema.json`: core envelope `interface_version`, `capability`, `adapter`, `run_id`, `task_id`, `revision`, `status`, `evidence: {reference, summary}`, plus `provenance`, `configuration_id`, `adapter_definition_id`, `targets`, `artifact`, `test_source`, `extensions`. The last three are conditional: artifact is required on successful build only when declared consumed downstream; test source/artifact lineage is required by the selected test binding. A malformed envelope remains a raw observation, not a fabricated result.
- `criteria.schema.json`: `$defs.Catalogue` holds `catalogue_version` and `criteria`; each definition has `id`, `category`, `required`, `description`, `allowed_methods`, `applicability_rule`, `scenario_ids`. `$defs.Assessment` has `catalogue_version`, `criterion_id`, `result`, `method`, `actor`, `evidence_refs`, `reason`, `assessed_configuration_id`. `PENDING` may have null method/actor; a satisfied result cannot. Definitions and results join by catalogue version plus ID to expose all R-06 fields without duplicating mutable catalogue text.
- `records.schema.json`: named `$defs` are `TaskSpec`, `TaskState`, `ConfigSnapshot`, `TransitionRequest`, `GateDecision`, `Event`, `EventLog`, `Invocation`, `CriterionReview`, `Observation`, `UpdateRecord`, `InstallationRecord`, `CheckerReport`, and `ScenarioResult`. Their exact fields are fixed below; all collections and pending alternatives are typed.
- `conformance.schema.json`: catalogue records `cases_version` and `cases`; case fields are `case_id`, `scenario_id`, `requirement_ids`, `initial_state`, `configuration`, `input_evidence`, `action`, `expected_decision`, `expected_state`, `expected_records`, `forbidden_effects`, `coverage_parts`. Definitions contain no `actual_result`. Each `coverage_parts` item identifies an `AUTOMATED` or `WALKTHROUGH` check and expected evidence. `ScenarioResult` stores `case_id`, `scenario_id`, `mode`, `actor`, `actual_result`, `observations`, `evidence_refs`, `limitations`; initial result is `PENDING`.

| Record | Required content beyond common version/type |
|---|---|
| `TaskSpec` | `task_id`, request/spec/design identities, acceptance authority, scope/non-goals, criteria with IDs/due states/allowed methods/required flags, target set, profile ID |
| `TaskState` | task/state/version, writer, pinned config ID, input snapshot, accepted identities, selected targets, criterion verdict references, repair counters by origin, invocation counters, pending invocation refs, stop reason/stopped-from state/resolution refs |
| `ConfigSnapshot` | configuration ID/revision, captured definition manifest, external service versions or explicit limitations |
| `TransitionRequest` | subject ID/kind, request ID, expected state/version, transition ID, configuration ID, accepted identities when due, evidence/review refs, request content identity |
| `GateDecision` | request ID, `ALLOW|DENY|BLOCKED`, rule findings `{rule_id,result,reason,evidence_refs}`, proposed destination or resolution route; decision itself has no mutation effect |
| `Event` / `EventLog` | ordered committed events with request ID/content identity, previous/next versions and states, UTC time, actor, decision/evidence refs, counter deltas, and complete typed `post_state` TaskState payload; initialization is version 1 from previous version 0. Replay restores every mutable task field, including pinned config, accepted identities, targets, invocations, and stop data. Referenced immutable payloads carry content identities. Update events analogously preserve complete typed update-current snapshots without recursively embedding the event list. Log has subject ID and events list. |
| `Invocation` | intent/request/run/task IDs, expected identities, source/target/environment/artifact/test-source inputs, dispatch status, external handle or null, absolute deadline, call/time counters, reconciliation/cancellation evidence; preserve unresolved dispatch |
| `CriterionReview` / `Observation` | criterion-level verdicts with due stage/evidence/unresolved findings / raw reference, diagnostics, interpreted outcome `UNKNOWN`, never an invented tool-reported outcome |
| `UpdateRecord` | update ID, request type/scope, writer, inspected config and before-values, prospective config ID, candidate identity/changed values, publication manifest of affected paths with before/after identities and ownership, checks/evidence, permissions/scoped approval, promotion intent/result/config identities, conditional rollback data, append-only events plus derived current summary, links to corrective attempts |
| `InstallationRecord` | installation/kit/schema IDs, mode `FRESH|RESUME|EXISTING`, target/root, generated and owned path inventory with before/after hashes, discovered facts, decisions, criterion assessments, checker coverage, entry-point candidate/activation state, timestamps |
| `CheckerReport` | checker/version, assessed config ID, platform/runtime/dependency versions, checked assessments, uncovered IDs, diagnostics, limitations, exit code, separate derived structure/integration assessment |

Installed rule headings in `verification-rules.md` are exactly `### RULE-01` through `### RULE-17`. Each defines inputs, method, pass/fail/unknown conditions, and failure/resolution route. IDs mean: 01 expected state/version/replay; 02 schema; 03 invocation/source/config/adapter identity; 04 targets/artifacts/test-source identity; 05 tool outcome/provenance; 06 due criterion coverage and LLM review; 07 applicability; 08 permissions/approval/current access; 09 repair progress/budget; 10 invocation/deadline/reconciliation; 11 writer/events/resume; 12 invalidation/adoption; 13 compatibility; 14 promotion/version/before-values; 15 rollback; 16 drift publication; 17 completion policy. A reference to any other rule requires an installed definition with the same contract. Unknown IDs or unresolved tool verifier bindings block progression.

## Task 1: Preserve the candidate and publish the typed contracts

**Files:** selectively modify existing `builder-kit/` from the earlier candidate; create its seven `templates/runtime/shared/schemas/*.schema.json` files above, `tests/test_contracts.py`, and `evidence/candidate-reuse.md`.

**Interfaces:** consumes the approved specification and earlier candidate; produces versioned schema definitions and the fixed record names used by every later task. Candidate content is provisional until its owning task passes review.

- [x] Inventory old/current/frozen candidate paths and content hashes; record which current candidate files are reused, adapted, or superseded and why. Preserve useful development/maintenance separation and installer edits; remove obsolete flat template copies when their replacements exist, and rename `skill-contract.md` to `shared/adapter-interface.md` with all active references updated.
- [x] Write `ContractTests.test_pending_is_typed`, `test_core_result_statuses`, `test_record_shapes`, and `test_schema_refs_are_local`: explicit pending deadline accepted, string `"PENDING"` rejected, four envelope statuses accepted, `SUCCESS` rejected, required fields absent rejected, malformed observation accepted only as `Observation`. Initially run `python -m unittest discover -s builder-kit/tests -p test_contracts.py -v` and retain the expected missing-schema failures.
- [x] Implement the seven schemas and shared field definitions. Use JSON Schema conditions for status-dependent fields and provenance; keep runtime comparisons as named procedural rules, not claims that schema validation compares records.
- [x] Run the same tests after the controller has explicitly provisioned the declared optional dependencies. Expect all assertions passing. Inspect every internal `$ref` without network access; record which shape tests cover only portions of S-14/S-45.
- [x] Review the interfaces against R-01–R-09/R-16/R-18/R-21–R-23, correct mismatches, and commit only this task's accepted files in the scratch checkout.

## Task 2: Complete development rules, records, and profiles

**Files:** modify `templates/runtime/development/{HARNESS.md,workflow.yaml,task-spec.md}`, `shared/{repo-profile.yaml,harness-status.md,adapter-interface.md}`; create `shared/verification-rules.md`, `development/templates/{task-spec.yaml,task-state.yaml,config-snapshot.yaml,transition-request.yaml,gate-decision.yaml,event-log.yaml,invocation.yaml,criterion-review.yaml,observation.yaml}`, `tests/test_development_definitions.py`, and `evidence/development-review.md`.

**Interfaces:** consumes Task 1 schemas; produces RULE-01–RULE-12/RULE-17, development edges, adapter contract, and typed templates. Run records use `development/runs/<task-id>/{task-spec.md,task-spec.yaml,state.yaml,events.yaml,config-snapshot.yaml,configuration/,requests/,invocations/,evidence/}`. `events.yaml` is the committed authority; snapshots are derived.

- [x] Write definition tests asserting the exact R-13 default sequence, distinct failure/stop states, no `capability_bindings`, disabled build/test repair with zero limits, source-only `PREFLIGHT_PASSED → TESTING`, docs `PREFLIGHT_PASSED → SPEC_VERIFIED`, and installed rule references. Run `python -m unittest discover -s builder-kit/tests -p test_development_definitions.py -v` and record expected failures.
- [x] Implement the default sequence and total outcome/stop routes. `BUILD_FAILED` and `TEST_FAILED` each select one of `repair_allowed` or `repair_denied`; compute those mutually exclusive labels by RULE-09. `BLOCKED` and `HUMAN_REQUIRED` resume through recorded-stage reevaluation/invalidation. Restoring a previously earned state requires its still-valid evidence; resumption cannot grant a new success state or bypass its gate. Keep every transition trigger finite and its interpretation documented.
- [x] Implement the record templates and concise development procedure. Document intent-before-dispatch, persisted handles/deadlines, replay identity, event/snapshot reconciliation, writer handoff, stage-specific review, explicit invalidation/adoption, current permission checks, and conditional build/test lineage. Reconstruct a lost TaskState from complete event post-states including configuration adoption and a pending invocation, comparing every field. Define `TOOL` conformance requirements without implementing a state writer.
- [x] Specify target reduction exactly: a known running child retains running status within deadline; once terminal outcomes are due, missing/malformed/mismatched/UNKNOWN wins, then BLOCKED, then FAIL, otherwise PASS. Preserve all findings and prohibit repair while a child is unresolved.
- [x] Run definition tests and conduct concrete rule walkthroughs for the Task 2 cases in the matrix. For each variant record actual inspected inputs, rule IDs, decision, separate follow-up transition, preserved state/history, and limitations in `evidence/development-review.md`; Task 6 will publish per-case records. Do not label the walkthrough as runtime tool execution.
- [x] Review and fix against R-05/R-08–R-17/R-20, then commit the accepted task in the scratch checkout.

## Task 3: Complete maintenance, drift, and recovery

**Files:** modify `templates/runtime/maintenance/{harness-maintenance.md,maintenance-workflow.yaml,templates/harness-update-record.yaml}`, append RULE-13–RULE-16 to `shared/verification-rules.md`; create `tests/test_maintenance_definitions.py` and `evidence/maintenance-review.md`.

**Interfaces:** consumes Tasks 1–2; produces an `UpdateRecord` at `maintenance/updates/<update-id>.yaml` with immutable prior `events` and a derived `current` summary. Ordinary binding/readiness updates publish the canonical profile. Approved migrations publish their inventoried workflow/rule/schema/structural files plus the profile as one configuration revision. Current tasks retain captured configurations.

- [x] Write tests asserting distinct adapter/fact/drift routes, no drift-to-binding-promotion edge, explicit ordinary/approved-migration routes, and stop/resume edges for `REJECTED`, `PENDING`, `HUMAN_REQUIRED`, `FAILED`. Run `python -m unittest discover -s builder-kit/tests -p test_maintenance_definitions.py -v` to observe initial failures.
- [x] Implement inspection/staging and compatibility precedence: known incompatibility REJECTED, otherwise missing evidence PENDING, otherwise unresolved policy HUMAN_REQUIRED, otherwise eligible. All four syntactically valid fixture outcomes can prove compatibility; none proves production success.
- [x] Implement the two documented promotion routes, candidate/base/scope-bound approval, just-before-publication version/before-value comparison, complete configuration publication, safe conditional rollback, and independently recoverable derived status. For migrations capture per-file before/after identities and write ownership; reconcile partial multi-file publication before new work. Preserve newer updates during recovery and retain failed attempts as history.
- [x] Implement watched-source drift publication with identity/version checks, fresh revision for accepted assessments, no-change closeout, optional-capability isolation, and linked corrective updates. Assess the prospective configuration and bind published assessments to that new ID; retain the inspected base and justified revalidation/carry-forward decisions. Assert that readiness is current immediately after accepted publication. A stale review of A cannot alter B.
- [x] Run definition tests and concrete S-30–S-39 walkthroughs, including permission revocation against pinned tasks; record observed outputs and preserved fields. Review against R-05/R-09/R-16–R-19, fix, and commit the accepted task.

## Task 4: Deliver recoverable installation and installed verification definitions

**Files:** modify `builder-kit/{README.md,INSTALLER_SPEC.md,installer/bootstrap-prompt.md,installer/installation-checklist.md}`; create `templates/runtime/shared/{verification-criteria.yaml,conformance-cases.yaml}`, `templates/runtime/installation/installation-record.yaml`, `tests/test_installation_definitions.py`, and `evidence/installation-review.md`.

**Interfaces:** consumes Tasks 1–3; produces the sole canonical catalogue at `templates/runtime/shared/verification-criteria.yaml` and copies it into the target. Installer checklist references IDs and derives status; it is not another mutable catalogue. Applicable conformance definitions are also installed for maintenance without builder access.

- [x] Write tests for exact catalogue IDs, scenario links, template inventory, target-only runtime links, and the typed installation record. Run `python -m unittest discover -s builder-kit/tests -p test_installation_definitions.py -v` and record expected failures.
- [x] Define these mandatory structural subcriteria: `IS-01.files`, `IS-01.schemas`, `IS-02.local_refs`, `IS-02.ownership`, `IS-03.registry`, `IS-03.separation`, `IS-04.graph`, `IS-04.routing`, `IS-05.result_schema`, `IS-05.evidence`, `IS-06.records`, `IS-06.recovery`, `IS-07.sequence`, `IS-07.applicability`, `IS-08.inventory`, `IS-08.assessment`. Each has concrete checks and scenario references. Scope each automated criterion to obligations fully checked under its ID; assign remaining semantic obligations to separately assessed review criteria. No partial check can mark a whole ID PASS. Additional explicit extension subcriteria join aggregation; tests assert the required base set plus unique valid extensions. Automated-capable definitions also permit equivalent review unless the particular evidence obligation requires execution. Accepted integration IDs encode each of the profile, capability and target components as `x` plus lowercase UTF-8 hex, joined with hyphens after `II-`; no normalization is applied, and the original tuple remains in applicability data (Task 4 accepted contract).
- [x] Encode integration assessment from current binding/configuration/compatibility/access evidence, not production PASS. Structure is complete only if every required structural subcriterion is satisfied. Profile aggregation is BLOCKED first, then none assessed → NOT_ASSESSED, then any partial/unassessed → PARTIAL, otherwise READY. Optional unused capabilities do not count. Document evidence requirements for conditional NOT_APPLICABLE.
- [x] Implement discovery, source provenance, scope-aware instruction integration, fresh/resume/existing detection, owned-file hashes, pending decisions, staged structural assessment, activation, and post-activation verification. Preserve changed user files and existing histories; existing live harnesses enter maintenance/migration.
- [x] Populate reusable S-01–S-48 case definitions and all scenario variants in the installed catalogue; retain fixture provenance. Trace fresh install with unknown test, skipped checker, interrupted/user-edited installation, existing instruction conflict, and builder-absent maintenance against actual staged examples. Store review evidence, not automatic PASS placeholders.
- [x] Run definition tests, inspect installer/runtime separation, review/fix R-01–R-07/R-21/R-23 coverage, and commit the accepted task.

## Task 5: Implement the optional read-only checker

**Files:** create `checker/check.py`, `checker/harness_check/{__init__.py,loader.py,schemas.py,checks.py,assessment.py,report.py,cli.py}`, `checker/requirements.lock`, `checker/README.md`, and `tests/{test_loader.py,test_checker.py,test_assessment.py}`.

**Interfaces:** consumes installed definitions and records. Public CLI is `python builder-kit/checker/check.py --repo-root <absolute-path> --harness-root <repo-relative-path> --record <harness-relative-path> --catalogue <harness-relative-path> --format json|text`; defaults for the latter two paths are `installation/installation-record.yaml` and `shared/verification-criteria.yaml`. Output goes to stdout; diagnostics may go to stderr. The checker never creates its own report file; callers redirect output outside the inspected tree.

Internal interfaces: `loader.load_document(path: Path, scope_root: Path) -> dict | list`, `schemas.validate_document(value: object, schema_path: Path, definition: str | None = None) -> list[dict]`, `checks.check_installation(repo_root: Path, harness_root: Path, record_path: Path, catalogue_path: Path) -> dict`, `assessment.summarize(catalogue: dict, assessments: list[dict], profile: dict) -> dict`, `cli.main(argv: list[str] | None = None) -> int`. Diagnostics have stable `code`, `path`, `message`, and `criterion_id` where applicable. Errors use `PARSE_*`, `PATH_*`, `SCHEMA_*`, `REFERENCE_*`, `GRAPH_*`, `REGISTRY_*`, or `PREREQUISITE_*` codes.

- [x] Declare these exact pins: `PyYAML==6.0.3`, `jsonschema==4.26.0`, `attrs==25.4.0`, `jsonschema-specifications==2025.9.1`, `referencing==0.37.0`, `rpds-py==0.30.0`, and `typing-extensions==4.15.0; python_version < "3.13"`. The controller verified non-yanked releases and Python 3.11 compatibility metadata against PyPI and explicitly installed dependencies in an isolated Python 3.14 venv; preserve `/private/tmp/harness-builder-20261004-efv7l2ai/dependency-metadata.json` as release evidence. Also provision the floor-version venv explicitly. Neither installer nor checker installs dependencies; document the review-only path when unavailable.
- [x] Write adversarial loader and subprocess CLI tests with `unittest` and `TemporaryDirectory`: all forbidden YAML/JSON constructs, typed ambiguous values, bad casing, traversal, escaping symlink, remote `$ref`, unreadable input, and dependency absence. Assert invalid data never calls a configured command or reads an outside sentinel. Observe initial failures.
- [x] Implement a restricted SafeLoader with duplicate/merge/tag/cycle rejection and JSON-compatible scalar validation; reject implicit timestamps and ambiguous YAML boolean spellings rather than silently coercing them. Reject duplicate JSON keys/non-finite values. Resolve paths and inspect component casing before file reads; check schema references under the installed schemas directory and register only local schemas.
- [x] Implement automated checks only for `IS-01.files`, `IS-01.schemas`, `IS-02.local_refs`, `IS-03.registry`, `IS-04.graph`, `IS-05.result_schema`, `IS-06.records`, `IS-07.sequence`, `IS-08.inventory`. A PASS covers every obligation defined for that ID. If an obligation is not checked, keep that criterion unresolved; descriptive coverage caveats cannot grant full PASS. Read supplied review assessments to aggregate final status; never turn semantic procedure text into automated PASS. Validate declared fixtures against schemas without invoking an adapter or runtime transition engine. Test a mixed group with automated shape PASS and unresolved semantic review: checker exit 0, structure INCOMPLETE.
- [x] Implement status aggregation and reports, tested against R-07 precedence, invalid PASS evidence, pending review, stale configuration assessments, and method mismatch. Exit 0 means all covered checks passed even when uncovered criteria remain pending; 1 means covered failures, including malformed/unsafe input whose failure was fully diagnosed; 2 means bad invocation, unavailable prerequisites, unreadable input, or an internal failure prevented completion. Preserve available diagnostics if exit 2 takes precedence.
- [x] Run `python -m unittest discover -s builder-kit/tests -v` plus read-only before/after tree-hash assertions. Inspect reports for versions, checked/uncovered IDs, assessed config, semantic limitations, and honest status. Review/fix R-06–R-07/R-22 coverage, then commit the accepted task.

## Task 6: Exercise disposable examples and publish actual evidence

**Files:** create `examples/{README.md,make_examples.py,synthetic_adapter.py}`, `examples/definitions/{compiled.yaml,source-only.yaml,docs.yaml,multi-target.yaml}`, `tests/{test_examples.py,test_conformance_records.py}`, and `evidence/{scenario-results.yaml,native-platform-matrix.yaml,walkthrough.md,checks/}`.

**Interfaces:** consumes Tasks 1–5. `make_examples.py --destination <explicit-empty-directory>` creates all four synthetic repos with complete installed harnesses; it refuses nonempty destinations. `synthetic_adapter.py --request <json> --outcome PASS|FAIL|BLOCKED|UNKNOWN` emits fixture envelopes to stdout and does not execute production commands. Names/commands/evidence are visibly synthetic and use `FIXTURE` provenance. `scenario-results.yaml` contains one or more typed `ScenarioResult` entries per case and no unstated automatic full-scenario verdict.

- [x] Write meaningful example tests asserting complete default/alternative layouts, pending versus ready profiles, all four normalized outcomes, consumed-artifact requirements, and builder-independent installed links. Assert example generation refuses existing user content. Run tests to observe initial missing-example failures.
- [x] Implement the disposable generators and synthetic adapter. Exercise non-Git and dirty-tree snapshots, complete/pending installations, source-only/docs applicability, two required targets, and a separate product/test-source lineage variant. Keep test outputs under a controller-chosen temporary directory.
- [x] Run the checker against the examples from a different working directory with spaces/Unicode and LF/CRLF variants; record exact command, tool/runtime versions, exit status, input identities, stdout/stderr location, and actual results. Hash trees before/after checker runs. No expected-output file is an execution result.
- [x] Carry out the install → development → build-binding replacement → explicit adoption/resume walkthrough using the installed instructions with the builder unavailable, followed by an approved inventoried rule/schema migration using only installed definitions. For each procedural case in the matrix, inspect concrete inputs, apply named rules, record the actual decision/event proposal and preserved fields, compare with expected behavior, and retain reviewer identity and evidence. Schema-validating those authored records is an additional automated check, not proof of runtime enforcement.
- [x] Complete every S-01–S-48 evaluation or leave its exact missing obligation visibly PENDING/BLOCKED. Publish native matrix entries for Windows/macOS/Linux with Python version, dependencies, command and evidence; run macOS on the available native Python 3.11 and 3.14 interpreters, and leave unavailable hosts pending with native reproduction commands. Do not mark Python 3.11 verified from the Python 3.14 run.
- [x] Run the full `unittest` suite and inspect the actual report/evidence files. Review coverage, repair any failed local checks, and commit the accepted task. Passing procedural walkthroughs certify inspected protocol behavior only.

## Task 7: Finish the pilot handoff and release assessment

**Files:** create `builder-kit/pilot/{README.md,report-template.yaml}` and `builder-kit/evidence/release-assessment.md`; update `builder-kit/README.md`, root `README.md`, `docs/{specification.md,acceptance-scenarios.md,implementation-status.md}`, and `tools/check-documents.py` only where new navigation/verification paths require changes.

**Interfaces:** consumes actual Task 6 evidence. Pilot report fields are repository-private installation ID, config identity, scoped task/update IDs, criterion/scenario outcomes, unresolved questions, platform/prerequisites, and evidence references; no private source or evidence is exported by this plan.

- [x] Write a bounded internal pilot procedure: inspect and install, perform one small development task, stage a compatible build-binding swap, then reconcile/resume the pinned task; use a disposable branch or approved private-repo area and the repository's own permissions. Provide entry-point and stop/resume prompts plus a report template. Actual private-repo pilot remains `PENDING` until the user's LLM runs it.
- [x] Reconcile package versions/paths and mark the approved specification/current implementation accurately. Link historical documents as historical without editing the archive. Describe optional checker coverage, procedural writer limitations, native OS/runtime gaps, and all failed/pending obligations explicitly in the release assessment.
- [x] Run `python tools/check-documents.py` and `python -m unittest discover -s builder-kit/tests -v`; retain results. Review root/package README and installer prompt against the actual delivered inventory, with no obsolete flat-template paths or duplicate entry point.
- [x] Perform whole-kit independent review after the seven task reviews, fix material findings and rerun only affected checks. Update `docs/implementation-status.md` from evidence. Commit in the scratch checkout, then let the controller copy accepted delivery files back and report the remaining platform/pilot limitations.

## Requirement and scenario coverage

`A` means an executable assertion on implemented schema/checker/example behavior. `W` means a recorded procedural walkthrough with actual inspected inputs/outputs and named rules. `A+W` requires both separate evidence parts; an automated definition check does not mechanize the workflow. Task 6 publishes all scenario results, including pending native/platform work.

| Requirements | Implementation tasks |
|---|---|
| R-01, R-02, R-03, R-04 | 1, 2, 4, 6, 7 |
| R-05 | 1, 2, 3, 5 |
| R-06, R-07 | 1, 4, 5, 6 |
| R-08, R-09 | 1, 2, 3, 5, 6 |
| R-10, R-11, R-12, R-13, R-14, R-15, R-16, R-17 | 1, 2, 6 |
| R-18, R-19 | 1, 3, 6 |
| R-20 | 2, 6 |
| R-21 | 1, 4, 6 |
| R-22 | 5, 6, 7 |
| R-23, R-24 | 1, 4, 6, 7 |

| Scenario | Owner task(s) | Required coverage and decisive assertion/observation |
|---|---|---|
| S-01 | 4, 5, 6 | A+W: valid pending test; complete structure only after reviews; PARTIAL profile; no invented command |
| S-02 | 4, 5 | A+W: undefined endpoint fails graph/structure; installer withholds activation |
| S-03 | 4, 5 | A+W: permitted actual reviews satisfy criteria with checker skipped |
| S-04 | 4, 5 | A+W: execution obligation cannot pass from LLM assertion |
| S-05 | 2, 5 | A: duplicate workflow binding rejected |
| S-06 | 4, 6 | W: interruption/resume preserves edited file, evidence, and history |
| S-07 | 4, 6 | W: live harness enters maintenance; scoped instruction conflict blocks activation |
| S-08 | 4, 6 | A+W: installed links/definitions complete without builder; development and migration walkthrough |
| S-09 | 3, 5 | A+W: profile precedence and isolated drift impact |
| S-10 | 2, 6 | A+W: declared exact sequence plus criterion/tool/event trace and completion condition |
| S-11 | 2 | W: missing/unmet review criterion refuses success despite tool PASS |
| S-12 | 2 | W: tool FAIL survives LLM PASS; separate failure/repair-stop route |
| S-13 | 2 | W: optional native validation absent without invention |
| S-14 | 1, 2, 5 | A+W: malformed/absent result diagnosed as observation; runtime blocks |
| S-15 | 2 | W: each run/target/config/source/adapter/test-source mismatch denies success |
| S-16 | 2, 5 | A+W: unknown rule/ambiguous edge diagnosed; unresolved verifier blocks progression |
| S-17 | 2 | W: exact replay unchanged; altered replay/stale version denied; no extra invocation/counter |
| S-18 | 2 | W: early request/review criteria and due-stage coverage without future artifacts |
| S-19 | 2 | W: changed spec invalidates affected results and returns to PATTERN_VERIFIED or earlier |
| S-20 | 2 | W: both failure origins stop when repair disabled |
| S-21 | 2 | W: limit 2/used 0 enters repair once, used 1, full preflight/build/test |
| S-22 | 2 | W: exhausted/no-new-evidence/out-of-scope variants stop directly |
| S-23 | 2 | W: shortcut needs declared artifact-validity rule and complete evidence |
| S-24 | 2 | W: restart reconnects saved invocation, no second submission |
| S-25 | 2 | W: dispatch/handle crash reconciles or blocks without blind resubmission |
| S-26 | 2 | W: deadline survives session restart; unknown external effects retained |
| S-27 | 2 | W: stale result, unexpected early change, and expected implementation edit differ correctly |
| S-28 | 2 | W: committed sequence reconstructs snapshot; corrupt/conflicting/uncommitted variants stop |
| S-29 | 2, 3 | W: explicit config adoption/re-evaluation; no blocked-to-success jump |
| S-30 | 3 | W: four valid outcome fixtures establish compatibility and policy-checked promotion |
| S-31 | 3 | W: unsupported/missing/policy variants route REJECTED/PENDING/HUMAN_REQUIRED |
| S-32 | 3 | W: exact approved migration can promote; changed candidate/base requires renewed review |
| S-33 | 3 | W: sourced fact correction eligible; unsupported guess remains pending |
| S-34 | 3, 5 | A+W: unchanged/changed/missing/inaccessible drift; stale A assessment cannot modify B |
| S-35 | 3 | A+W: no drift-to-binding edge; linked update follows normal promotion |
| S-36 | 2, 3 | W: existing task pinned A, new task B, explicit adoption, current revocation blocks dispatch |
| S-37 | 3 | W: stale base/before-values prevent second promotion |
| S-38 | 3 | W: restore only attempt-owned values; preserve newer accepted update |
| S-39 | 3 | W: stale Markdown regenerates without replay/rollback of successful promotion |
| S-40 | 2, 6 | A+W: source-only edge/identity; no counterfeit build artifact/PASS |
| S-41 | 2, 6 | A+W: docs checks support alternate edge; product-code change reclassifies |
| S-42 | 2, 6 | W: all specified terminal mixes and running-child variant; unknown targets block planning |
| S-43 | 2, 6 | W: separate product/test revisions and consumed artifact must all match |
| S-44 | 5, 6 | A: native paths/Unicode/cwd/line endings matrix; unavailable host obligations PENDING |
| S-45 | 1, 5 | A: casing/traversal/symlink/duplicate/tag/type/malformed diagnostics without unsafe read |
| S-46 | 4, 5, 6 | A+W: unavailable prerequisites, no download, covered success distinct from completeness |
| S-47 | 2, 6 | W: FIXTURE provenance denied at execution gate despite valid PASS envelope |
| S-48 | 6, 7 | A+W: document/inventory/version checks plus honest release/platform/pilot review |

## Completion evidence

The release assessment must link actual commands/reports and procedural case records, state which criteria remain unresolved, and keep unavailable native hosts/private-repo pilot pending. All mechanically implemented behavior must have executable evidence; all runtime claims remain procedural unless an installed state tool separately passes its applicable conformance cases. A clean unittest run alone does not establish whole-kit acceptance or native Windows/Linux support.
