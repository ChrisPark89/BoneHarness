# Idea: a harness CLI

**Status:** future direction. Context extraction now has a Python entry point and reusable functions; bounded checks are recorded in the [verification summary](verification.md). Command names below are illustrative.

One CLI could help humans and LLMs operate a repository's installed `.harness/`:

| Possible command | Purpose |
|---|---|
| `harness context <task>` | Get instructions and evidence references for the current stage. |
| `harness status <task>` | Show recorded progress and unresolved checks. |
| `harness logs <task>` | Find relevant failures and supporting evidence. |
| `harness install` | Create and assess a repository-specific harness. |
| `harness configure` | Update repository settings through maintenance. |
| `harness adapter add <skill>` | Connect a skill, check compatibility and update setup status. |

## Prepare the extraction script

Use this separation:

`arguments → reusable Python functions → structured result → text or JSON`

- Keep parsing, selection and validation callable without a CLI or shell subprocess.
- Reuse existing loaders; pass repository/task inputs explicitly.
- Return structured data and diagnostics. Keep printing and process exit handling at the command boundary.
- Keep extraction read-only and usable from the installed harness without the builder project.
- Use portable paths and the existing declared Python dependencies.

A future CLI can call these same functions. Write commands would follow existing installation/maintenance procedures and preserve history and permissions.

Add commands as concrete needs emerge. Packaging, plugin discovery and a general command framework remain future decisions.

[Current implementation plan](implementation-plan.md#next-focused-llm-guidance)
