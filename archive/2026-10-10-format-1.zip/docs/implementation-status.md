# Implementation status

Package layout: the installer uses `builder-kit/`. Project [tests](../tests/README.md), the short [verification summary](verification.md), and [historical records](../archive/verification/README.md) are kept separately. Earlier results describe their recorded source versions.

Updated: 2026-10-08. **The reviewed baseline implementation is delivered.** All seven task reviews and the final whole-kit correction are accepted. I-1 was fixed in `7db46b0`; independent scoped re-review found no new breakage. M-1 fixture formatting is deferred and nonblocking. External platform/tool validation remains pending.

[Workspace guide](../README.md) · [Builder](../builder-kit/README.md) · [Verification summary](verification.md)

## Current update: user-approved skipping

Implementation, independent review and regression verification are complete under the [approved plan](reporting-implementation-plan.md#current-update-user-approved-phase-skipping). Both full suites passed 201 tests, including 23 skip tests; see [verification](verification.md). It adds evidence-backed `USER_SKIPPED` routes to the existing state machine. Both specification phases and all accepted task requirements remain mandatory. The retained demo predates this update. A fresh LLM walkthrough is next; native Windows/Linux checks remain pending.

## Completed update: source evidence

The existing reporter now has a local SourceInventory format, a read-only capture helper and checks against the accepted file scope. The state machine is unchanged. New tasks capture the added files/records. Fifteen focused tests cover source capture, stale evidence, accepted scope, ordering, safe paths and report generation. Testing corrected an outdated report footer. The demo is freshly installed; prior history is archived. See [verification](verification.md) for full-suite results and limits.

## Next: focused LLM guidance

The [design](specification.md#15-planned-update-focused-llm-guidance) and [plan](implementation-plan.md#next-focused-llm-guidance) now have source implementations: situation index, short guides, read-only Python context selection, continuation pages and recovery guidance. Independent source review findings were addressed. New primary guides are 156–269 words. Execution checks now cover the context command, recovery selection and a fresh two-scenario demo; see the [verification summary](verification.md) for results and limits. The current demo has been refreshed with the updated kit; older temporary trials remain historical. Task guides/configuration are captured; old tasks without these captures need matching tools or an explicit migration.

## Current layout implementation (kit 1.1.0)

- [x] Updated actual templates, installer, checker and reporter to `.harness/docs/`, `framework/` and `artifacts/`.
- [x] Consolidated development history into a validated journal; retained five default task files plus referenced evidence and shared immutable snapshots.
- [x] Added fresh-install scaffolding, explicit legacy inspection and refusal of automatic replacement. Setup discovery/activation stays pending until verified.
- [x] Independent review completed; both reported integrity/legacy-schema regressions fixed and rechecked.
- [x] Final frozen full suites: **151 tests passed on each of Python 3.11 and 3.14**, macOS. Original-workspace transfer and retained demo inspection complete; [recorded layout verification](../archive/verification/layout-update/README.md).

## Setup checks and project tests

The full conformance catalogue and its schema now live in `tests/`. New installations retain setup criteria and the optional checker, with no dependency on the project catalogue. Maintenance reuses affected setup checks. Runtime guidance permits the LLM to interpret native tool output with evidence; the saved Result schema remains unchanged. Existing test sources were adjusted. Regression tests and a fresh temporary demo were run for these changes; see [verification](verification.md). The current demo now contains a fresh installation of the updated kit.

## Package simplification

The optional pilot guide and report template have been removed. Installation, development and maintenance use their normal verification; a separate pilot is not a delivery requirement. Earlier pilot references below describe historical work.

## Evidence organization

The root `evidence/` folder is retired. Test inputs live in `tests/fixtures/`; other authoring records are archived under `archive/verification/`. Read [verification.md](verification.md) for the short summary. This cleanup preserves recorded bytes and does not claim a new suite run.

## Reusable demo

- [x] [Tiny JavaScript app and runner](../tests/demo/README.md): one app rooted at `tests/demo/`, with its harness in `.harness/`.
- [x] Installed the updated kit at `tests/demo/.harness/`; preserved the previous demo in the verification archive.
- [x] Retained exactly two scenarios: success and test failure followed by repair. Open `tests/demo/.harness/docs/trial.md` for the short summary and reports.

The runner defaults to `tests/demo/`; automated tests copy only app files into temporary directories. Regression checks now include the single-directory layout and source inventories.

The runner executes real Node preflight/build/test commands. Lifecycle decisions are labelled fixtures; it does not claim accepted specifications, verified approvals or task completion. Replacing `.harness/` leaves the app intact and discards that trial's history.

## Remaining reporting work

- [x] [User-approved phase skipping](specification.md#12-planned-update-user-approved-phase-skipping): typed dispositions, declared routes, reporting and focused checks are implemented. Specification and final specification verification remain mandatory.
- [x] Source inventory implementation and focused execution checks: local file hashes tied to accepted scope, with stale/unsupported evidence exposed.
- [ ] Scoped applicability authority and in-task configuration adoption. Unsupported obligations still prevent positive completion support.
- [ ] Full [report acceptance](specification.md#13-planned-update-human-readable-task-reports), beyond the bounded executed cases. Native Windows/Linux validation remains pending.

These limitations are separate from the completed layout/source work. Existing [reporting](../archive/verification/history.zip#evidence/reporting/README.md) and [older JavaScript trial](../archive/verification/history.zip#evidence/javascript-trial/README.md) records remain historical.

## Historical JavaScript trial (2026-10-05)

- [x] Historical tiny JavaScript calculator and scenario runner; [archived with demo-only tests and generated records](../archive/verification/history.zip#evidence/javascript-trial/README.md) on 2026-10-06. The reusable app above replaces the old demo source; the current bounded harness trial is tracked above.
- [x] **45 scenarios / 24 development states**, with real build/test commands and explicitly labelled fixture histories; [archived results](../archive/verification/history.zip#evidence/javascript-trial/README.md).
- [x] **17 final trial tests passed** on macOS arm64, Python 3.11.16 and Node v24.10.0. All 120 existing tests passed in the earlier 130-test run; its two trial failures were corrected and covered by the final trial module. No final combined 137-test run is claimed.
- [x] Two reporter bugs corrected; independent review findings addressed and accepted. [Verification and review records](../archive/verification/history.zip#evidence/javascript-trial/README.md).

This checks recorded states, phase summaries and evidence handling. It does not establish live LLM obedience, human approval or full reporting conformance. Completion support, N/A authority and user-approved phase skipping remain unfinished. Native Windows/Linux trial execution remains pending.

## Completed baseline work

- [x] Approved [specification](specification.md), 48 [acceptance definitions](acceptance-scenarios.md), revised [plan](implementation-plan.md) and independent [plan review](reviews/implementation-plan-review.md).
- [x] Tasks 1–3: typed schemas, installed development/maintenance instructions, durable records, verification/recovery/publication rules.
- [x] Task 4: one installer prompt, recoverable activation, installed criteria/cases, target-only runtime layout.
- [x] Task 5: optional read-only checker, explicit dependencies, bounded coverage and safe parsing/path/schema checks.
- [x] Task 6: disposable examples, actual synthetic/checker execution, installed-only publication/adoption walkthrough and honest native matrix.
- [x] Task 7: bounded internal pilot/report, release assessment, navigation/inventory/version review and retained actual verification.
- [x] Seven task reviews/fixes; [digest](reviews/implementation-review.md).
- [x] Final independent whole-kit review, I-1 correction and accepted [scoped re-review](reviews/final-rereview.md). [Initial review](reviews/final-review.md) is historical; [decisions](reviews/review-decisions.md) preserve all adjudications.
- [x] First reviewed transfer at `7db46b0`: 284 writes, six obsolete flat templates removed, one identical file retained, 44 archive/research files byte-preserved, no collisions. Original has no Git. [Actual receipt](../tests/fixtures/checks/first-transfer-7db46b0.json).

- [x] Fresh controller full suites from the delivered original workspace: 120 tests on Python 3.14 and 120 on Python 3.11, both exit 0; [3.14 command/source/output record](../archive/verification/history.zip#evidence/checks/final-controller/python314.json), [3.11 record](../archive/verification/history.zip#evidence/checks/final-controller/python311.json).

The builder is an installer kit. The generated `framework/workflows/development/HARNESS.md` and `framework/workflows/maintenance/harness-maintenance.md` operate without it, with separate task/update records and shared definitions.

## Remaining validation and limitations

- [ ] Native Windows/Linux runs; retained native evidence is macOS arm64 Python 3.11/3.14 only.
- [ ] Optional TOOL replay enforcement evidence if a repository binds a state tool.
- [ ] Actual host without Python for the missing-interpreter parts; missing-dependency execution is distinct.
- [ ] Nonblocking M-1 authoring fixture reflow when those contracts are next touched; no release-blocking formatting sweep.

## Evidence

Final corrected-code scratch suites passed **120 tests each** on Python 3.14 (255.635s) and 3.11 (200.961s); exact source/output identities are retained in the [release assessment](../archive/verification/history.zip#evidence/release-assessment.md). The controller also ran both full suites from the delivered original workspace; their exact command/runtime/source/output records are linked above. That baseline closeout changed no code; its historical execution does not validate the new reporter.

The [scenario ledger](../tests/fixtures/scenario-results.yaml) retains 336 records (323 PASS, 13 PENDING), joined to 132 cases / 163 exact mode parts (154 PASS, 9 PENDING). Parts do not certify entire scenarios or unavailable platforms. Checker exit 0, structure, integration readiness and task success are distinct. Adapted repair policy requires a permitted current whole-obligation review; the checker grants no repair permission. Default runtime enforcement is procedural; no tool accuracy guarantee or state engine is supplied.

Earlier [design audit](reviews/2026-10-04-design-review.md), [research](research/README.md) and [archive](../archive/README.md) remain historical and unchanged.

## Original reporting source-review snapshot (2026-10-05)

The table below preserves the original source-only review status. Subsequent execution is recorded in the JavaScript trial above; it does not cover every planned case.

Source inspection covers the explicit map/schema, installed strict I/O, capture/history/identity checks, deterministic derivation, escaped rendering, fixed output/publication failure paths and installer/handoff integration. It provides no executed result. The optional checker now includes all 41 runtime paths/eight schemas, offline descriptor resolution and exact built-in RULE-06 parity. Installation reporting_generator metadata is optional for legacy ledgers and required by new installer guidance; availability and actual validation are independent of structure.

| Section 13 case | Authored behavior / boundary | Execution |
|---|---|---|
| COMPLETE with missing test log | Missing reference, unverified outcome and unsupported completion retained | NOT_RUN |
| Valid user skips build with existing-program evidence | Positive support requires separate section 12 approval/transitions/checks | NOT_RUN; integration pending |
| LLM-only approval or required criterion after skip | Unsupported skip and unresolved coverage retained | NOT_RUN |
| Failed build followed by PASS | Explicit current basis with earlier failures/repairs retained | NOT_RUN |
| Missing events, broken history, conflicting snapshot | Known phases and observed claims retained with uncertainty | NOT_RUN |
| Source/specification changed after evidence | Identity mismatch/stale outcomes visible; original evidence retained | NOT_RUN |
| Review evidence versus required execution | Execution missing stays unresolved; semantic reviews attributed | NOT_RUN |
| Incomplete task / unavailable generator | Derived partial report or REPORT_UNAVAILABLE, stale prior output notice | NOT_RUN |
| Inventory/local resolution/catalogue parity | Installed checklist/checker source includes reporting files and metadata obligations | NOT_RUN |

Opaque historical snapshots still leave source_content_inventory UNCHECKED. The current source-inventory addition supplies a local format/checker covered by the focused tests; see the verification summary. Scoped NOT_APPLICABLE authority is unsupported and remains unresolved. External evidence/custom mechanical rules may be unchecked; hashes do not prove authorship, tool quality or semantic review truth.

At the original source-review closeout, no reporting tests or runtime probes had been executed. The later user-authorized JavaScript trial provides the bounded execution evidence linked above. Its results do not replace the remaining planned cases or establish native Windows/Linux behavior.

Current skip integration is tracked at the top of this page. The historical table above records the original reporting review; it does not override the latest [verification summary](verification.md). Full section 13 acceptance and native platform checks remain separate obligations.
