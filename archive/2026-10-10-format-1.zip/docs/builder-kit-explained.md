# Harness builder kit explained

**Layout:** [human pages](artifact-layout.md) use `.harness/docs/`; installed instructions/tools use `framework/`; process records use `artifacts/`. The reference journal tools store records; they do not enforce workflow gates.

## What you get

This kit helps an LLM create a development harness for your repository. A **harness** is a set of instructions, workflow stages and saved records that guide the LLM through its work.

Your installed harness provides:

- **Development guidance:** agreed requirements and checks at each stage.
- **Progress records:** what has happened, what is blocked and where to resume.
- **Maintenance guidance:** a process for updating tools, repository facts and harness settings.

The LLM adapts the kit to your repository's actual commands, skills and conventions. Missing information stays marked as pending until it is resolved.

## Get started

You need an LLM that can read and edit your repository and access the tools you permit it to use.

1. Give the LLM the `builder-kit/` folder and access to your repository.
2. Use the [installation prompt](../builder-kit/installer/bootstrap-prompt.md). It directs the LLM to inspect the repository, generate its harness and verify the installation.
3. Review the installation report: where the harness was created, what is ready, and what still needs information or configuration.

Installation verification is required. The optional, recommended **installation checker** checks the generated harness's files, configuration and references. It needs Python 3.11 or newer and its listed dependencies, and reports which requirements it checked.

If the installation checker cannot run or leaves a requirement unchecked, the LLM follows the [workflows/verification-criteria.yaml](../builder-kit/templates/runtime/framework/workflows/verification-criteria.yaml). Each criterion states what must be checked and which methods are allowed: LLM review, human review, or an automated check. The LLM selects an allowed method, records the evidence, and leaves anything it cannot verify marked as pending. Required execution checks still need actual runs. The criteria are predefined; the specific review steps or alternative tools depend on your repository.

Only `builder-kit/` is needed from this project. The LLM creates your repository's own instructions and records during installation.

## After installation

Use the harness created inside your repository. The installed root is `.harness/`.

| Your next action | Installed entry point |
|---|---|
| Ask the LLM to develop a feature or fix a bug | `.harness/framework/workflows/development/HARNESS.md` |
| Ask the LLM to update the harness or replace a skill | `.harness/framework/workflows/maintenance/harness-maintenance.md` |
| Check the harness setup status | `.harness/docs/setup.md` |

Harness setup status covers installation completeness and tool readiness. Individual task records are under `.harness/artifacts/development/<task-id>/`. At every handoff, open `.harness/docs/development/<task-id>/report.md` for phase outcomes, issues and links to logs/reviews/artefacts. Follow History to earlier failed attempts and `report.json` for full diagnostics and source identities. Recorded COMPLETE and support from checked evidence are shown separately.

The installed reference reporter needs Python 3.11+ and provisioned dependencies, or a conforming replacement. Installation records reporter availability separately from structure. Regenerate using the command in installed HARNESS.md after resuming or changing evidence. REPORT_UNAVAILABLE means generation could not run; previous reports may be stale.

The reporter compares saved evidence with current files in the accepted source scope. Missing or changed evidence prevents supported completion. Decisions that a requirement does not apply remain unresolved. User-approved skips need the original instruction and a recorded scope review. Checks of records do not prove that every LLM judgment is correct.

Development follows a **state machine**: named stages with rules for moving between them. The LLM interprets tool evidence and saves a common result record, making skills easier to replace. Saved progress and results help the LLM resume interrupted work. Repair loops are available when enabled in the repository's harness settings.

For example, you can request: “Update the harness to use the `new-build-tool` skill.” The maintenance process checks how to invoke the replacement skill, interpret its evidence and use it within repository permissions. Skills can return ordinary output; the LLM records the harness decision with links to the evidence. Compatibility does not prove tool quality.

## How progress is verified

| Verification | What it establishes |
|---|---|
| Installation | The required harness structure exists and its tool connections are assessed. Structure completeness and tool readiness are reported separately. |
| Development | The current task meets the requirements for advancing to its next stage. The coordinating LLM reviews agreed criteria alongside any tool validation. |

You can start using the harness before every tool is connected. Setup status lists missing tools, and work can proceed through stages whose requirements are met. A missing tool pauses the stages that need it; it does not disable the whole harness or count as a successful check.

**User-approved skipping:** If the test skill is missing, you can add it through maintenance or say, “Skip testing for this task.” The harness records `USER_SKIPPED` and continues through the remaining phases whose requirements are met. Specification and final specification verification are mandatory. The task can finish only when evidence satisfies every required specification criterion, including any requirement for test execution. The report links each skip to its supporting instruction.

To add a skill later, use the maintenance flow. New tasks use the new configuration; existing tasks keep their captured configuration. The reference reporter does not yet support changing configuration within a task: start a linked task or use an explicitly verified migration. No reinstallation is needed.

The LLM is responsible for following the rules and recording progress. The kit does not include a program that automatically controls stage changes.

## What the package contains

| Group | When you use it |
|---|---|
| Installation instructions and checklist | To create and verify your repository's harness. |
| Runtime templates | Operating definitions grouped under `framework/`, adapted to the repository. |
| Python checker | Optional automation for inspecting an installed harness. |
| Examples | Optional sample repositories for exploring different setups. |

## File guide

Use this section when you want to understand a particular file. You do not need to read every file before starting. All paths are within `builder-kit/`.

### Installation and navigation

| File | Purpose and reason |
|---|---|
| [README.md](../builder-kit/README.md) | Package overview and links for getting started. |
| [INSTALLER_SPEC.md](../builder-kit/INSTALLER_SPEC.md) | Short ordered installation guide. |
| [installer/installation-reference.md](../builder-kit/installer/installation-reference.md) | Detailed obligations, read by section when the guide directs. |
| [installer/bootstrap-prompt.md](../builder-kit/installer/bootstrap-prompt.md) | Ready-to-use prompt that starts that procedure consistently. |
| [installer/install.py](../builder-kit/installer/install.py) | Creates a fresh `.harness/` scaffold without replacing an existing harness; discovery and reviews stay pending. |
| [installer/installation-checklist.md](../builder-kit/installer/installation-checklist.md) | Readable progress view so missing installation requirements are visible. |

### Development templates

Instructions: `templates/runtime/framework/workflows/development/`. Record templates: `templates/runtime/framework/templates/development/`. Templates describe journal payloads; they are not separate files created for every task.

| File | Purpose and reason |
|---|---|
| [workflows/development/HARNESS.md](../builder-kit/templates/runtime/framework/workflows/development/HARNESS.md) | Operating instructions so development starts consistently. |
| [workflows/context.md](../builder-kit/templates/runtime/framework/workflows/context.md) | How to request parsed, selected context and continuation pages. |
| [workflows/source-evidence.md](../builder-kit/templates/runtime/framework/workflows/source-evidence.md) | Steps for recording which source files evidence covers. |
| [tools/source.py](../builder-kit/templates/runtime/framework/tools/source.py) | Prints a source record for the journal writer; changes no files. |
| [tools/harness_io/source_inventory.py](../builder-kit/templates/runtime/framework/tools/harness_io/source_inventory.py) | Collects file hashes and checks inventory scope/identity. |
| [tools/context.py](../builder-kit/templates/runtime/framework/tools/context.py) | Read-only command entry point. |
| [tools/context_reader.py](../builder-kit/templates/runtime/framework/tools/context_reader.py) | Reusable selection and rendering functions for a future CLI. |
| [workflows/recovery.md](../builder-kit/templates/runtime/framework/workflows/recovery.md) | Resume from saved actions and evidence without blind retries. |
| [workflows/setup.md](../builder-kit/templates/runtime/framework/workflows/setup.md) | Inspect setup criteria and readiness. |
| [workflows/development/workflow.yaml](../builder-kit/templates/runtime/framework/workflows/development/workflow.yaml) | Allowed stages and transitions, including optional repair routes. |
| [templates/development/task-spec.md](../builder-kit/templates/runtime/framework/templates/development/task-spec.md) | Readable task scope and acceptance criteria for review. |
| [templates/development/task-spec.yaml](../builder-kit/templates/runtime/framework/templates/development/task-spec.yaml) | Structured criteria so reviews can reference specific requirements. |
| [templates/development/task-state.yaml](../builder-kit/templates/runtime/framework/templates/development/task-state.yaml) | Current progress snapshot for quick inspection and resumption. |
| [templates/development/event-log.yaml](../builder-kit/templates/runtime/framework/templates/development/event-log.yaml) | Legacy event-list example; current tasks append Event payloads to `history.jsonl`. |
| [templates/development/config-snapshot.yaml](../builder-kit/templates/runtime/framework/templates/development/config-snapshot.yaml) | Captured configuration so harness updates do not silently change an ongoing task. |
| [templates/development/transition-request.yaml](../builder-kit/templates/runtime/framework/templates/development/transition-request.yaml) | Proposed stage change, allowing review before it is accepted. |
| [templates/development/criterion-review.yaml](../builder-kit/templates/runtime/framework/templates/development/criterion-review.yaml) | Review of each requirement so completion has an explanation. |
| [templates/development/gate-decision.yaml](../builder-kit/templates/runtime/framework/templates/development/gate-decision.yaml) | Decision and reasons for allowing or blocking advancement. |
| [templates/development/invocation.yaml](../builder-kit/templates/runtime/framework/templates/development/invocation.yaml) | Planned tool action and execution details so interrupted work can be checked before resuming. |
| [templates/development/observation.yaml](../builder-kit/templates/runtime/framework/templates/development/observation.yaml) | Observed output, including malformed results that cannot count as success. |

### Maintenance and installation templates

Directory: `templates/runtime/framework/`.

| File | Purpose and reason |
|---|---|
| [workflows/maintenance/harness-maintenance.md](../builder-kit/templates/runtime/framework/workflows/maintenance/harness-maintenance.md) | Instructions for updating the harness without losing task history. |
| [workflows/maintenance/maintenance-workflow.yaml](../builder-kit/templates/runtime/framework/workflows/maintenance/maintenance-workflow.yaml) | Explicit stages for inspecting, checking and publishing updates. |
| [templates/maintenance/harness-update-record.yaml](../builder-kit/templates/runtime/framework/templates/maintenance/harness-update-record.yaml) | Change details, checks and history for reviewing or recovering an update. |
| [templates/installation/installation-record.yaml](../builder-kit/templates/runtime/framework/templates/installation/installation-record.yaml) | Installation details and file ownership so an interrupted installation can resume. |

### Shared definitions

Definitions are grouped under `templates/runtime/framework/`. Development and maintenance use the same definitions.

| File | Purpose and reason |
|---|---|
| [config/repo-profile.yaml](../builder-kit/templates/runtime/framework/config/repo-profile.yaml) | Your tools, targets, policies and readiness in one configuration. |
| [adapters/adapter-interface.md](../builder-kit/templates/runtime/framework/adapters/adapter-interface.md) | How the LLM interprets tool evidence and records outcomes so skills can be replaced. |
| [workflows/verification-rules.md](../builder-kit/templates/runtime/framework/workflows/verification-rules.md) | Evidence and decision rules explaining when progress is permitted. |
| [workflows/verification-criteria.yaml](../builder-kit/templates/runtime/framework/workflows/verification-criteria.yaml) | Installation and integration requirements defining completeness. |
| [templates/setup.md](../builder-kit/templates/runtime/framework/templates/setup.md) | Harness setup status: installation completeness, tool readiness and missing configuration. |

Schemas describe expected file formats, making structural mistakes detectable.

| File | Format it defines and why |
|---|---|
| [templates/schemas/common.schema.json](../builder-kit/templates/runtime/framework/templates/schemas/common.schema.json) | Shared fields so definitions stay consistent. |
| [templates/schemas/profile.schema.json](../builder-kit/templates/runtime/framework/templates/schemas/profile.schema.json) | Expected format for your tool choices and repository policies. |
| [templates/schemas/workflow.schema.json](../builder-kit/templates/runtime/framework/templates/schemas/workflow.schema.json) | State machines so stages and transitions can be checked. |
| [templates/schemas/result.schema.json](../builder-kit/templates/runtime/framework/templates/schemas/result.schema.json) | Tool results so success, failure and uncertainty are represented consistently. |
| [templates/schemas/criteria.schema.json](../builder-kit/templates/runtime/framework/templates/schemas/criteria.schema.json) | Requirements and assessments so verdicts match named criteria. |
| [templates/schemas/records.schema.json](../builder-kit/templates/runtime/framework/templates/schemas/records.schema.json) | Saved records so progress and evidence remain interpretable. |

### Optional installation checker

Directory: `checker/`. Use this optional tool to check the installed harness without changing its files.

| File | Purpose and reason |
|---|---|
| [README.md](../builder-kit/checker/README.md) | Usage and coverage limits so results are interpreted correctly. |
| [check.py](../builder-kit/checker/check.py) | Command entry point for inspecting an installed harness. |
| [requirements.lock](../builder-kit/checker/requirements.lock) | Fixed dependency versions for repeatable setup. |
| [harness_check/__init__.py](../builder-kit/checker/harness_check/__init__.py) | Package identity and version for reporting. |
| [harness_check/cli.py](../builder-kit/checker/harness_check/cli.py) | Command arguments identifying what to inspect. |
| [harness_check/loader.py](../builder-kit/checker/harness_check/loader.py) | Compatibility exports for the installed shared reader/parser. |
| [harness_check/schemas.py](../builder-kit/checker/harness_check/schemas.py) | Compatibility exports for the installed local schema resolver. |
| [harness_check/checks.py](../builder-kit/checker/harness_check/checks.py) | The supported structural and consistency checks. |
| [harness_check/assessment.py](../builder-kit/checker/harness_check/assessment.py) | Combines assessments into readiness statuses. |
| [harness_check/report.py](../builder-kit/checker/harness_check/report.py) | Reports findings and uncovered requirements. |

### Optional examples

| File | Purpose and reason |
|---|---|
| [examples/README.md](../builder-kit/examples/README.md) | Instructions for inspecting disposable examples. |
| [examples/make_examples.py](../builder-kit/examples/make_examples.py) | Generates example repositories for demonstrations. |
| [examples/synthetic_adapter.py](../builder-kit/examples/synthetic_adapter.py) | Simulates tool results to demonstrate interface handling. |
| [examples/definitions/compiled.yaml](../builder-kit/examples/definitions/compiled.yaml) | Demonstrates a build-based repository with test discovery pending. |
| [examples/definitions/source-only.yaml](../builder-kit/examples/definitions/source-only.yaml) | Demonstrates testing without a build artifact. |
| [examples/definitions/docs.yaml](../builder-kit/examples/definitions/docs.yaml) | Demonstrates documentation work with different checks. |
| [examples/definitions/multi-target.yaml](../builder-kit/examples/definitions/multi-target.yaml) | Demonstrates a task covering multiple targets. |

### Installed reporting files

| File | Purpose and reason |
|---|---|
| [templates/schemas/task-report.schema.json](../builder-kit/templates/runtime/framework/templates/schemas/task-report.schema.json) | Defines report data, phase maps and legacy display metadata separately from tool outcomes. |
| [workflows/reporting-legacy-baseline.json](../builder-kit/templates/runtime/framework/workflows/reporting-legacy-baseline.json) | Preserves the exact supported old-workflow fingerprint/map so old tasks cannot inherit a customized current map. |
| [tools/harness_io/__init__.py](../builder-kit/templates/runtime/framework/tools/harness_io/__init__.py) | Identifies the installed shared I/O package. |
| [tools/harness_io/loader.py](../builder-kit/templates/runtime/framework/tools/harness_io/loader.py) | Reads scoped bytes and parses strict JSON/YAML safely. |
| [tools/harness_io/schemas.py](../builder-kit/templates/runtime/framework/tools/harness_io/schemas.py) | Resolves installed schemas locally without network access. |
| [tools/requirements.lock](../builder-kit/templates/runtime/framework/tools/requirements.lock) | Pins the reference reporter dependencies for explicit provisioning. |
| [tools/reporting/__init__.py](../builder-kit/templates/runtime/framework/tools/reporting/__init__.py) | Identifies the installed reporting package. |
| [tools/reporting/evidence.py](../builder-kit/templates/runtime/framework/tools/reporting/evidence.py) | Captures records/identities and checks references and history. |
| [tools/reporting/summary.py](../builder-kit/templates/runtime/framework/tools/reporting/summary.py) | Derives phase outcomes, coverage and fixed summary wording. |
| [tools/reporting/render.py](../builder-kit/templates/runtime/framework/tools/reporting/render.py) | Renders escaped Markdown with links and publication identities. |
| [tools/report.py](../builder-kit/templates/runtime/framework/tools/report.py) | Generates the fixed report pair and reports availability/publication failures. |
| [templates/development/task-report.md](../builder-kit/templates/runtime/framework/templates/development/task-report.md) | Defines the compact report layout; the LLM does not choose its verdicts. |


### Compact storage tools

| File | Purpose and reason |
|---|---|
| [tools/journal.py](../builder-kit/templates/runtime/framework/tools/journal.py) | Appends typed records and derives the state view; it does not approve transitions. |
| [workflows/development/journal-protocol.md](../builder-kit/templates/runtime/framework/workflows/development/journal-protocol.md) | Record identities, integrity checks and interruption recovery. |
| [tools/harness_io/journal.py](../builder-kit/templates/runtime/framework/tools/harness_io/journal.py) | Shared journal parsing and storage implementation. |
