# Harness layout

**Kit 1.1.0 layout.**

```text
.harness/
  README.md                   # Start here
  docs/                       # HUMAN READING AND REVIEW
    setup.md
    development/<task>/       # spec.md and report.md
    maintenance/<update>.md
  framework/                  # INSTALLED HARNESS
    config/                   # Settings and bindings
    workflows/                # Instructions and rules
    adapters/                 # Skill interfaces and normalizers
    templates/                # Templates and schemas
    tools/                    # Checkers and report generator
  artifacts/                  # PROCESS RECORDS — usually ignore
    installation/
    configurations/
    development/<task>/       # State, history, report data and evidence
    maintenance/<update>/     # Update records and evidence
```

## What humans read

| Page | Answers |
|---|---|
| `README.md` | Where do I start? |
| `docs/setup.md` | What is ready, missing or blocked? |
| Task `spec.md` | What must this task achieve? |
| Task `report.md` | Phase outcomes and issues? |
| Maintenance summary | Harness changes and compatibility? |

Each page: **maximum 200 visible words**, tables/bullets and direct evidence links.

## Process records

- The LLM starts at the situation index, follows a short guide, and uses `framework/tools/context.py` for parsed context. Humans inspect `framework/` for harness changes.
- Project regression tests stay outside the installed harness. Setup checks are reused after harness updates.
- A task has five default files: `spec.md`, `report.md`, `state.json`, `history.jsonl`, `report.json`.
- Keep necessary logs/snapshots once under `artifacts/` for evidence and recovery.
- Create files when needed. No placeholder request/design files or routine reporter console logs.
