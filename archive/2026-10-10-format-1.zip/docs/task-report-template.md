# Task report template

**Human report layout.** Output: `.harness/docs/development/<task>/report.md`. Detail: `.harness/artifacts/development/<task>/report.json`. The generator fills this view from captured records; the LLM does not choose statuses or invent the summary. The rendered page is limited to 200 visible words.

## Task report: {{task_id}}

{{specification_link}}

**Summary:** {{derived_summary}} Validated state: {{recorded_state}}.
**Record checks:** {{check_result}}.

| Phase | Result | Evidence |
|---|---|---|
| Baseline | {{status}} | {{link}} |
| Research | {{status}} | {{link}} |
| Pattern review | {{status}} | {{link}} |
| Specification | {{status}} | {{link}} |
| Verification plan | {{status}} | {{link}} |
| Implementation plan | {{status}} | {{link}} |
| Implementation | {{status}} | {{link}} |
| Preflight | {{status}} | {{link}} |
| Build | {{status}} | {{link}} |
| Testing | {{status}} | {{link}} |
| Specification verification | {{status}} | {{link}} |
| Final review | {{status}} | {{link}} |

**History:** {{failures}} earlier failures; {{repairs}} repairs; {{tool_failures}} tool failures. {{attempt_link}}

{{diagnostics_link}} · {{criteria_link}} · {{sources_link}}

Tool claims do not establish phase success. See diagnostics for unchecked or failed evidence.

## Generator requirements — LLM implementation guidance

- Show an unsupported saved state separately as a linked, unverified claim; it must not appear validated.
- Link the sibling `spec.md` as **Specification**.
- Include every phase in the task's pinned workflow, including added phases. The rows above show the default work phases; include repair activity when present. A missing record produces `NOT_RECORDED`, not an omitted row.
- Use fixed wording for the summary, counts and issue descriptions. Keep each row compact; include a tool claim separately from phase support when present. Link full findings instead of pasting logs. If there are more than three open issues, show their total and link the complete list.
- Derive `PASS`, `FAIL`, `BLOCKED` or `IN_PROGRESS` only from matching recorded decisions, results and reviews. Use `UNVERIFIED` when the evidence needed to support a recorded outcome is missing, stale, inaccessible or inconsistent; show the original claim alongside its unverified status.
- Supported `USER_SKIPPED` requires a scoped PhaseDisposition, original instruction evidence and a declared skip route. Unsupported assertions remain `UNVERIFIED`. Specification and final specification verification cannot be waived. Scoped `NOT_APPLICABLE` authority is unsupported in current records; those claims remain unresolved.
- Evidence links identify the basis: **execution log**, **artefact**, **LLM review**, **human review** or **user decision**. Keep reviewers' identities in the linked record. A review-only phase is not reported as an executed test.
- Keep earlier failures and repairs accessible even after a successful retry. Their presence is included in the history line. Unverified failure/repair claims are counted separately from supported history; fixture claims never become verified repairs.
- A recorded `COMPLETE` with insufficient evidence must produce a summary such as **“Completion is recorded, but supporting evidence is incomplete.”** Never copy the LLM's completion statement into the summary as a verified conclusion.

`Record checks` reports `CONSISTENT`, `ISSUES_FOUND` or `UNVERIFIABLE` for the generator's declared checks. It checks records and evidence references; it does not independently prove every LLM review judgment. Full generation and evidence rules are in [the reporting design](specification.md#13-planned-update-human-readable-task-reports).

The reference reporter checks SourceInventory records against accepted source scope and current file contents. Missing, conflicting or outdated source evidence prevents supported completion. This does not establish tool execution or semantic correctness.
