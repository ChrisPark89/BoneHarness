# Repo-specific harness builder: consolidated design

**Current design, updated 2026-10-08.** For human review, start with the [short layout guide](artifact-layout.md). This specification contains detailed installer/runtime requirements.

**Delivery boundary:** kit 1.1.0 implements the `.harness/docs/`, `framework/` and `artifacts/` layout, consolidated development journal and compact split reports. Section 12 user-approved skipping is implemented and covered by review and regression tests; see [verification](verification.md). Local source-inventory verification is implemented; scoped applicability authority and in-task configuration adoption remain unsupported by the reference reporter. Existing installations require explicit maintenance; the fresh installer refuses replacement. Use the installed guides for runtime work.

**Focused guidance:** [section 15](#15-planned-update-focused-llm-guidance) defines the situation index, short procedures, parsed context extraction and recovery guide. Source implementation and bounded execution checks are complete; see [verification](verification.md) for limits.

All reporting source reviews are accepted, with bounded execution evidence in the [archived JavaScript trial](../archive/verification/history.zip#evidence/javascript-trial/README.md). That trial predates the redesign. The [current two-scenario demo](../tests/demo/README.md) exercises the new layout with real commands and labelled workflow fixtures. See [implementation status](implementation-status.md) for actual coverage and remaining obligations.

## Read this first

The deliverable is an installer kit that an LLM can use to create a harness inside a private repository. That generated harness is the only guide used for subsequent development and harness maintenance. Unknown repository facts stay visible and pending; they do not prevent generating a complete skeleton.

The everyday experience has three entry points:

1. **Install:** give the LLM the builder README and installation prompt. It inspects the repo, generates the harness, and reports what is ready and what needs information.
2. **Develop:** ask the LLM to make a change using the installed harness. It follows the selected workflow and checks evidence against the task specification before advancing.
3. **Maintain:** say, for example, “Replace the build tool with the `new-build-tool` skill.” The installed maintenance flow stages, checks, promotes, and records the change.

The default development sequence and optional repair loops are retained. Installation verification remains required; the Python checker is optional and highly recommended. At runtime, tool validation and the coordinating LLM's separate criterion review both contribute evidence. A configured runtime state tool records transitions; otherwise the LLM follows the same recording protocol and reports that enforcement is procedural.

This document consolidates [the review findings](reviews/2026-10-04-design-review.md) and the accepted maintenance/verification decisions. It replaces the earlier [maintenance-only design](../archive/2026-10-03-maintenance/design.md) as the design authority. The companion [acceptance scenarios](acceptance-scenarios.md) define expected behavior; they are not claims that an implementation has passed.

## 1. Scope and boundaries

**R-01 — Installer/runtime separation.** The builder contains installation instructions, runtime templates, installation criteria, optional checker, and reference examples. The installer adapts the templates into self-contained repo-specific instructions. Runtime instructions, schemas, workflow rules, and required procedures must be present in the target repo or explicitly bound to accessible approved tools. Runtime operation must not require builder paths, private authoring notes, or this design document.

**R-02 — Adaptation with evidence.** The installer reads repository and nested instructions, source structure, build/test configuration, CI definitions, and relevant documentation. It records sources for consequential facts and asks about unresolved material choices. It must not invent commands, approval policy, completion policy, target coverage, credentials, or tool availability. A pending value is valid configuration only where the schema explicitly permits it and defines the resulting stop behavior. A Git commit is not required: a documented file/content snapshot can identify a non-Git repo or dirty tree.

**R-03 — Small core.** The kit supplies rules, templates, examples, and optional installation checks. It does not require a particular LLM vendor, agent framework, skill packaging standard, CI system, scheduler, database, cloud service, or mandatory second agent. It does not implement a universal production build/test runner. Repository-specific adapters supply execution details. An existing skill can keep its native output. The coordinating LLM may interpret logs, exit status, reports or artifacts through a documented procedure; a normalizer script is optional. Keep the supplied tested core unchanged where possible and customize repository configuration and skill bindings.

The installation host must be supported on Windows, macOS, and Linux. Production tools can run elsewhere; each adapter declares its execution environment. Portability means the same documented rules and explicit prerequisites, not that every model or local tool can operate in every environment.

## 2. Installed layout and authority

**R-04 — Separate instructions and records.** Use this target layout; see section 14 for the file budget and migration requirements:

```text
.harness/
  README.md                         # short human index and LLM entry links
  docs/                             # generated HUMAN READING AND REVIEW
    setup.md                        # harness setup readiness
    development/<task-id>/          # spec.md and report.md
    maintenance/<update-id>.md      # update outcome and readiness change
  framework/                        # INSTALLED HARNESS definitions only
    config/                         # repository settings and skill bindings
    workflows/                      # development/maintenance instructions and rules
    adapters/                       # skill interfaces and normalizers
    templates/                      # document/record templates and schemas
    tools/                          # checkers and report generator
  artifacts/                        # PROCESS RECORDS — usually ignore
    installation/                   # inventory, assessments and evidence
    configurations/                 # immutable shared configuration snapshots
    development/<task-id>/          # state, history, report data and evidence
    maintenance/<update-id>/        # update history, recovery records and evidence
```

All harness-owned installed/generated files stay below `.harness/`. Read and respect existing repository instructions; installation must not create or edit root instruction files or add a root pointer. Hand off the explicit installed development and maintenance entry points. An unresolved instruction conflict remains a pending decision.

Installed `framework/` contains canonical definitions, never task/update results or generated setup reports. Installation records are retained evidence, not installer operating instructions. Install applicable structural/integration criteria and the optional checker for later maintenance. The full conformance catalogue and its schema belong only in this project's tests; neither they nor the builder's operating checklist are installed. Scenario IDs in criteria are traceability labels, not dependencies. Reuse affected setup checks for updates; changed core scripts or workflow behaviour need focused verification. Actual maintenance assessments belong in `artifacts/maintenance/`.

**R-05 — One source for each fact.** The installed `framework/config/repo-profile.yaml` owns active adapters, capability readiness, workflow-profile selection, permissions, configured state writer, and source references. Workflow files own transition definitions and reference capability IDs; they contain no second mutable adapter registry. `docs/setup.md` is rendered from recorded assessments and identifies the configuration revision it describes. It reports harness setup readiness, not development-task progress. A stale report must be refreshed or treated as stale, never used as newer authority than its inputs.

Configuration identity covers profile, workflow, rule/schema, and adapter definition versions/content identities. Pin those definitions for each task. If a referenced skill can change in place, record a content identity and detect changes before reuse; a path alone is insufficient. Record external service version information when available and its limitations when not available.

For this initial design, any canonical profile change, including published readiness assessment changes, advances its configuration revision. The task's pinned copy remains unchanged. Assessment publication uses the same version/before-value conflict check as binding changes; this simple rule avoids introducing a second revision system.

## 3. Installation criteria and status

**R-06 — Evidence-backed installation progress.** Each criterion has `id`, `category`, `required`, `description`, `allowed_methods`, `result`, `method`, `evidence_refs`, and `reason`. Categories are `STRUCTURE` and `INTEGRATION`. Results are `PENDING`, `PASS`, `FAIL`, `BLOCKED`, or `NOT_APPLICABLE`. Methods are `AUTOMATED`, `LLM_REVIEW`, or `HUMAN_REVIEW`; record the actual tool/reviewer identity. Mixed assessments use separate subcriteria. `NOT_APPLICABLE` needs an allowed applicability rule and its evidence. Every `PASS` needs evidence.

The canonical criterion catalogue is shipped with the kit. Installation records store results keyed by catalogue version and ID. Checklist boxes and status tables are derived views; a manually checked box cannot override a failed or unresolved criterion.

Mandatory structural groups are:

| ID | Required checks |
|---|---|
| IS-01 | Generated file inventory, required artifacts, and valid typed configuration; pending values represented explicitly. |
| IS-02 | Target-only runtime links, correct paths/casing, and resolved repository entry-point/instruction ownership. |
| IS-03 | One canonical binding registry and separated development/maintenance records. |
| IS-04 | Defined state/transition/rule IDs, valid endpoints, deterministic routing, and explicit failure/stop paths. |
| IS-05 | Adapter/result and criterion record definitions, identity/evidence rules, and compatibility boundary. |
| IS-06 | Task and maintenance persistence, resume, invalidation, promotion, and rollback rules. |
| IS-07 | Default development sequence, disabled-by-default repair loops, and explicit workflow adaptations. |
| IS-08 | Installation provenance, progress/resume inventory, correct criterion aggregation, and status report. |

Each group must have concrete subcriteria. Project documentation maps them to acceptance scenarios; installed criteria retain those IDs only for traceability. The optional checker reports only subcriteria it actually checks. Semantic review of installed procedures is permitted where the catalogue permits review; it must identify the procedure and inspected trace. A criterion requiring execution needs execution evidence. Pending adapter configuration can pass its structural representation check without passing integration checks.

**R-07 — Distinct status dimensions.** Structure is `STRUCTURE_COMPLETE` only when every required structural subcriterion is satisfied; otherwise `INCOMPLETE`. For a permitted conditional subcriterion, satisfaction can be justified `NOT_APPLICABLE`; unconditional structural requirements cannot be waived.

Integration readiness is assessed per supported workflow profile and required target set:

1. `NOT_ASSESSED` when no current assessment exists.
2. `BLOCKED` when a known access/policy/authorization restriction prevents a required capability.
3. Otherwise `PARTIAL` when any required capability is pending, unavailable, incompatible, or needs drift review.
4. Otherwise `READY` when all applicable required capabilities are configured and compatible under current policy.

Report each profile separately. Aggregate in this exact order: any profile `BLOCKED` means overall `BLOCKED`; otherwise no assessed profile means `NOT_ASSESSED`; otherwise any `PARTIAL` or unassessed supported profile means `PARTIAL`; otherwise `READY`. Optional unused capabilities do not lower a profile's readiness. A ready profile does not certify tool quality or the outcome of a task. Tool outcomes and LLM criterion verdicts belong to their individual runs.

Capability configuration uses `CONFIGURED`, `PENDING_DISCOVERY`, `UNAVAILABLE`, or `NOT_APPLICABLE`; compatibility uses `NOT_ASSESSED`, `COMPATIBLE`, `INCOMPATIBLE`, or `NEEDS_REVIEW`. `NOT_APPLICABLE` is scoped to a profile/target with evidence; it is not a global exemption from a required stage.

## 4. Adapter interface and evidence

**R-08 — Common saved result with conditional fields.** This format belongs to the harness record, not the tool's native output. The LLM may interpret ordinary output using the pinned binding procedure, retaining original evidence and identifying its interpretation in the saved summary. Invocation records supply context identities; the LLM cannot invent them. The versioned result envelope requires: `interface_version`, `capability`, `adapter`, `run_id`, `task_id`, `revision`, `status`, and `evidence.reference`/`evidence.summary`. Status is exactly `PASS`, `FAIL`, `BLOCKED`, or `UNKNOWN`. Installed bindings declare expected adapter identity/version, input schema, native validation availability, side effects, permissions, invocation/reconciliation procedure, and result normalization. Required execution deadlines and reconciliation settings may stay pending during installation but must be resolved before dispatch.

The invocation record supplies expected identities: task, run/request, capability, adapter definition, configuration, source snapshot, selected targets/environments, and consumed artifacts or test-source revisions. The gate compares results with this record. `revision` must identify the actual inputs, including relevant uncommitted files; a base commit alone is insufficient for modified work. Capability extensions add target results and artifact/test lineage where needed.

An artifact is required for a successful build only when downstream stages consume one. A failed build does not need to invent an artifact. Source-based tests identify their source snapshot instead. Required fields, types, allowed values, and conditional requirements are expressed in versioned schemas. Extra capability fields use declared extensions; they must not replace or weaken core fields.

Preserve raw results and native-validation evidence when supplied. Plain output can support a saved Result through the declared interpretation procedure. If evidence cannot support an outcome, record an observation with an `UNKNOWN` interpretation and diagnostics. Do not silently repair invalid structured output or invent a tool-reported outcome. A result grounded in actual invocation evidence uses `EXECUTION` provenance even when the LLM records it; the separate specification review uses `REVIEW`. An interpretation alone proves neither execution nor specification compliance.

**R-09 — Compatibility checks format, routing, and policy.** Assess whether native output can be interpreted into an evidence-backed saved result, identities and evidence can be supplied, every supported outcome has a safe route, and invocation fits policy. Fixtures for all four outcomes may establish these interface properties. Label their provenance `FIXTURE`. An execution criterion requires `EXECUTION` evidence from its actual invocation; a criterion whose declared method is review permits actual `REVIEW` evidence. Neither accepts a fixture as evidence that real task work was completed. A structurally valid `FAIL`, `BLOCKED`, or `UNKNOWN` can pass compatibility checks while preventing development advancement.

Check precedence: known structural incompatibility means `REJECTED`; missing evidence without demonstrated incompatibility means `PENDING`; a required policy decision means `HUMAN_REQUIRED`; only completed checks and resolved policy permit promotion. Record all findings even when one determines the route. Unsupported interface versions can instead enter an explicit migration request; that request must supply and check actual interface support before promotion.

## 5. Runtime gates and LLM review

**R-10 — Two assessments, one recorded decision.** Before implementation, capture accepted specification/design versions, criterion IDs, scope, and verification methods. At each gate, use applicable tool results/native validation and have the coordinating LLM separately inspect the relevant work and evidence against those criteria. Prior to `SPEC_READY`, use the request and installed stage criteria. At `SPEC_VERIFIED`, reconcile the full required acceptance matrix.

LLM review records criterion-level `PASS`, `FAIL`, `BLOCKED`, `PENDING`, or justified `NOT_APPLICABLE`, evidence references, and unresolved findings. Repeating the tool's summary is insufficient. Review only criteria due at that stage; a build gate must not demand test evidence deliberately produced later. Optional native validation can be absent without an invented result. Required checks cannot be substituted by LLM opinion.

A tool `PASS` with an unmet criterion cannot advance the gate. An LLM `PASS` cannot override a required tool `FAIL`, `BLOCKED`, `UNKNOWN`, or missing result. No second agent or automatic duplicate execution is required. Accepted spec/design changes are recorded explicitly and trigger re-evaluation of affected evidence; requirements cannot silently be rewritten to justify a result.

**R-11 — Explicit transition protocol.** Requests, decisions and reviews are logical records, not mandatory separate files. Development stores them as typed entries in the section 14 journal. A transition request contains task/update ID, request ID, expected current state and state version, transition ID, pinned configuration identity, accepted spec/design identity where applicable, and evidence/review references. The gate returns `ALLOW`, `DENY`, or `BLOCKED`, with rule-level findings and the expected destination or resolution route.

| Decision | Meaning and recording |
|---|---|
| `ALLOW` | The requested transition is declared, uniquely applicable, and its mandatory guards are satisfied. The single writer may commit it against the expected state version. |
| `DENY` | The request is invalid or positively fails a rule, for example wrong state, stale evidence, failed criterion, or stale state version. Record refusal; preserve state. Apply any declared failure/remediation transition separately with its own evidence. |
| `BLOCKED` | Required information, evidence, configuration, or authority is unresolved. Record the missing prerequisite; use a declared stop transition when a workflow stop is warranted. |

Gate decisions and workflow states are separate fields. A failed success request never silently becomes a successful failure-state mutation. Repeating a committed request ID returns its recorded outcome without creating another event. A reused request ID with different inputs is denied.

The installed rule catalogue gives each rule an ID, precise inputs, pass/fail/unknown conditions, verification method, and failure route. Built-in rules cover expected state/version, schema validity, invocation/source/target/configuration identity, required tool outcomes, criterion coverage, applicability, permissions/approval, and retry budget. Repo extensions must define the same information. Free-form expressions are documentation, never executable code. Unknown rule IDs or unresolved verifier bindings block progression; multiple applicable outcome routes are a configuration error and block progression.

**R-12 — One state writer.** Record writer mode `TOOL` or `LLM_PROTOCOL` and writer identity per task/update. A configured state tool validates and records requested transitions; action skills return evidence and cannot independently update harness state. When absent, the coordinating LLM follows the protocol and identifies it as procedural enforcement. The rules do not claim to prevent bypass without host/CI enforcement. Writer handoff requires a recorded, quiescent transfer after checking the latest state; two concurrent writers are unsupported and must stop on detected conflict.

## 6. Development stages, stops, and repair

**R-13 — Default workflow.** Retain:

```text
NEW → BASELINED → RESEARCHED → PATTERN_VERIFIED → SPEC_READY
→ TEST_READY → PLAN_READY → IMPLEMENTED → PREFLIGHT → PREFLIGHT_PASSED
→ BUILDING → BUILD_PASSED → TESTING → TEST_PASSED
→ SPEC_VERIFIED → READY_FOR_REVIEW → COMPLETE
```

`TEST_READY` means the verification plan exists; it does not require successful tests before implementation. `PATTERN_VERIFIED` permits an evidence-backed finding that no reusable pattern applies. Completion follows the installed repository completion policy; if unknown, stop at the relevant gate with a decision request. `COMPLETE` does not itself authorize publication, deployment, or merging.

| Stage group | Evidence required before the next success state |
|---|---|
| Baseline and research | Input snapshot, working-tree inventory, relevant instructions, sources, findings, and unresolved questions with impact. |
| Pattern/specification | Applicable patterns or justified absence; accepted spec/design, scope/non-goals, observable criteria, acceptance authority. |
| Test/implementation planning | Method and evidence planned for each criterion, target coverage, implementation tasks mapped to criteria, scope and dependencies. |
| Implementation/preflight | Actual change identity and scope; required preflight checks on that identity. |
| Build/test | Actual invocation, usable matching results, required artifact/source lineage and target coverage, stage-relevant LLM review. |
| Final verification/review | Complete criterion mapping, evidence freshness, diff review, unresolved risks, documentation decision, and recorded completion condition. |

Early planning exposes known missing build/test prerequisites before expensive execution. It may proceed through preparatory stages when their own prerequisites are met; it cannot pass a missing execution gate.

**R-14 — Total outcome routing.** For an active preflight/build/test invocation: a matching `PASS` plus satisfied stage criteria permits its success state; a matching `FAIL` records the respective `PREFLIGHT_FAILED`, `BUILD_FAILED`, or `TEST_FAILED`; `BLOCKED`/`UNKNOWN`, absent results after reconciliation/deadline, malformed results, or stale identity lead to `BLOCKED` with diagnostics and retained source state. While an invocation is genuinely running within its deadline, remain in the running state. A tool `PASS` with unmet or insufficient LLM criteria leaves its success transition uncommitted and moves to `BLOCKED` with the specific criterion remediation needed.

`PREFLIGHT_FAILED` defaults to `HUMAN_REQUIRED`. `BUILD_FAILED` and `TEST_FAILED` each have exactly two routes: permitted repair or `HUMAN_REQUIRED` with a reason. Other unmet gate prerequisites retain the current state while being resolved or use the declared `BLOCKED`/`HUMAN_REQUIRED` stop. Every nonterminal state must declare resolution/stop behavior; missing data cannot silently dead-end or advance.

**R-15 — Optional bounded repair.** Repair is allowed only when enabled for the originating failure, a positive configured budget remains, new diagnostic evidence or a materially revised evidence-grounded hypothesis exists, and proposed actions fit scope/permissions. Otherwise stop directly from the failed state. Entering `REPAIRING` increments that failure-origin counter once in the committed event; restart does not reset it. Repeated unchanged failure/hypothesis means no progress. Unavailable execution budgets/deadlines block dispatch. The default is disabled with zero automatic attempts.

Repair returns through `PREFLIGHT`, then a fresh build and tests. A test-only shortcut needs a declared profile rule and evidence that every consumed artifact remains valid. Separate persisted invocation/time budgets bound expensive calls and waits; repair budget is not permission for unbounded submissions. Budget increases require an explicit recorded decision under repository policy, never an automatic reset.

## 7. Durable state, resumption, and invalidation

**R-16 — Persist outside the conversation.** A task stores: current state/version, writer identity/mode, profile and pinned configuration, input snapshot, accepted spec/design versions, selected targets, criterion verdicts, repair/invocation counters, pending invocation intent/handle/deadline, stop reason, stopped-from state, and evidence references.

For development, preserve an ordered `artifacts/development/<task-id>/history.jsonl`; derive `state.json` from its committed events. Stable entry identities keep requests, reviews and results directly referenceable without separate files. Define journal schema/version, integrity checks and partial-write recovery before migrating readers or writers. Each committed event identifies its request, previous version, next version/state, timestamp, actor, evidence, and decision. A current snapshot is derived from committed events. Maintenance records use the same principle with an `events` list and a separate current summary; updating a scalar summary does not rewrite prior events. Uncommitted proposals and torn/inconsistent records are reconciled before further actions. A tool implementation must serialize writes; procedural mode must detect mismatches and stop rather than claim concurrency protection.

Before an external action, persist invocation intent with a unique request ID and inputs. Use tool idempotency keys when available. Persist its returned handle before continuing. After a crash between dispatch and handle recording, query by request ID or obtain reconciliation evidence; do not claim exactly-once execution or blindly resubmit when the outcome is unknown. Persist elapsed/deadline information across restarts.

On resume: restore and reconcile the event history/current snapshot; verify writer and pinned identities; inspect any pending external operation; apply invalidation if needed; then request a declared resume transition. `BLOCKED` and `HUMAN_REQUIRED` retain their stopped-from state and specific resolution evidence. Resumption cannot grant a newly earned success state; restoring an already earned state requires its evidence to remain valid. If the input/configuration/spec is unchanged, resume at the recorded stage to reevaluate its gate or reconnect; otherwise use the invalidation target below. A cancelled operation does not imply its external effects were undone.

**R-17 — Invalidate affected evidence explicitly.** Keep past reports; mark them superseded for affected criteria/stages. Input identity includes relevant source, uncommitted changes, test sources, targets/environment, and consumed artifacts.

| Change | Conservative resume target and action |
|---|---|
| Accepted task scope/spec/design changes | Return to `PATTERN_VERIFIED`; reaccept the revised specification and redo dependent verification/implementation planning. Research/pattern changes may require earlier return. |
| Unexpected baseline/source changes during research, planning, or implementation | Reassess affected assumptions and return to the earliest invalidated stage; if impact is unknown, return to `NEW` and capture a new baseline. Ordinary in-scope task implementation edits are expected and are captured at `IMPLEMENTED`; they do not restart the workflow merely for changing files. |
| Product/test source changes after implementation | Return to `IMPLEMENTED`; repeat preflight/build/test under the selected profile. A declared dependency rule may retain unaffected evidence with justification. |
| Configuration/adapter changes | Existing task remains pinned. Adoption is explicit; compare definitions and rerun affected gates, defaulting to `IMPLEMENTED` for execution-related changes after implementation. Earlier work stays at its current stage unless affected criteria require an earlier return. |
| Stale late result | Preserve it for diagnosis; it cannot satisfy the current gate. Reconcile the operation and restart from the applicable target. |

Completed task records remain historical; later work creates a linked new task. A pinned definition does not override revoked permissions, lost access, or an unresolved current drift finding affecting that invocation: check current authorization/access and relevant readiness findings before every new invocation, stopping for reconciliation where necessary.

## 8. Harness maintenance

**R-18 — Checked staging and promotion.** Use the separate maintenance lifecycle:

```text
REQUESTED → INSPECTED → PLANNED → STAGED
  adapter change → ADAPTER_COMPATIBLE ─┐
  fact correction → SOURCE_VERIFIED ───┤→ PROMOTED → STATUS_UPDATED → COMPLETE
  drift review → DRIFT_ASSESSED ────────────────→ STATUS_UPDATED → COMPLETE
```

Inspection captures affected before-values, configuration version, and source evidence. Staging preserves active configuration. An update record contains request/scope, candidate source/version/content identity, changed values, evidence/checks, permissions, approval when required, before/after configuration identities, promotion result, and rollback information. Drift-only records explicitly mark promotion/rollback as not applicable.

Ordinary same-capability compatible additions/swaps with no permission expansion may auto-promote under the recorded policy. Fact corrections require authoritative evidence and the same scope/policy check. Interface, permission, workflow, structural, or policy changes are migrations requiring scoped human approval. Approval identifies the exact candidate, base configuration, and affected scope; altered candidates or conflicts require renewed review of the changed scope. Approval permits the migration checks and eventual promotion; it cannot waive unsupported formats or unsatisfied structural criteria.

There are two promotion paths: compatible change under existing policy, or approved migration with all migration checks complete. The latter must not be tested again against the ordinary “no expansion/no interface change” condition. Migrations that alter rules must recheck affected structure, schemas, scenarios, and readiness before activation.

Immediately before promotion, compare the captured configuration version and affected before-values with current active values. Any intervening change requires reinspection and restaging; this minimal design serializes promotions. Publish a complete verified configuration and its revision, then refresh derived status. If a crash interrupts publication, reconcile the recorded promotion intent and actual files before other work; mixed/unverifiable configuration blocks new work. A tool can provide atomic publication, but procedural mode must disclose its limitations.

Rejected candidates leave active configuration unchanged. Failed promotion restores prior values only when current values are still those written by that attempt; never overwrite a newer accepted update. If restoration is unsafe or incomplete, record `FAILED`, affected integration `BLOCKED`, and the recovery required. A stale derived status report alone can be regenerated without rolling back a successfully published configuration.

Maintenance stop states are `REJECTED`, `PENDING`, `HUMAN_REQUIRED`, and `FAILED`. `PENDING` resumes through `INSPECTED` on new evidence. `HUMAN_REQUIRED` resumes through `INSPECTED` with the scoped decision; unchanged approved scope can proceed through the migration route. Rejected/failed attempts remain history; a corrective attempt gets a new linked update ID. No automatic retry loop is required.

**R-19 — Drift assessment can finish with findings.** Compare only declared watched sources. Record unchanged, changed, missing, or inaccessible source evidence and affected capabilities. No-change review closes without promotion. Changed/missing sources set affected capabilities to `NEEDS_REVIEW`; recompute profile readiness using R-07. Access/policy blockers are reported as such. Review completion does not imply integration readiness. Any proposed correction creates a linked adapter/fact/migration update and passes its normal checks; drift assessment has no direct binding-promotion edge.

Publishing readiness findings is a checked assessment update, even though no binding is promoted. Compare current configuration revision, adapter/source identities, and affected before-values with those inspected. On conflict, retain the findings as historical evidence and reinspect before modifying current readiness. Publish a new configuration revision with the accepted assessment; a review of adapter A cannot mark newly installed adapter B using A's stale findings.

## 9. Workflow applicability and multiple targets

**R-20 — Explicit profiles.** Task types classify work (feature/fix/docs); targets identify components/environments; workflow profiles declare the stage path and required capabilities/coverage. Begin with one default profile unless repository evidence justifies more. An unrecognized type/target or ambiguous profile selection needs clarification. No ad hoc stage skipping is permitted.

Supply three adaptation examples: compiled build-before-test; source-only tests (`PREFLIGHT_PASSED → TESTING` with source identity); documentation-only (`PREFLIGHT_PASSED → SPEC_VERIFIED` after all required documentation checks). A profile exception requires an evidence-backed applicability condition, defined alternate edge, required replacement evidence, and acceptance under repository policy. Untraversed stages are recorded as not applicable with that authority; no build/test `PASS` is fabricated. Changes outside the selected profile's scope trigger reclassification and evidence re-evaluation.

For multiple targets, record the required target/environment set before execution. A composite adapter may aggregate child reports; no scheduler is required. Known running children keep the invocation running within its deadline. Once terminal outcomes are expected, reduce required child results in this exact order: missing/malformed/mismatched/`UNKNOWN` result gives `UNKNOWN`; otherwise any `BLOCKED` gives `BLOCKED`; otherwise any `FAIL` gives `FAIL`; otherwise all matching `PASS` gives `PASS`. Preserve every child's result and diagnostics. Thus a known failure plus an unresolved child stops for reconciliation rather than starting repair while work may still be running. Cross-repo tests record both product and test-source identities and the consumed build artifact. Unresolved target selection cannot be solved by silently excluding a component.

## 10. Installation recovery and optional checker

**R-21 — Recoverable installation.** The installation record contains installation ID, kit/schema version, target identity, chosen harness root, generated/owned paths and before/after identities, discovered facts, resolved/pending decisions, criterion results/methods/evidence, checker coverage, activation status, and timestamps. It distinguishes fresh installation, interrupted installation, and an existing live harness. Resume reinspects generated files and source evidence before reusing prior results. Preserve user edits and runtime history; conflicting edits need reconciliation, not blind regeneration.

Prepare runtime files and explicit entry points under `.harness/` first. Check structure against the staged candidate. Activate only after structural criteria pass; verify that the LLM can load the installed entry and its local dependencies without modifying repository-root instructions, then finalize the record. An existing live harness is updated through its installed maintenance/migration flow, not overwritten as a new installation. Old installation results retain their provenance; later maintenance records establish current assessments.

**R-22 — Optional checker with bounded claims.** Provide a read-only Python reference checker, optional and highly recommended. Proposed implementation floor is Python 3.11; declare and lock its parser/schema dependencies in the implementation plan. Use a safe YAML parser with duplicate-key rejection and JSON Schema validation; no arbitrary YAML constructors, expression evaluation, or remote schema downloads. Machine YAML uses string keys, explicit booleans, quoted string-like dates/identifiers, and JSON-compatible values; reject merge keys, custom tags, non-finite numbers, duplicate keys, and cyclic aliases. JSON records also reject duplicate keys and non-finite numbers.

The checker consumes an explicit repository/harness root and installation record/catalogue. It checks file/schema/reference/registry/graph invariants and declared fixtures; it reports semantic review criteria as unresolved unless supplied review evidence satisfies their allowed method. It does not run configured production commands, fetch tools, modify runtime state, or certify tool work. A checker exit success means its covered checks passed, not that every installation criterion passed.

Define exit codes: `0` all covered checks passed; `1` one or more covered checks failed; `2` checker could not complete (bad invocation, missing prerequisites, unreadable input, internal error). Reports include checked IDs, results/evidence, uncovered IDs, coverage limitations, checker/version, OS/runtime/dependency versions, and the assessed configuration identity. The final installation assessment separately aggregates all required criteria. If the checker is skipped/unavailable, record that fact and assess criteria by permitted review or equivalent tooling. Skipping it alone does not lower readiness.

Portable behavior: UTF-8, LF/CRLF input, explicit roots independent of working directory, exact path casing, paths with spaces/Unicode, platform-native path APIs, and no shell requirement. Generated internal paths are root-relative, use `/` separators, and resolve within their declared repo/harness scope. External evidence is an explicitly typed reference and cannot be treated as a local path; inaccessible evidence stays unresolved. Check symbolic-link resolution and path traversal before local reads. Platform-specific commands belong to declared adapters. No interpreter/dependency download is implicit.

The checker implementation must publish actual native Windows/macOS/Linux results. A macOS run or path simulation alone cannot mark Windows/Linux validation complete. If those hosts are unavailable, record the remaining matrix entries as pending; continue all local work without claiming full platform verification.

Implementation references: Python's [path APIs](https://docs.python.org/3/library/pathlib.html) and [JSON support](https://docs.python.org/3/library/json.html); [PyYAML safe-loading documentation](https://pyyaml.org/wiki/PyYAMLDocumentation); [jsonschema validation documentation](https://python-jsonschema.readthedocs.io/en/stable/). These libraries inform the optional checker only. Parser defaults must be tightened to meet the rules above.

## 11. Delivery and evidence

**R-23 — Finish the existing candidate deliberately.** Reuse the prior development/maintenance/shared separation and useful adapter records. Correct the ten reviewed defects and the newer runtime-review rules; complete installer guidance and README. Do not copy the frozen review snapshot over newer work or treat prior narrow task reviews as whole-kit acceptance. Old authoring documents remain history and are labelled superseded when this specification is approved.

**R-24 — Conformance before completion claims.** The [scenario catalogue](acceptance-scenarios.md) maps requirements to inputs and expected behavior. Convert it into executable fixture checks where mechanical behavior exists; record walkthrough evidence for procedural behavior and actual tool evidence for execution criteria. The optional installation checker does not establish runtime enforcement. An installed runtime tool implementation must exercise applicable transition/persistence cases before its mechanical-enforcement claim is accepted.

Provide disposable compiled, source-only/docs, and multi-target examples with synthetic adapters. Include a short install → development → build-skill replacement → resume walkthrough. Example commands/evidence remain clearly synthetic and cannot be copied as discovered private-repo facts. No separate pilot procedure or report is required. Each repository uses the normal installation criteria and development/maintenance verification; its private source and evidence stay in that repository.

Release evidence must identify implemented versus planned behavior, checked versus unresolved criteria, and tested versus pending OS/runtime combinations. The simple entry points link to detailed references as needed; the everyday user is not required to read this authoring specification or its research background.

## 12. Planned update: user-approved phase skipping

**Purpose.** Exactly two development phases are mandatory: specification (`SPEC_READY`) and final specification verification (`SPEC_VERIFIED`). Users can explicitly skip the other development work phases, including implementation, compilation/packaging and testing. A task can check whether an existing program satisfies an accepted specification without making changes or creating a new build. Completion depends on verified specification requirements. This replaces the proposed restriction that every task must produce a successful build.

### Rules

1. **User choice.** An explicit user instruction can skip one or more identified development work phases for the current task, except the two mandatory specification phases. The LLM never infers a skip from a missing tool, a failure or a time limit. An unclear instruction needs clarification. The decision does not change future tasks or the harness's tool readiness.
2. **Separate records.** Record `USER_SKIPPED` as the phase's disposition, with the task, phase, user instruction reference, actor, time and applicable request/specification revision. For a skip before specification acceptance, reference the captured request and reconcile its scope when the spec is accepted. Keep any previous results and the reason for the skip when supplied. A skip creates no execution result, successful phase verdict or applicability exemption.
3. **Two mandatory phases.** The specification phase (`SPEC_READY`) establishes the accepted scope, target, observable requirements and allowed verification methods. An existing specification can be reused, but its explicit acceptance for this task completes the mandatory phase; the phase is never skipped. Final specification verification (`SPEC_VERIFIED`) checks evidence against those accepted requirements. Neither phase accepts `USER_SKIPPED`, and both must be satisfied before `COMPLETE`.
4. **Requirements survive skips.** Separate phase-progression criteria from task acceptance criteria. Skipping a phase bypasses its ordinary progression gate through a declared skip route. It does not remove requirements from the accepted specification or repository obligations. If the spec requires a fresh build or actual test execution, that evidence is still required. Changing those requirements is an explicit specification revision with acceptance and evidence review.
5. **Evidence identifies what was checked.** An existing executable, package or running program may supply evidence when the spec's allowed methods permit it. Record its identity and relevant environment. If a requirement concerns the current source, establish that the evaluated program corresponds to that source; otherwise that requirement remains unverified. A successful run of an unidentified or older program cannot establish that newer source works.
6. **Dependencies still apply.** Proceed to the next unskipped phase only when its own inputs are available. Skipping compilation cannot invent an artifact needed by testing. The user may provide an acceptable existing artifact or explicitly skip that later phase too; final verification still needs evidence for every required criterion.
7. **Completion follows evidence.** At final verification, independently assess every required criterion against the accepted spec and retain its evidence. A demonstrated failure prevents completion; insufficient evidence remains unresolved. If all requirements and recorded acceptance obligations are satisfied, use the normal `COMPLETE` state and list skipped phases in the summary. No separate completion state is needed just because work phases were skipped.
8. **Preserve the harness's records.** Skips use recorded, defined transitions; they cannot jump into unearned `BUILD_PASSED`, `TEST_PASSED` or `SPEC_VERIFIED` states. Task identity, configuration, evidence provenance and permission checks still apply even when related work phases are skipped. Running operations must be reconciled before advancing; a skip is not evidence that an operation stopped. Retain skip decisions across restart and reassess affected decisions/evidence when task scope changes.

### Record and validation interface

Store a typed `PhaseDisposition` in the existing task journal. It identifies the skipped phase, original user instruction, user/message identity, time, task/request/specification/configuration scope and attributed review of the instruction. Evidence must preserve the instruction's bytes; an LLM's unsupported statement that approval exists is insufficient. Hashes check identity, not authorship.

Each skippable phase has a declared skipped state and route. Only phase-progression obligations are bypassed. An accepted task criterion remains required even if its identifier matches a built-in stage criterion. Before committing a skip, reconcile running or uncertain invocations using records already available at that point; a later terminal result cannot justify an earlier transition retroactively.

Pre-specification skips bind to the captured request. At specification acceptance, record their explicit reconciliation to the accepted scope. Changed request, specification or configuration cannot silently reuse old authority. These records reuse the journal and referenced evidence; no additional default task file or runtime controller is introduced.

### Examples to cover in the implementation

| Scenario | Expected result |
|---|---|
| User skips implementation and build, then checks an existing program using methods permitted by the accepted spec. | Complete if all required criteria are verified for the identified target. No new diff or build is required. |
| User skips testing, but the spec explicitly requires successful automated tests. | Testing stays `USER_SKIPPED`; the test requirement remains unresolved without the required evidence. No completion. |
| User skips build, but a later phase needs an artifact that is unavailable. | Pause that phase for its missing input; no fabricated artifact or automatic additional skip. |
| A build skill is missing and the user skips build. | Record the task skip; setup status continues to show the missing skill. Assess final completion from the spec. |
| User provides an existing specification. | Complete the mandatory specification phase by accepting it for the task, then perform mandatory final verification. No new spec document is required. |
| User requests skipping the specification phase or final specification verification. | Refuse that skip; do not claim the corresponding phase or task is complete. |
| An earlier attempt failed before the user requested a skip. | Preserve the failure and skip decision; relevant unmet requirements still prevent completion. |

### Implementation scope

Update the baseline requirements and scenarios, development workflow, phase records and schemas, stage/final verification rules, and user guide together. Keep specification and final specification verification mandatory, and separate skippable phase obligations from specification acceptance obligations so a skip neither falsely passes a phase nor permanently blocks an otherwise satisfied task. Update installer/conformance guidance and affected checker coverage to recognize the revised structure. Keep tool result statuses unchanged: `USER_SKIPPED` belongs to the task record.

Existing installed harnesses receive this interface/workflow change through the maintenance migration process. Preserve previous task histories and their pinned definitions. Installation completeness and maintenance compatibility checks are outside this development-phase skip feature.

## 13. Planned update: human-readable task reports

**Purpose.** Give a human a report they can skim in about a minute: a short summary, the status of every development phase, specification coverage, and direct links to the relevant logs and artefacts. It must expose missing evidence and unsupported completion claims even when the coordinating LLM says the task is complete. Use the approved [report template](task-report-template.md).

### Report generation

The installed harness must provide or bind a deterministic, read-only report generator. It reads the task's pinned workflow/configuration, accepted specification, committed event history, transition decisions, invocations, results, criterion reviews and referenced evidence. It writes only derived report files; it cannot change task state, invoke build/test tools, approve skips, or repair source records. It is separate from the optional installation checker and from any runtime transition controller. An LLM-written summary is not an equivalent generated report.

Generate `docs/development/<task-id>/report.md` and a linked `artifacts/development/<task-id>/report.json` beneath `.harness/` containing source identities, declared check coverage, row derivations and complete diagnostics. Render both from the same captured input set. Keep the human report within 200 visible words, with every configured phase visible and a short evidence link per row. Put complete task/spec/configuration identities, target, source/artifact identities, last event/version, generator/version and generation time in the linked machine report; show only brief identifying context on the human page. If inputs change during capture, retry capture or report the inconsistency; do not combine incompatible snapshots. The report is a view of recorded evidence as of generation, not a new authority for task state.

Generate the report at each handoff, including incomplete or blocked work, and regenerate it on resume or after relevant evidence changes. After an abrupt interruption, regenerate when execution resumes. If the generator cannot run, explicitly report `REPORT_UNAVAILABLE`; do not fill a supposedly generated report by hand. Reporting is an output obligation, not a third mandatory development phase. A report is required even when the task cannot reach completion.

The generator must run on Windows, macOS and Linux, or be replaced by a conforming repository-specific tool with the same output and evidence rules. Installation records its prerequisites and availability. No LLM vendor or enforcing host integration is required to read and report saved records.

### Evidence and status rules

1. **All phases remain visible.** Derive the phase inventory from the pinned workflow's explicit mapping of states/transitions to phase IDs. Include unstarted, skipped, failed and repository-added phases. Repair attempts and return loops remain linked, with counts and earlier failures visible even after recovery. A final successful attempt does not erase earlier history.
2. **Check before displaying an outcome.** Validate source record shapes and history continuity; match task, request, phase, configuration, accepted spec, source/artifact and required target identities as applicable. Check referenced files and hashes where available, criterion coverage, allowed verification methods and invalidation/supersession records. A later PASS supersedes an earlier outcome only through a valid recorded transition and evidence. Unknown custom rules or unsupported evidence formats stay explicitly unchecked.
3. **Show unsupported claims.** Missing, stale, inaccessible or contradictory support produces `UNVERIFIED` for the affected outcome, with the recorded claim and precise diagnostic retained. A phase with no outcome record displays `NOT_RECORDED`, which makes no claim about unrecorded activity. Fixture evidence cannot support a real task success. Externally hosted evidence needs a supported retrieval/validation method or is reported as unchecked; a URL alone does not prove the result.
4. **Keep judgment attributable.** Identify execution evidence, LLM reviews and human reviews separately. The generator can verify that a review and its required evidence exist and match the task. It cannot mechanically prove every semantic judgment made by the reviewer. Uncovered semantic checks remain attributed to the review method and actor, never relabelled as independent automated verification.
5. **Verify skip provenance.** A `USER_SKIPPED` row must reference the actual user instruction, its scope and its trustworthy source. An LLM-authored assertion that approval exists is insufficient. If the host provides no independently identifiable user record, expose that approval as unverified. Neither mandatory specification phase can be accepted as skipped. Skips leave specification requirements and setup readiness unchanged.
6. **Derive the summary.** Generate its wording and counts from the checked records. Display the recorded task state separately from the report's check result. A completion claim with missing specification acceptance, unresolved required criteria, missing final verification or inconsistent evidence is flagged explicitly. A clean report says that recorded completion is supported by the checked records; it does not certify tool quality. Permitted `NOT_APPLICABLE` criteria are counted as satisfied only with their required authority/evidence and remain individually identifiable in the linked matrix.
7. **Make investigation quick.** Each phase links directly to its decision/review, relevant execution output or artefact, and user instruction when skipped. Link the actual failed attempt and diagnostic when something went wrong. Keep the table compact; put full logs, all criterion verdicts, complete issue lists and hashes behind links. Generate escaped Markdown and safe links so evidence text cannot rewrite the report's structure.
8. **Expose trust limits.** The report is reproducible from its captured source records, and a fresh generation can detect unsupported manual edits or stale source references. File hashes do not prove authorship. If the LLM can rewrite both the records and the report, report generation alone cannot make them tamper-proof. Preserve original tool/user records through the host where available and state any verification limits. This feature supports human inspection; it does not claim strict control over an unrestricted LLM.

### Review cases for implementation

- Recorded COMPLETE with a missing test log: unsupported outcome and completion discrepancy are visible with the missing reference.
- User skips build; valid existing-program evidence satisfies the accepted spec: show USER_SKIPPED and supported recorded completion with exact target evidence.
- User approval exists only as an LLM assertion: skip remains UNVERIFIED and links to the unsupported assertion.
- A required specification criterion is unverified despite a skipped phase: show the missing criterion; do not report supported completion.
- A failed build later passes: show the latest supported status, failure/repair counts and links to both attempts.
- No phase event, broken history or conflicting snapshot: retain every known workflow phase and expose missing/uncertain status; never reconstruct success from conversation.
- Source/specification changes after evidence capture: mark affected outcomes unverified until valid reconciliation/review; preserve old records.
- Only review evidence exists for a criterion requiring execution: flag insufficient evidence. For a criterion permitting review, identify the reviewer and linked basis.
- Task stops before completion or report generation fails: provide the partial report or explicit REPORT_UNAVAILABLE, with diagnostics where available.

### Implementation scope

Finalize the phase inventory and record mapping alongside the skip changes in section 12. Implement the report generator, report-data definition and installed template; update installation inventory/checks, development handoff instructions and user guide. Add conformance cases for derivation, links, stale evidence, history, unsupported completion and truthful coverage. Existing harnesses receive the new files and definitions through maintenance. Separate human reports in `docs/` from their machine data in `artifacts/`; setup, development and maintenance views remain distinct.

### Reference implementation coverage (2026-10-05)

The installed reference generator, explicit phase map, strict local I/O, report schema/layout and handoff integration implement basic reports for saved completed/incomplete tasks. The archived JavaScript trial supplies bounded macOS execution evidence for the earlier layout; it does not validate the new storage design or establish full acceptance. Installation checks cover reporting inventory/local resolution and built-in RULE-06 map parity, independently of Python/dependency/replacement availability.

Source-content verification now has the local inventory implementation described below, with focused execution coverage recorded in [verification](verification.md). Older opaque snapshots remain UNCHECKED. Scoped NOT_APPLICABLE authority is also unsupported and unresolved. Custom mechanical rules/external evidence may remain unchecked; permitted semantic reviews remain attributed.

The section 12 update adds typed PhaseDisposition records, declared skip routes and reporting checks. Original-message attribution and scope interpretation remain explicit review judgments; hashes do not authenticate users. Unsupported assertions remain UNVERIFIED. Existing installations adopt this through maintenance with a new configuration revision; old task pins and records are preserved. See [verification](verification.md) for executed coverage.

### Local source inventory update

Store one SourceInventory per source revision in the existing task journal. Its revision hashes canonical `{scope, files}` JSON: literal roots/exclusions and a sorted, unique list of repository-relative paths with SHA-256 file hashes. The accepted TaskSpec records the same scope in `extensions.source_scope`. Directory roots include added/untracked files; exclusions are explicit reviewed subtrees/files. No Git dependency, duplicate source copies or new default task files.

Append the inventory after ConfigSnapshot and before any Event, invocation, result or review using that revision. Existing state/operation identities reference it; workflow gates and invalidation rules stay unchanged. The read-only helper generates records; the journal writer persists them. Capturing after execution cannot establish that earlier execution used those bytes.

The reporter checks scope acceptance, unique inventory/hash/order, current file membership/content and stability before publication. Missing, ambiguous, late or unsupported records leave the mandatory check unresolved; changed files flag stale evidence. Reject traversal, symlinks and source scopes including harness files. Check only local regular files; remote sources remain unsupported. Existing executables can be selected when the accepted specification permits them. Scope completeness and execution truth remain attributed review obligations.

Additive schemas/helpers are installed together under a new captured configuration. Preserve older pins/history; do not invent missing historical inventories. This removes one known reporting limitation, not all completion requirements.

## 14. Proposed update: fewer artefacts and clear audiences

**Status: implemented in kit 1.1.0/layout 2.** The user requested a builder-kit redesign after reviewing the JavaScript demo. The [short human guide](artifact-layout.md) is the review entry point. This section and the updated requirements above define the installed layout. `docs/`, `framework/` and `artifacts/` replace the earlier four-area proposal. Historical plan sections and earlier evidence retain their original scope.

### Installed and generated files

The target harness root is `.harness/`. Installation, maintenance, reporting and harness diagnostics must place harness-owned files beneath it. Read and respect existing repository instructions, but installation must not create or edit root instruction files or add a root pointer. The installer hands off the explicit installed entry point. Activation checks must verify loading that entry point and its local dependencies without a repository-root write. Product source edits and normal application build outputs remain governed by the requested development task.

Use `.harness/framework/` exclusively for installed definitions. `config/` owns repository settings and skill bindings; `workflows/` owns separate development and maintenance instructions, state machines, verification rules and criteria; `adapters/` owns skill interfaces and normalizers; `templates/` owns document/record templates and schemas; `tools/` owns checker/reporter code and declared dependencies. No generated task/update output belongs here. These directories do not imply a new automatic runtime controller.

The LLM entry points are `framework/workflows/development/HARNESS.md` and `framework/workflows/maintenance/harness-maintenance.md`. The installed README links both. Runtime instructions require no builder-kit or authoring-project paths. Bound external skills can remain in their existing approved locations; the harness stores their binding and identity, without requiring a copied skill.

Workflow rules refer to capability IDs and normalized outcomes. Adapter/tool implementation details must not determine workflow policy. Replacing a skill changes its binding/adapter through maintenance; changing workflow rules requires an explicit workflow revision. Reports read saved records and cannot alter those records or authorize transitions.

Generated human pages go in `.harness/docs/`. Generated machine records and supporting raw evidence go together in `.harness/artifacts/`, grouped by installation, development task or maintenance update. There is no separate top-level records/evidence split. Human pages use `docs/setup.md`, `docs/development/<task>/` and `docs/maintenance/<update>.md`. The small installed `.harness/README.md` links the human views and the LLM entry points.

A human normally opens README and `docs/`; `framework/` is for inspecting/changing operation, and `artifacts/` is reached through direct report links during investigation. These are audience labels, not access restrictions: the LLM also reads accepted human specifications. Generated pages must identify their underlying records/version and retain the existing acceptance and evidence rules. The builder project's own `docs/` and `evidence/` remain authoring material; these target paths all refer to the installed `.harness/`.

### Human reading budget

Every human-facing entry page, setup summary, specification summary and task/update report has a maximum of 200 visible words. Use short tables or bullets. A task report includes every configured phase, its status and one short evidence link per row; lengthy diagnostics, hashes, reviewer chains and previous attempts belong in the linked machine record. Preserve the distinction between a recorded claim and verified support. A short summary must never convert an unresolved result into success.

`docs/development/<task>/spec.md` presents the request, required outcome and relevant design notes together. Full accepted criteria and their provenance are retained in structured records; the human page summarizes the same accepted version and links to detail. Specification changes still require explicit acceptance and affected-evidence review. No additional request.txt, specification.txt or design.txt is required merely to supply an identity.

### Consolidated machine records

Each development task has `artifacts/development/<task>/state.json`, `history.jsonl` and, after report generation, `report.json`. The coordinator reads the small current-state view first and accesses the relevant history/evidence on demand. Human specification/report pages plus these three machine files give a default ceiling of **five task files**, excluding referenced execution evidence and immutable shared snapshots. Create files when needed, not as empty placeholders.

The journal retains typed transition proposals, gate decisions, criterion reviews, invocation intent/status revisions, results and committed events as embedded records with stable identities. A separate file per proposal, decision or review is no longer required. The current-state file is derived from the valid committed history; it cannot override that history. The installed [journal protocol](../builder-kit/templates/runtime/framework/workflows/development/journal-protocol.md) defines version 1 envelopes, sequence and task identity, stable entry IDs, canonical payload hashes, chained entry hashes and refusal of incomplete final lines. A LOCAL reference can select a journal payload with `entry_id`; its evidence identity hashes that canonical payload. Storage append/read/state commands validate records but do not approve workflow gates. Preserve pre-dispatch intent, failure history, denied requests, repair counts, freshness checks and resume behavior. Consolidation does not grant runtime enforcement or permit rewriting earlier entries.

Installation and maintenance use separate structured records with their existing publication and recovery obligations. Retain each distinct configuration bundle once under `artifacts/configurations/<bundle-hash>/`, preserving relative schema paths, and reference it from tasks/updates. The bundle identity hashes the sorted relative-path/content-identity mapping; each captured definition retains its own byte identity. Keep task-specific raw output with its task under `artifacts/development/<task>/`; keep update output with its update. Shared immutable source snapshots may live under `artifacts/snapshots/` when needed. Capture unchanged source content once and reference it; do not create empty evidence subdirectories. Sharing immutable bytes must not reuse a verdict across different tasks or inputs. The reference reporter still supports one pinned configuration per task; in-task configuration adoption remains unsupported and requires explicit migration or a linked new task, never silent snapshot replacement.

### Evidence and temporary output

Keep original tool outcomes and any raw output needed to support them. Store each output once and link it from its invocation/result. Stop creating routine reporter.stdout.txt and reporter.stderr.txt files. Normal reporter output is its report pair; a report-generation failure returns a concise availability error, with detailed diagnostic evidence only when needed. The reporter remains read-only with respect to task state and history.

Temporary staging belongs under `.harness/artifacts/tmp/` only while needed. Referenced evidence is not temporary. Cleanup must preserve pending-operation recovery data and evidence for retained histories. Do not create a mandatory scratch directory, duplicate debug log, or source copy for every stage.

### Delivery and acceptance

Update the builder's installer, templates, schemas, checker, reporter, maintenance instructions and user guide together. The obsolete demo is archived. The [demo](../tests/demo/README.md) is one JavaScript project rooted at `tests/demo/`, with app source, tests, build scripts and `.harness/` together. There is no permanent project/workspace duplication. Replacing only `.harness/` leaves the app intact and explicitly discards its prior harness records. Preserve app changes with version control or a backup before experiments. The trial runner restores its intentional source mutation in `finally`; this cannot guarantee recovery after forced termination. Automated project tests may use temporary app copies for isolation.

Keep the first trial to two scenarios: successful build/test and a test failure followed by repair. Reports must reference actual execution and preserve both failed and repaired attempts; a passing app test does not establish harness conformance. New demo harness output and trial summaries belong beneath `tests/demo/.harness/`, using `docs/`, `framework/` and `artifacts/`. Test-only scenario records must be clearly identified and must not become required installation files.

Acceptance must establish: no harness-owned root writes; installed/generated separation; human/LLM entry points; the five-file default task budget; bounded human pages; unchanged state/evidence decisions after consolidation; preserved repair/resume history; and no unnecessary console/placeholder files. Existing retained evidence stays historical. Any existing-installation migration needs an explicit version/identity mapping and must preserve earlier records and their meaning. This redesign does not implicitly implement pending skip authority, source-inventory verification or positive completion support.

## 15. Planned update: focused LLM guidance

**Status:** implemented with bounded execution checks; see [verification](verification.md) for coverage and remaining limits. Reduce what the LLM must interpret at once while preserving applicable requirements. This section extends R-01, R-03–R-06, R-10–R-15 and R-24.

### Situation index and short procedures

Use the existing installed `README.md` as a situation index, within its 200-word limit:

| Situation | Destination |
|---|---|
| Start a task | Development start guide |
| Continue a task | Instructions extracted for its recorded stage |
| Resume interrupted work | Recovery guide |
| Tool failed or evidence unclear | Current stage's failure/recovery procedure |
| Change a skill or configuration | Maintenance guide |
| Check setup readiness | Setup report and relevant criteria |

The builder README separately routes installation. Runtime guidance remains independent of builder/project documents.

Write procedures in order: **locate → check prerequisites → act → verify → record → continue or stop**. Each identifies the current situation, required evidence and next destination. Aim for 200–300 words per procedure; retain the stricter 200-word limit on human pages. Group detailed reference material by purpose and load only needed sections. Avoid a file per rule and duplicate authoritative instructions.

### Parse, select, then present

The reference command is `framework/tools/context.py`, backed by importable `context_reader.extract_context`, `context_page` and `render_text`. It reuses existing loaders and evidence capture. Parse lengthy JSON/YAML, schemas and journals before presenting selected information to the LLM. Parsing and printing the entire file is insufficient.

Keep the Python command entry point thin: reusable functions accept explicit inputs and return structured data/diagnostics; formatting and process exit handling stay at the command boundary. This supports the [future CLI idea](cli-idea.md) without implementing its additional commands now.

For the selected task/stage or installation/maintenance situation, return applicable transitions, due criteria, bindings, unresolved issues and required rule/procedure sections with source IDs/references. The overview is navigation only: select an outgoing transition or named resolution route to retrieve action requirements. Setup criteria select their mapped contracts; explicit section, contract and journal-entry selectors provide additional detail without reading whole files. Use the task's captured configuration; never silently substitute current settings. Include applicable shared constraints automatically. Missing, conflicting or unsupported inputs produce explicit diagnostics, not guessed guidance.

Extract from authoritative definitions rather than maintaining separate summaries. Large relevant results use explicit continuation sections; required checks cannot be silently truncated. The command neither changes state nor grants permission, approves gates or certifies tool quality. Preserve the LLM's evidence-based interpretation and separate specification review.

Parsing is required independently of the optional installation checker. Reuse the existing Python loader where available, or an equivalent local parser with declared prerequisites on Windows, macOS and Linux. If parsing is unavailable, report that limitation and withhold dependent conclusions; do not fall back to a raw file dump.

### Recovery guide

1. Read the recorded stage from validated history and inspect the last action/evidence.
2. Check relevant inputs, captured configuration and current permissions for changes.
3. Determine whether execution is unstarted, running, finished or uncertain.
4. Reconnect to an existing operation, verify saved output, or resolve uncertainty before retrying.
5. Record the supported outcome and follow its permitted next action.

Use existing state, journal and invocation records; no per-instruction checkpoint or extra default task file. A stage alone cannot identify the exact unfinished step. Missing completion evidence does not prove an action never ran. Changed inputs require the existing invalidation/review procedure; recovery cannot invent success or silently repeat an external action.
