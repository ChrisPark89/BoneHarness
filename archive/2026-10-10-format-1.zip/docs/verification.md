# Kit verification

Checked on macOS arm64, 2026-10-08, including user-approved skipping.

| Check | Result |
|---|---|
| Python 3.11.16 | 201 tests passed |
| Python 3.14.0 | 201 tests passed |
| User-approved skipping | 23 focused tests passed; included in both full suites |
| Source evidence | 15 tests passed; included in both full suites |
| Documentation | Links and requirement mappings passed |
| Independent source review | Findings corrected; no remaining material findings |

The [skip tests](../tests/test_user_skips.py) cover supported completion, invalid instructions, changed scope, pre-spec reconciliation, unfinished operations, retained failures and approval links. Generated reports stay within 200 words and do not modify their inputs. Test approvals are synthetic; these checks establish record handling, not live LLM compliance or user authentication.

The [retained demo](../tests/demo/.harness/README.md) predates skip support. Its real build/test runs and simulated workflow decisions remain unchanged; its reports remain **UNVERIFIABLE**. The next step is a fresh LLM walkthrough using the updated kit.

Native Windows/Linux execution remains unverified. Other [reporting limitations](implementation-status.md#remaining-reporting-work) still apply.

[Run the checks](../tests/README.md) · [Demo guide](../tests/demo/README.md)
