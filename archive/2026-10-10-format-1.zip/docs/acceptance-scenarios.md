# Harness builder acceptance scenarios

Status: baseline acceptance definitions, 2026-10-04, with layout redesign checks added 2026-10-06. Baseline scenarios retain their historical numbering; for current layout path and storage behavior, the redesign checks below take precedence. No row below is a test result. Current layout checks and limits are recorded in the [layout update assessment](../archive/verification/layout-update/README.md). Actual results are in the [scenario ledger](../tests/fixtures/scenario-results.yaml), with scope and pending obligations in the [release assessment](../archive/verification/history.zip#evidence/release-assessment.md).

Design authority: [consolidated design](specification.md). Each scenario pins the behavior a generated harness must provide. The [implementation plan](implementation-plan.md) assigns executable cases and procedural walkthroughs to files and tasks. Installed case definitions have exact per-mode coverage parts; a passing part is not a whole-scenario verdict.

## Scenario record and evaluation

Each implemented case records `scenario_id`, `requirement_ids`, `mode` (`AUTOMATED` or `WALKTHROUGH`), `initial_state`, `configuration`, `input_evidence`, `action`, `expected_decision`, `expected_state`, `expected_records`, `forbidden_effects`, `actual_result`, and `evidence_refs`. A walkthrough traces named rules with supplied inputs and inspected output definitions; it never claims a runtime tool executed. Execution-specific claims require `AUTOMATED` evidence or an actual recorded human/tool invocation as specified by the criterion.

Use `PASS`, `FAIL`, `PENDING`, or `BLOCKED` for scenario evaluation. Before evaluation each case is `PENDING`. Fixture provenance is always explicit. The same fixture cannot later be submitted as a real build/test result. Besides the expected change, assert that unrelated active bindings, user files, historical records, and budgets remain preserved.

Shared fixture defaults: task `task-1`, source `src-1`, configuration `cfg-1`, spec `spec-1`, adapter definition `adapter-1`, required target `app/local`, repair disabled, and procedural writer unless a case says otherwise. IDs are illustrative identities, not commands or private-repo facts. A gate's expected state refers to the state after its declared follow-up route is committed; the gate decision itself never performs an undeclared mutation.

## A. Installation and handoff

| ID | Requirements | Initial conditions and action | Expected behavior and preserved records |
|---|---|---|---|
| S-01 | R-01–R-07, R-21 | Fresh repo; discovered build skill; test binding unknown. Generate and assess scaffold. | All structural subcriteria can pass with a valid pending test binding. Report `STRUCTURE_COMPLETE` and default profile `PARTIAL`; list missing test evidence. No guessed test command. Runtime instructions resolve without builder files. |
| S-02 | R-06–R-07 | All artifact-presence checks pass; one transition has an undefined endpoint. Aggregate installation status. | The graph subcriterion fails and structure is `INCOMPLETE`, regardless of checked boxes elsewhere. Entry point remains unactivated. |
| S-03 | R-06, R-22 | Optional checker skipped; every required criterion has permitted review/equivalent-tool evidence. | Record checker skipped and actual methods; completion/readiness derive from criteria. No false automated-check claim or penalty merely for skipping Python. |
| S-04 | R-06, R-22 | A criterion specifically requires execution; only an LLM assertion is provided. | Criterion remains unresolved; any completion claim depending on it is withheld. A written review cannot be recorded as execution. |
| S-05 | R-04–R-05 | Workflow duplicates a profile's active build binding and names a different adapter. | Structural authority check fails; maintenance cannot appear complete while development still resolves the other binding. |
| S-06 | R-02, R-21 | Installation interrupted after two generated files; one is then user-edited. Resume. | Restore inventory, reinspect, retain valid completed evidence, and reconcile the edited file. Do not overwrite edits, regenerate unrelated files, or reset an existing run history. |
| S-07 | R-01, R-21 | Installer finds a live harness and existing root/nested instructions. | Inspect existing installation/version and scopes; route changes through maintenance/migration. Unresolved instruction conflict is recorded before activation; no duplicate competing entry point. |
| S-08 | R-01, R-04, R-24 | Builder package is absent after installation. Request development, a build-skill replacement, then an approved structural/rule migration. | Installed instructions, setup criteria and schemas suffice for normal operation and affected maintenance checks; no project regression catalogue is installed. Development/maintenance results go to separate record directories; shared contains definitions only. |
| S-09 | R-07, R-19 | Docs profile ready; code profile has pending required test; optional unused capability unavailable. Then test blocked code plus unassessed docs, and all profiles unassessed. | First overall `PARTIAL`; optional capability alone changes neither profile. Blocked plus unassessed is `BLOCKED`; all unassessed is `NOT_ASSESSED`. Later drift lowers only affected readiness plus the aggregate. |

## B. Runtime progression and review

| ID | Requirements | Initial conditions and action | Expected behavior and preserved records |
|---|---|---|---|
| S-10 | R-08, R-10–R-14 | All stage prerequisites/evidence match in the default profile. Traverse a complete task. | Exact declared default sequence; separate tool reports, LLM criterion verdicts, and transition records. Completion requires the configured completion condition. |
| S-11 | R-10, R-14 | Tool reports `PASS`; one criterion due at this gate lacks coverage. Request its success transition. | Gate `DENY` for a demonstrated unmet criterion or `BLOCKED` for insufficient evidence, followed by recorded `BLOCKED` stop. Preserve tool `PASS`; record missing criterion/remediation. No success state. |
| S-12 | R-10, R-14 | Required build reports `FAIL`; LLM review says work is correct. | Deny `BUILD_PASSED`; record `BUILD_FAILED` from the valid report and follow repair/stop policy. LLM cannot upgrade the tool result. |
| S-13 | R-10 | Optional native validation absent; required execution and LLM criterion review complete. | Optional validation recorded absent; gate may allow if all other requirements pass. No fabricated native-validation result. |
| S-14 | R-08, R-11, R-14 | Missing saved-result field, unsupported saved status, or insufficient completion evidence; separately, plain native output with sufficient evidence. | Insufficient evidence or invalid saved records remain `UNKNOWN` with diagnostics and block advancement. Plain output may be interpreted by the LLM under the pinned procedure with evidence and attribution; no invented execution or tool-reported `PASS`. |
| S-15 | R-08, R-11 | Valid result belongs to wrong run, target, config, source/diff, adapter definition, or test-source revision. | Each variant denies success; retain mismatch evidence and use the declared stop/reconciliation route. A base commit matching while dirty contents differ is insufficient. |
| S-16 | R-11–R-12 | Unknown rule ID, unresolved verifier, or two applicable outcome routes. | Gate blocks with a configuration error; no arbitrary transition selection. The prior state/version is preserved until an explicit stop event. |
| S-17 | R-11–R-12, R-16 | Replay an already committed request; then reuse its ID with altered evidence; then submit against stale version. | Exact replay returns original event/outcome once. Altered replay and stale version are denied; no second event, invocation, or counter increment. Both writer modes document this behavior; procedural mode does not claim atomic locking. |
| S-18 | R-09–R-10, R-13 | Before `SPEC_READY`, accepted task spec does not yet exist; a planning criterion permits review evidence; later at build stage test evidence is not yet due. | Early gate uses request and installed criteria; actual permitted REVIEW evidence can satisfy planning without invented execution. Build gate evaluates only criteria due there. No future-artifact requirement or fixture substitution. |
| S-19 | R-10, R-17 | Accepted spec changes after tests were recorded. | Preserve old reports/spec version; explicitly invalidate affected criteria and return to `PATTERN_VERIFIED` to reaccept and replan, or earlier if research changed. No silent requirements rewrite or reused blanket PASS. |

## C. Failure, repair, and resumption

| ID | Requirements | Initial conditions and action | Expected behavior and preserved records |
|---|---|---|---|
| S-20 | R-14–R-15 | Build/test failure with repair disabled. | Record failure, then `HUMAN_REQUIRED` with diagnostics and requested resolution. No repair or resubmission. Test both failure origins. |
| S-21 | R-14–R-15 | Repair enabled, limit 2, used 0, new evidence and in-scope hypothesis. | Enter `REPAIRING`, used becomes 1 once. Default route goes through preflight/build/test. Preserve original failure and repair rationale. |
| S-22 | R-14–R-16 | At `BUILD_FAILED` or `TEST_FAILED`, limit 2 and used 2; separately test no new evidence and out-of-scope repair. | Direct `HUMAN_REQUIRED` with the precise reason. No unreachable repair-only exhaustion edge; no budget reset after restart. |
| S-23 | R-15, R-17 | Test repair proposes bypassing rebuild. First no validity rule, then a declared rule with complete artifact-validity evidence. | First run uses full preflight/build/test. Second may use the explicitly configured shortcut after preflight; record why every consumed artifact remains valid. |
| S-24 | R-08, R-14, R-16 | Remote build still running; LLM restarts with saved handle and deadline. | Restore `BUILDING`, reconnect/poll the same operation within budget, then consume its matching terminal result. No new build submission. |
| S-25 | R-16 | Crash after external dispatch but before saving its handle. Intent/request ID exists; external status cannot be resolved. | Attempt documented reconciliation; record uncertainty and block. Do not blindly resubmit or claim exactly-once execution. |
| S-26 | R-14–R-16 | Invocation deadline reached, including time spent between sessions. | Record timeout/unknown outcome and reconciliation or cancellation status; stop `BLOCKED`. No infinite poll loop or deadline reset. External effects are not assumed undone. |
| S-27 | R-16–R-17 | Source changes while remote build runs; old-source result arrives. Separately test an external baseline change during research and an expected in-scope implementation edit. | Stale build result is retained but cannot pass; reconcile and return to `IMPLEMENTED`. External early change returns to earliest invalidated stage, default NEW to rebaseline if impact unknown. Expected implementation edit is captured normally and does not itself restart research. |
| S-28 | R-12, R-16 | Event committed but snapshot not refreshed; separately test corrupt event, competing writer, or uncommitted proposal. | Rebuild snapshot only from a valid committed sequence. Unresolvable inconsistency/conflict blocks work. No reconstruction from conversation guesses and no claim of tool-enforced safety in procedural mode. |
| S-29 | R-07, R-13, R-16–R-17 | Task stopped because test skill was pending; maintenance later supplies it. | Preparatory work may remain valid. Explicitly adopt/reconcile new config, invalidate affected evidence, and resume at declared stage. Do not jump from `BLOCKED` to `TEST_PASSED` or silently use a new skill. |

## D. Maintenance and compatibility

| ID | Requirements | Initial conditions and action | Expected behavior and preserved records |
|---|---|---|---|
| S-30 | R-05, R-09, R-18 | Active build A; candidate B supplies valid PASS/FAIL/BLOCKED/UNKNOWN fixtures, preserves interface and permissions. | Check format/routing/policy, enter `ADAPTER_COMPATIBLE`, promote B under existing policy, increment config identity, derive status, preserve before-values/history. No production success requirement. |
| S-31 | R-09, R-18 | Candidate cannot map its evidence into a supported harness outcome; separately test missing compatibility evidence and unresolved permission expansion. | Respectively `REJECTED`, `PENDING`, `HUMAN_REQUIRED`; preserve active A in all cases. A valid UNKNOWN fixture alone is not rejection/pending. |
| S-32 | R-09, R-18 | Candidate migration changes interface/permissions; exact candidate and scope approved; migration checks then pass. | Approved migration can reach `PROMOTED` without being rejected by ordinary no-expansion guard. Altered candidate/base invalidates reuse of approval; unsupported interface without migration support never promotes. |
| S-33 | R-18 | Correct a recorded repo fact with authoritative source; separately use an unsupported guess. | Supported correction uses `SOURCE_VERIFIED` and policy-checked promotion. Unsupported claim stays pending; active fact is preserved. |
| S-34 | R-05, R-07, R-19 | Drift review finds unchanged sources; separately changed, missing, and inaccessible source. Then adapter B replaces A while a review of A is pending. | Findings close without binding promotion; accepted readiness publication advances config revision. Changed/missing sources mark affected NEEDS_REVIEW. A's stale review cannot update B's readiness: retain history and reinspect. Optional unrelated capability does not lower an unaffected profile. |
| S-35 | R-18–R-19 | Drift suggests replacing a build binding. | Drift record completes; linked adapter update must pass normal staging/compatibility/promotion. No drift-to-binding-promotion bypass. |
| S-36 | R-05, R-16–R-18 | Task pinned to A; maintenance promotes B. | Existing task/invocation keeps captured A definitions. New task uses B. Explicit adoption rechecks affected gates. Permission revocation still blocks a new A invocation. |
| S-37 | R-18 | Two staged updates share cfg-1; one promotes cfg-2 before the other. | Second fails the version/before-value comparison and reinspects/restages. No lost update, stale approval reuse, or overwrite of first accepted update. |
| S-38 | R-18 | Promotion partially fails; separately a newer update already replaced its written values. | First restores only its own changes when safe and records FAILED/recovery evidence. Second preserves newer values and records unresolved recovery with affected integration BLOCKED. No blind rollback. |
| S-39 | R-05, R-18 | Configuration promotion succeeds but status refresh is interrupted. | Reconcile promotion record and active configuration, regenerate derived status. Do not rerun promotion or roll back valid configuration merely for stale Markdown. |

## E. Applicability and portability

| ID | Requirements | Initial conditions and action | Expected behavior and preserved records |
|---|---|---|---|
| S-40 | R-08, R-20 | Source-only profile selected with accepted scope, source snapshot, and no build artifact. | Explicit preflight-to-test edge; matching source tests can pass. Build is not applicable with authority, never counterfeit BUILD_PASSED/artifact. |
| S-41 | R-20 | Docs profile selected and required doc checks complete; separately discover a product-code change. | Docs path can proceed to spec verification with criterion evidence. Product-code change forces reclassification/re-evaluation, not quiet continued skipping. |
| S-42 | R-08, R-20 | Required targets report PASS plus missing/FAIL/BLOCKED/PASS; also FAIL+missing, FAIL+BLOCKED, FAIL+BLOCKED+UNKNOWN, and FAIL+still-running. | Respectively UNKNOWN/FAIL/BLOCKED/PASS; mixed terminal cases UNKNOWN/BLOCKED/UNKNOWN; a known running child keeps execution running within deadline. No repair with unresolved children. Retain target set and every child finding. Unresolved target selection blocks planning. |
| S-43 | R-08, R-20 | Product repo and test repo are distinct; report references wrong test revision or consumed artifact. | Deny success on either mismatch; matching both source identities plus artifact lineage permits normal review. |
| S-44 | R-22 | Same fixture checked natively on Windows/macOS/Linux; root has spaces/Unicode; run from different directory; LF/CRLF variants. | Same semantic check results apart from platform metadata/path spelling. Record actual native matrix; absent OS evidence remains pending. No shell, WSL, or production command dependency. |
| S-45 | R-02, R-22 | Bad path casing, local traversal/symlink escape, duplicate YAML/JSON key, custom tag, ambiguous typed value, or malformed document. | Specific structural/parse diagnostic; no arbitrary execution, remote reference fetch, silent key overwrite, or out-of-scope file read. Required coverage stays incomplete. |
| S-46 | R-06, R-22 | Missing interpreter/dependency; separately checker covers structural checks but semantic review remains pending. | No implicit download. First records unavailable checker and alternative criterion methods; second reports covered checks honestly without claiming structure complete. Exit/report semantics distinguish failed checks from incomplete execution. |
| S-47 | R-09, R-24 | Submit a compatibility fixture as evidence for real task BUILD_PASSED. | Reject fixture provenance at the runtime gate regardless of its syntactically valid PASS. Preserve diagnostic and real task state. |
| S-48 | R-23–R-24 | Assemble kit release after candidate fixes; compare README, installer prompt, templates, catalogue, schemas, scenarios, and platform report. | One installation entry point and consistent versions/paths; historical documents labelled. All actual checks and pending limitations disclosed; no stale installation instructions or claims of unperformed repository validation. |

## Review finding coverage

| Review finding | Design requirements | Principal cases |
|---|---|---|
| F-01 gate semantics | R-10–R-12 | S-10–S-19 |
| F-02 structure aggregation | R-06–R-07 | S-01–S-04, S-46 |
| F-03 configuration ownership | R-04–R-05 | S-05, S-30, S-36, S-39 |
| F-04 repair dead ends | R-14–R-15 | S-20–S-23, S-26 |
| F-05 compatibility versus outcome | R-08–R-09 | S-14, S-30–S-31, S-47 |
| F-06 approved migrations | R-18 | S-32, S-37 |
| F-07 drift closeout | R-19 | S-09, S-34–S-35 |
| F-08 recovery/concurrency | R-12, R-16–R-18 | S-17, S-24–S-29, S-36–S-39 |
| F-09 profiles/targets | R-20 | S-40–S-43 |
| F-10 installation recovery | R-01–R-02, R-21 | S-06–S-08 |
| Optional checker / three host platforms | R-06, R-22 | S-03–S-04, S-44–S-46 |
| Tool validation plus coordinating-LLM review | R-10–R-12, R-17 | S-10–S-19 |

## Release assessment checklist

- [ ] Every requirement R-01 through R-24 maps to at least one case and an implementation task.
- [ ] Concrete scenario fixtures identify initial values, action, expected decisions/state, and forbidden effects.
- [ ] All cases have actual evidence or are visibly PENDING/BLOCKED; prose expectations are not marked PASS.
- [ ] Mechanical and procedural verification claims are distinguished.
- [ ] Compiled, source-only/docs, and multi-target examples are usable without production tool access.
- [ ] Native OS/runtime results and remaining platform gaps are published.
- [ ] User-facing README and installed entry points are consistent and concise.
- [ ] Installation and runtime instructions keep private repository evidence inside that repository.

## Artefact layout acceptance definitions

These checks apply to specification section 14. They are requirements, not executed results. Baseline S-01–S-48 retain their state/evidence obligations; earlier path-specific root integration and separate-file expectations must be adapted to the target layout before reuse.

| Check | Required observation |
|---|---|
| A-01 Containment | All harness-owned files, staging and diagnostics stay under `.harness/`; installation does not edit root instructions. Product edits remain governed by the task. |
| A-02 Separation | Human pages use `docs/`; installed definitions use `framework/`; generated machine records and raw evidence stay together in `artifacts/`, grouped by installation/task/update. Development and maintenance remain separate. |
| A-03 Human review | README directs humans to `docs/` and LLMs to the separate development/maintenance entry points in `framework/workflows/`. Entry page, setup page, specification and task/update reports each fit 200 visible words. Every configured phase is shown; an issue links directly to its supporting records. |
| A-04 File budget | An ordinary task creates at most five default task files, only when needed, plus necessary referenced evidence/shared snapshots. No placeholder request/design files or routine reporter console logs. |
| A-05 History parity | Consolidation preserves decisions, refused requests, earlier failures, repair budgets, review identity and pre-dispatch intent. Interrupted writes and pending operations recover without fabricated success or blind resubmission. |
| A-06 Derived views | State/report views agree with the valid journal and captured input identities. Missing/stale/contradictory support is visible. Compact pages cannot hide unsupported completion. |
| A-07 Shared bytes | Unchanged configuration/source content is stored once per applicable namespace. Different tasks never inherit verdicts merely because bytes match. |
| A-08 Migration | Explicit version/identity mapping preserves old histories and evidence. Cleanup preserves referenced evidence and pending recovery data. |
| A-09 Replacement demo | Use one app rooted at `tests/demo/`. Install the kit into `tests/demo/.harness/`; its `docs/`, `framework/` and `artifacts/` hold all harness files. Inspect success and test-failure/repair scenarios. Replacing `.harness/` preserves the app. Fixtures are labelled; old results and app-only checks are not new-layout evidence. |
| A-10 Replaceable skills | Workflow policy uses capability IDs and normalized outcomes. A compatible skill replacement updates its binding/adapter without rewriting unrelated workflow rules. Generated reports cannot authorize transitions. |

Native platform behavior and skip integration require their own execution evidence; this layout checklist does not establish either. See [verification](verification.md) for the current results.

## Focused guidance acceptance checks

Acceptance definitions for [specification section 15](specification.md#15-planned-update-focused-llm-guidance); these rows are not execution claims. Bounded results and remaining limits are in the [verification summary](verification.md).

| Check | Required observation |
|---|---|
| G-01 Navigation | The ≤200-word installed index routes start, continue, recovery, failure, maintenance and setup situations. Runtime destinations require no builder files. |
| G-02 Procedures | Each short procedure gives ordered actions, required evidence and next routes. Applicable constraints remain available at the relevant step; shortening loses no mandatory checks. |
| G-03 Extraction | Large structured inputs are parsed. Selected output includes applicable criteria, transitions, bindings, unresolved issues and source references from the correct captured configuration. Changing the live profile cannot silently change task guidance. |
| G-04 Incomplete inputs | Missing parser, malformed records, unknown stage, missing definitions and conflicting evidence are explicit. Large results have continuation; no required criterion is silently omitted or marked satisfied. |
| G-05 Recovery | Uncertain dispatch is reconciled before retry; running work is reconnected; saved output is verified; a committed transition resumes at its recorded destination. Changed inputs invoke review/invalidation. No invented success or additional per-step checkpoints. |
| G-06 Authority and footprint | Extraction changes no files, executes no action and grants no transition authority. The default task file budget stays unchanged. Project tests remain outside installed harnesses. |

## User-approved skipping acceptance checks

Definitions for [specification section 12](specification.md#12-planned-update-user-approved-phase-skipping), not execution claims.

| Check | Required observation |
|---|---|
| U-01 Supported skip | Explicit scoped instruction produces `USER_SKIPPED` through a declared route, with direct evidence links and no invented success result. |
| U-02 Mandatory phases | Neither specification acceptance nor final specification verification accepts a skip. |
| U-03 Authority | Missing, fixture, conflicting or unsupported instruction evidence leaves the claim unverified. Hashes do not authenticate a user. |
| U-04 Scope | Wrong task/request/spec/configuration is rejected; pre-specification authority is explicitly reconciled at acceptance. |
| U-05 Running work | Pending or uncertain work is reconciled before the skip. Later records cannot retroactively authorize it. |
| U-06 Acceptance | Skipping progression never waives a task criterion, including an identifier collision. Missing required evidence blocks completion. |
| U-07 Recovery and history | Prior failures remain visible after a supported skip; restart preserves the decision without inventing additional skips. |
| U-08 Completion and compatibility | Satisfied specifications can support completion with skipped work phases. Standard unskipped routes and old pinned histories retain their meaning. |
