# Task Reporting Implementation Plan

## Current update: user-approved phase skipping

Approved scope: extend the existing workflow, journal and reporter. Keep the five-file task budget and both mandatory specification phases.

1. [x] **Define the interface.** A typed `PhaseDisposition` records `USER_SKIPPED`, the original instruction and attributed scope review. Declared skipped states/routes never stand in for successful execution states.
2. [x] **Connect the workflow.** Update schemas, journal readers, phase mapping, installed guides, configuration capture and installation checks together. Preserve old task pins.
3. [x] **Check authority and scope.** Require evidence of the user instruction, task/request/spec/configuration match and reconciliation of live operations before the skip event. Reconcile pre-specification skips explicitly at acceptance.
4. [x] **Derive truthful reports.** Show approval links and earlier failures. Bypass only the skipped phase's progression criteria; retain every accepted task requirement. Unsupported claims remain `UNVERIFIED`.
5. [x] **Review and test.** Exercise supported skips, mandatory-phase refusals, missing/fixture/conflicting approvals, changed scope, pending operations, preserved failures and specification obligations. Run the existing regression suites after source changes settle.

Independent source review found and corrected four issues: task-criterion ID collisions, terminal-operation evidence, approval links after failure, and malformed phase metadata. Scoped re-review found no remaining material issue. Both full regression suites passed: 201 tests each on Python 3.11 and 3.14, including 23 skip tests. See [verification](verification.md) for limits.

Hashes establish byte identity, not user authorship or correctness of a semantic review. The reporter checks recorded support and attributes interpretation to its reviewer; the LLM still performs the procedure.

The retained demo is a previous installation. A realistic LLM walkthrough and native Windows/Linux checks follow this update separately.

## Completed update: source evidence

Approved scope: extend the existing reporter; retain the state machine and five-file task budget.

- [x] Define SourceInventory and accepted source_scope, using canonical scope/file hashes.
- [x] Add read-only capture, journal support and current-file/publication-stability checks.
- [x] Update installation inventory, configuration captures and concise runtime guidance.
- [x] Execute focused cases: matching bytes; changed/added/deleted files; changed scope; late/missing inventory; unsafe paths; changes during publication; legacy unchecked behavior.

Fifteen focused tests pass after correcting the human report footer. Complete-suite results, demo execution and remaining limits are recorded in [verification](verification.md).

## Layout implementation

The agreed layout separates human `docs/`, installed `framework/` and generated `artifacts/` beneath `.harness/`. Implemented in kit 1.1.0; see the [main sequence](implementation-plan.md#layout-implementation) and [validation status](implementation-status.md).

- [x] Move reporter code/dependencies to `framework/tools/`, its document template/schema to `framework/templates/`, and phase definitions to `framework/workflows/`.
- [x] Read the consolidated task journal, state and referenced evidence from `artifacts/development/<task>/`; resolve immutable configuration snapshots in `artifacts/configurations/`.
- [x] Generate `docs/development/<task>/report.md` and `artifacts/development/<task>/report.json` from the same captured inputs. Update the specification and evidence links for their separate locations.
- [x] Enforce the 200-visible-word human budget while keeping every configured phase and a direct evidence link visible. Put full metadata, diagnostics and prior attempts in the linked machine data.
- [x] Preserve read-only reporting, safe path handling, interrupted-publication detection and source-record integrity. Store temporary staging under `artifacts/tmp/` only when needed; remove routine console logs.
- [x] Review adapted reporting cases and acceptance A-01–A-10. Use the two [demo scenarios](../tests/demo/README.md) for the initial report inspection: success and failure/repair. Human reports go inside `tests/demo/.harness/docs/`, backed by its `artifacts/`. Reuse prior evidence only as historical evidence; it cannot validate the new journal or output paths.

## Historical reporting implementation

The document checker now lives at `tests/check-documents.py`. Older commands below retain their original paths.

The remainder records the delivered reporter's earlier paths and work. Its completed steps do not establish migration completion. The [current report template](task-report-template.md) describes the target human page.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Generate a short human-readable task report from saved evidence, making unsupported completion claims and missing phase records easy to investigate.

**Architecture:** A read-only Python tool captures task records, checks their consistency and evidence references, derives phase summaries, and renders Markdown plus detailed JSON. It operates on incomplete tasks too and writes only its report outputs. It does not control transitions or execute development tools.

**Tech Stack:** Python 3.11+, the existing pinned PyYAML/jsonschema dependencies, Markdown, JSON, and locally resolved JSON Schema Draft 2020-12.

**Spec:** [Specification section 13](specification.md#13-planned-update-human-readable-task-reports) and the approved [report template](task-report-template.md). [Section 12](specification.md#12-planned-update-user-approved-phase-skipping) defines the pending skip feature with which reporting must integrate.

**Status:** User approved implementation on 2026-10-05. All six tasks are implemented and source-reviewed. The combined source review findings have been corrected and accepted by scoped final source review. See the [review records](../archive/verification/history.zip#evidence/reporting/README.md). The original implementation was source-reviewed without executing tests. The subsequent user-authorized [JavaScript trial](../archive/verification/history.zip#evidence/javascript-trial/README.md) now supplies bounded executable coverage on macOS. Full acceptance, supported source enumeration, scoped N/A authority, other native platforms and section 12 skip integration remain pending.

## Scope and delivery order

Implement reporting against the existing installed record protocol first. Add an explicit phase map so the reporter does not guess meaning from state names or Markdown headings. This map describes the current workflow; it does not authorize any new transition.

The separate skip update must define and install its actual transitions and approval records before reporting can accept their outcomes. Until then, an unsupported `USER_SKIPPED` claim is displayed as `UNVERIFIED`, with the claim preserved. Do not silently enable skips as a side effect of installing reporting, and do not claim that the section 13 skip scenarios are delivered before that integration is complete.

The user's previously selected execution approach is subagent-driven. The user approved this plan for execution and subsequently authorized the JavaScript trial and regression tests. That trial does not claim every planned acceptance case. The earlier completed [implementation plan](implementation-plan.md) remains historical.

## Global constraints

- Exactly two development phases are mandatory in the planned skip design: specification (`SPEC_READY`) and final specification verification (`SPEC_VERIFIED`). Reporting cannot waive either requirement or override the task's pinned workflow rules.
- Reporting is an output obligation, not a third mandatory development phase. Generate a report at handoff, including blocked/incomplete work, and on resumed work when evidence changes.
- The generator must run on Windows, macOS and Linux. Record actual platform coverage; no simulated run establishes native support.
- Python is required for this reference generator. A conforming repository-specific replacement is allowed. Without a working generator, report `REPORT_UNAVAILABLE`; an LLM-written report is not equivalent.
- All installed code and definitions must work without `builder-kit/`, `docs/`, this project's tests or authoring evidence.
- Preserve tool result statuses: `PASS`, `FAIL`, `BLOCKED`, `UNKNOWN`. Report statuses are a separate display vocabulary.
- Never change task state, events, invocation records, approvals or source files while reporting. Never execute repository commands, load arbitrary verifier code, fetch remote schemas or install dependencies automatically.
- Use the existing exact-case, scoped-path and strict JSON/YAML rules. Preserve the separation of development records, maintenance records and setup status.
- A recorded outcome, mechanically checked reference and semantic review judgment are distinct. Do not certify tool quality or authenticity from a hash alone.
- Keep `archive/`, `docs/research/` and historical result records unchanged. Do not initialize Git in the original workspace.
- Proposed verification cases are listed below. Do not add or run tests until the user authorizes testing/verification of this implementation. Source and document inspection are permitted during planning.

## Review focus

1. A task says COMPLETE but lacks matching evidence: Task 4 must show the discrepancy prominently.
2. Evidence supports an older source/spec or a different target: Tasks 3–4 must retain it as history and prevent current support claims.
3. A failed attempt is followed by success or a skip claim: Task 4 must preserve all attempts and distinguish recorded user authority from an assertion.
4. Records change during capture or output publication stops halfway: Tasks 3 and 5 must expose inconsistent generations without changing task records.
5. Custom phases, unsafe paths and untrusted Markdown content: Tasks 1, 3 and 5 must retain phase coverage while refusing unsafe reads and escaping display content.

## File map

All installed paths below are relative to `builder-kit/templates/runtime/`.

| File or group | Responsibility |
|---|---|
| `shared/schemas/task-report.schema.json` | Phase-map and report-data formats; no mutable run data. |
| `development/workflow.yaml` | Explicit reporting map for the existing phase/state relationships. |
| `shared/python/harness_io/{__init__.py,loader.py,schemas.py}` | One reusable implementation of the existing strict loader and offline schema resolver. |
| `shared/python/requirements.lock` | Existing dependency pins, available after installation. |
| `development/report.py` | CLI entry point, prerequisite handling and report-file publication. |
| `development/reporting/{__init__.py,evidence.py,summary.py,render.py}` | Snapshot/check inputs; derive outcomes; render concise Markdown. |
| `development/templates/task-report.md` | Approved human-readable layout with deterministic placeholders. |
| Existing installer/runtime guidance and inventory | Install and discover the generator, explain limitations and link generated reports. |

The installation checker's existing `loader.py` and `schemas.py` become compatibility imports of `harness_io`. This small extraction prevents two independent implementations of path/parsing rules. Its public functions and diagnostic codes remain available. The optional checker continues to inspect installation only.

Authoring changes belong in the existing `docs/`, `tests/` and `evidence/` locations. New runtime source files must each receive a short purpose entry in the human-facing file guide.

## Fixed interfaces

### CLI

```text
python <harness-root>/development/report.py --repo-root <absolute-path> --harness-root <repo-relative-path> --task-id <id>
```

`task-id` is one directory name, never a path. Resolve the existing run at `development/runs/<id>/`. Outputs are fixed to that run's `report.md` and `report-data.json`; do not accept arbitrary output paths in the first version.

Exit `0`: generated report with declared mechanical checks consistent. This does not imply task completion; a well-recorded failed or incomplete task can have consistent records. Exit `1`: generated report exposes missing, mismatched, unsupported or inconsistent records. Exit `2`: prerequisites, unsafe input or an operational failure prevented generation. Print a concise diagnostic, including `REPORT_UNAVAILABLE` for exit 2; never replace a prior report with a fabricated successful one.

### Phase map

Use `workflow.extensions.reporting = {version: "1.0.0", phases: [...], control_states: [...], stage_criteria: [...]}`. Each phase has `id`, `label`, `order`, `profiles`, `success_states`, `active_states`, `failure_states` and `criterion_ids`. Each stage criterion has `id`, `due_state`, `required`, `allowed_methods`, `execution_required` and `independent_review_required`, transcribed from the installed stage rules and checked for consistency during installation. A conditional replacement method needs its pinned policy/review evidence; an unsupported alternative remains unchecked. No field in this map changes workflow permissions or requirements.

Map the twelve default work phases shown in the template. Map `REPAIRING` to a separate repair row so recorded attempts remain visible. Treat `NEW`, `BLOCKED`, `HUMAN_REQUIRED`, `RESUME_REVIEW` and `COMPLETE` as control states. Attribute a stop to its recorded origin; never guess an origin when it is missing. Each declared state must have exactly one phase mapping or control-state role. Preserve repository-added phases and the selected profile. Unknown or ambiguous mappings produce diagnostics and visible unmapped-state rows.

Legacy pinned workflows without this extension use a bundled mapping only if their complete relevant graph matches the supported baseline. Otherwise show observed states as unmapped with `UNVERIFIABLE` coverage; never silently read the current workflow instead of the pinned one. Recognizing the baseline supplies display names only, not proof of transition validity.

### Report data

Use `record_type: "TaskReport"` and independent `report_version: "1.0.0"`. Keep existing record/schema/interface versions intact for compatible additions; install this through a new configuration revision. Required top-level fields:

- `generation_id`, `generated_at`, `generator`, `task_id`, `scope`, `source_manifest`;
- `recorded_state`, `record_checks`, `completion_support`, `phases`, `specification_coverage`;
- `history`, `diagnostics`, `coverage`, `limitations`.

`record_checks` is `CONSISTENT`, `ISSUES_FOUND` or `UNVERIFIABLE`. `completion_support` is `SUPPORTED_BY_CHECKED_RECORDS`, `UNSUPPORTED` or `NOT_RECORDED_COMPLETE`. Any unchecked mandatory mechanical obligation prevents `SUPPORTED_BY_CHECKED_RECORDS`. Semantic conclusions permitted to be reviewed remain attributed to their reviewer and listed as such in coverage.

Each phase has `phase_id`, `label`, `status`, `recorded_claim`, `detail_code`, `evidence_refs`, `attempt_refs` and `diagnostic_refs`. Display statuses are `PASS`, `FAIL`, `BLOCKED`, `IN_PROGRESS`, `USER_SKIPPED`, `NOT_APPLICABLE`, `NOT_RECORDED` and `UNVERIFIED`. Missing support changes the display to `UNVERIFIED` while preserving the recorded claim. `NOT_RECORDED` makes no assertion about unrecorded activity.

Diagnostics use `{code, severity, phase_id, criterion_id, references, message}` with nullable phase/criterion IDs. Use stable `REPORT_*` codes and fixed display text. `source_manifest` records exact-byte SHA-256 identities and scoped paths, including pinned definitions and referenced evidence; it excludes the report outputs to avoid self-reference.

`specification_coverage` counts accepted task acceptance criteria separately from phase-progression criteria. Classify criteria by the exact pinned stage catalogue IDs and accepted task definitions, never by a guessed ID prefix. An empty or unmapped task acceptance matrix remains unresolved; do not infer completion from zero requirements. Preserve permitted NOT_APPLICABLE decisions individually. Conflicting verdicts with no recorded supersession are unresolved; do not use file timestamp or directory order to choose a winner.

Compute `generation_id` as SHA-256 of deterministic JSON containing the ordered source manifest, supplied generation time and generator/report versions. Use sorted object keys, UTF-8, compact separators and no non-finite numbers for canonical JSON. The same captured input and supplied time must yield the same report data.

### Python interfaces

- `harness_io.loader.parse_document(content: bytes, source: Path) -> dict | list`; `load_document(path, scope_root)` retains its existing behavior and calls this helper after a checked read.
- `reporting.evidence.capture_task(repo_root: Path, harness_root: Path, task_id: str) -> dict`: return captured document values, file identities, indexed records, diagnostics and check coverage; no source mutation.
- `reporting.evidence.check_unchanged(capture: dict) -> list[dict]`: compare every inspected input and the record inventory against the captured set immediately before publication.
- `reporting.summary.derive_report(capture: dict, *, generated_at: str) -> dict`: deterministic derivation, apart from the explicitly supplied timestamp; no I/O.
- `reporting.render.render_markdown(report: dict, *, run_root: Path) -> str`: render escaped text and verified evidence links, without reading evidence or making verdicts.
- `development/report.py: main(argv: list[str] | None = None) -> int`: orchestrate capture, derivation, output validation and publication.

The capture dictionary has `roots`, `documents`, `record_index`, `source_manifest`, `phase_map`, `history`, `evidence_checks`, `diagnostics` and `coverage`. `documents` maps scoped paths to parsed captured values; `record_index` maps record type and stable ID to document references and exposes collisions as diagnostics. `history` is the validated committed prefix plus any invalid suffix diagnostics, never a repaired event log. `evidence_checks` maps evidence references to identity/provenance/check findings. Task 3 owns this format; subsequent tasks do not reopen source files to derive different inputs.

## Task 1: Define report data and phase mapping

**Files:** create `shared/schemas/task-report.schema.json`; modify `development/workflow.yaml`, installed verification rules and relevant conformance definitions. Prepare corresponding authoring cases in `tests/test_task_report_contracts.py` when testing is authorized.

**Consumes:** the current workflow and record definitions. **Produces:** `$defs.PhaseMap` and `$defs.TaskReport` using the fixed interfaces above; default map consumed by Tasks 3–4.

- [x] Define strict local schemas for the phase map, report data, diagnostics and coverage. Use `additionalProperties: false` with an explicit extensions field where needed.
- [x] Add the reporting map to the existing development workflow without changing any state, edge, guard or skip permission.
- [x] Record machine-readable phase criterion IDs and their already-installed evidence methods. Task acceptance criteria remain in the accepted TaskSpec. Do not turn prose into executable rules or redefine what PASS means.
- [x] Define the legacy-map match and unsupported-skip behavior. Pending section 12 support stays visible as an integration dependency.
- [ ] Review cases: `test_every_state_is_mapped_or_control`, `test_custom_phase_is_preserved`, `test_report_status_is_not_tool_status`, and `test_phase_map_does_not_authorize_skip`. Assertions cover duplicate mappings, omitted states, all display enums and unchanged transition definitions.

**Verification when authorized:** `python -m unittest discover -s tests -p test_task_report_contracts.py -v`. Each case must pass; graph comparison must show no changed transitions.

## Task 2: Make strict input utilities available after installation

**Files:** create `shared/python/harness_io/{__init__.py,loader.py,schemas.py}` and `shared/python/requirements.lock`; modify `builder-kit/checker/harness_check/{__init__.py,loader.py,schemas.py}` and `builder-kit/checker/requirements.lock`.

**Consumes:** existing strict loader/schema behavior. **Produces:** installed `harness_io` API with compatible checker imports and no runtime dependency on the builder.

- [x] Move the existing loader and schema resolver into the installed support package. Preserve public APIs, exception fields and diagnostic codes. Extract `parse_document` so captured bytes are parsed without a second read.
- [x] Make checker modules explicit compatibility exports; configure imports only from the known package-relative support directory. Do not search arbitrary repository locations for code.
- [x] Keep dependency pins at `PyYAML==6.0.3`, `jsonschema==4.26.0`, `attrs==25.4.0`, `jsonschema-specifications==2025.9.1`, `referencing==0.37.0`, `rpds-py==0.30.0`, and `typing-extensions==4.15.0; python_version < "3.13"`. Make the checker lock refer to the canonical installed lock; no installation or upgrade is implicit.
- [ ] Review cases: existing loader cases retain their outcomes; `test_installed_io_has_no_builder_dependency` imports from a copied runtime after the builder is unavailable; `test_parse_captured_bytes_matches_load` exercises strict JSON/YAML behavior.

**Verification when authorized:** existing `test_loader.py` cases plus the installed-only import case. Confirm duplicate keys, non-finite values, unsafe tags, escaping paths and remote schema references still fail without outside reads.

## Task 3: Capture and inspect task evidence

**Files:** create `development/reporting/{__init__.py,evidence.py}`; proposed authoring cases in `tests/test_task_report_evidence.py` and reusable fixtures in `tests/task_report_support.py`.

**Consumes:** Task 1 schemas/mapping and Task 2 I/O. **Produces:** `capture_task` and `check_unchanged` for Tasks 4–5.

- [x] Resolve repo/harness/run roots using scoped paths before reading. Locate the task's captured definitions from `config-snapshot.yaml`, verify their identities, and validate records against those pinned schemas.
- [x] Index committed events and referenced request/decision/invocation/result/review records by their explicit IDs. Detect duplicate/conflicting IDs. Directory scanning may discover records but cannot make an uncommitted proposal authoritative.
- [x] Check continuous versions, subject/state continuity, request digests excluding `request_content_identity`, declared edge selection, gate decisions, post-state consistency and counter deltas. Check snapshot consistency separately; a stale snapshot does not replace valid event history.
- [x] Inspect actual evidence bytes and provenance. Match source/spec/configuration/adapter/run/target identities and required artifact/test-source lineage. Preserve superseded records. A FIXTURE cannot support a real execution verdict.
- [x] Record uncovered semantic/custom rules explicitly. The reference tool does not execute external verifiers or fetch remote evidence; inaccessible external evidence and unsupported approval origins remain unchecked. A conforming repository-specific replacement can provide these checks.
- [x] Detect new/removed/changed input records during publication checking. Include all read inputs in the manifest. Do not read report outputs as evidence for their own derivation.
- [ ] Review cases: `test_missing_log`, `test_dirty_source_mismatch`, `test_wrong_target_or_artifact`, `test_altered_request_replay`, `test_stale_snapshot_keeps_valid_history`, `test_external_evidence_unchecked`, `test_inventory_changes_during_capture`, `test_path_escape_has_no_outside_read`.

**Verification when authorized:** `python -m unittest discover -s tests -p test_task_report_evidence.py -v`; fixtures must assert exact diagnostic codes and unchanged source bytes.

## Task 4: Derive phase outcomes and completion support

**Files:** create `development/reporting/summary.py`; proposed cases in `tests/test_task_report_summary.py`.

**Consumes:** captured evidence and diagnostics from Task 3. **Produces:** validated TaskReport dictionaries without filesystem access.

- [x] Produce one row for each mapped phase in display order, plus visible unmapped states where necessary. Include repair activity; never suppress an unstarted or failed phase.
- [x] Derive the latest supported outcome from committed order and explicit reconciliation/supersession. A missing outcome is NOT_RECORDED. A recorded outcome without sufficient matching support is UNVERIFIED. Preserve its original claim and link the diagnostic.
- [x] Count attempts, prior failures and repairs from records. Distinguish tool execution from LLM/human review in link metadata and coverage.
- [x] Reconcile accepted task criteria by ID and revision. Only properly evidenced PASS contributes in the current implementation; scoped NOT_APPLICABLE authority remains unsupported/unresolved. Do not waive a criterion because a phase is skipped. No spec or no final verification prevents supported completion.
- [x] Calculate check result: unreadable/ambiguous authority preventing derivation gives UNVERIFIABLE; diagnosable missing/mismatched/unsupported support gives ISSUES_FOUND; otherwise CONSISTENT within declared coverage. Missing evidence for unstarted work does not itself contradict the records, but cannot support completion.
- [x] Produce fixed summary wording. For unsupported recorded COMPLETE, use: “Completion is recorded, but supporting evidence is incomplete or inconsistent.” For other states, report the recorded state and remaining criterion counts. Never accept a free-form LLM summary as the conclusion.
- [x] Treat arbitrary skip assertions as UNVERIFIED. Reserve supported USER_SKIPPED for the later installed skip protocol with a declared edge, scoped decision and supported user-origin verification. Do not accept `user_approved: true` by itself.
- [ ] Review cases: `test_complete_with_missing_log_is_unsupported`, `test_failed_then_passed_retains_both_attempts`, `test_unstarted_phase_is_visible`, `test_review_does_not_replace_required_execution`, `test_no_spec_blocks_supported_completion`, `test_untrusted_skip_is_unverified`, `test_unresolved_criterion_survives_skip`, `test_conflicting_verdicts_are_unresolved`.

**Verification when authorized:** `python -m unittest discover -s tests -p test_task_report_summary.py -v`. Repeated calls with the same capture/time must produce equal data.

## Task 5: Render and publish the short report

**Files:** create `development/report.py`, `development/reporting/render.py`, `development/templates/task-report.md`; proposed cases in `tests/test_task_report_cli.py`.

**Consumes:** `capture_task`, `check_unchanged`, `derive_report` and TaskReport schema. **Produces:** the CLI and its two report files, including partial reports.

- [x] Install the approved layout as a declarative template with a fixed phase-row repeat marker and allowlisted tokens. Unknown tokens or malformed sections produce a diagnostic; never evaluate template expressions as code.
- [x] Render summary, recorded state, check result, scope, phase table, coverage, up to three attention items and history links. Keep row details to a short fixed phrase. Link the full issue list in report-data rather than dropping extra issues.
- [x] Escape table delimiters, newlines, HTML and Markdown control characters in untrusted content. Percent-encode verified local link paths, including spaces/Unicode. Restrict external clickable links to http/https and label them unchecked; disallow executable URL schemes.
- [x] Import optional dependencies only after CLI parsing so missing prerequisites can produce a useful REPORT_UNAVAILABLE message. Reject unsafe task IDs and output symlinks before writes.
- [x] Capture and derive once; immediately before publication, check input stability. Retry capture once after a change. A second change produces an inconsistency report where safe, never a clean mixed snapshot.
- [x] Write temporary output files in the task directory; publish JSON then Markdown through file replacement. Include matching generation IDs and the JSON-byte hash in Markdown. Do not claim the pair is transactionally atomic: interrupted or mismatched publication must be detectable on the next inspection. Clean up only this invocation's temporary files.
- [x] Inspect any existing report pair's IDs and JSON hash before replacement. Report a mismatch as a prior-output diagnostic; it never becomes task evidence or prevents regeneration from valid source records. Absence of both outputs on the first run is normal.
- [x] On failure preserve old reports and print that they may be stale. On success print report paths, record-check result and exit code meaning. Output only derived files; never update events/state from the report.
- [ ] Review cases: `test_partial_task_has_report`, `test_same_inputs_same_body`, `test_markdown_injection_is_escaped`, `test_spaces_unicode_links`, `test_unavailable_dependency_exits_two`, `test_report_pair_mismatch_is_detected`, `test_reporting_changes_only_outputs`, `test_runtime_without_builder`.

**Verification when authorized:** `python -m unittest discover -s tests -p test_task_report_cli.py -v`; invoke the CLI from an unrelated working directory on a disposable installed runtime. Also visually inspect one complete, one blocked and one unsupported-completion report against the one-minute reading goal.

## Task 6: Integrate installation, handoff and user guidance

**Files:** modify `builder-kit/INSTALLER_SPEC.md`, installer prompt/checklist, runtime `development/HARNESS.md`, `development/task-spec.md`, shared verification rules/catalogue/conformance cases, installation-record template, `builder-kit/README.md`, example guidance, `docs/builder-kit-explained.md`, `docs/specification.md`, `docs/implementation-status.md`, and `tools/check-documents.py` only where existing fixed inventories need adjustment.

**Consumes:** accepted outputs of Tasks 1–5. **Produces:** a discoverable installed report feature and truthful coverage/delivery statements.

- [x] Register every added runtime file in the canonical inventory and installation provenance; add new schemas/support code to configuration capture. Keep installation structure distinct from reporter availability.
- [x] Add installation discovery of the reference generator prerequisites or a conforming replacement. A complete installation may report the generator unavailable; the LLM must not claim that a generated task report exists in that case.
- [x] Add handoff instructions to generate/link reports for completed and unfinished tasks. Reporting never becomes an extra state-machine phase and never authorizes state mutation.
- [x] Update the human-facing file guide and file counts from the actual package. Explain how to open the report, find failed attempts, and distinguish recorded completion from evidence support. Remove draft labels only for implemented behavior.
- [x] Explain migration for existing installations and legacy pinned tasks. Never rewrite old records or substitute current definitions during report generation.
- [x] Retain an explicit skip-integration checklist: install section 12 transitions/approval records; implement their mechanical derivation checks; exercise valid/invalid approval and mandatory-phase cases; only then advertise supported USER_SKIPPED reporting. The basic report can be delivered before this dependency is complete.
- [x] Review section 13 case coverage against actual changes by source inspection only. Record what was inspected and, if authorized, executed. Keep unavailable platform and skip-integration evidence pending.

**Verification when authorized:** targeted report cases, existing checker/definition suites affected by shared-I/O extraction and inventory changes, then `python tools/check-documents.py`. Native Windows/Linux remain pending until actually exercised. No historical PASS count is evidence for this update.

## Self-review and handoff

- [x] Kept the reporter independent of state enforcement and repository build/test tools.
- [x] Made phase mapping explicit and kept new skip permissions outside reporting.
- [x] Preserved the distinction between reported completion, mechanical evidence checks and reviewer judgment.
- [x] Specified installed-only dependencies, safe I/O, deterministic summaries, partial reports and output failure behavior.
- [x] Listed review cases for all five focus areas; execution remains pending authorization.
- [x] Kept source/version/profile pinning and unsupported external evidence visible.
- [x] User review of this implementation plan.
- [x] Implement and source-review Tasks 1–6 with the previously selected subagent-driven approach.
- [x] Complete scoped final source review of the combined review corrections; executable acceptance remains NOT_RUN.

Full section 13 completion also requires its skip-dependent cases after the separate section 12 implementation. Report that dependency explicitly at handoff rather than marking it satisfied by a fixture or unsupported label.

## Current implementation limits

Opaque source snapshots remain UNCHECKED. The current source-evidence update adds an explicit local enumeration format/checker with focused execution coverage. Scoped NOT_APPLICABLE authority remains unsupported. Installed parity checks require the sixteen built-in stage IDs as a subset and permit additional declared phase/criterion metadata. Reporting checks the complete supported RULE-06 policy identity separately from metadata joins. Changed policy or custom stage criteria remain mandatory UNCHECKED with affected satisfaction and phase outcomes unresolved; the reporter has no supported whole-obligation mechanism to resolve them.

The CLI disables bytecode writes before installed module imports. Library hosts must set `sys.dont_write_bytecode = True`, use `python -B`, or set `PYTHONDONTWRITEBYTECODE` before importing installed reporting/I/O modules to retain the derived-output-only contract.

The historical checklist above records the original reporting delivery. Current skip integration is tracked at the top of this plan; executed results belong in [verification](verification.md). Historical unchecked boxes are not current test results.
