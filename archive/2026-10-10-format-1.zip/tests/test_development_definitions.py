"""Installed-definition checks only; these do not execute a runtime state writer."""
import copy
import json
from pathlib import Path
import re
import unittest
import yaml
from jsonschema import ValidationError
from support import validator, FIXTURES

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'builder-kit/templates/runtime'
SEQUENCE = ('NEW BASELINED RESEARCHED PATTERN_VERIFIED SPEC_READY TEST_READY PLAN_READY '
            'IMPLEMENTED PREFLIGHT PREFLIGHT_PASSED BUILDING BUILD_PASSED TESTING '
            'TEST_PASSED SPEC_VERIFIED READY_FOR_REVIEW COMPLETE').split()
TEMPLATES = {
    'task-spec': 'TaskSpec', 'task-state': 'TaskState', 'config-snapshot': 'ConfigSnapshot',
    'transition-request': 'TransitionRequest', 'gate-decision': 'GateDecision',
    'event-log': 'EventLog', 'invocation': 'Invocation',
    'criterion-review': 'CriterionReview', 'observation': 'Observation',
}

def load(path):
    return yaml.safe_load(path.read_text())

def graph_findings(workflow):
    """Authoring graph check; neither gates nor runtime writes are implemented."""
    errors = []
    ids = [s['id'] for s in workflow['states']]
    if len(ids) != len(set(ids)):
        errors.append('duplicate state')
    seen, transition_ids = set(), set()
    for edge in workflow['transitions']:
        if edge['id'] in transition_ids:
            errors.append('duplicate transition')
        transition_ids.add(edge['id'])
        if edge['from'] not in ids or edge['to'] not in ids:
            errors.append('undefined endpoint')
        for profile in edge['profiles']:
            key = (edge['from'], profile, edge['trigger'])
            if key in seen:
                errors.append('ambiguous outcome')
            seen.add(key)
    return errors

def walkthrough_data():
    encoded = json.loads((FIXTURES / 'development-walkthroughs.json').read_text())
    def expand(value):
        if isinstance(value, dict):
            if set(value) == {'fixture_ref'}:
                return copy.deepcopy(encoded['shared_fixtures'][value['fixture_ref']])
            return {k: expand(v) for k, v in value.items()}
        if isinstance(value, list):
            return [expand(v) for v in value]
        return value
    return expand(encoded)


class DevelopmentDefinitionTests(unittest.TestCase):
    def workflow(self):
        data = load(RUNTIME / 'framework/workflows/development/workflow.yaml')
        self.assertEqual(data.get('record_type'), 'Workflow')
        return data

    def test_finite_repair_labels_are_schema_supported(self):
        from support import workflow_fixture
        for label in ['repair_allowed', 'repair_denied']:
            sample = workflow_fixture()
            sample['transitions'][0]['trigger'] = label
            self.assertTrue(validator('workflow.schema.json').is_valid(sample), label)

    def test_exact_default_sequence_and_schema(self):
        w = self.workflow()
        validator('workflow.schema.json').validate(w)
        self.assertEqual(w['initial_state'], 'NEW')
        self.assertEqual(w['terminal_states'], ['COMPLETE'])
        self.assertEqual(w['extensions']['default_sequence'], SEQUENCE)
        for a, b in zip(SEQUENCE, SEQUENCE[1:]):
            edges = [e for e in w['transitions'] if e['from'] == a and e['to'] == b and 'default' in e['profiles']]
            self.assertEqual(len(edges), 1, (a, b))
        self.assertFalse(graph_findings(w))

    def test_distinct_failures_and_exact_repair_routes(self):
        w = self.workflow()
        ids = {s['id'] for s in w['states']}
        self.assertTrue({'PREFLIGHT_FAILED', 'BUILD_FAILED', 'TEST_FAILED', 'BLOCKED', 'HUMAN_REQUIRED'} <= ids)
        self.assertEqual(w['stop_states'], ['BLOCKED', 'HUMAN_REQUIRED'])
        for origin in ['BUILD_FAILED', 'TEST_FAILED']:
            edges = [e for e in w['transitions'] if e['from'] == origin and not e['trigger'].startswith('USER_SKIP_')]
            self.assertEqual({(e['trigger'], e['to']) for e in edges}, {('repair_allowed', 'REPAIRING'), ('repair_denied', 'HUMAN_REQUIRED')})
            self.assertEqual(len(edges), 2)
            self.assertTrue(all('RULE-09' in e['rule_ids'] for e in edges))
        for origin in ['PREFLIGHT', 'BUILDING', 'TESTING']:
            routes = {e['trigger']: e['to'] for e in w['transitions'] if e['from'] == origin}
            self.assertEqual(routes['FAIL'], {'PREFLIGHT': 'PREFLIGHT_FAILED', 'BUILDING': 'BUILD_FAILED', 'TESTING': 'TEST_FAILED'}[origin])
            for outcome in ['BLOCKED', 'UNKNOWN', 'PENDING']:
                self.assertEqual(routes[outcome], origin if outcome == 'PENDING' else 'BLOCKED')

    def test_profile_owns_bindings_and_disabled_repair(self):
        w = self.workflow()
        self.assertNotIn('capability_bindings', w)
        p = load(RUNTIME / 'framework/config/repo-profile.yaml')
        validator('profile.schema.json').validate(p)
        for origin in ['build', 'test']:
            self.assertEqual(p['extensions']['repair_policy'][origin]['enabled'], False)
            self.assertEqual(p['extensions']['repair_policy'][origin]['max_attempts'], 0)
        self.assertEqual(p['state_writer']['mode'], 'LLM_PROTOCOL')
        self.assertIsNone(p['state_writer']['binding'])
        self.assertEqual([x['id'] for x in p['workflow_profiles']], ['default'])
        self.assertTrue(all(b['configuration_status'] == 'PENDING_DISCOVERY' for b in p['capabilities'].values()))
        broken = copy.deepcopy(w)
        broken['capability_bindings'] = p['capabilities']
        with self.assertRaises(ValidationError):
            validator('workflow.schema.json').validate(broken)

    def test_alternate_profiles_have_explicit_edges(self):
        w = self.workflow()
        for profile, destination in [('source-only', 'TESTING'), ('docs', 'SPEC_VERIFIED')]:
            edges = [e for e in w['transitions'] if e['from'] == 'PREFLIGHT_PASSED' and profile in e['profiles'] and e['trigger'] == 'READY']
            self.assertEqual([e['to'] for e in edges], [destination])
            self.assertIn('RULE-07', edges[0]['rule_ids'])
        examples = w['extensions']['profile_examples']
        self.assertEqual(set(examples), {'default', 'source-only', 'docs'})
        self.assertFalse(examples['source-only']['installed'])
        self.assertFalse(examples['docs']['installed'])

    def test_resolution_covers_every_nonterminal_and_resume_is_reevaluation(self):
        w = self.workflow()
        routes = {r['id']: r for r in w['resolution_routes']}
        for state in w['states']:
            if state['id'] == 'COMPLETE':
                continue
            for key in ['unresolved_route', 'stop_route', 'resume_route']:
                self.assertIn(state[key], routes)
        for stop in w['stop_states']:
            state = next(s for s in w['states'] if s['id'] == stop)
            self.assertEqual(routes[state['stop_route']]['to'], stop)
            edges = [e for e in w['transitions'] if e['from'] == stop]
            self.assertTrue(edges)
            self.assertTrue(all(e['trigger'] in ['RESOLVED', 'INVALIDATED', 'ADOPTED'] for e in edges))
            self.assertTrue(all({'RULE-11', 'RULE-12'} <= set(e['rule_ids']) for e in edges))

    def test_all_rule_references_are_installed(self):
        path = RUNTIME / 'framework/workflows/verification-rules.md'
        self.assertTrue(path.is_file(), 'installed rule catalogue missing')
        rules = path.read_text()
        headings = re.findall(r'^### (RULE-\d\d)$', rules, re.M)
        self.assertEqual(headings, [f'RULE-{i:02}' for i in range(1, 18)])
        for edge in self.workflow()['transitions']:
            for rule in edge['rule_ids']:
                self.assertIn(rule, headings)
                self.assertNotIn(rule, ['RULE-13', 'RULE-14', 'RULE-15', 'RULE-16'])
        for i in list(range(1, 13)) + [17]:
            body = rules.split(f'### RULE-{i:02}\n', 1)[1].split('\n### ', 1)[0]
            for label in ['Inputs:', 'Method:', 'PASS:', 'FAIL:', 'UNKNOWN:', 'Route:']:
                self.assertIn(label, body, (i, label))

    def test_snapshot_manifest_captures_required_definition_kinds(self):
        path = RUNTIME / 'framework/templates/development/config-snapshot.yaml'
        data = load(path)
        kinds = {d['kind'] for d in data['captured_definitions']}
        self.assertTrue({'PROFILE', 'WORKFLOW', 'RULES', 'SCHEMA', 'ADAPTER', 'CRITERIA'} <= kinds)
        for item in data['captured_definitions']:
            if item['kind'] != 'CRITERIA':  # Task 6 installs the catalogue.
                self.assertTrue((RUNTIME / item['reference']['path']).is_file())
        self.assertIn('EXAMPLE', path.read_text())

    def test_templates_conform_and_have_fixture_warning(self):
        for stem, definition in TEMPLATES.items():
            path = RUNTIME / f'framework/templates/development/{stem}.yaml'
            self.assertTrue(path.is_file(), f'{definition} template missing')
            self.assertIn('EXAMPLE', path.read_text())
            validator('records.schema.json', definition).validate(load(path))
        state = load(RUNTIME / 'framework/templates/development/task-state.yaml')
        self.assertEqual(state['version'], 1)
        self.assertEqual(state['repair_counters'], {'build': 0, 'test': 0})

    def test_ambiguous_workflow_binding_is_detected(self):
        w = self.workflow()
        broken = copy.deepcopy(w)
        broken['transitions'].append({**broken['transitions'][0], 'id': 'DEV-999'})
        self.assertIn('ambiguous outcome', graph_findings(broken))

    def test_concrete_walkthroughs_cover_task2_variants(self):
        path = FIXTURES / 'development-walkthroughs.json'
        self.assertTrue(path.is_file(), 'concrete walkthrough inputs and decisions missing')
        data = walkthrough_data()
        scenarios = {x['scenario_id'] for x in data['cases']}
        self.assertEqual(scenarios, {'S-05'} | {f'S-{i:02}' for i in range(10, 30)} | {'S-36', 'S-40', 'S-41', 'S-42', 'S-43', 'S-47'})
        self.assertGreaterEqual(len(data['cases']), 55)
        for case in data['cases']:
            validator('records.schema.json', 'GateDecision').validate(case['gate_decision'])
            validator('records.schema.json', 'TaskState').validate(case['state_before'])
            validator('records.schema.json', 'TaskState').validate(case['state_immediately_after_decision'])
            self.assertEqual(case['state_before'], case['state_immediately_after_decision'])
            self.assertTrue(case['inspected_inputs'])
            self.assertTrue(case['reason'])
            self.assertTrue(case['limitations'])
            self.assertEqual(case['history_before'], case['history_after'])
            if case['follow_up'] is not None:
                if case['gate_decision']['decision'] != 'ALLOW':
                    self.assertNotEqual(case['follow_up']['request_id'], case['gate_decision']['request_id'])
                validator('records.schema.json', 'TaskState').validate(case['follow_up']['post_state'])
        self.assertEqual(data['provenance'], 'FIXTURE')

    def test_complete_committed_replay_preserves_every_field(self):
        path = FIXTURES / 'development-replay.json'
        self.assertTrue(path.is_file(), 'concrete replay evidence missing')
        data = json.loads(path.read_text())
        validator('records.schema.json', 'EventLog').validate(data['committed_log'])
        previous = None
        for event in data['committed_log']['events']:
            self.assertEqual(event['previous_version'], 0 if previous is None else previous['version'])
            self.assertEqual(event['previous_state'], None if previous is None else previous['state'])
            self.assertEqual(event['next_version'], event['previous_version'] + 1)
            post = event['post_state']
            self.assertEqual(post['version'], event['next_version'])
            self.assertEqual(post['state'], event['next_state'])
            self.assertEqual(post['task_id'], event['subject_id'])
            for key, delta_key in [('repair_counters', 'repair'), ('invocation_counters', 'invocation')]:
                old = {} if previous is None else previous[key]
                deltas = {k: post[key].get(k, 0) - old.get(k, 0) for k in set(post[key]) | set(old)}
                self.assertEqual({k: v for k, v in deltas.items() if v}, event['counter_deltas'][delta_key])
            previous = copy.deepcopy(post)
        self.assertEqual(set(previous), set(data['expected_snapshot']))
        for field, value in data['expected_snapshot'].items():
            self.assertEqual(previous[field], value, field)
        self.assertEqual(previous['configuration_id'], 'cfg-2')
        self.assertTrue(previous['pending_invocation_refs'])
        self.assertEqual(previous['invocation_counters']['build'], 2)
        for definition, value in data['immutable_records'].items():
            validator('records.schema.json', definition).validate(value)

    def test_safe_stops_are_admissible_without_success_guards(self):
        rules = (RUNTIME / 'framework/workflows/verification-rules.md').read_text()
        self.assertTrue('Destination-aware safe-stop admission' in rules, 'safe-stop admission is undefined')
        self.assertIn('does not relabel an adapter PASS', rules)
        cases = {c['case_id']: c for c in walkthrough_data()['cases']}
        for case_id, cause_rule, outcome in [
            ('S-11-safe-stop-pass-missing', 'RULE-06', 'UNKNOWN'),
            ('S-18-safe-stop-planning-missing', 'RULE-06', 'UNKNOWN'),
            ('S-22-safe-stop-permission-denied', 'RULE-08', 'FAIL'),
            ('S-22-safe-stop-budget-pending', 'RULE-10', 'UNKNOWN'),
        ]:
            self.assertIn(case_id, cases)
            case = cases[case_id]
            stop_request = case['follow_up']['request']
            stop_decision = case['follow_up']['gate_decision']
            validator('records.schema.json', 'TransitionRequest').validate(stop_request)
            validator('records.schema.json', 'GateDecision').validate(stop_decision)
            self.assertEqual(stop_decision['decision'], 'ALLOW')
            edge = next(e for e in self.workflow()['transitions'] if e['id'] == stop_request['transition_id'])
            self.assertEqual(edge['from'], case['state_before']['state'])
            self.assertEqual(edge['to'], case['follow_up']['post_state']['state'])
            findings = {f['rule_id']: f for f in stop_decision['rule_findings']}
            self.assertTrue(set(edge['rule_ids']) <= set(findings), 'every listed stop rule needs a recorded finding')
            for rule in ['RULE-01', 'RULE-02', 'RULE-11']:
                self.assertEqual(findings[rule]['result'], 'PASS')
            self.assertEqual(findings[cause_rule]['result'], outcome)
            self.assertIn(cause_rule, edge['rule_ids'])
            self.assertEqual(case['follow_up']['post_state']['invocation_counters'], case['state_before']['invocation_counters'])
            self.assertEqual(case['follow_up']['post_state']['repair_counters'], case['state_before']['repair_counters'])
            self.assertEqual(case['follow_up']['post_state']['pending_invocation_refs'], case['state_before']['pending_invocation_refs'])
            self.assertNotEqual(stop_request['request_id'], case['request']['request_id'])
        self.assertEqual(cases['S-11-safe-stop-pass-missing']['inspected_inputs']['result']['status'], 'PASS')

    def test_sequence_trace_and_dispatch_records_are_coherent(self):
        cases = {c['case_id']: c for c in walkthrough_data()['cases']}
        case = cases['S-10-default-sequence']
        trace = case['inspected_inputs']['trace']
        self.assertEqual(case['request']['expected_version'], trace[-2]['committed_version'])
        self.assertEqual(case['follow_up']['post_state']['version'], trace[-1]['committed_version'])
        self.assertEqual(case['follow_up']['post_state']['invocation_counters'], {'preflight': 1, 'build': 1, 'test': 1})
        self.assertEqual(case['state_before'], trace[-1]['state_before'])
        self.assertEqual(case['follow_up']['post_state'], trace[-1]['post_state'])
        for prior, row in zip(trace, trace[1:]):
            self.assertEqual(prior['post_state'], row['state_before'])
        for row in trace:
            validator('records.schema.json', 'TaskState').validate(row['post_state'])
            self.assertEqual(row['state_before']['version'] + 1, row['committed_version'])
            self.assertEqual(row['post_state']['state'], row['to'])
            self.assertEqual(row['criterion_review']['criteria'][0]['criterion_id'], row['stage_criterion_id'])

    def test_default_trace_reports_match_pinned_inputs(self):
        case = next(c for c in walkthrough_data()['cases'] if c['case_id'] == 'S-10-default-sequence')
        self.assertIn('configuration_profile', case['inspected_inputs'])
        profile = case['inspected_inputs']['configuration_profile']
        validator('profile.schema.json').validate(profile)
        self.assertNotEqual(profile['permissions'].get('status'), 'PENDING_DISCOVERY')
        intents = {}
        for row in case['inspected_inputs']['trace']:
            if row['persisted_intent']:
                intent = row['persisted_intent']
                intents[intent['capability']] = intent
                binding = profile['capabilities'][intent['capability']]
                self.assertEqual(binding['configuration_status'], 'CONFIGURED')
                self.assertEqual(intent['expected_identities']['adapter'], binding['adapter'])
                self.assertEqual(intent['inputs']['source'], row['post_state']['input_snapshot'])
                self.assertEqual(row['post_state']['invocation_counters'][intent['capability']], row['state_before']['invocation_counters'][intent['capability']] + 1)
                self.assertTrue(row['post_state']['pending_invocation_refs'])
            if row['tool_result']:
                result = row['tool_result']
                validator('result.schema.json').validate(result)
                intent = intents[result['capability']]
                self.assertEqual(result['run_id'], intent['run_id'])
                self.assertEqual(result['revision'], intent['expected_identities']['revision'])
                self.assertEqual(result['targets'], intent['inputs']['targets'])
                self.assertEqual(result['configuration_id'], intent['expected_identities']['configuration_id'])
                normalization = profile['capabilities'][result['capability']]['normalization']
                for selector, flag in result['extensions'].items():
                    self.assertEqual(flag, normalization[selector])
                self.assertFalse(row['post_state']['pending_invocation_refs'])

    def test_default_trace_invocation_budgets_match_pinned_policy(self):
        case = next(c for c in walkthrough_data()['cases'] if c['case_id'] == 'S-10-default-sequence')
        profile = case['inspected_inputs']['configuration_profile']
        for row in case['inspected_inputs']['trace']:
            invocations = [row['persisted_intent'], row['minimum_evidence'].get('persisted_intent'), row['minimum_evidence'].get('completed_invocation')]
            for invocation in filter(None, invocations):
                policy = profile['capabilities'][invocation['capability']]['invocation']
                self.assertEqual(invocation['counters']['call_budget'], policy['call_budget'])
                self.assertEqual(invocation['counters']['time_budget_seconds'], policy['deadline_seconds'])
                self.assertLessEqual(invocation['counters']['calls'], invocation['counters']['call_budget'])
                self.assertLessEqual(invocation['counters']['elapsed_seconds'], invocation['counters']['time_budget_seconds'])

    def test_default_verification_plan_covers_all_required_accepted_criteria(self):
        case = next(c for c in walkthrough_data()['cases'] if c['case_id'] == 'S-10-default-sequence')
        criteria = case['inspected_inputs']['accepted_specification']['criteria']
        row = next(r for r in case['inspected_inputs']['trace'] if r['to'] == 'TEST_READY')
        plan = {p['id']: p for p in row['minimum_evidence']['criterion_verification_plan']}
        required = {c['id'] for c in criteria if c['required']}
        self.assertTrue(required <= set(plan), sorted(required - set(plan)))
        for criterion in criteria:
            if criterion['required']:
                entry = plan[criterion['id']]
                self.assertEqual(entry['due_state'], criterion['due_state'])
                self.assertTrue(any(method in entry['method'] for method in criterion['allowed_methods']))
                self.assertTrue(entry['planned_evidence'])

    def test_alternate_test_dispatch_persists_intent_and_counter(self):
        cases = {c['case_id']: c for c in walkthrough_data()['cases']}
        for case_id in ['S-40-source-only', 'S-23-shortcut-declared-valid']:
            case = cases[case_id]
            self.assertIn('persisted_test_intent', case['inspected_inputs'])
            invocation = case['inspected_inputs']['persisted_test_intent']
            validator('records.schema.json', 'Invocation').validate(invocation)
            self.assertEqual(invocation['dispatch_status'], 'INTENT_RECORDED')
            post = case['follow_up']['post_state']
            self.assertEqual(post['invocation_counters']['test'], case['state_before']['invocation_counters']['test'] + 1)
            self.assertTrue(post['pending_invocation_refs'])
            self.assertEqual(invocation['expected_identities']['configuration_id'], post['configuration_id'])
            self.assertEqual(invocation['inputs']['source'], post['input_snapshot'])
            self.assertEqual(invocation['inputs']['targets'], post['selected_targets'])
            self.assertEqual(case['follow_up']['invocation_counter_delta'], {'test': 1})

    def test_default_stage_criteria_are_installed_and_referenced(self):
        rules = (RUNTIME / 'framework/workflows/verification-rules.md').read_text()
        body = rules.split('### RULE-06\n', 1)[1].split('### RULE-07', 1)[0]
        rows = re.findall(r'^\| (D-[A-Z-]+) \| ([A-Z_]+) \| ([^|]+) \| ([^|]+) \|$', body, re.M)
        self.assertEqual([r[1] for r in rows], SEQUENCE[1:])
        self.assertEqual(len({r[0] for r in rows}), 16)
        for _, _, methods, minimum in rows:
            self.assertIn('LLM_REVIEW', methods)
            self.assertGreater(len(minimum.strip()), 20)
        for phrase in ['relevant instruction', 'question', 'impact', 'pattern', 'tasks mapped to criterion', 'Repository/task extensions']:
            self.assertIn(phrase, body)
        criterion_ids = {r[0] for r in rows}
        spec = load(RUNTIME / 'framework/templates/development/task-spec.yaml')
        self.assertTrue(criterion_ids <= {c['id'] for c in spec['criteria']})
        self.assertIn('D-BASELINE', (RUNTIME / 'framework/templates/development/criterion-review.yaml').read_text())
        trace = next(c for c in walkthrough_data()['cases'] if c['case_id'] == 'S-10-default-sequence')['inspected_inputs']['trace']
        self.assertEqual([r['stage_criterion_id'] for r in trace], [r[0] for r in rows])

    def test_rules_describe_reduction_and_binding_authority(self):
        path = RUNTIME / 'framework/workflows/verification-rules.md'
        self.assertTrue(path.is_file())
        text = path.read_text()
        for phrase in ['known running child', 'missing/malformed/mismatched/UNKNOWN',
                       'then BLOCKED', 'then FAIL', 'otherwise PASS',
                       'absent or false', 'every field', 'No repair while a child is unresolved']:
            self.assertIn(phrase, text)

if __name__ == '__main__':
    unittest.main()
