"""Check retained evidence integrity; these assertions do not enforce runtime gates."""
import hashlib
import json
from pathlib import Path
import unittest
import zipfile
import yaml
from support import validator, recorded_evidence_path, FIXTURES

ROOT=Path(__file__).resolve().parents[1]


class ConformanceRecordTests(unittest.TestCase):
    def test_each_scenario_has_typed_obligation_results(self):
        path=FIXTURES/'scenario-results.yaml'
        self.assertTrue(path.exists(),'actual conformance results not retained')
        records=yaml.safe_load(path.read_text())['results']
        self.assertEqual({r['scenario_id'] for r in records},{f'S-{n:02}' for n in range(1,49)})
        for r in records:
            with self.subTest(case=r['case_id']):
                self.assertTrue(validator('records.schema.json','ScenarioResult').is_valid(r),r)
                self.assertTrue(r['limitations'])
                if r['actual_result']=='PASS':
                    self.assertTrue(r['evidence_refs'])
                    for e in r['evidence_refs']:
                        self.assertEqual(e['reference']['scope'],'REPOSITORY')
                        p=recorded_evidence_path(e['reference']['path'])
                        self.assertTrue(p.is_file(),str(p))
                        self.assertEqual(e['identity'],'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest())

    def test_native_matrix_keeps_unavailable_hosts_pending(self):
        path=FIXTURES/'native-platform-matrix.yaml'
        self.assertTrue(path.exists(),'native execution matrix not retained')
        matrix=yaml.safe_load(path.read_text())
        actual=[x for x in matrix['runs'] if x['status']=='PASS']
        self.assertEqual({x['python_minor'] for x in actual},{'3.11','3.14'})
        self.assertEqual({x['os'] for x in actual},{'macOS'})
        for run in actual:
            self.assertEqual(run['exit_code'],0)
            self.assertEqual(run['before_tree'],run['after_tree'])
            self.assertNotEqual(run['cwd'],run['repository'])
            self.assertTrue(run['dependencies'])
        self.assertEqual({x['os'] for x in matrix['pending']},{'Windows','Linux'})
        for row in matrix['pending']:
            self.assertEqual(row['status'],'PENDING');self.assertTrue(row['reproduction_commands'])

    def test_retained_walkthrough_publishes_real_bytes_and_preserves_pins(self):
        archive=FIXTURES/'checks/installed-walkthrough.zip'
        self.assertTrue(archive.exists(),'installed-only publication evidence not retained')
        with zipfile.ZipFile(archive) as z:
            def get(path):return yaml.safe_load(z.read('compiled/.harness/'+path))
            profile=get('shared/repo-profile.yaml')
            self.assertEqual(profile['configuration_id'],'cfg-5')
            task=get('development/runs/SYNTHETIC-task/state.yaml')
            self.assertEqual(task['state'],'IMPLEMENTED')
            self.assertEqual(task['configuration_id'],'cfg-4')
            original=get('development/runs/SYNTHETIC-task/config-snapshot.yaml')
            self.assertEqual(original['configuration_id'],'cfg-3')
            for name in ['replace-build','rule-schema-migration']:
                update=get('maintenance/updates/'+name+'.yaml')
                self.assertTrue(validator('records.schema.json','UpdateRecord').is_valid(update))
                self.assertEqual(update['current']['state'],'COMPLETE')
                promoted=[e for e in update['events'] if e['next_state']=='PROMOTED']
                self.assertTrue(promoted)
                for item in promoted[0]['post_state']['publication_manifest']:
                    expected=item['after_identity']
                    receipt=get('maintenance/updates/'+name+'/evidence/receipt.json')
                    self.assertIn(item,receipt['manifest'])
                self.assertEqual(update['current'],update['events'][-1]['post_state'])
            replacement=get('maintenance/updates/replace-build.yaml')
            states=[e['next_state'] for e in replacement['events']]
            self.assertIn(['PENDING','INSPECTED','PROMOTED'],[states[i:i+3] for i in range(len(states)-2)])
            self.assertEqual(z.read('compiled/USER-NOTES.txt'),b'SYNTHETIC user-owned note; preserve on resume.\n')

    def test_retained_events_replay_and_match_explicit_requests(self):
        archive=FIXTURES/'checks/installed-walkthrough.zip'
        self.assertTrue(archive.exists())
        with zipfile.ZipFile(archive) as z:
            prefix='compiled/.harness/'
            records={name[len(prefix):]:yaml.safe_load(z.read(name)) for name in z.namelist()
                if name.startswith(prefix) and name.endswith('.yaml') and '/configuration/' not in name and '/candidate/' not in name}
            requests={r['request_id']:r for r in records.values() if isinstance(r,dict) and r.get('record_type')=='TransitionRequest'}
            for path,data in records.items():
                if not isinstance(data,dict) or data.get('record_type') not in ('EventLog','UpdateRecord'):continue
                if '/templates/' in path:continue
                previous=None
                for event in data['events']:
                    self.assertEqual(event['previous_version'],0 if previous is None else previous['next_version'])
                    self.assertEqual(event['previous_state'],None if previous is None else previous['next_state'])
                    self.assertEqual(event['post_state']['version'],event['next_version'])
                    self.assertEqual(event['post_state']['state'],event['next_state'])
                    decision_path=event['decision_ref']['reference']['path']
                    decision=records[decision_path]
                    self.assertEqual(decision['record_type'],'GateDecision')
                    self.assertEqual(decision['decision'],'ALLOW')
                    self.assertEqual(decision['request_id'],event['request_id'])
                    self.assertEqual(decision['proposed_destination'],event['next_state'])
                    self.assertEqual(event['decision_ref']['identity'],'sha256:'+hashlib.sha256(z.read(prefix+decision_path)).hexdigest())
                    if previous:
                        request=requests[event['request_id']]
                        self.assertEqual(request['expected_state'],event['previous_state'])
                        self.assertEqual(request['expected_version'],event['previous_version'])
                        self.assertEqual(request['request_content_identity'],event['request_content_identity'])
                    previous=event
                if data['record_type']=='UpdateRecord':self.assertEqual(data['current'],previous['post_state'])
            for path in ['development/runs/SYNTHETIC-task/config-snapshot.yaml','development/runs/SYNTHETIC-task/adopted-config-snapshot.yaml']:
                for entry in records[path]['captured_definitions']:
                    stored=prefix+'development/runs/SYNTHETIC-task/'+entry['captured_path']
                    self.assertEqual(entry['identity'],'sha256:'+hashlib.sha256(z.read(stored)).hexdigest())

    def test_reviewed_installations_keep_readiness_and_coverage_separate(self):
        for name in ['compiled','source-only','docs','multi-target']:
            report=json.loads((FIXTURES/('checks/reviewed-'+name+'.stdout.json')).read_text())
            self.assertEqual(report['exit_code'],0,report['diagnostics'])
            self.assertEqual(report['structure_assessment'],'STRUCTURE_COMPLETE')
            self.assertEqual(report['integration_assessment'],'PARTIAL' if name=='compiled' else 'READY')
            self.assertIn('IS-03.separation',report['uncovered_ids'])
            self.assertIn('IS-08.assessment',report['uncovered_ids'])
            if name=='compiled':
                self.assertIn('IS-08.inventory',report['uncovered_ids'])
                self.assertFalse(any(a['criterion_id']=='IS-08.inventory' and a['result']=='PASS' for a in report['checked_assessments']))

    def test_catalogue_join_covers_every_exact_part_without_mode_substitution(self):
        catalogue=json.loads((ROOT/'tests/conformance-cases.yaml').read_text())
        ledger=yaml.safe_load((FIXTURES/'scenario-results.yaml').read_text())
        expected={p['id']:(c['case_id'],p['mode']) for c in catalogue['cases'] for p in c['coverage_parts']}
        joins=ledger.get('catalogue_part_coverage',[])
        # Reporting added these obligations after the retained authoring ledger.
        # The JavaScript trial is not a formal conformance assessment or a review
        # of every new obligation: these parts remain explicitly unassessed.
        pending_reporting={
            'S-48.reporting-handoff-migration.walkthrough',
            'S-10.reporting-review-execution-separation.walkthrough',
            'S-10.reporting-failed-then-passed-history.walkthrough',
            'S-10.reporting-every-state-is-mapped-or-control.walkthrough',
            'S-10.reporting-skip-integration-pending.walkthrough',
            'S-48.reporting-partial-and-unavailable.walkthrough',
            'S-10.reporting-stale-source-or-spec.walkthrough',
            'S-10.reporting-unresolved-history.walkthrough',
            'S-48.reporting-installation-availability.walkthrough',
            'S-10.reporting-missing-log-completion.walkthrough',
            'S-10.reporting-custom-phase-is-preserved.walkthrough',
            'S-10.reporting-report-status-is-not-tool-status.walkthrough',
            'S-10.reporting-source-inventory-and-applicability.walkthrough',
            'S-10.reporting-phase-map-does-not-authorize-skip.walkthrough',
            'S-10.reporting-installed-catalogue-parity.walkthrough',
        }
        covered={j['part_id'] for j in joins}
        self.assertFalse(covered & pending_reporting)
        self.assertEqual(covered | pending_reporting,set(expected))
        self.assertEqual(len(joins),len(expected)-len(pending_reporting))
        self.assertEqual({part for part in expected if '.reporting-' in part},pending_reporting)
        results={r['case_id']:r for r in ledger['results']}
        for join in joins:
            self.assertEqual((join['case_id'],join['mode']),expected[join['part_id']])
            result=results[join['result_id']]
            self.assertEqual(result['mode'],join['mode'])
            self.assertEqual(result['actual_result'],join['actual_result'])
            self.assertEqual(result['extensions']['catalogue_case_id'],join['case_id'])
            self.assertEqual(result['extensions']['coverage_part_ids'],[join['part_id']])
            self.assertTrue(result['observations'])
            if result['actual_result']=='PASS':self.assertTrue(result['extensions']['source_result_ids'])

    def test_additional_procedural_reviews_have_typed_linked_proposals(self):
        for name in ['research-invalidated','test-origin-repair','migration-changed-base']:
            folder=FIXTURES/'checks/additional-procedural'/name
            inputs=json.loads((folder/'inputs.json').read_text());review=json.loads((folder/'review.json').read_text())
            previous=inputs['state']
            for proposal in review['proposals']:
                request=proposal['request'];decision=proposal['gate_decision'];event=proposal['event_proposal']
                for value in [request,decision,event]:
                    errors=list(validator('records.schema.json',value['record_type']).iter_errors(value))
                    self.assertFalse(errors,[e.message for e in errors])
                self.assertEqual(request['expected_state'],previous['state'])
                self.assertEqual(request['expected_version'],previous['version'])
                self.assertEqual(event['post_state']['state'],decision['proposed_destination'])
                self.assertEqual(event['request_id'],request['request_id'])
                self.assertEqual(event['request_content_identity'],request['request_content_identity'])
                decision_path=recorded_evidence_path(event['decision_ref']['reference']['path'])
                self.assertEqual(json.loads(decision_path.read_text()),decision)
                self.assertEqual(event['decision_ref']['identity'],'sha256:'+hashlib.sha256(decision_path.read_bytes()).hexdigest())
                for field in review['preserved_fields']:self.assertEqual(previous[field],event['post_state'][field])
                previous=event['post_state']
            if name=='research-invalidated':self.assertEqual(previous['state'],'NEW')
            elif name=='test-origin-repair':
                self.assertEqual(previous['repair_counters']['test'],1)
                self.assertEqual(previous['repair_counters']['build'],inputs['state']['repair_counters']['build'])
                self.assertEqual(review['required_continuation'][-1]['to'],'TEST_PASSED')
            else:
                self.assertNotEqual(inputs['approved_base'],inputs['actual_current_configuration_id'])
                self.assertEqual(review['refused_success']['decision'],'DENY')
                self.assertEqual(review['state_immediately_after_refusal'],inputs['state'])
                self.assertEqual(previous['state'],'PENDING')

    def test_prospective_compatibility_uses_exact_inspected_adapter_before_publication(self):
        with zipfile.ZipFile(FIXTURES/'checks/installed-walkthrough.zip') as z:
            prefix='compiled/.harness/'
            def get(path):return json.loads(z.read(prefix+path))
            initial=get('development/runs/SYNTHETIC-task/configuration/initial/shared/repo-profile.yaml')
            original_adapter=initial['capabilities']['build']['adapter']['content_identity']
            self.assertEqual(original_adapter,'sha256:'+hashlib.sha256(z.read(prefix+'development/runs/SYNTHETIC-task/configuration/initial/shared/adapters/synthetic_adapter.py')).hexdigest())
            for envelope in get('installation/evidence/final-review.json')['compatibility_fixture_observations']:
                self.assertEqual(envelope['adapter_definition_id'],original_adapter)
                self.assertEqual(envelope['adapter']['content_identity'],original_adapter)
            for update_id in ['replace-build','rule-schema-migration']:
                dossier=get('installation/evidence/'+update_id+'-review.json')
                update=get('maintenance/updates/'+update_id+'.yaml')
                receipt=get('maintenance/updates/'+update_id+'/evidence/receipt.json')
                candidate=get('maintenance/updates/'+update_id+'/evidence/candidate/shared/repo-profile.yaml')
                for envelope in sorted(dossier['compatibility_fixture_observations'],key=lambda e:e['capability']):
                    capability=envelope['capability']
                    self.assertEqual(envelope['adapter_definition_id'],envelope['adapter']['content_identity'])
                    inspected=dossier['inspected_adapter_sources'][capability]
                    module=z.read(prefix+inspected['module']['path'])
                    procedure=z.read(prefix+inspected['procedure']['path'])
                    actual='sha256:'+hashlib.sha256(module).hexdigest()
                    self.assertEqual(actual,inspected['module']['identity'])
                    self.assertEqual(actual,envelope['adapter_definition_id'])
                    self.assertEqual(actual,candidate['capabilities'][capability]['adapter']['content_identity'])
                    self.assertEqual(inspected['procedure']['identity'],'sha256:'+hashlib.sha256(procedure).hexdigest())
                    self.assertIn(inspected['module']['path'].split('/')[-1].encode(),procedure)
                    self.assertEqual(envelope['configuration_id'],candidate['configuration_id'])
                    self.assertEqual(envelope['revision'],initial['repository']['identity'])
                    self.assertEqual(envelope['provenance'],'FIXTURE')
                compatible=next(e for e in update['events'] if e['next_state'] in ['ADAPTER_COMPATIBLE','MIGRATION_CHECKED'])
                self.assertLess(dossier['observed_at'],compatible['timestamp'])
                self.assertTrue(all(compatible['timestamp']<w['observed_at'] for w in receipt['writes']))
                for claim in candidate['assessments']:
                    if claim['result']=='PASS':
                        self.assertEqual(claim['evidence_refs'][0]['identity'],'sha256:'+hashlib.sha256(z.read(prefix+'installation/evidence/'+update_id+'-review.json')).hexdigest())
            build=[e for e in get('installation/evidence/replace-build-review.json')['compatibility_fixture_observations'] if e['capability']=='build']
            self.assertNotEqual(build[0]['adapter_definition_id'],original_adapter)

    def test_s47_catalogue_join_is_exact_build_gate_with_preflight_supplement(self):
        ledger=json.loads((FIXTURES/'scenario-results.yaml').read_text())
        result=next(r for r in ledger['results'] if r['case_id']=='T6-catalogue-S-47.fixture-at-execution-gate.walkthrough')
        self.assertEqual(result['extensions']['source_result_ids'],['T6-index-S-47-fixture-at-execution-gate'])
        source=json.loads((FIXTURES/'development-walkthroughs.json').read_text())
        raw=next(c for c in source['cases'] if c['case_id']=='S-47-fixture-at-execution-gate')
        def expand(v):
            if isinstance(v,dict):
                if set(v)=={'fixture_ref'}:return expand(source['shared_fixtures'][v['fixture_ref']])
                return {k:expand(x) for k,x in v.items()}
            if isinstance(v,list):return [expand(x) for x in v]
            return v
        case=expand(raw)
        self.assertEqual(case['state_before']['state'],'BUILDING')
        self.assertEqual(case['gate_decision']['decision'],'DENY')
        flow=yaml.safe_load((ROOT/'builder-kit/templates/runtime/framework/workflows/development/workflow.yaml').read_text())
        transition=next(e for e in flow['transitions'] if e['id']==case['request']['transition_id'])
        self.assertEqual((transition['from'],transition['to']),('BUILDING','BUILD_PASSED'))
        self.assertTrue(any(r['case_id']=='T6-actual-fixture-refusal' for r in ledger['results']))
