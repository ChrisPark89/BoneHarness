"""Bounded installation invariants. Never dispatches adapters or mutates records."""
from collections import Counter
from copy import deepcopy
import hashlib
import json
import posixpath
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit
from .layout import legacy_path, NEW_ONLY, check_layout
from .assessment import summarize
from .loader import DocumentError, load_document, read_bytes, relative_path, scoped_path
from .report import new_report
from .schemas import local_validator

SEQUENCE = ['NEW','BASELINED','RESEARCHED','PATTERN_VERIFIED','SPEC_READY','TEST_READY',
            'PLAN_READY','IMPLEMENTED','PREFLIGHT','PREFLIGHT_PASSED','BUILDING','BUILD_PASSED',
            'TESTING','TEST_PASSED','SPEC_VERIFIED','READY_FOR_REVIEW','COMPLETE']
TEMPLATES = {
    'framework/templates/installation/installation-record.yaml':'InstallationRecord',
    'framework/templates/development/config-snapshot.yaml':'ConfigSnapshot',
    'framework/templates/development/criterion-review.yaml':'CriterionReview',
    'framework/templates/development/event-log.yaml':'EventLog',
    'framework/templates/development/gate-decision.yaml':'GateDecision',
    'framework/templates/development/invocation.yaml':'Invocation',
    'framework/templates/development/observation.yaml':'Observation',
    'framework/templates/development/task-spec.yaml':'TaskSpec',
    'framework/templates/development/task-state.yaml':'TaskState',
    'framework/templates/development/transition-request.yaml':'TransitionRequest',
    'framework/templates/maintenance/harness-update-record.yaml':'UpdateRecord',
}
SCHEMA_FILES = ('common','criteria','profile','records','result','workflow','task-report')
BUILTIN_STAGE_IDS = {'D-BASELINE','D-RESEARCH','D-PATTERN','D-SPEC',
    'D-VERIFY-PLAN','D-IMPLEMENT-PLAN','D-IMPLEMENT','D-PREFLIGHT-INTENT',
    'D-PREFLIGHT','D-BUILD-INTENT','D-BUILD','D-TEST-INTENT','D-TEST',
    'D-SPEC-FULL','D-FINAL-REVIEW','D-COMPLETE'}
REQUIRED_FILES = set(TEMPLATES) | {f'framework/templates/schemas/{s}.schema.json' for s in SCHEMA_FILES} | {
    'framework/workflows/development/HARNESS.md','framework/templates/development/task-spec.md','framework/workflows/development/workflow.yaml',
    'framework/workflows/maintenance/harness-maintenance.md','framework/workflows/maintenance/maintenance-workflow.yaml',
    'framework/templates/setup.md','framework/adapters/adapter-interface.md','framework/workflows/verification-rules.md',
    'framework/config/repo-profile.yaml','framework/workflows/verification-criteria.yaml',
    'framework/templates/installation/installation-record.yaml',
    'framework/workflows/reporting-legacy-baseline.json','framework/tools/requirements.lock',
    'framework/tools/harness_io/__init__.py','framework/tools/harness_io/loader.py',
    'framework/tools/harness_io/schemas.py','framework/tools/report.py',
    'framework/tools/reporting/__init__.py','framework/tools/reporting/evidence.py',
    'framework/tools/reporting/summary.py','framework/tools/reporting/render.py',
    'framework/templates/development/task-report.md','README.md',
    'framework/tools/journal.py','framework/tools/harness_io/journal.py',
    'framework/workflows/development/journal-protocol.md',
    'framework/tools/source.py',
    'framework/tools/harness_io/source_inventory.py',
    'framework/workflows/source-evidence.md',
    'framework/tools/context.py',
    'framework/tools/context_reader.py',
    'framework/workflows/context.md',
    'framework/workflows/recovery.md',
    'framework/workflows/setup.md',

}
AUTOMATED = ('IS-01.files','IS-01.schemas','IS-02.local_refs','IS-03.registry','IS-04.graph',
             'IS-05.result_schema','IS-06.records','IS-07.sequence','IS-08.inventory')

# Version 1.0.0 coverage binds exact scoped obligations. Changed descriptions
# require review instead of silently inheriting a partial automated PASS.
CORE_CRITERIA = ('IS-01.files', 'IS-01.schemas', 'IS-02.local_refs', 'IS-02.ownership', 'IS-03.registry', 'IS-03.separation', 'IS-04.graph', 'IS-04.routing', 'IS-05.result_schema', 'IS-05.evidence', 'IS-06.records', 'IS-06.recovery', 'IS-07.sequence', 'IS-07.applicability', 'IS-08.inventory', 'IS-08.assessment', 'IS-01.discovery', 'IS-08.provenance')
OBLIGATION_IDENTITIES = {'IS-01.files': '27397e85ec9b1a3c5bf5481977cf1df5b7e4e6d0a2fcbbee70d96e3a8b84ac0b', 'IS-01.schemas': '840061f761348ddee5968d51ed3b790778eccb5b803f99c787366fe3b6854a91', 'IS-02.local_refs': '1f76bba225453326b9acdcc403017585c260438130857653c21b4552109117bc', 'IS-03.registry': 'dfcb09a5df52596f9624fc99ab804812edb36567a76ed505405c62369c69343e', 'IS-04.graph': '503781ab10e61fc9eb772f9657b0c4df93d0a301fce98e4532eb3cca84cbdf6c', 'IS-05.result_schema': '76da592c98dfd176b28d65e74289e5231a225a24117c647baf412dc16a036426', 'IS-06.records': 'b2bc6e78d460e1844fc6c817db86c2640f86b2ac17552d945b63412d23201c47', 'IS-07.sequence': 'f83ff1cbd0911bd33eeb89d8ae23f02723a7408469c0168a5f1697d444df6170', 'IS-08.inventory': '3167ac29d37df05788f1245a6506fdfcb86308b66764bf0106e06121aa00cf31'}


def identity(data):
    return 'sha256:' + hashlib.sha256(data).hexdigest()


def walk(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


class Inspection:
    def __init__(self, repo, harness, record, catalogue, legacy=False):
        self.legacy = legacy
        self.record_templates = {legacy_path(k) if legacy else k: v for k,v in TEMPLATES.items()
                          if not (legacy and v == "InstallationRecord")}
        self.required_files = {legacy_path(k) if legacy else k for k in REQUIRED_FILES
                               if not (legacy and k in NEW_ONLY)}
        self.repo, self.harness = repo, harness
        self.record_path, self.catalogue_path = record, catalogue
        self.report = new_report()
        self.documents, self.bytes, self.validators = {}, {}, {}
        self.coverage = {}
        self.eligibility = {}
        self.active = {}
        self.updates = []

    def name(self, name):
        return legacy_path(name) if self.legacy else name

    def location(self, name):
        return self.harness / self.name(name)

    def relative(self, name, **kwargs):
        return relative_path(self.name(name), self.harness, **kwargs)

    def diagnostic(self, code, path, message, cid=None, exit_code=1):
        d = dict(code=code,path=str(path) or '/',message=message,reference=None)
        if cid:
            d['criterion_id'] = cid
        self.report['diagnostics'].append(d)
        self.report['exit_code'] = max(self.report['exit_code'],exit_code)

    def error(self, exc, cid):
        self.diagnostic(exc.code,exc.path,str(exc),cid,exc.exit_code)

    def document(self, path, *, require_object=False):
        scoped_path(path,self.harness)
        name = str(path.relative_to(self.harness))
        if name not in self.documents:
            self.documents[name] = load_document(path,self.harness)
            self.bytes[name] = read_bytes(path,self.harness)
        if require_object and not isinstance(self.documents[name],dict):
            raise DocumentError('SCHEMA_ROOT',path,'This machine definition requires an object root')
        return self.documents[name]

    def data(self, path):
        name = str(path.relative_to(self.harness))
        if name not in self.bytes:
            self.bytes[name] = read_bytes(path,self.harness)
        return self.bytes[name]

    def validate(self, value, filename, definition, path, cid):
        key = (filename,definition)
        try:
            if key not in self.validators:
                self.validators[key] = local_validator(scoped_path(self.location('framework/templates/schemas')/filename,self.harness),definition)
            errors = sorted(self.validators[key].iter_errors(value),key=lambda e:str(e.path))
            for error in errors:
                self.diagnostic('SCHEMA_INVALID',str(path)+'/'+ '/'.join(map(str,error.absolute_path)),error.message,cid)
            return not errors
        except DocumentError as exc:
            self.error(exc,cid)
        except Exception as exc:
            self.diagnostic('SCHEMA_DEFINITION',path,f'{type(exc).__name__}: {exc}',cid)
        return False

    def eligible(self, cid):
        if cid not in self.eligibility:
            definitions = [d for d in self.catalogue['criteria'] if d['id'] == cid]
            eligible = len(definitions) == 1 and 'AUTOMATED' in definitions[0]['allowed_methods']
            if eligible and hashlib.sha256(definitions[0]['description'].encode('utf-8')).hexdigest() != (('f6c61f6ba43bef03db6cb1cb795da5d344db17e1fd5a7c5582de9a23600a8d3e' if cid == 'IS-08.inventory' else OBLIGATION_IDENTITIES[cid]) if self.legacy else OBLIGATION_IDENTITIES[cid]):
                eligible = False
            if not eligible:
                self.report['limitations'].append(cid+' uncovered: installed methods or obligation text differ from automated coverage; whole-obligation review is required.')
            if cid == 'IS-07.sequence' and not self.default_repair_policy():
                eligible = False
                self.report['limitations'].append(cid+' wholly uncovered: adapted repair policy requires current whole-obligation authority/applicability review. The checker does not grant runtime repair permission or certify review truth.')
            self.eligibility[cid] = eligible
        return self.eligibility[cid]

    def run_check(self, cid, procedure, *, input_safety=False):
        before = len(self.report['diagnostics'])
        try:
            eligible = self.eligible(cid)
            if not eligible and not input_safety:
                return
            complete = procedure()
        except DocumentError as exc:
            self.error(exc,cid); complete = False
        except (KeyError, TypeError, ValueError, IndexError) as exc:
            self.diagnostic('SCHEMA_INVALID',cid,f'Invalid input prevents check: {type(exc).__name__}: {exc}',cid)
            complete = False
        except Exception as exc:
            self.diagnostic('PREREQUISITE_INTERNAL',cid,f'{type(exc).__name__}: {exc}',cid,2)
            complete = False
        new_errors = self.report['diagnostics'][before:]
        if not self.eligibility.get(cid):
            return
        self.coverage[cid] = 'FAIL' if any(d.get('criterion_id') == cid for d in new_errors) else ('PASS' if complete else 'PENDING')

    def files(self):
        declared = self.catalogue['extensions']['required_runtime_files']
        if self.eligibility['IS-01.files'] and (len(declared) != len(set(declared)) or not self.required_files.issubset(declared)):
            self.diagnostic('REFERENCE_INVENTORY','required_runtime_files','Required paths must be unique and include every version 1.0.0 runtime artifact','IS-01.files')
        for name in sorted(set(declared) | self.required_files):
            try:
                relative_path(name,self.harness)
            except DocumentError as exc:
                self.error(exc,'IS-01.files')
        roots = [relative_path(name,self.harness,directory=True).resolve() for name in (('development','maintenance','shared','installation') if self.legacy else ('framework','docs','artifacts'))]
        if len(set(roots)) != (4 if self.legacy else 3) or any(a.is_relative_to(b) for a in roots for b in roots if a != b):
            self.diagnostic('PATH_SEPARATION',self.harness,'Runtime purpose directories must be distinct','IS-01.files')
        return True

    def schema_checks(self):
        cid = 'IS-01.schemas'
        definitions = {d['id']:d for d in self.catalogue['criteria']}
        if any(k not in definitions or definitions[k]['category']!='STRUCTURE' or definitions[k]['required'] is not True for k in CORE_CRITERIA):
            self.diagnostic('REFERENCE_CRITERIA','criteria','Required core structural criteria cannot be removed, made optional, or reclassified',cid)
        schemas_complete = self.schema_dependencies(cid)
        self.validate_repair_policy(cid)
        pairs = [('framework/config/repo-profile.yaml','profile.schema.json',None),
                 ('framework/workflows/reporting-legacy-baseline.json','task-report.schema.json','ReportingLegacyBaseline'),
                 ('framework/workflows/development/workflow.yaml','workflow.schema.json',None),
                 ('framework/workflows/maintenance/maintenance-workflow.yaml','workflow.schema.json',None)]
        for name,schema,definition in pairs:
            doc = self.document(self.location(name))
            self.validate(doc,schema,definition,name,cid)
            self.active[name] = doc
        self.validate(self.catalogue,'criteria.schema.json','Catalogue',self.catalogue_path,cid)
        self.validate(self.record,'records.schema.json','InstallationRecord',self.record_path,cid)
        self.active[str(self.record_path.relative_to(self.harness))] = self.record
        self.active[str(self.catalogue_path.relative_to(self.harness))] = self.catalogue
        # Inventory explicitly supplies additional current machine definitions/records.
        names = {p['path'] for p in self.record.get('generated_paths',[]) if p['scope']=='HARNESS'}
        names |= self.history_records()
        for name in sorted(names - set(self.active) - set(self.record_templates)):
            if (name.startswith(self.name('framework/templates/schemas') + '/')
                    or 'evidence' in Path(name).parts
                    or not name.endswith(('.yaml','.yml','.json'))):
                continue
            doc = self.document(relative_path(name,self.harness))
            kind = doc.get('record_type') if isinstance(doc,dict) else None
            self.validate_record(doc,kind,name,cid)
            self.active[name] = doc
            if kind == 'UpdateRecord':
                self.updates.append(doc)
        return schemas_complete

    def schema_dependencies(self, cid):
        # Core schemas, inventoried definitions and every active binding schema
        # share one installed scope. Transitive refs are resolved offline there.
        schema_root = self.relative('framework/templates/schemas',directory=True)
        paths = {schema_root/(name+'.schema.json') for name in SCHEMA_FILES}
        complete = True
        for item in self.record.get('generated_paths',[]):
            if item['scope']=='HARNESS' and item['path'].startswith(self.name('framework/templates/schemas') + '/'):
                paths.add(relative_path(item['path'],self.harness))
        for binding in self.profile['capabilities'].values():
            references = [binding['input_schema']]
            normalization = binding.get('normalization')
            if isinstance(normalization,dict):
                references.append(normalization.get('extensions_schema'))
            for ref in references:
                if not isinstance(ref,dict) or ref.get('status')=='PENDING_DISCOVERY':
                    continue
                if ref.get('kind')=='EXTERNAL':
                    complete = False
                    self.report['limitations'].append(cid+' unresolved: active external schema cannot be validated offline; no schema retrieval attempted.')
                else:
                    resolved = self.resolve_reference(ref)
                    if resolved:
                        paths.add(resolved[0])
        for path in sorted(paths):
            try:
                # Containment is checked against the installed schema scope before
                # local_validator opens the adapter schema or its dependencies.
                local_validator(scoped_path(path,schema_root),scope_root=schema_root)
            except DocumentError as exc:
                self.error(exc,cid)
        return complete

    def history_records(self):
        # Read only named machine records under installed durable histories; raw
        # evidence is consumed through typed references, never as an implicit record.
        names = set()
        for prefix in ('artifacts/maintenance','artifacts/development'):
            base = self.location(prefix)
            if not base.exists():
                continue
            base = self.relative(prefix,directory=True)
            def descend(directory):
                for path in directory.iterdir():
                    # Validate each component before traversing any symlink.
                    relative = path.relative_to(self.harness).as_posix()
                    if path.is_symlink():
                        scoped_path(path,self.harness,directory=path.is_dir())
                    if path.is_dir():
                        if path.name not in ('evidence','configuration'):
                            descend(relative_path(relative,self.harness,directory=True))
                    elif path.suffix in ('.yaml','.yml','.json'):
                        names.add(relative)
            descend(base)
        return names

    def validate_record(self, doc, kind, name, cid):
        special = {'Result':('result.schema.json',None),'Profile':('profile.schema.json',None),
                   'Workflow':('workflow.schema.json',None),'CriteriaCatalogue':('criteria.schema.json','Catalogue'),
                   'CriterionAssessment':('criteria.schema.json','Assessment'),
                   'TaskReport':('task-report.schema.json','TaskReport'),
                   'ReportingLegacyBaseline':('task-report.schema.json','ReportingLegacyBaseline')}
        # Older installations may inventory this project-only catalogue. Validate
        # it if supplied, but do not require or install it for new harnesses.
        special['ConformanceCatalogue'] = ('conformance.schema.json', None)
        filename,definition = special.get(kind,('records.schema.json',kind))
        if kind is None:
            self.diagnostic('SCHEMA_RECORD_TYPE',name,'Supplied active record requires record_type',cid)
            return False
        return self.validate(doc,filename,definition,name,cid)

    def resolve_reference(self, ref):
        if ref['kind'] == 'EXTERNAL':
            return None
        if ref.get('scope') not in ('HARNESS','REPOSITORY'):
            raise DocumentError('PATH_SCOPE',ref.get('path','?'),'Unknown reference scope')
        root = self.harness if ref['scope']=='HARNESS' else self.repo
        path = relative_path(ref['path'],root)
        if 'entry_id' in ref:
            self.journal_entry(ref, path, root)
        return path,root

    def journal_entry(self, ref, path, root):
        if path.name != 'history.jsonl':
            raise DocumentError('REFERENCE_ENTRY', path, 'Entry references require history.jsonl')
        from harness_io.journal import parse_history
        entries = parse_history(read_bytes(path, root), path.parent.name)
        selected = [entry for entry in entries if entry['entry_id'] == ref['entry_id']]
        if len(selected) != 1:
            raise DocumentError('REFERENCE_ENTRY', path, 'Journal entry ID is absent or ambiguous')
        return selected[0]

    def references(self):
        cid = 'IS-02.local_refs'
        # Inventory ownership/lineage may require review, but its declared
        # file paths still undergo containment/casing checks without reads.
        for item in self.record['generated_paths'] + self.record['owned_paths']:
            try:
                self.resolve_reference(dict(kind='LOCAL',scope=item['scope'],path=item['path']))
            except DocumentError as exc:
                self.error(exc,cid)
        for name,doc in self.active.items():
            # Template references and embedded case literals are inert. Conformance
            # catalogue typed evidence/action/config refs are still active.
            for item in walk(doc):
                if item.get('kind') == 'LOCAL' and 'scope' in item and 'path' in item:
                    try:
                        self.resolve_reference(item)
                    except DocumentError as exc:
                        self.error(exc,cid)
        for path in sorted(self.harness.rglob('*.md')):
            # Histories and evidence are not runtime procedure definitions.
            name = path.relative_to(self.harness).as_posix()
            if any(part in ('runs','updates','evidence') for part in path.relative_to(self.harness).parts):
                continue
            text = self.data(path).decode('utf-8')
            destinations = re.findall(r'\[[^\]\n]*\]\(([^\n]+?)\)',text)
            destinations += re.findall(r'^\s{0,3}\[[^\]\n]+\]:\s*(\S+)',text,re.M)
            for destination in destinations:
                destination = destination.strip()
                if destination.startswith('<'):
                    destination = destination[1:destination.index('>')]
                else:
                    destination = destination.split(' ',1)[0]
                parts = urlsplit(destination)
                if parts.scheme in ('https','http','mailto'):
                    continue
                if parts.scheme or parts.netloc or '\\' in destination:
                    self.diagnostic('PATH_MARKDOWN',name,'Unsupported nonlocal runtime link',cid);continue
                if not parts.path:
                    continue
                if parts.path.startswith('/'):
                    self.diagnostic('PATH_MARKDOWN',name,'Runtime link must be relative',cid);continue
                local = posixpath.normpath(posixpath.join(str(path.parent.relative_to(self.harness)),unquote(parts.path)))
                try:
                    target = self.harness/local
                    relative_path(local,self.harness,directory=parts.path.endswith('/'))
                except DocumentError as exc:
                    self.error(exc,cid)
        return self.schema_dependencies(cid)

    def registry(self):
        cid = 'IS-03.registry'
        profiles = [p['id'] for p in self.profile['workflow_profiles']]
        if len(set(profiles)) != len(profiles):
            self.diagnostic('REGISTRY_DUPLICATE','workflow_profiles','Duplicate active profile ID',cid)
        caps = set(self.profile['capabilities'])
        for p in self.profile['workflow_profiles']:
            for cap in p['required_capabilities']:
                if cap not in caps:
                    self.diagnostic('REGISTRY_CAPABILITY',p['id'],'Unknown required capability: '+cap,cid)
        for flow in self.flows:
            for item in walk(flow):
                if any(key in item for key in ('capabilities','adapters','capability_registry','adapter_registry')):
                    self.diagnostic('REGISTRY_DUPLICATE',flow['workflow_id'],'Workflow-local binding registry forbidden',cid)
            selections = flow.get('extensions',{}).get('stage_capabilities',{})
            for state,cap in selections.items():
                if cap not in caps or state not in {s['id'] for s in flow['states']}:
                    self.diagnostic('REGISTRY_CAPABILITY',state,'Stage capability/state does not resolve',cid)
        mapping = self.flows[1].get('extensions',{}).get('request_type_profiles',{})
        if set(mapping) != {'ADAPTER_CHANGE','FACT_CORRECTION','DRIFT_REVIEW','MIGRATION'} or len(set(mapping.values())) != 4:
            self.diagnostic('REGISTRY_MAINTENANCE','request_type_profiles','Require four unique maintenance request selectors',cid)
        return True

    def graph(self):
        cid = 'IS-04.graph'
        rules_text = self.data(self.location('framework/workflows/verification-rules.md')).decode('utf-8')
        headings = re.findall(r'^### (RULE-\d+)\s*$',rules_text,re.M)
        required_rules = {f'RULE-{i:02}' for i in range(1,18)}
        if not required_rules.issubset(headings) or len(set(headings)) != len(headings):
            self.diagnostic('GRAPH_RULE','framework/workflows/verification-rules.md','Missing/duplicate installed rule headings',cid)
        active_profiles = {p['id'] for p in self.profile['workflow_profiles']}
        for flow in self.flows:
            label = flow['workflow_id']
            states = [s['id'] for s in flow['states']]
            edges = flow['transitions'] + flow['resolution_routes']
            ids = [e['id'] for e in edges]
            if len(set(states)) != len(states) or len(set(ids)) != len(ids):
                self.diagnostic('GRAPH_DUPLICATE',label,'Duplicate state or route/transition ID',cid)
            members = [flow['initial_state'],*flow['terminal_states'],*flow['stop_states']]
            if any(s not in states for s in members):
                self.diagnostic('GRAPH_STATE',label,'Initial/terminal/stop state is undefined',cid)
            routes = {e['id']:e for e in flow['resolution_routes']}
            for state in flow['states']:
                if state['id'] not in flow['terminal_states']:
                    for key in ('unresolved_route','stop_route','resume_route'):
                        target = state[key]
                        if target not in states and not (target in routes and routes[target]['from']==state['id']):
                            self.diagnostic('GRAPH_ROUTE',state['id'],'Missing or invalid '+key,cid)
            selectors = (active_profiles | set(flow.get('extensions',{}).get('profile_examples',{}))) if label=='development' else set(flow.get('extensions',{}).get('request_type_profiles',{}).values())
            seen = set()
            for edge in edges:
                if edge['from'] not in states or edge['to'] not in states:
                    self.diagnostic('GRAPH_ENDPOINT',edge['id'],'Undefined edge endpoint',cid)
                if not edge['rule_ids'] or any(r not in headings for r in edge['rule_ids']):
                    self.diagnostic('GRAPH_RULE',edge['id'],'Unknown/uninstalled rule reference',cid)
                if 'profiles' in edge:
                    for selector in edge['profiles']:
                        if selector not in selectors:
                            self.diagnostic('GRAPH_SELECTOR',edge['id'],'Unknown workflow selector: '+selector,cid)
                        key = (edge['from'],selector,edge['trigger'])
                        if key in seen:
                            self.diagnostic('GRAPH_AMBIGUOUS',edge['id'],'More than one edge for source/profile/trigger',cid)
                        seen.add(key)
        return self.reporting_map(self.flows[0], rules_text, active_profiles)

    def reporting_map(self, flow, rules_text, active_profiles):
        """Check display metadata against the installed graph and RULE-06 table."""
        cid = 'IS-04.graph'
        name = 'framework/workflows/development/workflow.yaml/extensions/reporting'
        mapping = flow.get('extensions', {}).get('reporting')
        if not self.validate(mapping, 'task-report.schema.json', 'PhaseMap', name, cid):
            return
        selectors = active_profiles | set(flow.get('extensions', {}).get('profile_examples', {}))
        states = {s['id'] for s in flow['states']}
        assignments = list(mapping['control_states'])
        phase_ids, orders, referenced = [], [], []
        criteria = mapping['stage_criteria']
        criterion_ids = [c['id'] for c in criteria]
        by_id = {c['id']: c for c in criteria}
        for phase in mapping['phases']:
            phase_ids.append(phase['id']); orders.append(phase['order'])
            members = phase['success_states'] + phase['active_states'] + phase['failure_states']
            assignments.extend(members)
            if not set(phase['profiles']).issubset(selectors):
                self.diagnostic('GRAPH_REPORTING_PROFILE', name, 'Unknown reporting profile selector', cid)
            for criterion in phase['criterion_ids']:
                referenced.append(criterion)
                if criterion not in by_id or by_id[criterion]['due_state'] not in members:
                    self.diagnostic('GRAPH_REPORTING_CRITERION', name, 'Phase criterion does not resolve to its due state', cid)
        if (len(phase_ids) != len(set(phase_ids)) or len(orders) != len(set(orders))
                or Counter(assignments) != Counter({state: 1 for state in states})):
            self.diagnostic('GRAPH_REPORTING_PARTITION', name, 'Require unique phase IDs/orders and exactly one role per declared state', cid)
        if len(criterion_ids) != len(set(criterion_ids)) or len(referenced) != len(set(referenced)):
            self.diagnostic('GRAPH_REPORTING_CRITERION', name, 'Duplicate stage criterion or phase criterion assignment', cid)
        for criterion in criteria:
            if (criterion['due_state'] not in states or
                    (criterion['due_state'] not in mapping['control_states'] and criterion['id'] not in referenced)):
                self.diagnostic('GRAPH_REPORTING_CRITERION', name, 'Stage criterion is unmapped or has an unknown due state', cid)
        # Parse metadata joins only. Every other policy-bearing byte, including
        # Minimum evidence cells and extra rows, remains in the coverage identity;
        # unknown prose cannot become an executable rule or a waived obligation.
        normalized_rules = rules_text.replace('\r\n', '\n')
        section = normalized_rules.split('### RULE-06\n', 1)[-1].split('### RULE-07', 1)[0]
        policy_supported = hashlib.sha256(section.strip().encode('utf-8')).hexdigest() == '1b40d31acc23fe2f91bb8466a1a78cb45faf97bad9f549b9167abfdd893ad69f'
        rows = [(identifier.strip(), due.strip(), methods.strip())
                for identifier, due, methods in re.findall(
                    r'^\s*\|\s*([^|\n]+)\|\s*([^|\n]+)\|\s*([^|\n]+)\|', section, re.M)
                if (identifier.strip(), due.strip(), methods.strip()) !=
                    ('ID', 'Due success state', 'Allowed methods') and
                not all(re.fullmatch(r':?-+:?', field.strip())
                        for field in (identifier, due, methods))]
        declared_ids = [row[0] for row in rows]
        if len(declared_ids) != len(set(declared_ids)):
            self.diagnostic('GRAPH_REPORTING_CATALOGUE', name, 'Duplicate installed RULE-06 table criterion', cid)
        expected = {}
        for criterion, due, methods in rows:
            allowed = [method.strip() for method in methods.split('+')]
            actual = by_id.get(criterion)
            if actual is None:
                self.diagnostic('GRAPH_REPORTING_CATALOGUE', name, 'Installed RULE-06 criterion is missing from reporting catalogue: '+criterion, cid)
            elif actual['due_state'] != due or actual['allowed_methods'] != allowed:
                self.diagnostic('GRAPH_REPORTING_CATALOGUE', name, 'Reporting metadata differs from installed RULE-06 table: '+criterion, cid)
            if criterion not in BUILTIN_STAGE_IDS:
                continue
            expected[criterion] = dict(id=criterion, due_state=due, required=True,
                allowed_methods=allowed, execution_required=criterion in {'D-PREFLIGHT','D-BUILD','D-TEST'},
                independent_review_required=True)
        if (set(expected) != BUILTIN_STAGE_IDS or
                len([row for row in rows if row[0] in BUILTIN_STAGE_IDS]) != 16):
            self.diagnostic('GRAPH_REPORTING_CATALOGUE', name, 'Installed sixteen-criterion RULE-06 table is missing or ambiguous; equivalent review is required', cid)
        for criterion, obligation in expected.items():
            actual = by_id.get(criterion, {})
            if any(actual.get(key) != value for key, value in obligation.items()):
                self.diagnostic('GRAPH_REPORTING_CATALOGUE', name, 'Reporting catalogue differs from installed RULE-06: '+criterion, cid)
        # The legacy fingerprint is an immutable shipped identity, not the hash
        # of the repository's potentially customized current workflow.
        legacy = self.active.get('framework/workflows/reporting-legacy-baseline.json', {})
        if legacy.get('workflow_identity') != 'sha256:1a404d4658c10e812b828e32dd1cd87292087c0a8c15eee14e3a50066998854b':
            self.diagnostic('GRAPH_REPORTING_LEGACY', 'framework/workflows/reporting-legacy-baseline.json', 'Unsupported immutable baseline fingerprint', cid)
        legacy_map = legacy.get('phase_map', {})
        legacy_identity = hashlib.sha256(json.dumps(legacy_map, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()
        if legacy_identity != 'd1cb0003b5bc3c52346e7ec75442aaa6ce158db5d0471add0f94832cd8fcce69':
            self.diagnostic('GRAPH_REPORTING_LEGACY', 'framework/workflows/reporting-legacy-baseline.json', 'Immutable supported legacy map changed', cid)
        baseline_states = set(SEQUENCE) | {'PREFLIGHT_FAILED','BUILD_FAILED','TEST_FAILED','REPAIRING','BLOCKED','HUMAN_REQUIRED','RESUME_REVIEW'}
        legacy_roles = list(legacy_map.get('control_states', []))
        for phase in legacy_map.get('phases', []):
            legacy_roles.extend(phase['success_states'] + phase['active_states'] + phase['failure_states'])
        if Counter(legacy_roles) != Counter({state: 1 for state in baseline_states}):
            self.diagnostic('GRAPH_REPORTING_LEGACY', 'framework/workflows/reporting-legacy-baseline.json', 'Legacy map does not partition supported baseline states', cid)
        if not policy_supported:
            self.reporting_policy_uncovered = True
            self.report['limitations'].append('IS-04.graph uncovered: installed RULE-06 policy, including table rows and Minimum evidence, differs from the supported contract; equivalent whole-obligation review is required.')
            return False
        if set(criterion_ids) - BUILTIN_STAGE_IDS:
            self.reporting_policy_uncovered = True
            self.report['limitations'].append('IS-04.graph uncovered: custom stage criterion metadata joins are checked, but custom required/method/execution/review policy needs equivalent whole-obligation review.')
            return False
        return True

    def templates(self):
        declared = self.catalogue['extensions']['template_record_definitions']
        if self.eligibility['IS-06.records'] and (set(declared) != set(self.record_templates) or len(declared)!=len(self.record_templates)):
            self.diagnostic('REFERENCE_TEMPLATE','template_record_definitions','Require all declared persistence templates exactly once','IS-06.records')
        for name,kind in self.record_templates.items():
            self.validate(self.document(self.location(name)),'records.schema.json',kind,name,'IS-06.records')
        return True

    def default_repair_policy(self):
        policies = self.profile.get('extensions',{}).get('repair_policy')
        if not isinstance(policies,dict):
            return False
        for cap in ('build','test'):
            policy = policies.get(cap)
            if (not isinstance(policy,dict) or policy.get('enabled') is not False or
                    type(policy.get('max_attempts')) is not int or policy['max_attempts'] != 0 or
                    policy.get('route_after_repair') != 'PREFLIGHT' or
                    'shortcut_rule' not in policy or policy['shortcut_rule'] is not None):
                return False
        return True

    def validate_repair_policy(self, cid):
        # RULE-09 declares this extension's input contract. Validate it even
        # when an adaptation makes the whole sequence obligation review-only.
        policies = self.profile.get('extensions',{}).get('repair_policy')
        rules = set(re.findall(r'^### (RULE-\d+)\s*$',
                    self.data(self.location('framework/workflows/verification-rules.md')).decode('utf-8'),re.M))
        for cap in ('build','test'):
            policy = policies.get(cap) if isinstance(policies,dict) else None
            if (not isinstance(policy,dict) or type(policy.get('enabled')) is not bool or
                    type(policy.get('max_attempts')) is not int or policy['max_attempts'] < 0 or
                    policy.get('route_after_repair') != 'PREFLIGHT' or 'shortcut_rule' not in policy or
                    (policy['shortcut_rule'] is not None and
                     (not isinstance(policy['shortcut_rule'],str) or policy['shortcut_rule'] not in rules))):
                self.diagnostic('SCHEMA_REPAIR_POLICY',cap,
                    'Repair policy requires explicit enabled boolean, nonnegative integer max_attempts, PREFLIGHT route, and null or declared shortcut rule; shape is not action authority.',cid)

    def sequence(self):
        cid = 'IS-07.sequence'
        flow = self.flows[0]
        if self.catalogue['extensions']['default_sequence'] != SEQUENCE or flow['extensions']['default_sequence'] != SEQUENCE:
            self.diagnostic('GRAPH_SEQUENCE','default_sequence','Default sequence differs from approved version 1.0.0 sequence',cid)
        edges = flow['transitions']
        for source,target in zip(SEQUENCE,SEQUENCE[1:]):
            matches = [e for e in edges if e['from']==source and e['to']==target and 'default' in e['profiles'] and e['trigger'] in ('READY','PASS','COMPLETED')]
            if len(matches)!=1:
                self.diagnostic('GRAPH_SEQUENCE',source,'Missing/ambiguous default success edge to '+target,cid)
        success = {(e['from'],e['to']) for e in edges if 'default' in e['profiles'] and e['trigger'] in ('READY','PASS','COMPLETED') and e['from'] in SEQUENCE}
        if success != set(zip(SEQUENCE,SEQUENCE[1:])):
            self.diagnostic('GRAPH_SEQUENCE','default','Unexpected success shortcut',cid)
        required = [('BUILDING','FAIL','BUILD_FAILED'),('TESTING','FAIL','TEST_FAILED'),
                    ('BUILD_FAILED','repair_denied','HUMAN_REQUIRED'),('TEST_FAILED','repair_denied','HUMAN_REQUIRED'),
                    ('BUILD_FAILED','repair_allowed','REPAIRING'),('TEST_FAILED','repair_allowed','REPAIRING'),
                    ('REPAIRING','READY','PREFLIGHT')]
        for source,trigger,target in required:
            if not any(e['from']==source and e['trigger']==trigger and e['to']==target and 'default' in e['profiles'] for e in edges):
                self.diagnostic('GRAPH_REPAIR',source,'Required failure/repair edge is missing',cid)
        for selector,target in (('source-only','TESTING'),('docs','SPEC_VERIFIED')):
            if not any(e['from']=='PREFLIGHT_PASSED' and e['to']==target and e['profiles']==[selector] and 'RULE-07' in e['rule_ids'] for e in edges):
                self.diagnostic('GRAPH_SEQUENCE',selector,'Explicit scoped alternative edge missing',cid)
        return True

    def result_schemas(self):
        cid = 'IS-05.result_schema'
        result_validator = local_validator(scoped_path(self.location('framework/templates/schemas/result.schema.json'),self.harness))
        criterion_validator = local_validator(scoped_path(self.location('framework/templates/schemas/criteria.schema.json'),self.harness),'Assessment')
        content_id = 'sha256:' + 'a'*64
        ref = dict(kind='LOCAL',scope='HARNESS',path='framework/adapters/adapter-interface.md')
        sample = dict(schema_version='1.0.0',record_type='Result',interface_version='1.0.0',capability='build',
                      adapter=dict(identity='checker-fixture',version='1.0.0',content_identity=content_id),
                      run_id='fixture-run',task_id='fixture-task',revision=content_id,status='PASS',
                      evidence=dict(reference=ref,summary='Synthetic schema probe; not executed'),provenance='FIXTURE',
                      configuration_id='cfg-1',adapter_definition_id=content_id,
                      targets=[dict(target_id='fixture',environment='fixture')],extensions={})
        def probe(value, expected, validator, label):
            actual = validator.is_valid(value)
            if actual != expected:
                self.diagnostic('SCHEMA_PROBE',label,f'Installed schema accepted={actual}, expected={expected}',cid)
        for status in ('PASS','FAIL','BLOCKED','UNKNOWN'):
            value = dict(sample,status=status)
            probe(value,True,result_validator,status)
            for required in ('schema_version','record_type','interface_version','capability','adapter','run_id','task_id','revision','status','evidence','provenance','configuration_id','adapter_definition_id','targets'):
                missing = deepcopy(value);missing.pop(required)
                probe(missing,False,result_validator,status+' missing '+required)
        for status in ('SUCCESS','pass',None):
            probe(dict(sample,status=status),False,result_validator,'invalid status')
        artifact = dict(identity=content_id,reference=ref)
        source = dict(artifact,artifact_identity=content_id)
        for flag in ('artifact_consumed_downstream','test_source_required','artifact_lineage_required'):
            value = deepcopy(sample);value['extensions']={flag:True}
            probe(value,False,result_validator,flag+' missing lineage')
            value.update(artifact=artifact,test_source=source)
            probe(value,True,result_validator,flag+' full lineage')
            if flag == 'artifact_lineage_required':
                value['test_source']=artifact
                probe(value,False,result_validator,'missing artifact_identity')
        evidence = dict(reference=ref,provenance='REVIEW',summary='Schema fixture',identity=content_id)
        assessment = dict(schema_version='1.0.0',record_type='CriterionAssessment',catalogue_version='1.0.0',
                          criterion_id='IS-05.result_schema',result='PASS',method='AUTOMATED',actor='reference-checker',
                          evidence_refs=[evidence],reason='Schema probe',assessed_configuration_id='cfg-1')
        for result in ('PASS','NOT_APPLICABLE'):
            value = dict(assessment,result=result)
            probe(value,True,criterion_validator,result)
            for field,bad in (('evidence_refs',[]),('method',None),('actor',None)):
                probe(dict(value,**{field:bad}),False,criterion_validator,result+' missing '+field)
        return True

    def verify_evidence(self, evidence, cid, *, require_external_access=True):
        ref = evidence['reference']
        resolved = self.resolve_reference(ref)
        if resolved:
            path,root = resolved
            actual = (self.journal_entry(ref, path, root)['payload_identity'] if 'entry_id' in ref
                      else identity(read_bytes(path,root)))
            if actual != evidence['identity']:
                self.diagnostic('REFERENCE_IDENTITY',ref['path'],'Evidence content identity does not match current bytes',cid)
                return False
        elif require_external_access and ref.get('accessibility') != 'AVAILABLE':
            self.diagnostic('REFERENCE_ACCESS',ref.get('uri','external'),'External evidence is not recorded as accessible',cid)
            return False
        return True

    def inventory(self):
        cid = 'IS-08.inventory'
        generated,owned = {},{}
        physical = {}
        for name,destination in (('generated_paths',generated),('owned_paths',owned)):
            for item in self.record[name]:
                key = (item['scope'],item['path'])
                if key in destination:
                    self.diagnostic('REFERENCE_INVENTORY',item['path'],'Duplicate '+name+' entry',cid)
                destination[key] = item
                root = self.harness if item['scope']=='HARNESS' else self.repo
                safe = relative_path(item['path'],root)
                if not self.legacy and not safe.resolve().is_relative_to(self.harness.resolve()):
                    self.diagnostic('REFERENCE_OWNERSHIP', item['path'],
                                    'Layout 2 harness-owned writes must remain below .harness', cid)
                if name == 'generated_paths':
                    resolved = safe.resolve()
                    if resolved in physical:
                        self.diagnostic('REFERENCE_INVENTORY',item['path'],'Two scoped paths identify the same file',cid)
                    physical[resolved] = key
        for key,item in owned.items():
            if generated.get(key) != item:
                self.diagnostic('REFERENCE_OWNERSHIP',item['path'],'Owned entry must exactly match a generated entry',cid)
        required = {('HARNESS',name) for name in self.catalogue['extensions']['required_runtime_files']}
        # Required runtime files may predate an EXISTING installation, but FRESH
        # must capture their creation in its generated inventory.
        if self.record['mode']=='FRESH' and not required.issubset(generated):
            self.diagnostic('REFERENCE_INVENTORY','generated_paths','Fresh installation inventory omits required files',cid)
        ledger = ('HARNESS',self.name('artifacts/installation/installation-record.yaml'))
        for key,item in generated.items():
            if key == ledger:
                if item['ownership']!='GENERATED' or item['before_identity'] is not None or item['after_identity'] is not None or owned.get(key)!=item:
                    self.diagnostic('REFERENCE_LEDGER',item['path'],'Exact mutable ledger must be GENERATED, owned, with both identities null',cid)
            elif item['after_identity'] is None:
                self.diagnostic('REFERENCE_IDENTITY',item['path'],'Only the exact mutable ledger may omit its after identity',cid)
        if ledger not in generated:
            self.diagnostic('REFERENCE_LEDGER','generated_paths','Exact mutable ledger inventory entry missing',cid)
        if self.record['harness_root'] != self.harness.relative_to(self.repo).as_posix() or self.profile['repository']['harness_root'] != self.record['harness_root']:
            self.diagnostic('REFERENCE_ROOT',self.record_path,'Record/profile harness root differs from inspected root',cid)
        baseline = {a['assessed_configuration_id'] for a in self.record['criterion_assessments']}
        if len(baseline)!=1:
            self.report['limitations'].append('IS-08.inventory unresolved: historical baseline configuration is missing or ambiguous.')
            return False
        base = next(iter(baseline))
        endpoints = {key:item['after_identity'] for key,item in generated.items()}
        current = self.profile['configuration_id']
        maintained = base != current
        publications = {}
        for update in self.updates:
            events = update['events']
            accepted = {}
            if not events or events[-1]['post_state'] != update['current']:
                self.diagnostic('REFERENCE_HISTORY',update['update_id'],'Update current does not equal committed final snapshot',cid)
            for event in events:
                state = event['post_state']
                if event['next_state'] not in ('PROMOTED','ASSESSMENT_PUBLISHED'):
                    continue
                before,after = state['inspected_configuration_id'],state['prospective_configuration_id']
                if state.get('extensions',{}).get('accepted_trigger') == 'RECONCILED':
                    # The installed recovery edge restores an already accepted
                    # publication state. It must identify that exact receipt,
                    # not introduce another publication or quietly replace it.
                    original = accepted.get((before,after,event['next_state']))
                    selector = self.flows[1].get('extensions',{}).get('request_type_profiles',{}).get(update['request_type'])
                    routes = [edge for edge in self.flows[1]['transitions']
                              if edge['from']==event['previous_state'] and edge['to']==event['next_state']
                              and edge['trigger']=='RECONCILED' and selector in edge['profiles']]
                    if (original is None or len(routes)!=1 or
                            state['publication_manifest']!=original['publication_manifest'] or
                            state['candidate']!=original['candidate'] or
                            state['writer']!=original['writer'] or
                            state['before_values']!=original['before_values'] or
                            state['changed_values']!=original['changed_values'] or
                            state['promotion']!=original['promotion'] or
                            not original['evidence_refs'] or
                            not all(e in state['evidence_refs'] for e in original['evidence_refs'])):
                        self.diagnostic('REFERENCE_PUBLICATION',update['update_id'],
                                        'Reconciliation does not reuse the exact prior accepted publication and receipt',cid)
                    continue
                accepted[(before,after,event['next_state'])] = state
                if before in publications:
                    self.diagnostic('REFERENCE_ANCESTRY',update['update_id'],'Forked or duplicate publication base',cid)
                publications[before] = (after,state,update)
                promotion = state['promotion']
                expected = 'PROMOTED' if event['next_state']=='PROMOTED' else 'NOT_APPLICABLE'
                if promotion['result'] != expected:
                    self.diagnostic('REFERENCE_PUBLICATION',update['update_id'],'Publication state and promotion result disagree',cid)
                if expected == 'PROMOTED':
                    intent = promotion['intent']
                    if not intent or intent['base_configuration_id']!=before or intent['prospective_configuration_id']!=after or promotion['before_configuration_id']!=before or promotion['after_configuration_id']!=after:
                        self.diagnostic('REFERENCE_PUBLICATION',update['update_id'],'Promotion intent/base/prospective identities disagree',cid)
                elif update['request_type']!='DRIFT_REVIEW':
                    self.diagnostic('REFERENCE_PUBLICATION',update['update_id'],'Assessment publication must be a drift review',cid)
        visited = set()
        while base != current and base in publications and base not in visited:
            visited.add(base)
            after,state,update = publications[base]
            manifest_keys = set()
            for item in state['publication_manifest']:
                key = (item['scope'],item['path'])
                if key in manifest_keys:
                    self.diagnostic('REFERENCE_ANCESTRY',item['path'],'Duplicate path in publication manifest',cid)
                manifest_keys.add(key)
                root = self.harness if item['scope']=='HARNESS' else self.repo
                safe = relative_path(item['path'],root)
                resolved = safe.resolve()
                if resolved in physical and physical[resolved] != key:
                    self.diagnostic('REFERENCE_ANCESTRY',item['path'],'Publication aliases another scoped inventory path',cid)
                physical[resolved] = key
                if key not in owned and key not in generated:
                    # A scoped new GENERATED path may join the accepted chain.
                    # Its claimed prior absence/authority needs receipt review;
                    # this never turns untyped receipts into an automated PASS.
                    if (item['ownership']=='GENERATED' and item['before_identity'] is None and
                            item['after_identity'] is not None and state['evidence_refs']):
                        owned[key] = item
                    else:
                        self.diagnostic('REFERENCE_ANCESTRY',item['path'],
                                        'New publication path requires GENERATED ownership, absent before identity and receipt evidence',cid)
                if key not in owned or owned[key]['ownership'] != item['ownership'] or endpoints.get(key)!=item['before_identity']:
                    self.diagnostic('REFERENCE_ANCESTRY',item['path'],'Publication does not continue prior owned identity',cid)
                endpoints[key] = item['after_identity']
            for e in state['evidence_refs'] + state['promotion']['evidence_refs']:
                self.verify_evidence(e,cid)
            base = after
        if base != current:
            self.report['limitations'].append('IS-08.inventory unresolved: missing accepted installation-to-current maintenance lineage; no baseline-only PASS.')
            return False
        for key,expected in endpoints.items():
            if key==ledger or (maintained and key==('HARNESS',self.name('docs/setup.md'))):
                continue
            scope,path = key
            root = self.harness if scope=='HARNESS' else self.repo
            if expected is not None and identity(read_bytes(relative_path(path,root),root)) != expected:
                self.diagnostic('REFERENCE_IDENTITY',path,'Current bytes differ from accepted inventory endpoint',cid)
        if maintained:
            self.report['limitations'].append('IS-08.inventory remains wholly unresolved: receipt attempt/writer/manifest semantics and immutable baseline snapshot require equivalent whole-obligation review. Typed publication fields alone do not establish receipt acceptance.')
            return False
        return True

    def supplied_assessments(self):
        assessments = deepcopy(self.profile['assessments'])
        # Validate claims before combining with fresh checker observations. Bad
        # supplied evidence remains a failure even when a mechanical recheck passes.
        prior = summarize(self.catalogue,assessments,self.profile)
        for d in prior['diagnostics']:
            self.diagnostic(d['code'],d['path'],d['message'],d.get('criterion_id'))
        historical = self.record['criterion_assessments']
        for a in assessments:
            cid = a['criterion_id']
            if (cid == 'IS-04.graph' and getattr(self, 'reporting_policy_uncovered', False)
                    and a['result'] in ('PASS','NOT_APPLICABLE')
                    and (a['method'] not in ('LLM_REVIEW','HUMAN_REVIEW') or
                         not any(e['provenance']=='REVIEW' for e in a['evidence_refs']))):
                a['result'] = 'PENDING'
                a['reason'] = 'Custom reporting stage policy requires attributable current whole-obligation review.'
            if (cid == 'IS-07.sequence' and not self.default_repair_policy() and
                    a['result'] in ('PASS','NOT_APPLICABLE') and
                    (a['method'] not in ('LLM_REVIEW','HUMAN_REVIEW') or
                     not any(e['provenance']=='REVIEW' for e in a['evidence_refs']))):
                a['result'] = 'PENDING'
                a['reason'] = 'Adapted repair policy requires attributable current whole-obligation authority/applicability review.'
            old = [h for h in historical if h['criterion_id']==cid and h['assessed_configuration_id']!=self.profile['configuration_id']]
            old_ids = {e['identity'] for h in old for e in h['evidence_refs']}
            retained = old_ids.intersection(e['identity'] for e in a['evidence_refs'])
            if retained and a['result'] in ('PASS','NOT_APPLICABLE'):
                revalidation = [e for e in a['evidence_refs'] if e['identity'] not in old_ids and
                    e['provenance']=='REVIEW' and 'dependency' in e['summary'].lower() and
                    'revalidat' in e['summary'].lower() and self.profile['configuration_id'] in e['summary']]
                if not revalidation:
                    a['result']='PENDING'
                    a['reason']='Retained historical evidence lacks an explicit current dependency-revalidation review.'
                    self.report['limitations'].append(cid+' unresolved: no attributable current dependency-revalidation evidence for carried-forward historical inputs.')
                else:
                    self.report['limitations'].append(cid+' uses supplied dependency-revalidation review; its semantic truth is attributed to the named reviewer, not certified by automation.')
            for e in a['evidence_refs']:
                try:
                    if not self.verify_evidence(e,cid,require_external_access=a['result']!='PENDING'):
                        a['result']='PENDING'
                except DocumentError as exc:
                    self.error(exc,cid);a['result']='PENDING'
            if cid=='IS-08.provenance' and a['result']=='PASS' and (self.record['entry_point']['activation_state']!='ACTIVE' or not self.record['entry_point']['evidence_refs']):
                self.diagnostic('REFERENCE_ACTIVATION',self.record_path,'Provenance cannot pass before observed activation and reread evidence',cid)
                a['result']='PENDING'
        return assessments

    def finish(self):
        supplied = self.supplied_assessments()
        status = self.data(self.location('docs/setup.md')).decode('utf-8')
        described = re.search(r'Described configuration: `([^`]+)`, revision `([0-9]+)`',status)
        canonical = summarize(self.catalogue,supplied,self.profile)
        if described and (described[1] != self.profile['configuration_id'] or int(described[2]) != self.profile['configuration_revision']):
            self.diagnostic('REFERENCE_STATUS','docs/setup.md','Derived status configuration/revision is stale; regenerate procedurally, never roll back canonical state.','IS-08.assessment')
        for label,key in (('Structure','structure_assessment'),('Integration','integration_assessment')):
            displayed = re.search(label+r' status: `([^`]+)`',status)
            if displayed and displayed[1] != canonical[key]:
                self.diagnostic('REFERENCE_STATUS','docs/setup.md',label+' view disagrees with current canonical assessments.','IS-08.assessment')
        if not described:
            self.report['limitations'].append('Status prose format is not mechanically interpretable; whole IS-08.assessment status-view review remains required.')
        catalogue_defs = {d['id']:d for d in self.catalogue['criteria']}
        checked = []
        # Each fresh PASS references exact inspected input bytes; report content is
        # never self-hashed and no report file is created in the inspected tree.
        evidence = [dict(reference=dict(kind='LOCAL',scope='HARNESS',path=name),provenance='REVIEW',
                         summary='Input inspected by reference-checker 1.0.0 for the recorded structural checks.',identity=identity(content))
                    for name,content in sorted(self.bytes.items())]
        for cid,status in self.coverage.items():
            if status == 'PENDING':
                continue
            checked.append(dict(schema_version='1.0.0',record_type='CriterionAssessment',
                catalogue_version=self.catalogue['catalogue_version'],criterion_id=cid,result=status,
                method='AUTOMATED',actor='reference-checker/1.0.0',evidence_refs=evidence if status=='PASS' else [],
                reason='All installed obligations for this mechanical criterion checked.' if status=='PASS' else 'See diagnosed failure; no completion claim.',
                assessed_configuration_id=self.profile['configuration_id']))
        checked_ids = {a['criterion_id'] for a in checked}
        # A fresh failed check cannot be overridden by a supplied PASS. Supplied
        # FAIL/BLOCKED also cannot be silently erased by a new shape PASS.
        merged = [a for a in supplied if a['criterion_id'] not in checked_ids]
        for a in checked:
            old = [s for s in supplied if s['criterion_id']==a['criterion_id']]
            merged.append(next((s for s in old if s['result'] in ('FAIL','BLOCKED')),a))
        aggregate = summarize(self.catalogue,merged,self.profile)
        for d in aggregate['diagnostics']:
            if not any(x['code']==d['code'] and x['message']==d['message'] and x.get('criterion_id')==d.get('criterion_id') for x in self.report['diagnostics']):
                self.diagnostic(d['code'],d['path'],d['message'],d.get('criterion_id'))
        self.report.update(checked_assessments=checked,
                           uncovered_ids=sorted(set(catalogue_defs)-checked_ids),
                           structure_assessment=aggregate['structure_assessment'],
                           integration_assessment=aggregate['integration_assessment'])
        self.report['extensions']['profiles']=aggregate['profiles']
        self.report['extensions']['supplied_assessments']=supplied
        if self.report['exit_code']:
            self.report['structure_assessment']='INCOMPLETE'
        return self.report


def check_installation(repo_root: Path, harness_root: Path, record_path: Path, catalogue_path: Path, legacy=False) -> dict:
    inspection = Inspection(repo_root.resolve(strict=True),harness_root.resolve(strict=True),record_path,catalogue_path,legacy)
    try:
        scoped_path(harness_root,repo_root,directory=True)
        check_layout(harness_root, legacy)
        inspection.catalogue = inspection.document(catalogue_path,require_object=True)
        inspection.record = inspection.document(record_path,require_object=True)
        inspection.profile = inspection.document(inspection.location('framework/config/repo-profile.yaml'),require_object=True)
        inspection.report['assessed_configuration_id'] = inspection.profile.get('configuration_id')
        inspection.flows = [inspection.document(inspection.location(name),require_object=True) for name in ('framework/workflows/development/workflow.yaml','framework/workflows/maintenance/maintenance-workflow.yaml')]
        inspection.run_check('IS-01.files',inspection.files,input_safety=True)
        inspection.run_check('IS-01.schemas',inspection.schema_checks,input_safety=True)
        for cid,procedure in [('IS-02.local_refs',inspection.references),('IS-03.registry',inspection.registry),
                              ('IS-04.graph',inspection.graph),('IS-05.result_schema',inspection.result_schemas),
                              ('IS-06.records',inspection.templates),('IS-07.sequence',inspection.sequence),
                              ('IS-08.inventory',inspection.inventory)]:
            inspection.run_check(cid,procedure,input_safety=cid in ('IS-02.local_refs','IS-06.records'))
        return inspection.finish()
    except DocumentError as exc:
        inspection.error(exc,'IS-01.schemas')
    except (KeyError,ValueError,TypeError,IndexError) as exc:
        inspection.diagnostic('SCHEMA_INVALID','installation',f'Cannot interpret malformed definitions: {exc}','IS-01.schemas')
    except Exception as exc:
        inspection.diagnostic('PREREQUISITE_INTERNAL','checker',f'{type(exc).__name__}: {exc}',exit_code=2)
    inspection.report['uncovered_ids']=sorted(d['id'] for d in getattr(inspection,'catalogue',{}).get('criteria',[]) if isinstance(d,dict) and 'id' in d)
    return inspection.report
