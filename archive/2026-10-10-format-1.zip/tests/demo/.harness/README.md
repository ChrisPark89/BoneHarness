# Repository harness

## Choose your situation

| You need to… | Follow |
|---|---|
| Start or continue development | [Development guide](framework/workflows/development/HARNESS.md) |
| Resume interrupted work | [Recovery guide](framework/workflows/recovery.md) |
| Investigate a failed tool or uncertain outcome | [Recovery guide](framework/workflows/recovery.md), then the current stage's selected transition |
| Replace a skill or update configuration | [Maintenance guide](framework/workflows/maintenance/harness-maintenance.md) |
| Check what is ready or missing | [Setup status](docs/setup.md) and [setup guide](framework/workflows/setup.md) |
| Read task results | `docs/development/<task-id>/report.md` |

Start with one guide. Use the [context command](framework/workflows/context.md) to parse records and select relevant requirements. Read all continuation pages for the selected action. An overview helps navigation; it grants no approval.

Human pages are in `docs/`. Installed definitions are in `framework/`. Process records and supporting evidence are in `artifacts/`.

Respect repository instructions and current permissions. Keep harness-owned files under `.harness/`. Missing tools remain visible in setup status. Recorded progress and verified success are separate.

[Two-scenario trial](docs/trial.md)
