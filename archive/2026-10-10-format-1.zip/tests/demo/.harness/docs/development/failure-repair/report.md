# Task report: failure\-repair

[Specification](spec.md)

**Summary:** Task incomplete. Saved claim: [TEST\_PASSED](../../../artifacts/development/failure-repair/state.json) (unverified). Validated state: none.
**Record checks:** UNVERIFIABLE.

| Phase | Result | Evidence |
|---|---|---|
| Baseline | UNVERIFIED (BASELINED) | [record](../../../artifacts/development/failure-repair/history.jsonl#entry=fixture-transition-1-gate) |
| Research | UNVERIFIED (RESEARCHED) | [record](../../../artifacts/development/failure-repair/history.jsonl#entry=fixture-transition-2-gate) |
| Pattern review | UNVERIFIED (PATTERN\_VERIFIED) | [record](../../../artifacts/development/failure-repair/history.jsonl#entry=fixture-transition-3-gate) |
| Specification | UNVERIFIED (SPEC\_READY) | [record](../../../artifacts/development/failure-repair/history.jsonl#entry=fixture-transition-4-gate) |
| Verification plan | UNVERIFIED (TEST\_READY) | [record](../../../artifacts/development/failure-repair/history.jsonl#entry=fixture-transition-5-gate) |
| Implementation plan | UNVERIFIED (PLAN\_READY) | [record](../../../artifacts/development/failure-repair/history.jsonl#entry=fixture-transition-6-gate) |
| Implementation | UNVERIFIED (IMPLEMENTED) | [record](../../../artifacts/development/failure-repair/history.jsonl#entry=fixture-transition-7-gate) |
| Preflight | UNVERIFIED (PREFLIGHT\_PASSED); tool PASS | [record](../../../artifacts/development/failure-repair/repaired-preflight.log) |
| Build | UNVERIFIED (BUILD\_PASSED); tool PASS | [record](../../../artifacts/development/failure-repair/repaired-build.log) |
| Testing | UNVERIFIED (TEST\_PASSED); tool PASS | [record](../../../artifacts/development/failure-repair/repaired-test.log) |
| Final specification verification | NOT\_RECORDED | [details](../../../artifacts/development/failure-repair/report.json#/phases/10) |
| Final review | NOT\_RECORDED | [details](../../../artifacts/development/failure-repair/report.json#/phases/11) |
| Repair | UNVERIFIED (REPAIRING) | [record](../../../artifacts/development/failure-repair/history.jsonl#entry=fixture-transition-14-gate) |

**History:** 0 earlier failures; 0 repairs; 1 tool failures. [Attempts](../../../artifacts/development/failure-repair/report.json#/history).

[Full diagnostics](../../../artifacts/development/failure-repair/report.json#/diagnostics) · [Criteria](../../../artifacts/development/failure-repair/report.json#/specification_coverage) · [Sources](../../../artifacts/development/failure-repair/report.json#/source_manifest).
Tool claims do not establish phase success. See diagnostics for unchecked or failed evidence.
1 recorded failure claims (unverified).
1 recorded repair claims (unverified); [history](../../../artifacts/development/failure-repair/report.json#/history).

<!-- task-report generation_id=7036f91ef459f77a228fdfc2e902c24a4d3af8227ec1682ad871210bfdf568ce json_sha256=a8cf896b946c8c44a19f5fa3c0244184af666695c16bcea5448b14d0bd02e7c0 -->
