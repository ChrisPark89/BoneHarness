# failure-repair

Build the calculator and test its generated dist module. Require add(2, 3) = 5 and add(-2, 3) = 1. Inject subtraction, preserve the failed test, restore addition and rebuild/retest. 

Execution trial only. Workflow decisions are labelled fixtures; no accepted specification, workflow approval, semantic review or COMPLETE claim is supplied. Installation readiness and source-inventory verification remain unassessed.

[Report](report.md) · [History](../../../artifacts/development/failure-repair/history.jsonl)
