# Harness setup

Described configuration: `cfg-1`, revision `1`. Kit: `1.1.0`; layout: `2`.

Structure status: `INCOMPLETE`. Integration status: `NOT_ASSESSED`. Discovery, policy, bindings, targets and activation remain pending. Scaffolding creates files; it performs no semantic assessment.

Reporter: **NOT_CHECKED**. Checker: **NOT_RUN**. No dependencies were installed. Both reference tools require Python 3.11+ and the provisioned [dependencies](../framework/tools/requirements.lock).

Read the [profile](../framework/config/repo-profile.yaml), [installation record](../artifacts/installation/installation-record.yaml), [development](../framework/workflows/development/HARNESS.md) and [maintenance](../framework/workflows/maintenance/harness-maintenance.md). Follow the installer assessment procedure before activation.

State writing is procedural. Automatic repair is disabled. Source inventory, skip authority and scoped applicability checks remain unsupported by the reference reporter.
