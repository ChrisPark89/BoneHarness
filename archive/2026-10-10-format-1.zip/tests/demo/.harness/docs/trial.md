# Two-scenario trial

| Scenario | Actual commands | Report |
|---|---|---|
| Success | Build and test passed | [Report](development/success/report.md) |
| Failure and repair | Build passed; test failed; restored source, rebuild and retest passed | [Report](development/failure-repair/report.md) |

[Failed test](../artifacts/development/failure-repair/broken-test.log) · [Repaired test](../artifacts/development/failure-repair/repaired-test.log)

Execution trial only. Workflow decisions are labelled fixtures; no accepted specification, workflow approval, semantic review or COMPLETE claim is supplied. Installation readiness and source-inventory verification remain unassessed.

Recorded repair claims remain unverified. Original app source was restored. Passing commands do not establish harness conformance.
