#!/usr/bin/env python3
"""Two execution trials using the installed journal and reporter; no workflow approval."""
import argparse
from copy import deepcopy
import platform
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import shutil
import sys
import time

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[2]
PROJECT = Path(__file__).resolve().parent
APP_FILES = ('package.json', 'src/calculator.js', 'scripts/build.mjs', 'test/calculator.test.mjs')
TARGETS = [{'target_id': 'calculator', 'environment': 'local'}]
BOUNDARY = ('Execution trial only. Workflow decisions are labelled fixtures; no accepted specification, '
            'workflow approval, semantic review or COMPLETE claim is supplied. Installation readiness '
            'and source-inventory verification remain unassessed.')


def stamp(delta=0):
    return (datetime.now(timezone.utc) + timedelta(seconds=delta)).isoformat().replace('+00:00', 'Z')


def identity(raw):
    return 'sha256:' + hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def record(kind, **fields):
    return dict(schema_version='1.0.0', record_type=kind, **fields)


def ref(path, entry_id=None):
    return dict(kind='LOCAL', scope='HARNESS', path=path, **({'entry_id': entry_id} if entry_id else {}))


def check_workspace(workspace):
    if not workspace.is_dir() or workspace.is_symlink():
        raise ValueError('Use an existing demo directory.')
    if (workspace / '.harness').exists() or (workspace / '.harness').is_symlink():
        raise ValueError('Existing .harness refused; retained trial records must not be overwritten.')
    for name in APP_FILES:
        path = workspace / name
        if (not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1
                or not path.resolve().is_relative_to(workspace.resolve())):
            raise ValueError(f'Demo requires a local regular app file: {name}')
    if (workspace / 'src/calculator.js').read_bytes().count(b'a + b') != 1:
        raise ValueError('The failure/repair scenario requires one original a + b expression.')


def configure_demo(harness):
    """Explicit trial-only bindings; this does not assess installation readiness."""
    import yaml
    adapter_path = harness / 'framework/adapters/demo.md'
    adapter_path.write_text(
        '# Demo subprocess binding\n\n'
        'Trial-only policy fixture. The caller executes resolved Node.js directly in the demo repository: '
        '`node --check src/calculator.js`, `node scripts/build.mjs`, '
        '`node --test test/calculator.test.mjs`. Each call has a 60-second deadline and one-call budget. '
        'Exit zero normalizes to PASS, nonzero to FAIL; combined stdout/stderr is retained. '
        'Build copies the module to dist; tests consume dist. Source, generated artifact and log hashes are retained. '
        'The fixture permits one test repair by restoring original addition, followed by preflight/build/test. '
        'No network, secrets or external actions are permitted. On interruption, restore source and retain history; '
        'do not overwrite or automatically resume this trial. Workflow guard claims are fixtures, '
        'not semantic review, user approval, or production readiness.\n')
    adapter_id = identity(adapter_path.read_bytes())
    adapter = dict(identity='demo-subprocess', version='1.0.0', content_identity=adapter_id)
    procedure = ref('framework/adapters/demo.md')
    permissions = dict(filesystem_scopes=[
        dict(scope='REPOSITORY', path=name, access='READ') for name in APP_FILES] + [
        dict(scope='REPOSITORY', path='src/calculator.js', access='WRITE'),
        dict(scope='REPOSITORY', path='dist', access='WRITE'),
        dict(scope='HARNESS', path='artifacts', access='WRITE'),
        dict(scope='HARNESS', path='docs', access='WRITE')], external_actions=[],
        secrets_policy='No credentials or network access.',
        approval_policy=dict(mode='RECORDED_POLICY', procedure=procedure))
    path = harness / 'framework/config/repo-profile.yaml'
    profile = yaml.safe_load(path.read_text())
    profile.update(configuration_id='cfg-2', configuration_revision=2, permissions=permissions)
    profile['extensions'] = {'fixture_policy': True, 'repair_budget': {'test': 1}, 'limitations': BOUNDARY}
    for capability in ('preflight', 'build', 'test'):
        binding = profile['capabilities'][capability]
        binding.update(configuration_status='CONFIGURED', compatibility='COMPATIBLE', adapter=adapter,
            input_schema=ref('framework/templates/schemas/records.schema.json'),
            execution_environment=dict(id='local', description='Local calculator trial',
                                       native_platforms=[{'Darwin': 'macOS'}.get(platform.system(), platform.system())], evidence_refs=[]),
            permissions=permissions,
            invocation=dict(procedure=procedure, reconciliation=procedure, deadline_seconds=60, call_budget=1),
            normalization=dict(procedure=procedure, interface_version='1.0.0',
                               artifact_consumed_downstream=capability == 'build',
                               test_source_required=False, artifact_lineage_required=False, extensions_schema=None))
    path.write_text(yaml.safe_dump(profile, sort_keys=False))
    return adapter


def capture_config(harness):
    template = harness / 'framework/templates/development/config-snapshot.yaml'
    import yaml
    snapshot = yaml.safe_load(template.read_text())
    definitions = snapshot['captured_definitions']
    definitions.append(dict(kind='ADAPTER', reference=ref('framework/adapters/demo.md')))
    known = {item['reference']['path'] for item in definitions}
    for path in sorted((harness / 'framework/tools').rglob('*.py')):
        relative = path.relative_to(harness).as_posix()
        if relative not in known:
            definitions.append(dict(kind='SUPPORT', reference=ref(relative)))
    contents = {item['reference']['path']: (harness / item['reference']['path']).read_bytes()
                for item in definitions}
    bundle = identity(canonical({name: identity(raw) for name, raw in contents.items()})).split(':')[1]
    for item in definitions:
        name = item['reference']['path']
        destination = f'artifacts/configurations/{bundle}/{name}'
        target = harness / destination
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(contents[name])
        item.update(identity=identity(contents[name]), captured_path=destination)
    profile = yaml.safe_load((harness / 'framework/config/repo-profile.yaml').read_text())
    snapshot.update(configuration_id=profile['configuration_id'],
                    configuration_revision=profile['configuration_revision'], limitations=[BOUNDARY])
    return snapshot


class Trial:
    def __init__(self, workspace, task_id, snapshot):
        from harness_io.journal import append_record, publish_state
        self.append_record, self.publish_state = append_record, publish_state
        self.workspace, self.task_id = workspace, task_id
        self.harness = workspace / '.harness'
        self.directory = self.harness / 'artifacts/development' / task_id
        self.directory.mkdir(parents=True)
        self.history = self.directory / 'history.jsonl'
        self.schemas = self.harness / 'framework/templates/schemas'
        self.config = snapshot['configuration_id']
        self.source_records = set()
        self.adapter = dict(identity='demo-subprocess', version='1.0.0',
                            content_identity=identity((self.harness / 'framework/adapters/demo.md').read_bytes()))
        import yaml
        self.workflow = yaml.safe_load((self.harness / 'framework/workflows/development/workflow.yaml').read_text())
        self.append('configuration', snapshot)
        docs = self.harness / 'docs/development' / task_id
        docs.mkdir(parents=True)
        spec = (f'# {task_id}\n\nBuild the calculator and test its generated dist module. '
                'Require add(2, 3) = 5 and add(-2, 3) = 1. '
                + ('Inject subtraction, preserve the failed test, restore addition and rebuild/retest. '
                   if task_id == 'failure-repair' else 'Run the unchanged application. ')
                + f'\n\n{BOUNDARY}\n\n[Report](report.md) · '
                f'[History](../../../artifacts/development/{task_id}/history.jsonl)\n')
        (docs / 'spec.md').write_text(spec)
        request_id = identity(spec.encode())
        decision = record('GateDecision', request_id='fixture-initialization', decision='ALLOW',
                          proposed_destination='NEW', resolution_route=None,
                          rule_findings=[dict(rule_id='RULE-01', result='PASS',
                                              reason='Fixture initialization only. ' + BOUNDARY, evidence_refs=[])],
                          extensions={'fixture': True, 'purpose': 'Storage initialization only'})
        entry = self.append('fixture-initialization', decision)
        state = record('TaskState', task_id=task_id, state='NEW', version=1,
                       writer=dict(mode='LLM_PROTOCOL', identity='demo-fixture', binding=None,
                                   enforcement_evidence_refs=[]), profile_id='default',
                       configuration_id=self.config, input_snapshot=self.source_identity(),
                       accepted_identities=dict(request=request_id, specification=None, design=None),
                       selected_targets=TARGETS, criterion_verdict_refs=[], repair_counters={},
                       invocation_counters={}, pending_invocation_refs=[], stop_reason=None,
                       stopped_from_state=None, resolution_refs=[], evidence_refs=[],
                       extensions={'fixture': True, 'limitations': BOUNDARY})
        self.append('fixture-event', record('Event', subject_kind='TASK', subject_id=task_id,
                    request_id='fixture-initialization', request_content_identity=request_id,
                    previous_version=0, next_version=1, previous_state=None, next_state='NEW',
                    timestamp=stamp(), actor='demo-fixture',
                    decision_ref=dict(reference=ref(self.history.relative_to(self.harness).as_posix(),
                                                   entry['entry_id']),
                                      provenance='FIXTURE', summary=BOUNDARY,
                                      identity=entry['payload_identity']), evidence_refs=[],
                    counter_deltas=dict(repair={}, invocation={}), post_state=state,
                    extensions={'fixture': True}))
        self.state = state
        self.publish_state(self.history, task_id)

    def append(self, entry_id, payload):
        return self.append_record(self.history, self.task_id, entry_id, payload, self.schemas)

    def transition(self, destination, evidence=(), capability=None):
        """Exercise installed edges with explicit fixture policy, never accepted review."""
        edge = next(t for t in self.workflow['transitions']
                    if t['from'] == self.state['state'] and t['to'] == destination)
        request_id = 'fixture-transition-' + str(self.state['version'])
        refs = [dict(reference=ref(self.history.relative_to(self.harness).as_posix(), e['entry_id']),
                     identity=e['payload_identity'], provenance='EXECUTION', summary='Actual command record')
                for e in evidence]
        request = record('TransitionRequest', subject_id=self.task_id, subject_kind='TASK',
                         request_id=request_id, expected_state=self.state['state'],
                         expected_version=self.state['version'], transition_id=edge['id'],
                         configuration_id=self.config, accepted_identities=self.state['accepted_identities'],
                         evidence_refs=refs, review_refs=[])
        request['request_content_identity'] = identity(canonical(request))
        self.append(request_id, request)
        decision = self.append(request_id + '-gate', record('GateDecision', request_id=request_id,
            decision='ALLOW', proposed_destination=destination, resolution_route=None,
            rule_findings=[dict(rule_id=rule, result='PASS', reason='Scenario fixture claim only; ' + BOUNDARY,
                                evidence_refs=refs) for rule in edge['rule_ids']],
            extensions={'fixture': True, 'limitations': BOUNDARY}))
        state = deepcopy(self.state)
        state.update(state=destination, version=state['version'] + 1, input_snapshot=self.source_identity())
        if capability:
            state['invocation_counters'][capability] = state['invocation_counters'].get(capability, 0) + 1
        if destination == 'REPAIRING':
            state['repair_counters']['test'] = 1
        self.append(request_id + '-event', record('Event', subject_kind='TASK', subject_id=self.task_id,
            request_id=request_id, request_content_identity=request['request_content_identity'],
            previous_version=self.state['version'], next_version=state['version'],
            previous_state=self.state['state'], next_state=destination, timestamp=stamp(), actor='demo-fixture',
            decision_ref=dict(reference=ref(self.history.relative_to(self.harness).as_posix(), decision['entry_id']),
                              identity=decision['payload_identity'], provenance='FIXTURE', summary=BOUNDARY),
            evidence_refs=refs, counter_deltas=dict(repair={'test': 1} if destination == 'REPAIRING' else {},
                invocation={capability: 1} if capability else {}), post_state=state, extensions={'fixture': True}))
        self.state = state
        self.publish_state(self.history, self.task_id)

    def prepare(self):
        for destination in ('BASELINED', 'RESEARCHED', 'PATTERN_VERIFIED', 'SPEC_READY',
                            'TEST_READY', 'PLAN_READY', 'IMPLEMENTED', 'PREFLIGHT'):
            self.transition(destination)


    def source_identity(self):
        from harness_io.source_inventory import capture_inventory
        inventory = capture_inventory(self.workspace, self.harness, self.task_id,
                                      dict(roots=['src', 'test', 'scripts', 'package.json'], exclude=[]))
        revision = inventory['revision']
        if revision not in self.source_records:
            self.append('source-' + revision.split(':')[1], inventory)
            self.source_records.add(revision)
        return revision

    def execute(self, run_id, capability, expected):
        node = shutil.which('node')
        if not node:
            raise RuntimeError('Node.js is required for the demo')
        command = [node] + {'preflight': ['--check', 'src/calculator.js'],
                            'build': ['scripts/build.mjs'],
                            'test': ['--test', 'test/calculator.test.mjs']}[capability]
        revision = self.source_identity()
        artifact_path = self.workspace / 'dist/calculator.js'
        artifact = self.capture_artifact(artifact_path) if capability == 'test' else None
        invocation = record('Invocation', intent_id=run_id, request_id='trial-execution', run_id=run_id,
                            task_id=self.task_id, capability=capability,
                            expected_identities=dict(configuration_id=self.config,
                                adapter_definition_id=self.adapter['content_identity'],
                                adapter=self.adapter, revision=revision),
                            inputs=dict(source=revision, targets=TARGETS, environment='local',
                                        artifact=artifact, test_source=None),
                            dispatch_status='INTENT_RECORDED', external_handle=None, deadline=stamp(60),
                            counters=dict(calls=0, elapsed_seconds=0, call_budget=1, time_budget_seconds=60),
                            reconciliation_evidence_refs=[], cancellation_evidence_refs=[],
                            extensions={'command': command, 'boundary': BOUNDARY})
        self.append(run_id + '-intent', invocation)
        start = time.monotonic()
        completed = subprocess.run(command, cwd=self.workspace, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, timeout=60)
        output = (f'$ {" ".join(command)}\nexit_code={completed.returncode}\n'.encode() + completed.stdout)
        log = self.directory / (run_id + '.log')
        log.write_bytes(output)
        invocation.update(dispatch_status='COMPLETED', counters=dict(calls=1,
                          elapsed_seconds=time.monotonic() - start, call_budget=1, time_budget_seconds=60))
        completed_entry = self.append(run_id + '-completed', invocation)
        if capability == 'build' and completed.returncode == 0:
            artifact = self.capture_artifact(artifact_path)
        result = record('Result', interface_version='1.0.0', capability=capability,
                        adapter=self.adapter, run_id=run_id, task_id=self.task_id, revision=revision,
                        status='PASS' if completed.returncode == 0 else 'FAIL', provenance='EXECUTION',
                        configuration_id=self.config, adapter_definition_id=self.adapter['content_identity'],
                        targets=TARGETS, evidence=dict(reference=ref(log.relative_to(self.harness).as_posix()),
                            summary=f'{" ".join(command)} exited {completed.returncode}'),
                        extensions={'capability_data': {'exit_code': completed.returncode,
                                    'log_identity': identity(output), 'command': command}})
        if artifact:
            result['artifact'] = artifact
        result_entry = self.append(run_id + '-result', result)
        if (completed.returncode == 0) != expected:
            raise RuntimeError(f'Unexpected command outcome; inspect {log}')
        destination = capability.upper() + ('_PASSED' if completed.returncode == 0 else '_FAILED')
        self.transition(destination, [completed_entry, result_entry], capability)

    def capture_artifact(self, path):
        raw = path.read_bytes()
        digest = identity(raw)
        relative = f'artifacts/snapshots/{digest.split(":")[1]}/calculator.js'
        destination = self.harness / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            destination.write_bytes(raw)
        return dict(identity=digest, reference=ref(relative))

    def report(self):
        result = subprocess.run([sys.executable, str(self.harness / 'framework/tools/report.py'),
                        '--repo-root', str(self.workspace), '--harness-root', str(self.harness),
                        '--task-id', self.task_id])
        if result.returncode not in (0, 1):
            raise RuntimeError('REPORT_UNAVAILABLE: installed reporter could not publish the report pair')


def run(workspace):
    check_workspace(workspace)
    workspace = workspace.resolve()
    subprocess.run([sys.executable, str(ROOT / 'builder-kit/installer/install.py'),
                    '--repo-root', str(workspace)], check=True)
    harness = workspace / '.harness'
    sys.path.insert(0, str(harness / 'framework/tools'))
    configure_demo(harness)
    snapshot = capture_config(harness)
    success = Trial(workspace, 'success', snapshot)
    success.prepare()
    success.execute('preflight', 'preflight', True)
    success.transition('BUILDING')
    success.execute('build', 'build', True)
    success.transition('TESTING')
    success.execute('test', 'test', True)
    success.report()
    repair = Trial(workspace, 'failure-repair', snapshot)
    repair.prepare()
    source = workspace / 'src/calculator.js'
    original = source.read_bytes()
    try:
        source.write_bytes(original.replace(b'a + b', b'a - b'))
        repair.execute('broken-preflight', 'preflight', True)
        repair.transition('BUILDING')
        repair.execute('broken-build', 'build', True)
        repair.transition('TESTING')
        repair.execute('broken-test', 'test', False)
        repair.transition('REPAIRING')
    finally:
        source.write_bytes(original)
    repair.transition('PREFLIGHT')
    repair.execute('repaired-preflight', 'preflight', True)
    repair.transition('BUILDING')
    repair.execute('repaired-build', 'build', True)
    repair.transition('TESTING')
    repair.execute('repaired-test', 'test', True)
    repair.report()
    (harness / 'docs/trial.md').write_text(
        '# Two-scenario trial\n\n'
        '| Scenario | Actual commands | Report |\n|---|---|---|\n'
        '| Success | Build and test passed | [Report](development/success/report.md) |\n'
        '| Failure and repair | Build passed; test failed; restored source, rebuild and retest passed | '
        '[Report](development/failure-repair/report.md) |\n\n'
        '[Failed test](../artifacts/development/failure-repair/broken-test.log) · '
        '[Repaired test](../artifacts/development/failure-repair/repaired-test.log)\n\n'
        + BOUNDARY + '\n\nRecorded repair claims remain unverified. Original app source was restored. '
        'Passing commands do not establish harness conformance.\n')
    with (harness / 'README.md').open('a') as stream:
        stream.write('\n[Two-scenario trial](docs/trial.md)\n')
    print(f'Trial evidence: {harness / "docs/trial.md"}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=PROJECT,
                        help='Demo root (defaults to the directory containing this script)')
    args = parser.parse_args()
    try:
        run(args.workspace)
    except (ValueError, RuntimeError, subprocess.SubprocessError) as error:
        parser.exit(1, f'{error}\n')
