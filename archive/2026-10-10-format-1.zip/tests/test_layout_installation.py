"""Fresh layout boundaries and explicitly selected legacy inspection."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from support import validator

KIT = Path(__file__).resolve().parents[1] / 'builder-kit'
INSTALL = KIT / 'installer/install.py'


def fingerprint(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


class LayoutInstallationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='layout install café ')
        self.addCleanup(self.temp.cleanup)
        self.repo = Path(self.temp.name).resolve()
        (self.repo/'AGENTS.md').write_text('Existing scoped instructions.\n')
        (self.repo/'app.py').write_text('print("source")\n')
        self.before = fingerprint(self.repo)
        self.proc = subprocess.run([sys.executable, '-B', str(INSTALL), '--repo-root', str(self.repo)],
                                   capture_output=True, text=True)
        self.assertEqual(self.proc.returncode, 0, self.proc.stderr)
        self.harness = self.repo/'.harness'

    def test_only_harness_owned_writes_and_honest_generated_records(self):
        self.assertEqual({k:v for k,v in fingerprint(self.repo).items() if not k.startswith('.harness/')}, self.before)
        self.assertEqual({p.name for p in self.harness.iterdir()}, {'README.md','docs','framework','artifacts'})
        self.assertFalse((self.repo/'ENTRYPOINT.candidate.md').exists())
        self.assertEqual(list((self.harness/'artifacts/development').iterdir()), [])
        self.assertEqual(list((self.harness/'artifacts/maintenance').iterdir()), [])
        ledger=json.loads((self.harness/'artifacts/installation/installation-record.yaml').read_text())
        validator('records.schema.json','InstallationRecord').validate(ledger)
        self.assertEqual(ledger['kit_version'], '1.1.0')
        self.assertEqual(ledger['entry_point']['activation_state'], 'STAGED')
        self.assertEqual(ledger['entry_point']['candidate']['path'], '.harness/README.md')
        self.assertIsNone(ledger['completed_at'])
        self.assertTrue(all(row['result']=='PENDING' for row in ledger['criterion_assessments']))
        for row in ledger['owned_paths']:
            self.assertEqual(row['scope'], 'HARNESS')
            if row['path']=='artifacts/installation/installation-record.yaml':
                self.assertIsNone(row['after_identity'])
            else:
                self.assertEqual(row['after_identity'],'sha256:'+hashlib.sha256((self.harness/row['path']).read_bytes()).hexdigest())
        for name in ('README.md','docs/setup.md'):
            self.assertLessEqual(len((self.harness/name).read_text().split()),200)

    def test_existing_installation_refused_without_changes(self):
        before=fingerprint(self.repo)
        rerun=subprocess.run([sys.executable,'-B',str(INSTALL),'--repo-root',str(self.repo)],capture_output=True,text=True)
        self.assertEqual(rerun.returncode,2)
        self.assertIn('already exists',rerun.stderr)
        self.assertEqual(fingerprint(self.repo),before)

    def test_installed_checker_without_builder_and_wrong_layout_flag(self):
        before=fingerprint(self.repo)
        command=[sys.executable,'-B',str(self.harness/'framework/tools/check.py'),
                 '--repo-root',str(self.repo),'--harness-root','.harness','--format','json']
        checked=subprocess.run(command,cwd=self.repo,capture_output=True,text=True)
        report=json.loads(checked.stdout)
        self.assertEqual(checked.returncode,0,report['diagnostics'])
        self.assertEqual(report['structure_assessment'],'INCOMPLETE')
        self.assertEqual(fingerprint(self.repo),before)
        wrong=subprocess.run(command+['--legacy-layout'],capture_output=True,text=True)
        self.assertEqual(wrong.returncode,1)
        self.assertEqual(json.loads(wrong.stdout)['diagnostics'][0]['code'],'LAYOUT_MODE')
        (self.harness/'shared').mkdir()
        (self.harness/'shared/repo-profile.yaml').write_text('{}')
        mixed=subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(mixed.returncode,1)
        self.assertEqual(json.loads(mixed.stdout)['diagnostics'][0]['code'],'LAYOUT_AMBIGUOUS')

    def test_checker_rejects_claimed_root_instruction_write(self):
        path=self.harness/'artifacts/installation/installation-record.yaml'
        record=json.loads(path.read_text())
        entry=dict(scope='REPOSITORY',path='AGENTS.md',ownership='SHARED',before_identity=None,
                   after_identity='sha256:'+hashlib.sha256((self.repo/'AGENTS.md').read_bytes()).hexdigest())
        record['generated_paths'].append(entry);record['owned_paths'].append(dict(entry))
        path.write_text(json.dumps(record))
        proc=subprocess.run([sys.executable,'-B',str(self.harness/'framework/tools/check.py'),
            '--repo-root',str(self.repo),'--harness-root','.harness','--format','json'],capture_output=True,text=True)
        self.assertEqual(proc.returncode,1)
        self.assertTrue(any(row['code']=='REFERENCE_OWNERSHIP' for row in json.loads(proc.stdout)['diagnostics']))
        self.assertEqual(hashlib.sha256((self.repo/'AGENTS.md').read_bytes()).hexdigest(),self.before['AGENTS.md'])

    def test_existing_harness_symlink_refused(self):
        other=self.repo/'other';other.mkdir()
        external=self.repo/'external';external.mkdir()
        (other/'.harness').symlink_to(external,target_is_directory=True)
        before=fingerprint(self.repo)
        proc=subprocess.run([sys.executable,'-B',str(INSTALL),'--repo-root',str(other)],capture_output=True,text=True)
        self.assertEqual(proc.returncode,2)
        self.assertEqual(fingerprint(self.repo),before)
        self.assertEqual(list(external.iterdir()),[])
