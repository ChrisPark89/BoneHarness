"""Disposable protocol fixtures: exercise checked claims, never real user authority."""
from copy import deepcopy
import json
import re
import unittest
import yaml
from support import fixtures, STAMP, HASH, validator
import test_journal_reporting
from harness_io.journal import canonical_json, content_identity, publish_state, read_history
from harness_io.source_inventory import capture_inventory
from reporting.evidence import capture_task
from reporting.summary import derive_report


class UserSkipTests(unittest.TestCase):
    def setUp(self):
        self.f = test_journal_reporting.JournalReportingTests()
        self.f.setUp()
        self.addCleanup(self.f.doCleanups)
        self.flow = yaml.safe_load((self.f.harness / 'framework/workflows/development/workflow.yaml').read_text())
        self.f.history.unlink()
        (self.f.run / 'state.json').unlink()
        # Pin a real local adapter definition so terminal-invocation checks can
        # compare the claimed configuration identity without executing a tool.
        adapter_path = self.f.harness / 'framework/adapters/adapter-interface.md'
        self.adapter_identity = content_identity(adapter_path.read_bytes())
        definitions = self.f.configuration['captured_definitions']
        captured = [(d, (self.f.harness / d['captured_path']).read_bytes(),
                     '/'.join(d['captured_path'].split('/')[3:])) for d in definitions]
        extra = dict(kind='ADAPTER', reference=dict(kind='LOCAL',scope='HARNESS',path='framework/adapters/adapter-interface.md'),
                     identity=self.adapter_identity)
        captured.append((extra, adapter_path.read_bytes(), 'adapters/adapter-interface.md'))
        bundle = content_identity(canonical_json({path: d['identity'] for d,raw,path in captured})).split(':')[1]
        self.f.configuration['captured_definitions'] = []
        for definition,raw,path in captured:
            saved = self.f.harness / 'artifacts/configurations' / bundle / path
            saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(raw)
            self.f.configuration['captured_definitions'].append(dict(definition,captured_path=saved.relative_to(self.f.harness).as_posix()))
        self.f.append('configuration', self.f.configuration)
        (self.f.repo / 'src').mkdir()
        (self.f.repo / 'src/program.txt').write_text('Existing program: answer=42\n')
        self.scope = dict(roots=['src'], exclude=[])
        self.inventory = capture_inventory(self.f.repo, self.f.harness, 'task-1', self.scope)
        self.f.append('source', self.inventory)
        self.message = self.file_evidence('instruction.txt', 'Skip baseline, research, pattern_review, verification_plan, implementation_plan, implementation, preflight, build, testing, final_review for task-1.\n')
        self.review_evidence = self.file_evidence('review.txt', 'Protocol fixture: reviewer inspected the original host user message and explicit task/phase scope.\n')
        self.spec_evidence = dict(reference=dict(kind='LOCAL', scope='HARNESS', path='docs/development/task-1/spec.md'),
                                  provenance='REVIEW', summary='Accepted task specification',
                                  identity=content_identity((self.f.docs / 'spec.md').read_bytes()))
        self.spec = fixtures()['TaskSpec']
        self.spec.update(request_identity=self.message['identity'], specification_identity=self.spec_evidence['identity'],
                         design_identity=self.spec_evidence['identity'], extensions={'source_scope': self.scope})
        self.spec['acceptance_authority']['evidence_refs'] = [self.spec_evidence]
        self.post = fixtures()['TaskState']
        self.post['input_snapshot'] = self.inventory['revision']
        self.post['accepted_identities']['request'] = self.message['identity']
        self.event('NEW', initial=True)
        self.decisions = {}

    def file_evidence(self, name, text):
        path = self.f.run / name
        path.write_text(text)
        return dict(reference=dict(kind='LOCAL', scope='HARNESS', path=path.relative_to(self.f.harness).as_posix()),
                    provenance='REVIEW', summary='Protocol test input', identity=content_identity(path.read_bytes()))

    def saved(self, entry_id, payload):
        entry = self.f.append(entry_id, payload)
        return dict(reference=self.f.ref(entry_id), provenance='REVIEW', summary='Retained protocol record', identity=entry['payload_identity'])

    def disposition(self, phase, **changes):
        prior = self.decisions.get(phase)
        value = dict(schema_version='1.0.0', record_type='PhaseDisposition', disposition_id='skip-'+phase+'-'+str(self.post['version']),
            task_id='task-1', phase_id=phase, disposition='USER_SKIPPED', configuration_id='cfg-1',
            request_identity=self.post['accepted_identities']['request'],
            specification_identity=self.post['accepted_identities']['specification'], actor='coordinator', timestamp=STAMP,
            instruction=dict(source='HOST_USER_MESSAGE', message_id='host:test-message-1', user='user', timestamp=STAMP,
                             quote='Skip baseline, research, pattern_review, verification_plan, implementation_plan, implementation, preflight, build, testing, final_review for task-1.', evidence=deepcopy(self.message)),
            review=dict(method='LLM_REVIEW', actor='reviewer', timestamp=STAMP, result='CONFIRMED', evidence=deepcopy(self.review_evidence)),
            reconciles=prior, reason=None)
        value.update(changes)
        evidence = self.saved(value['disposition_id'], value)
        self.decisions[phase] = evidence
        return evidence

    def event(self, target, refs=(), *, initial=False, reviews=()):
        before = deepcopy(self.post)
        version = 1 if initial else before['version'] + 1
        request_id = 'event-' + str(version)
        self.post.update(state=target, version=version, evidence_refs=list(refs))
        self.post['criterion_verdict_refs'] += list(reviews)
        edges = [e for e in self.flow['transitions'] if e['from'] == before['state'] and e['to'] == target and 'default' in e['profiles']]
        if not initial:
            self.assertEqual(1, len(edges), (before['state'], target))
            edge = edges[0]
            request = fixtures()['TransitionRequest']
            request.update(request_id=request_id, expected_state=before['state'], expected_version=before['version'],
                           transition_id=edge['id'], accepted_identities=deepcopy(self.post['accepted_identities']),
                           evidence_refs=list(refs), review_refs=list(reviews))
            request['request_content_identity'] = content_identity(canonical_json({k:v for k,v in request.items() if k != 'request_content_identity'}))
            self.saved('request-'+str(version), request)
        decision = fixtures()['GateDecision']
        decision.update(request_id=request_id, decision='ALLOW', proposed_destination=target, resolution_route=None,
            rule_findings=[dict(rule_id=rid, result='PASS', reason='Protocol fixture judgment', evidence_refs=[])
                           for rid in (edges[0]['rule_ids'] if edges else ['RULE-01','RULE-02','RULE-11'])])
        dec = self.saved('decision-'+str(version), decision)
        event = fixtures()['Event']
        event.update(timestamp=getattr(self, 'event_stamp', STAMP), request_id=request_id, request_content_identity=HASH if initial else request['request_content_identity'],
            previous_state=None if initial else before['state'], previous_version=0 if initial else before['version'],
            next_state=target, next_version=version, decision_ref=dec, evidence_refs=list(refs), post_state=deepcopy(self.post))
        self.f.append(request_id, event)
        publish_state(self.f.history, 'task-1', self.f.schemas)

    def skip(self, phase, **changes):
        evidence = self.disposition(phase, **changes)
        self.event(phase.upper()+'_SKIPPED', [evidence])

    def review(self, state, criteria):
        value = fixtures()['CriterionReview']
        value.update(revision=self.inventory['revision'], due_state=state,
                     criteria=[dict(criterion_id=cid, result='PASS', reason='Inspected actual target against this criterion',
                                    evidence_refs=[self.review_evidence], unresolved_findings=[]) for cid in criteria])
        return self.saved('review-'+str(self.post['version']), value)

    def accept(self, reconcile=True):
        spec_ref = self.saved('specification', self.spec)
        self.post['accepted_identities'].update(specification=self.spec['specification_identity'], design=self.spec['design_identity'])
        refs = [spec_ref]
        if reconcile:
            refs += [self.disposition(p) for p in list(self.decisions)]
        self.event('SPEC_READY', refs, reviews=[self.review('SPEC_READY', ['D-SPEC'])])

    def before_spec(self):
        for phase in ('baseline','research','pattern_review'):
            self.skip(phase)

    def after_spec(self):
        for phase in ('verification_plan','implementation_plan','implementation','preflight','build','testing'):
            self.skip(phase)

    def complete(self):
        self.before_spec()
        self.accept()
        self.after_spec()
        self.event('SPEC_VERIFIED', reviews=[self.review('SPEC_VERIFIED', ['D-SPEC-FULL']+[c['id'] for c in self.spec['criteria']])])
        self.skip('final_review')
        self.event('COMPLETE', reviews=[self.review('COMPLETE', ['D-COMPLETE'])])

    def report(self):
        return derive_report(capture_task(self.f.repo, self.f.harness, 'task-1'), generated_at=STAMP)

    def test_explicit_skip_and_stage_criteria_are_separate(self):
        self.skip('baseline')
        report = self.report()
        self.assertEqual('USER_SKIPPED', report['phases'][0]['status'], report['diagnostics'])
        self.assertNotEqual('SUPPORTED_BY_CHECKED_RECORDS', report['completion_support'])
        row = next(c for c in report['specification_coverage']['stage_progression']['criteria'] if c['criterion_id']=='D-BASELINE')
        self.assertEqual(('USER_SKIPPED',False), (row['result'],row['required']))

    def test_existing_target_can_complete_with_scoped_skips(self):
        self.complete()
        report = self.report()
        self.assertEqual('SUPPORTED_BY_CHECKED_RECORDS', report['completion_support'], report['diagnostics'])
        self.assertEqual('CONSISTENT', report['record_checks'])
        self.assertFalse(any(e['payload']['record_type']=='Result' for e in read_history(self.f.history,'task-1',self.f.schemas)))
        self.assertEqual('PASS', next(p for p in report['phases'] if p['phase_id']=='specification_verification')['status'])

    def test_prespec_skip_requires_reconciliation_at_acceptance(self):
        self.before_spec()
        self.accept(reconcile=False)
        report = self.report()
        self.assertIn('REPORT_SKIP_SCOPE_UNRECONCILED', [d['code'] for d in report['diagnostics']])

    def test_fixture_instruction_rejected(self):
        self.message['provenance']='FIXTURE'
        self.skip('baseline')
        self.assertEqual('UNVERIFIED', self.report()['phases'][0]['status'])

    def test_contradictory_review_rejected(self):
        review=dict(method='LLM_REVIEW',actor='reviewer',timestamp=STAMP,result='CONTRADICTED',evidence=self.review_evidence)
        self.skip('baseline',review=review)
        self.assertEqual('UNVERIFIED', self.report()['phases'][0]['status'])

    def test_missing_original_instruction_rejected(self):
        (self.f.run/'instruction.txt').unlink()
        self.skip('baseline')
        self.assertEqual('UNVERIFIED', self.report()['phases'][0]['status'])

    def test_changed_instruction_bytes_rejected(self):
        (self.f.run/'instruction.txt').write_text('Do not skip baseline.')
        self.skip('baseline')
        self.assertEqual('UNVERIFIED', self.report()['phases'][0]['status'])

    def test_task_acceptance_collision_is_not_waived(self):
        self.spec['criteria']=[dict(id='D-BUILD',due_state='BUILD_PASSED',allowed_methods=['AUTOMATED','LLM_REVIEW'],required=True)]
        self.complete()
        report=self.report()
        row=report['specification_coverage']['task_acceptance']['criteria'][0]
        self.assertEqual('D-BUILD',row['criterion_id'])
        self.assertEqual('UNRESOLVED',row['result'])
        self.assertEqual('UNSUPPORTED',report['completion_support'])

    def test_mandatory_phases_have_no_skip_route(self):
        for phase in ('specification','specification_verification'):
            self.assertFalse(next(p for p in self.flow['extensions']['reporting']['phases'] if p['id']==phase)['skipped_states'])
            self.assertFalse(any(e['trigger']=='USER_SKIP_'+phase.upper() for e in self.flow['transitions']))

    def test_schema_requires_identifiable_original_message(self):
        evidence=self.disposition('baseline')
        payload=read_history(self.f.history,'task-1',self.f.schemas)[-1]['payload']
        del payload['instruction']['message_id']
        self.assertTrue(list(validator('records.schema.json','PhaseDisposition').iter_errors(payload)))

    def test_unresolved_invocation_cannot_be_backfilled_after_skip(self):
        intent=self.intent()
        self.saved('intent',intent)
        self.skip('baseline')
        terminal=deepcopy(intent);terminal['dispatch_status']='CANCELLED';terminal['cancellation_evidence_refs']=[self.review_evidence]
        self.saved('late-terminal',terminal)
        self.assertEqual('UNVERIFIED',self.report()['phases'][0]['status'])

    def test_terminal_invocation_before_skip_is_admitted(self):
        intent=self.intent()
        self.saved('intent',intent)
        terminal=deepcopy(intent);terminal['dispatch_status']='CANCELLED';terminal['cancellation_evidence_refs']=[self.review_evidence]
        self.saved('terminal',terminal)
        self.skip('baseline')
        self.assertEqual('USER_SKIPPED',self.report()['phases'][0]['status'])

    def test_normal_standard_sequence_is_preserved(self):
        sequence=self.flow['extensions']['default_sequence']
        for source,dest in zip(sequence,sequence[1:]):
            self.assertEqual(1,len([e for e in self.flow['transitions'] if e['from']==source and e['to']==dest and 'default' in e['profiles']]))

    def intent(self):
        intent=fixtures()['Invocation']
        intent['expected_identities'].update(adapter_definition_id=self.adapter_identity,revision=self.inventory['revision'])
        intent['inputs']['source']=self.inventory['revision']
        return intent

    def test_fractional_timestamps_compare_instants(self):
        self.event_stamp='2026-10-04T12:00:00.3Z'
        review=dict(method='LLM_REVIEW',actor='reviewer',timestamp='2026-10-04T12:00:00.2Z',result='CONFIRMED',evidence=self.review_evidence)
        self.skip('baseline',timestamp='2026-10-04T12:00:00.1Z',review=review)
        self.assertEqual('USER_SKIPPED',self.report()['phases'][0]['status'])

    def test_terminal_cancellation_with_missing_evidence_is_rejected(self):
        intent=self.intent();self.saved('intent',intent)
        terminal=deepcopy(intent);terminal['dispatch_status']='CANCELLED'
        terminal['cancellation_evidence_refs']=[self.review_evidence]
        self.saved('terminal',terminal)
        (self.f.run/'review.txt').unlink()
        self.skip('baseline')
        self.assertEqual('UNVERIFIED',self.report()['phases'][0]['status'])

    def test_wrong_request_scope_is_unverified(self):
        self.skip('baseline',request_identity=HASH)
        self.assertEqual('UNVERIFIED',self.report()['phases'][0]['status'])

    def test_wrong_configuration_scope_is_unverified(self):
        self.skip('baseline',configuration_id='cfg-2')
        self.assertEqual('UNVERIFIED',self.report()['phases'][0]['status'])

    def test_after_spec_skip_requires_current_specification_scope(self):
        self.before_spec();self.accept()
        self.skip('verification_plan',specification_identity=HASH)
        self.assertEqual('UNVERIFIED',next(p for p in self.report()['phases'] if p['phase_id']=='verification_plan')['status'])

    def test_supported_skip_cli_is_brief_linked_and_read_only(self):
        self.complete()
        before={p:p.read_bytes() for p in self.f.repo.rglob('*') if p.is_file()}
        result=self.f.report()
        self.assertEqual(0,result.returncode,result.stderr+result.stdout)
        markdown=(self.f.docs/'report.md').read_text().replace('\\','')
        build=next(line for line in markdown.splitlines() if line.startswith('| Build |'))
        self.assertIn('USER_SKIPPED',build)
        self.assertIn('/instruction.txt)',build)
        self.assertIn('approval',build)
        visible=re.sub(r'<!--.*?-->','',markdown)
        visible=re.sub(r'\[([^]]*)\]\([^)]*\)',r'\1',visible)
        self.assertLessEqual(len(re.sub(r'[#*|_`—-]',' ',visible).split()),200)
        for path,raw in before.items():self.assertEqual(raw,path.read_bytes(),str(path))

    def test_prior_failed_admission_is_retained_after_skip(self):
        self.before_spec();self.accept()
        for phase in ('verification_plan','implementation_plan','implementation','preflight'):
            self.skip(phase)
        self.event('BUILDING')
        self.event('BUILD_FAILED')
        self.skip('build')
        report=self.report()
        build=next(p for p in report['phases'] if p['phase_id']=='build')
        self.assertEqual('USER_SKIPPED',build['status'])
        self.assertEqual(1,build['extensions']['reporting']['earlier_failure_count'])
        failures=[a for a in report['history']['attempts'] if a['state']=='BUILD_FAILED']
        self.assertEqual(1,len(failures))
        # An unsupported original failure claim is retained, never upgraded.
        self.assertEqual('UNVERIFIED',failures[0]['status'])
        result=self.f.report()
        self.assertEqual(1,result.returncode,result.stderr)
        row=next(line for line in (self.f.docs/'report.md').read_text().splitlines() if line.startswith('| Build |'))
        self.assertIn('/instruction.txt)',row)
        self.assertIn('#entry=skip-build-',row)
        self.assertNotIn('#entry=decision-',row)


    def test_same_id_task_criterion_is_retained_without_any_skip(self):
        self.spec['criteria']=[dict(id='D-BASELINE',due_state='BASELINED',allowed_methods=['LLM_REVIEW'],required=True)]
        for target,cid in [('BASELINED','D-BASELINE'),('RESEARCHED','D-RESEARCH'),('PATTERN_VERIFIED','D-PATTERN')]:
            self.event(target,reviews=[self.review(target,[cid])])
        self.accept()
        task=self.report()['specification_coverage']['task_acceptance']['criteria']
        self.assertEqual(['D-BASELINE'],[c['criterion_id'] for c in task])

    def test_malformed_reporting_metadata_stays_unverified(self):
        from reporting.evidence import _Capture
        capture=capture_task(self.f.repo,self.f.harness,'task-1')
        for value in (None, 'bad', {'phases':None}, {'stage_criteria':None}, {'stage_criteria':[None]}):
            with self.subTest(value=value):
                broken=deepcopy(capture)
                broken['phase_map'].update(value=value,valid=False)
                reader=_Capture.__new__(_Capture);reader.data=broken
                reader.phase_dispositions()
                report=derive_report(broken,generated_at=STAMP)
                self.assertNotEqual('SUPPORTED_BY_CHECKED_RECORDS',report['completion_support'])

    def test_untyped_skip_assertion_remains_unverified(self):
        self.post['extensions']={'skip':{'user_approved':True}}
        self.event('BASELINED',reviews=[self.review('BASELINED',['D-BASELINE'])])
        phase=self.report()['phases'][0]
        self.assertEqual(('USER_SKIPPED','UNVERIFIED'),(phase['recorded_claim'],phase['status']))
