"""Adversarial parser and local schema boundary tests."""
import importlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

CHECKER = Path(__file__).resolve().parents[1] / 'builder-kit/checker'
sys.path.insert(0, str(CHECKER))

class LoaderTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((CHECKER / 'harness_check/loader.py').exists(), 'restricted loader not implemented')
        self.loader = importlib.import_module('harness_check.loader')
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()

    def load(self, body, suffix='.yaml'):
        p = self.root / ('input' + suffix)
        p.write_text(body, encoding='utf-8')
        return self.loader.load_document(p, self.root)

    def test_forbidden_yaml_constructs_and_ambiguous_scalars(self):
        invalid = ['a: 1\na: 2', 'a: &a {b: 1}\nc: {<<: *a}', 'a: !custom x',
                   'a: !!str x', 'a: &a [*a]', '1: x', '? [a,b]\n: x',
                   'a: 2026-10-04', 'a: 2026-10-04T12:00:00Z', 'a: yes', 'a: NO',
                   'a: On', 'a: True', 'a: FALSE', 'a: .nan', 'a: -.inf',
                   'a: 012', 'a: 0x12', 'a: 1:20', 'a: 1_000', 'a: +1',
                   'a: ~', 'a: Null', 'a:', '---\na: 1\n---\na: 2', '[unterminated']
        for body in invalid:
            with self.subTest(body=body), self.assertRaises(self.loader.DocumentError) as err:
                self.load(body)
            self.assertTrue(err.exception.code.startswith('PARSE_'))

    def test_json_duplicate_nonfinite_overflow_and_root_scalars(self):
        for body in ['{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}', '{"a":1e999}', 'null', '"a"']:
            with self.subTest(body=body), self.assertRaises(self.loader.DocumentError):
                self.load(body, '.json')

    def test_utf8_crlf_quoted_dates_explicit_types_and_acyclic_alias(self):
        value = self.load('name: "日本語 café"\r\ndate: "2026-10-04"\r\nflag: true\r\n"no": "no"\r\na: &a [1, 2]\r\nb: *a\r\n')
        self.assertEqual(value['a'], value['b'])
        self.assertIs(value['flag'], True)
        self.assertEqual(value['date'], '2026-10-04')

    def test_paths_rejected_before_outside_content_read(self):
        with tempfile.TemporaryDirectory() as outside:
            sentinel = Path(outside).resolve() / 'sentinel.yaml'
            sentinel.write_text('secret: sentinel')
            (self.root / 'escape').symlink_to(sentinel)
            (self.root / 'Case.yaml').write_text('ok: true')
            original = Path.read_bytes
            seen = []
            def read(path):
                seen.append(path)
                self.assertNotEqual(path.resolve(), sentinel)
                return original(path)
            with patch.object(Path, 'read_bytes', read):
                for path in [self.root / '../sentinel.yaml', self.root / 'escape', self.root / 'case.yaml', sentinel]:
                    with self.subTest(path=path), self.assertRaises(self.loader.DocumentError) as err:
                        self.loader.load_document(path, self.root)
                    self.assertTrue(err.exception.code.startswith('PATH_'))
            self.assertEqual(seen, [])

    def test_unreadable_file_distinct_from_malformed(self):
        p = self.root / 'unreadable.yaml'; p.write_text('a: 1')
        with patch.object(Path, 'read_bytes', side_effect=PermissionError('denied')):
            with self.assertRaises(self.loader.DocumentError) as err:
                self.loader.load_document(p, self.root)
        self.assertEqual(err.exception.exit_code, 2)

    def test_schema_remote_reference_is_never_retrieved(self):
        schemas = importlib.import_module('harness_check.schemas')
        p = self.root / 'test.schema.json'
        for ref in ['https://invalid.example/secret', '../outside.schema.json', 'file:///tmp/outside.schema.json']:
            p.write_text(json.dumps({'$schema': 'https://json-schema.org/draft/2020-12/schema', '$ref': ref}))
            result = schemas.validate_document({}, p)
            self.assertTrue(result)
            self.assertTrue(result[0]['code'].startswith(('SCHEMA_', 'PATH_')))

    def test_schema_datetime_checks_calendar(self):
        schemas = importlib.import_module('harness_check.schemas')
        p = self.root / 'test.schema.json'
        p.write_text(json.dumps({'$schema': 'https://json-schema.org/draft/2020-12/schema', 'type':'object', 'properties': {'time':{'type':'string','format':'date-time'}}}))
        self.assertTrue(schemas.validate_document({'time':'2026-02-30T00:00:00Z'}, p))
        self.assertFalse(schemas.validate_document({'time':'2026-02-28T00:00:00Z'}, p))

    def test_unused_local_schema_reference_must_resolve_fragment(self):
        schemas=importlib.import_module('harness_check.schemas')
        p=self.root/'test.schema.json'
        p.write_text(json.dumps({'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':{'unused':{'$ref':'#/$defs/missing'}}}))
        self.assertTrue(schemas.validate_document({},p))

    def test_invalid_schema_definition_is_classified_as_input_error(self):
        schemas=importlib.import_module('harness_check.schemas')
        p=self.root/'test.schema.json';p.write_text(json.dumps({'$schema':'https://json-schema.org/draft/2020-12/schema','type':42}))
        with self.assertRaises(self.loader.DocumentError) as err:
            schemas.local_validator(p)
        self.assertEqual(err.exception.code,'SCHEMA_DEFINITION')
        self.assertEqual(err.exception.exit_code,1)

    def test_transitive_schema_refs_resolve_relative_to_declaring_file(self):
        schemas=importlib.import_module('harness_check.schemas')
        nested=self.root/'nested';nested.mkdir()
        p=self.root/'test.schema.json';p.write_text(json.dumps({'$schema':'https://json-schema.org/draft/2020-12/schema','$ref':'nested/child.schema.json'}))
        (nested/'child.schema.json').write_text(json.dumps({'$ref':'leaf.schema.json'}))
        (nested/'leaf.schema.json').write_text(json.dumps({'type':'object','required':['value']}))
        self.assertFalse(schemas.validate_document({'value':True},p))
        self.assertTrue(schemas.validate_document({},p))
