"""Disposable examples exercise public CLIs, never production commands."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import yaml
from support import validator

KIT = Path(__file__).resolve().parents[1] / 'builder-kit'
GEN = KIT / 'examples/make_examples.py'
ADAPTER = KIT / 'examples/synthetic_adapter.py'


class ExampleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='examples café ')
        cls.destination = Path(cls.tmp.name) / 'repos'
        cls.proc = subprocess.run([sys.executable, str(GEN), '--destination', str(cls.destination)],
                                  capture_output=True, text=True)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_complete_layouts_pending_and_configured_profiles(self):
        self.assertEqual(self.proc.returncode, 0, self.proc.stderr)
        for name, root, profile_id in [('compiled', '.harness', 'default'),
                ('source-only', '.harness', 'source-only'),
                ('docs', '.harness', 'docs'), ('multi-target', '.harness', 'default')]:
            with self.subTest(name=name):
                h = self.destination / name / root
                profile = yaml.safe_load((h/'framework/config/repo-profile.yaml').read_text())
                self.assertTrue(validator('profile.schema.json').is_valid(profile))
                cat = yaml.safe_load((h/'framework/workflows/verification-criteria.yaml').read_text())
                for f in cat['extensions']['required_runtime_files']:
                    self.assertTrue((h/f).is_file(), f)
                self.assertEqual(profile['workflow_profiles'][0]['id'], profile_id)
                self.assertEqual(profile['state_writer']['mode'], 'LLM_PROTOCOL')
                self.assertEqual(profile['capabilities']['test']['configuration_status'],
                    'PENDING_DISCOVERY' if name == 'compiled' else 'NOT_APPLICABLE' if name == 'docs' else 'CONFIGURED')
                self.assertFalse(profile['assessments'], 'generation must not pretend actual semantic review')
                self.assertFalse((self.destination/name/'ENTRYPOINT.candidate.md').exists())
                self.assertTrue((h/'README.md').is_file())
                for f in h.rglob('*.md'):
                    self.assertNotIn(str(KIT), f.read_text())
                self.assertEqual(len(profile['workflow_profiles'][0]['required_targets']), 2 if name == 'multi-target' else 1)

    def test_refuses_existing_user_content_without_changes(self):
        root = Path(self.tmp.name)/'occupied'; root.mkdir(exist_ok=True)
        sentinel=root/'notes.txt'; sentinel.write_text('user content café')
        proc=subprocess.run([sys.executable,str(GEN),'--destination',str(root)],capture_output=True,text=True)
        self.assertNotEqual(proc.returncode,0)
        self.assertIn('empty directory',proc.stderr)
        self.assertEqual(sentinel.read_text(),'user content café')
        self.assertEqual(sorted(p.name for p in root.iterdir()),['notes.txt'])

    def test_four_outcomes_and_consumed_artifact_lineage(self):
        self.assertEqual(self.proc.returncode,0,self.proc.stderr)
        request=json.loads((self.destination/'multi-target/fixture-request.json').read_text())
        for outcome in ['PASS','FAIL','BLOCKED','UNKNOWN']:
            proc=subprocess.run([sys.executable,str(ADAPTER),'--request',json.dumps(request),'--outcome',outcome],
                capture_output=True,text=True)
            self.assertEqual(proc.returncode,0,proc.stderr)
            envelope=json.loads(proc.stdout)
            self.assertEqual(envelope['status'],outcome)
            self.assertEqual(envelope['provenance'],'FIXTURE')
            self.assertTrue(validator('result.schema.json').is_valid(envelope),envelope)
            self.assertEqual('artifact' in envelope,outcome=='PASS')
        request.pop('artifact')
        proc=subprocess.run([sys.executable,str(ADAPTER),'--request',json.dumps(request),'--outcome','PASS'],capture_output=True,text=True)
        self.assertEqual(proc.returncode,2)
        self.assertFalse(proc.stdout)

    def test_adapter_rejects_command_and_noncanonical_json(self):
        self.assertTrue(ADAPTER.exists(), 'missing synthetic adapter')
        for request in ['{"x":1,"x":2}', '{"value":NaN}', '{"command":"touch SENTINEL"}']:
            proc=subprocess.run([sys.executable,str(ADAPTER),'--request',request,'--outcome','PASS'],capture_output=True,text=True)
            self.assertEqual(proc.returncode,2)
            self.assertFalse(proc.stdout)

    def test_separate_test_source_and_consumed_artifact_must_match(self):
        self.assertEqual(self.proc.returncode,0,self.proc.stderr)
        request=json.loads((self.destination/'multi-target/fixture-test-request.json').read_text())
        proc=subprocess.run([sys.executable,str(ADAPTER),'--request',json.dumps(request),'--outcome','PASS'],capture_output=True,text=True)
        self.assertEqual(proc.returncode,0,proc.stderr)
        envelope=json.loads(proc.stdout)
        self.assertTrue(validator('result.schema.json').is_valid(envelope))
        self.assertEqual(envelope['artifact']['identity'],envelope['test_source']['artifact_identity'])
        self.assertNotEqual(envelope['revision'],envelope['test_source']['identity'])
        for variant in ['missing-source','wrong-artifact']:
            bad=deepcopy(request)
            if variant=='missing-source':bad.pop('test_source')
            else:bad['test_source']['artifact_identity']='sha256:'+'0'*64
            proc=subprocess.run([sys.executable,str(ADAPTER),'--request',json.dumps(bad),'--outcome','PASS'],capture_output=True,text=True)
            self.assertEqual(proc.returncode,2)
            self.assertFalse(proc.stdout)

    def test_adapter_rejects_malformed_nested_lineage_reference(self):
        self.assertEqual(self.proc.returncode,0,self.proc.stderr)
        request=json.loads((self.destination/'multi-target/fixture-test-request.json').read_text())
        request['artifact']['reference']['path']='../outside'
        proc=subprocess.run([sys.executable,str(ADAPTER),'--request',json.dumps(request),'--outcome','PASS'],capture_output=True,text=True)
        self.assertEqual(proc.returncode,2)
        self.assertFalse(proc.stdout)
