"""Focused consolidated storage and split report publication regression coverage."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from support import fixtures, result_fixture, SCHEMAS, HASH

RUNTIME = SCHEMAS.parents[2]
TOOLS = RUNTIME / 'framework/tools' if (RUNTIME / 'framework/tools').exists() else SCHEMAS.parents[1] / 'tools'
sys.path.insert(0, str(TOOLS))
from harness_io.journal import canonical_json, content_identity, make_entry, parse_history, append_record, publish_state, read_history
from harness_io.loader import DocumentError
from reporting.evidence import capture_task, check_unchanged, reference_key
from reporting.summary import derive_report
from reporting.render import inspect_pair_metadata

FRAMEWORK = TOOLS.parent


class JournalReportingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='journal report ü ')
        self.addCleanup(self.temporary.cleanup)
        self.repo = Path(self.temporary.name).resolve()
        self.harness = self.repo / '.harness'
        shutil.copytree(FRAMEWORK, self.harness / 'framework', ignore=shutil.ignore_patterns('__pycache__'))
        self.run = self.harness / 'artifacts/development/task-1'
        self.run.mkdir(parents=True)
        self.docs = self.harness / 'docs/development/task-1'
        self.docs.mkdir(parents=True)
        (self.docs / 'spec.md').write_text('# Storage regression task\n', encoding='utf-8')
        self.history = self.run / 'history.jsonl'
        self.schemas = self.harness / 'framework/templates/schemas'
        files = [('PROFILE', 'config/repo-profile.yaml'), ('WORKFLOW', 'workflows/development/workflow.yaml'),
                 ('RULES', 'workflows/verification-rules.md')]
        files += [('SCHEMA', p.relative_to(FRAMEWORK).as_posix()) for p in sorted(SCHEMAS.glob('*.json'))]
        mapping = {path: content_identity((self.harness / 'framework' / path).read_bytes()) for _, path in files}
        bundle = content_identity(canonical_json(mapping)).split(':')[1]
        self.configuration = fixtures()['ConfigSnapshot']
        self.configuration['captured_definitions'] = []
        for kind, path in files:
            target = self.harness / 'artifacts/configurations' / bundle / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((self.harness / 'framework' / path).read_bytes())
            self.configuration['captured_definitions'].append(dict(kind=kind,
                reference=dict(kind='LOCAL', scope='HARNESS', path='framework/' + path),
                identity=mapping[path], captured_path=target.relative_to(self.harness).as_posix()))
        self.append('configuration', self.configuration)
        decision = fixtures()['GateDecision']
        decision.update(decision='ALLOW', proposed_destination='NEW', resolution_route=None)
        self.decision = self.append('initialize-decision', decision)
        event = fixtures()['Event']
        event['decision_ref'] = dict(reference=self.ref('initialize-decision'), provenance='REVIEW',
                                    summary='Procedural initialization only', identity=self.decision['payload_identity'])
        self.event = self.append('initialize-event', event)
        publish_state(self.history, 'task-1', self.schemas)

    def ref(self, entry_id):
        return dict(kind='LOCAL', scope='HARNESS', path='artifacts/development/task-1/history.jsonl', entry_id=entry_id)

    def append(self, entry_id, payload):
        return append_record(self.history, 'task-1', entry_id, payload, self.schemas)

    def capture(self):
        return capture_task(self.repo, self.harness, 'task-1')

    def report(self):
        return subprocess.run([sys.executable, str(self.harness / 'framework/tools/report.py'),
            '--repo-root', str(self.repo), '--harness-root', str(self.harness), '--task-id', 'task-1'],
            text=True, capture_output=True)

    def test_real_capture_selects_canonical_payload_and_projects_state(self):
        capture = self.capture()
        self.assertTrue(capture['history']['snapshot_consistent'])
        self.assertEqual(1, len(capture['history']['committed_prefix']))
        selected = capture['evidence_checks'][reference_key(self.ref('initialize-decision'))]
        self.assertEqual(self.decision['payload_identity'], selected['identity'])
        self.assertTrue(selected['checked'])
        self.assertEqual([], check_unchanged(capture))
        report = derive_report(capture, generated_at='2026-10-06T12:00:00Z')
        self.assertNotEqual('SUPPORTED_BY_CHECKED_RECORDS', report['completion_support'])
        self.assertGreater(len(report['phases']), 10)

    def test_report_pair_is_brief_and_sources_are_immutable(self):
        before = {p: p.read_bytes() for p in self.harness.rglob('*') if p.is_file()}
        completed = self.report()
        self.assertEqual(1, completed.returncode, completed.stdout + completed.stderr)
        machine = (self.run / 'report.json').read_bytes()
        document = json.loads(machine)
        markdown = (self.docs / 'report.md').read_text()
        marker = inspect_pair_metadata(markdown)
        self.assertEqual((document['generation_id'], content_identity(machine).split(':')[1]), marker)
        visible = re.sub(r'<!--.*?-->', '', markdown)
        visible = re.sub(r'\[([^]]*)\]\([^)]*\)', r'\1', visible)
        self.assertLessEqual(len(re.sub(r'[#*|_`—-]', ' ', visible).split()), 200)
        for phase in document['phases']:
            self.assertIn(phase['label'], markdown.replace('\\', ''))
        for path, content in before.items():
            self.assertEqual(content, path.read_bytes(), str(path))
        self.assertEqual({'history.jsonl', 'state.json', 'report.json'}, {p.name for p in self.run.iterdir()})
        self.assertEqual({'spec.md', 'report.md'}, {p.name for p in self.docs.iterdir()})
        self.assertEqual([], list((self.harness / 'artifacts/tmp').iterdir()))

    def append_test_result(self, entry_id, run_id, status):
        intent = fixtures()['Invocation']
        intent.update(intent_id=run_id + '-intent', run_id=run_id, capability='test')
        self.append(entry_id + '-intent', intent)
        log = self.run / (run_id + '.log')
        log.write_text('Actual observed test outcome: ' + status + '\n')
        result = result_fixture()
        result.update(run_id=run_id, capability='test', status=status, provenance='EXECUTION')
        result['evidence'] = dict(reference=dict(kind='LOCAL', scope='HARNESS',
            path=log.relative_to(self.harness).as_posix()), summary='Recorded execution outcome')
        return self.append(entry_id, result)

    def test_saved_unsupported_state_is_visible_without_changing_machine_authority(self):
        for state in ('TEST_PASSED', 'COMPLETE'):
            entries = parse_history(self.history.read_bytes(), 'task-1')
            event = deepcopy(self.event['payload'])
            event['decision_ref']['provenance'] = 'FIXTURE'
            event['next_state'] = state
            event['post_state']['state'] = state
            entries[-1] = make_entry(event, 'task-1', 'initialize-event', entries[-2])
            self.history.write_bytes(b''.join(canonical_json(e) + b'\n' for e in entries))
            publish_state(self.history, 'task-1', self.schemas)
            completed = self.report()
            self.assertEqual(1, completed.returncode, completed.stderr)
            report = json.loads((self.run / 'report.json').read_text())
            markdown = (self.docs / 'report.md').read_text().replace('\\', '')
            self.assertIsNone(report['recorded_state'])
            self.assertEqual(0, report['history']['committed_prefix_length'])
            self.assertNotEqual('SUPPORTED_BY_CHECKED_RECORDS', report['completion_support'])
            self.assertIn('Saved claim: [' + state + ']', markdown)
            self.assertIn('(unverified)', markdown)
            self.assertIn('Validated state: none', markdown)
            self.assertIn('Recorded completion unsupported.' if state == 'COMPLETE' else 'Task incomplete.', markdown)

    def test_testing_phase_displays_test_capability_claim_and_direct_log(self):
        self.append_test_result('test-result', 'actual-test', 'PASS')
        completed = self.report()
        self.assertEqual(1, completed.returncode, completed.stderr)
        markdown = (self.docs / 'report.md').read_text().replace('\\', '')
        row = next(line for line in markdown.splitlines() if line.startswith('| Testing |'))
        self.assertIn('NOT_RECORDED; tool PASS', row)
        self.assertIn('/actual-test.log)', row)
        report = json.loads((self.run / 'report.json').read_text())
        phase = next(p for p in report['phases'] if p['phase_id'] == 'testing')
        self.assertEqual('NOT_RECORDED', phase['status'])

    def test_tool_claim_selection_uses_journal_sequence_not_lexical_entry_id(self):
        earlier = self.append_test_result('z-earlier-result', 'earlier-failed-test', 'FAIL')
        later = self.append_test_result('a-later-result', 'later-passing-test', 'PASS')
        completed = self.report()
        self.assertEqual(1, completed.returncode, completed.stderr)
        report = json.loads((self.run / 'report.json').read_text())
        results = {r['reference']['entry_id']: r for r in report['extensions']['reporting']['recorded_results']}
        self.assertEqual(earlier['sequence'], results['z-earlier-result']['journal_sequence'])
        self.assertEqual(later['sequence'], results['a-later-result']['journal_sequence'])
        self.assertLess(earlier['sequence'], later['sequence'])
        row = next(line for line in (self.docs / 'report.md').read_text().splitlines() if line.startswith('| Testing |'))
        self.assertIn('tool PASS', row)
        self.assertIn('/later-passing-test.log)', row)
        self.assertNotIn('tool FAIL', row)

    def test_torn_or_corrupt_suffix_refuses_report_and_preserves_prior_pair(self):
        self.assertEqual(1, self.report().returncode)
        before = (self.run / 'report.json').read_bytes(), (self.docs / 'report.md').read_bytes()
        original = self.history.read_bytes()
        cases = [original[:-1], original + b'{"torn":', original + b'\n', original.replace(b'coordinator', b'coordinatOr')]
        for raw in cases:
            with self.subTest(tail=raw[-20:]):
                self.history.write_bytes(raw)
                with self.assertRaises(ValueError):
                    parse_history(raw, 'task-1')
                self.assertEqual(2, self.report().returncode)
                self.assertEqual(before, ((self.run / 'report.json').read_bytes(), (self.docs / 'report.md').read_bytes()))
        self.history.write_bytes(original)

    def test_duplicate_conflicting_entry_and_cross_task_are_rejected(self):
        original = self.history.read_bytes()
        self.assertEqual(self.event, self.append('initialize-event', self.event['payload']))
        self.assertEqual(original, self.history.read_bytes())
        changed = deepcopy(self.event['payload']); changed['actor'] = 'different'
        with self.assertRaises(ValueError):
            self.append('initialize-event', changed)
        last = parse_history(original, 'task-1')[-1]
        duplicate = make_entry(self.decision['payload'], 'task-1', 'another-decision', last)
        with self.assertRaises(ValueError):
            parse_history(original + canonical_json(duplicate) + b'\n', 'task-1')
        foreign = fixtures()['Observation']; foreign['task_id'] = 'other'
        with self.assertRaises(ValueError):
            self.append('foreign', foreign)

    def test_duplicate_json_keys_and_envelope_sequence_fail_closed(self):
        raw = self.history.read_bytes()
        with self.assertRaises(ValueError):
            parse_history(raw.replace(b'"sequence":1', b'"sequence":1,"sequence":1', 1), 'task-1')
        entries = parse_history(raw, 'task-1'); entries[-1]['sequence'] = 99
        with self.assertRaises(ValueError):
            parse_history(b''.join(canonical_json(e) + b'\n' for e in entries), 'task-1')

    def test_unsafe_or_foreign_entry_references_fail_closed(self):
        original = self.history.read_bytes()
        for path in ('../outside/history.jsonl', '/tmp/history.jsonl', 'artifacts/development/other/history.jsonl'):
            self.history.write_bytes(original)
            event = deepcopy(self.event['payload']); event['decision_ref']['reference']['path'] = path
            entries = parse_history(original, 'task-1')
            entries[-1] = make_entry(event, 'task-1', 'initialize-event', entries[-2])
            self.history.write_bytes(b''.join(canonical_json(e) + b'\n' for e in entries))
            with self.assertRaises(ValueError):
                self.capture()
        self.history.write_bytes(original)

    def test_evidence_and_configuration_byte_hash_mismatch_are_diagnostics(self):
        captured = self.capture()
        rules = self.harness / self.configuration['captured_definitions'][2]['captured_path']
        rules.write_bytes(rules.read_bytes() + b'\nchanged\n')
        self.assertTrue(check_unchanged(captured))
        changed = self.capture()
        self.assertIn('REPORT_IDENTITY_MISMATCH', {d['code'] for d in changed['diagnostics']})

    def test_missing_entry_and_wrong_payload_hash_cannot_support_event(self):
        for selector, identity in [('missing', self.decision['payload_identity']), ('initialize-decision', HASH)]:
            entries = parse_history(self.history.read_bytes(), 'task-1')
            event = deepcopy(self.event['payload'])
            event['decision_ref'].update(reference=self.ref(selector), identity=identity)
            entries[-1] = make_entry(event, 'task-1', 'initialize-event', entries[-2])
            self.history.write_bytes(b''.join(canonical_json(e) + b'\n' for e in entries))
            if selector == 'missing':
                with self.assertRaises(ValueError):
                    self.capture()
                self.history.write_bytes(b''.join(canonical_json(e) + b'\n' for e in [entries[0], entries[1], self.event]))
            else:
                captured = self.capture()
                self.assertFalse(captured['history']['snapshot_consistent'])

    def test_review_after_event_does_not_change_state(self):
        before = (self.run / 'state.json').read_bytes()
        self.append('later-review', fixtures()['CriterionReview'])
        publish_state(self.history, 'task-1', self.schemas)
        self.assertEqual(before, (self.run / 'state.json').read_bytes())

    def test_typed_read_and_state_projection_refuse_malformed_payload(self):
        original = self.history.read_bytes()
        entries = parse_history(original, 'task-1')
        changed = deepcopy(self.event['payload'])
        changed['post_state']['writer'] = 'untyped writer'
        entries[-1] = make_entry(changed, 'task-1', 'initialize-event', entries[-2])
        self.history.write_bytes(b''.join(canonical_json(e) + b'\n' for e in entries))
        state = (self.run / 'state.json').read_bytes()
        damaged_history = self.history.read_bytes()
        with self.assertRaises(ValueError):
            self.append('after-invalid', fixtures()['CriterionReview'])
        self.assertEqual(damaged_history, self.history.read_bytes())
        with self.assertRaises(ValueError):
            self.append('initialize-event', changed)
        self.assertEqual(damaged_history, self.history.read_bytes())
        with self.assertRaises(ValueError):
            read_history(self.history, 'task-1', self.schemas)
        with self.assertRaises(ValueError):
            publish_state(self.history, 'task-1', self.schemas)
        self.assertEqual(state, (self.run / 'state.json').read_bytes())
        completed = subprocess.run([sys.executable, str(self.harness / 'framework/tools/journal.py'),
            'read', '--history', str(self.history), '--task-id', 'task-1'], capture_output=True, text=True)
        self.assertEqual(2, completed.returncode)
        self.assertIn('JOURNAL_UNAVAILABLE', completed.stderr)

    def test_invocation_revisions_preserve_predispatch_inputs_and_monotonic_counters(self):
        intent = fixtures()['Invocation']
        self.append('intent', intent)
        completed = deepcopy(intent)
        completed['dispatch_status'] = 'COMPLETED'
        completed['counters']['calls'] = 1
        completed['counters']['elapsed_seconds'] = 1
        self.append('completed', completed)
        for field, value in [('inputs', dict(intent['inputs'], source='sha256:' + 'b' * 64)),
                             ('dispatch_status', 'RUNNING'),
                             ('counters', dict(completed['counters'], calls=0))]:
            invalid = deepcopy(completed); invalid[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.append('invalid-' + field, invalid)
        self.assertEqual(['INTENT_RECORDED', 'COMPLETED'],
                         [e['payload']['dispatch_status'] for e in parse_history(self.history.read_bytes(), 'task-1')
                          if e['payload']['record_type'] == 'Invocation'])

    def test_spec_revisions_remain_distinct_and_do_not_collide_by_task_id(self):
        spec = fixtures()['TaskSpec']
        self.append('spec-v1', spec)
        revised = deepcopy(spec); revised['specification_identity'] = 'sha256:' + 'b' * 64
        self.append('spec-v2', revised)
        capture = self.capture()
        self.assertEqual(2, len(capture['record_index']['TaskSpec']))
        self.assertFalse(any(d['code'] == 'REPORT_RECORD_COLLISION' for d in capture['diagnostics']))

    def test_stale_pair_is_detected_and_replaced(self):
        self.assertEqual(1, self.report().returncode)
        (self.docs / 'report.md').write_text('stale report')
        completed = self.report()
        self.assertEqual(1, completed.returncode, completed.stderr)
        self.assertIn('REPORT_PRIOR_OUTPUT_MISMATCH', completed.stderr)
        report = json.loads((self.run / 'report.json').read_text())
        self.assertTrue(report['extensions']['reporting']['presentation']['publication_diagnostics'])

    def test_stale_lock_and_symlink_outputs_refuse_mutation(self):
        lock = self.run / '.journal.lock'; lock.write_text('interrupted')
        with self.assertRaises(FileExistsError):
            self.append('review', fixtures()['CriterionReview'])
        lock.unlink()
        external = self.repo / 'external.txt'; external.write_text('preserve')
        (self.docs / 'report.md').symlink_to(external)
        self.assertEqual(2, self.report().returncode)
        self.assertEqual('preserve', external.read_text())

    def test_sources_changing_across_recapture_publish_unverified_pair(self):
        import reporting.evidence as evidence_module
        spec = importlib.util.spec_from_file_location('changing_report_cli', self.harness / 'framework/tools/report.py')
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        original = evidence_module.check_unchanged
        spec_path = self.docs / 'spec.md'
        def change_then_check(capture):
            spec_path.write_bytes(spec_path.read_bytes() + b'changed during capture\n')
            return original(capture)
        with patch.object(evidence_module, 'check_unchanged', side_effect=change_then_check):
            code = module.main(['--repo-root', str(self.repo), '--harness-root', str(self.harness), '--task-id', 'task-1'])
        self.assertEqual(1, code)
        raw = (self.run / 'report.json').read_bytes()
        report = json.loads(raw)
        self.assertTrue(report['extensions']['reporting']['captured_before_change'])
        self.assertIn('REPORT_SOURCE_CHANGED', {d['code'] for d in report['diagnostics']})
        self.assertEqual(content_identity(raw).split(':')[1], inspect_pair_metadata((self.docs / 'report.md').read_text())[1])

    def test_legacy_capture_is_explicit_but_publication_requires_migration(self):
        legacy = self.harness / 'development/runs/task-1'
        legacy.mkdir(parents=True)
        self.run.rename(self.repo / 'preserved-modern-task')
        config = deepcopy(self.configuration)
        for definition in config['captured_definitions']:
            source = self.harness / definition['captured_path']
            relative = '/'.join(definition['captured_path'].split('/')[3:])
            destination = legacy / 'configuration' / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(source.read_bytes())
            definition['captured_path'] = 'configuration/' + relative
        event = deepcopy(self.event['payload'])
        event['decision_ref']['reference'] = dict(kind='LOCAL', scope='HARNESS',
            path='development/runs/task-1/decision.json')
        (legacy / 'decision.json').write_bytes(canonical_json(self.decision['payload']))
        (legacy / 'config-snapshot.yaml').write_bytes(canonical_json(config))
        (legacy / 'state.yaml').write_bytes(canonical_json(event['post_state']))
        (legacy / 'events.yaml').write_bytes(canonical_json(dict(schema_version='1.0.0', record_type='EventLog',
            subject_id='task-1', subject_kind='TASK', events=[event])))
        capture = self.capture()
        self.assertTrue(capture['history']['snapshot_consistent'])
        before = {p: p.read_bytes() for p in legacy.rglob('*') if p.is_file()}
        completed = self.report()
        self.assertEqual(2, completed.returncode)
        self.assertIn('preserved legacy reporter', completed.stderr)
        self.assertEqual(before, {p: p.read_bytes() for p in legacy.rglob('*') if p.is_file()})

    def test_self_or_future_entry_reference_is_rejected(self):
        original = self.history.read_bytes()
        review = fixtures()['CriterionReview']
        review['criteria'][0]['evidence_refs'] = [dict(reference=self.ref('future'), provenance='REVIEW',
            identity=HASH, summary='unavailable future payload')]
        with self.assertRaises(ValueError):
            self.append('future', review)
        self.assertEqual(original, self.history.read_bytes())

    def test_split_publication_failure_rolls_back_owned_outputs(self):
        self.assertEqual(1, self.report().returncode)
        before = (self.run / 'report.json').read_bytes(), (self.docs / 'report.md').read_bytes()
        spec = importlib.util.spec_from_file_location('journal_report_cli', self.harness / 'framework/tools/report.py')
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        original = module.os.replace
        def fail_markdown(source, destination):
            if Path(destination) == self.docs / 'report.md':
                raise OSError('injected split publication failure')
            return original(source, destination)
        with patch.object(module.os, 'replace', side_effect=fail_markdown):
            code = module.main(['--repo-root', str(self.repo), '--harness-root', str(self.harness), '--task-id', 'task-1'])
        self.assertEqual(2, code)
        self.assertEqual(before, ((self.run / 'report.json').read_bytes(), (self.docs / 'report.md').read_bytes()))


if __name__ == '__main__':
    unittest.main()
