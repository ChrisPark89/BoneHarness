"""Bounded trial checks; all command execution happens in disposable copies."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('demo_runner', ROOT / 'tests/demo/run.py')
demo = importlib.util.module_from_spec(spec)
spec.loader.exec_module(demo)


class DemoTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.workspace = Path(self.temporary.name) / 'workspace'
        self.workspace.mkdir()
        for name in demo.APP_FILES:
            target = self.workspace / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(demo.PROJECT / name, target)

    def test_refuses_unsupported_source_and_previous_history(self):
        source = self.workspace / 'src/calculator.js'
        source.write_text('changed')
        with self.assertRaises(ValueError):
            demo.check_workspace(self.workspace)
        source.write_bytes((demo.PROJECT / 'src/calculator.js').read_bytes())
        (self.workspace / '.harness').mkdir()
        retained = self.workspace / '.harness/history.jsonl'
        retained.write_text('retained')
        result = subprocess.run([sys.executable, str(ROOT / 'tests/demo/run.py'), '--workspace',
                                 str(self.workspace)], capture_output=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(retained.read_text(), 'retained')

    def test_source_restored_when_failure_sequence_is_interrupted(self):
        class InterruptedTrial:
            def __init__(self, *args):
                pass
            def execute(self, run_id, *args):
                if run_id == 'broken-test':
                    raise RuntimeError('interruption')
            def report(self):
                pass
            def prepare(self):
                pass
            def transition(self, *args):
                pass
        original = (self.workspace / 'src/calculator.js').read_bytes()
        with patch.object(demo, 'Trial', InterruptedTrial), patch.object(demo, 'capture_config', return_value={}), \
                patch.object(demo.subprocess, 'run'), patch.object(demo, 'configure_demo'):
            with self.assertRaisesRegex(RuntimeError, 'interruption'):
                demo.run(self.workspace)
        self.assertEqual((self.workspace / 'src/calculator.js').read_bytes(), original)

    def test_installed_trial_keeps_real_failure_and_repair(self):
        result = subprocess.run([sys.executable, str(ROOT / 'tests/demo/run.py'), '--workspace',
                                 str(self.workspace)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        harness = self.workspace / '.harness'
        self.assertEqual({p.name for p in harness.iterdir()}, {'README.md', 'docs', 'framework', 'artifacts'})
        self.assertEqual({p.name for p in (harness / 'artifacts/development').iterdir()},
                         {'success', 'failure-repair'})
        self.assertEqual(len(list((harness / 'artifacts/configurations').iterdir())), 1)
        for name in demo.APP_FILES:
            self.assertEqual((self.workspace / name).read_bytes(), (demo.PROJECT / name).read_bytes())
        for task in ('success', 'failure-repair'):
            task_dir = harness / 'artifacts/development' / task
            self.assertEqual({p.name for p in task_dir.iterdir() if p.suffix != '.log'},
                             {'state.json', 'history.jsonl', 'report.json'})
            self.assertEqual({p.name for p in (harness / 'docs/development' / task).iterdir()},
                             {'spec.md', 'report.md'})
            records = [json.loads(line)['payload'] for line in (task_dir / 'history.jsonl').read_text().splitlines()]
            results = [r for r in records if r['record_type'] == 'Result']
            inventories = [r for r in records if r['record_type'] == 'SourceInventory']
            self.assertEqual(1 if task == 'success' else 2, len(inventories))
            expected = ['PASS', 'PASS', 'PASS'] if task == 'success' else ['PASS', 'PASS', 'FAIL', 'PASS', 'PASS', 'PASS']
            self.assertEqual([r['status'] for r in results], expected)
            for item in results:
                inventory = next(r for r in inventories if r['revision'] == item['revision'])
                self.assertLess(records.index(inventory), records.index(item))
                self.assertEqual(item['provenance'], 'EXECUTION')
                log = harness / item['evidence']['reference']['path']
                self.assertIn('exit_code=', log.read_text())
                if item['capability'] == 'test':
                    self.assertIn('calculator', log.read_text())
                intent = next(r for r in records if r['record_type'] == 'Invocation'
                              and r['run_id'] == item['run_id'] and r['dispatch_status'] == 'INTENT_RECORDED')
                self.assertLess(records.index(intent), records.index(item))
            state = json.loads((task_dir / 'state.json').read_text())
            self.assertEqual(state['state'], 'TEST_PASSED')
            report = (harness / 'docs/development' / task / 'report.md').read_text()
            self.assertIn('tool PASS', report)
            self.assertIn('UNVERIFIED', report)
            if task == 'failure-repair':
                self.assertEqual(state['repair_counters']['test'], 1)
                self.assertIn('1 recorded repair claims (unverified)', report)
                events = [r for r in records if r['record_type'] == 'Event']
                repair_event = next(r for r in events if r['next_state'] == 'REPAIRING')
                self.assertEqual(repair_event['previous_state'], 'TEST_FAILED')
                self.assertEqual(events[events.index(repair_event) + 1]['next_state'], 'PREFLIGHT')
            self.assertTrue(all(r['decision_ref']['provenance'] == 'FIXTURE'
                                for r in records if r['record_type'] == 'Event'))
        repair = harness / 'artifacts/development/failure-repair'
        self.assertIn('ERR_ASSERTION', (repair / 'broken-test.log').read_text())
        self.assertIn('exit_code=0', (repair / 'repaired-test.log').read_text())
        self.assertEqual((self.workspace / 'dist/calculator.js').read_bytes(),
                         (demo.PROJECT / 'src/calculator.js').read_bytes())
        self.assertFalse(list(harness.rglob('__pycache__')))
        self.assertFalse(list(harness.rglob('reporter.stdout.txt')))


if __name__ == '__main__':
    unittest.main()
