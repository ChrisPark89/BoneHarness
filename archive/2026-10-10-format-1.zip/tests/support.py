"""Authoring-only fixtures and offline schema validation; never installed runtime code."""
from copy import deepcopy
import json
from pathlib import Path
from datetime import datetime, timezone
from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

FORMATS = FormatChecker()
@FORMATS.checks('date-time', raises=(ValueError, TypeError))
def valid_utc_timestamp(value):
    if not isinstance(value, str):
        return True
    return value.endswith('Z') and datetime.fromisoformat(value).utcoffset() == timezone.utc.utcoffset(None)

SCHEMAS = Path(__file__).resolve().parents[1] / 'builder-kit/templates/runtime/framework/templates/schemas'

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / 'tests/fixtures'

def recorded_evidence_path(path):
    """Resolve original recorded paths to immutable authoring test inputs."""
    recorded = json.loads((FIXTURES / 'paths.json').read_text())['recorded_paths']
    return FIXTURES / recorded[path] if path in recorded else ROOT / path

STAMP = '2026-10-04T12:00:00Z'
HASH = 'sha256:' + 'a' * 64
REF = {'kind': 'LOCAL', 'scope': 'HARNESS', 'path': 'evidence/report.json'}
EVIDENCE = {'reference': REF, 'provenance': 'REVIEW', 'summary': 'inspected definition', 'identity': HASH}
ADAPTER = {'identity': 'fixture-adapter', 'version': '1.0.0', 'content_identity': HASH}
PENDING = {'status': 'PENDING_DISCOVERY', 'value': None, 'reason': 'discovery needed', 'stop_state': 'BLOCKED'}

def record(kind, **fields):
    return {'schema_version': '1.0.0', 'record_type': kind, **fields}

def schema_path(filename):
    return ROOT / 'tests' / filename if filename == 'conformance.schema.json' else SCHEMAS / filename

def validator(filename, definition=None, overrides=None):
    resources = {}
    for path in [*SCHEMAS.glob('*.schema.json'), schema_path('conformance.schema.json')]:
        schema = (overrides or {}).get(path.name, json.loads(path.read_text()))
        resources[path.as_uri()] = Resource.from_contents(schema)
    def no_network(uri):
        raise ValueError(f'Unregistered schema; network retrieval forbidden: {uri}')
    registry = Registry(retrieve=no_network).with_resources(resources.items())
    uri = schema_path(filename).as_uri()
    schema = {'$ref': uri + (f'#/$defs/{definition}' if definition else '')}
    return Draft202012Validator(schema, registry=registry, format_checker=FORMATS)

def result_fixture():
    return record('Result', interface_version='1.0.0', capability='build', adapter=ADAPTER,
                  run_id='run-1', task_id='task-1', revision=HASH, status='PASS',
                  evidence={'reference': REF, 'summary': 'fixture outcome'}, provenance='FIXTURE',
                  configuration_id='cfg-1', adapter_definition_id=HASH,
                  targets=[{'target_id': 'default', 'environment': 'local'}], extensions={})

def profile_fixture():
    binding = dict(configuration_status='PENDING_DISCOVERY', compatibility='NOT_ASSESSED',
                   adapter=None, input_schema=PENDING, execution_environment=PENDING,
                   native_validation={'available': False, 'procedure': None}, side_effects=[],
                   permissions=PENDING,
                   invocation={'procedure': PENDING, 'reconciliation': PENDING,
                               'deadline_seconds': PENDING, 'call_budget': PENDING},
                   normalization=PENDING, evidence_refs=[],
                   applicability={'rule': None, 'evidence_refs': []})
    return record('Profile', repository={'name': 'fixture', 'identity': HASH, 'instruction_files': [],
                                        'harness_root': '.harness'},
                  configuration_revision=1, configuration_id='cfg-1', capabilities={'build': binding},
                  workflow_profiles=[{'id': 'default', 'workflow_id': 'development',
                                      'required_capabilities': ['build'], 'required_targets': PENDING,
                                      'applicability': {'rule': None, 'evidence_refs': []},
                                      'readiness': 'NOT_ASSESSED', 'evidence_refs': []}],
                  permissions=PENDING, completion_policy=PENDING,
                  state_writer={'mode': 'LLM_PROTOCOL', 'identity': 'coordinator', 'binding': None,
                                'enforcement_evidence_refs': []},
                  watched_sources=[], assessments=[])

def fixtures():
    writer={'mode': 'LLM_PROTOCOL', 'identity': 'coordinator', 'binding': None,
            'enforcement_evidence_refs': []}
    accepted={'request': HASH, 'specification': None, 'design': None}
    target={'target_id': 'default', 'environment': 'local'}
    state=record('TaskState', task_id='task-1', state='NEW', version=1, writer=writer,
                 profile_id='default', configuration_id='cfg-1', input_snapshot=HASH,
                 accepted_identities=accepted, selected_targets=[target], criterion_verdict_refs=[],
                 repair_counters={'build': 0}, invocation_counters={'build': 0},
                 pending_invocation_refs=[], stop_reason=None, stopped_from_state=None,
                 resolution_refs=[], evidence_refs=[])
    event=record('Event', subject_kind='TASK', subject_id='task-1', request_id='request-1',
                 request_content_identity=HASH, previous_version=0, next_version=1,
                 previous_state=None, next_state='NEW', timestamp=STAMP, actor='coordinator',
                 decision_ref=EVIDENCE, evidence_refs=[], counter_deltas={'repair': {}, 'invocation': {}},
                 post_state=state)
    assessment=record('CriterionAssessment', catalogue_version='1.0.0', criterion_id='IS-01.1',
                      result='PENDING', method=None, actor=None, evidence_refs=[],
                      reason='not assessed', assessed_configuration_id='cfg-1')
    current=record('UpdateCurrent', update_id='update-1', state='REQUESTED', version=1,
                   writer=writer, inspected_configuration_id='cfg-1', before_values=[],
                   prospective_configuration_id='cfg-2', candidate=None, changed_values=[],
                   publication_manifest=[], checks=[], evidence_refs=[], permissions=PENDING,
                   scoped_approval=None, promotion={'intent': None, 'result': 'NOT_APPLICABLE',
                   'before_configuration_id': 'cfg-1', 'after_configuration_id': None,
                   'evidence_refs': []}, rollback={'status': 'NOT_APPLICABLE', 'paths': [],
                   'evidence_refs': [], 'reason': 'not promoted'}, stop_reason=None,
                   stopped_from_state=None, resolution_refs=[], corrective_attempt_refs=[])
    upd_event={**event, 'subject_kind': 'UPDATE', 'subject_id': 'update-1', 'next_state': 'REQUESTED',
               'post_state': current}
    shape={
      'TaskSpec': record('TaskSpec',task_id='task-1',request_identity=HASH,specification_identity=HASH,
          design_identity=HASH,acceptance_authority={'actor':'user','evidence_refs':[EVIDENCE]},
          scope=['component'],non_goals=[],criteria=[{'id':'AC-01','due_state':'SPEC_VERIFIED',
          'allowed_methods':['LLM_REVIEW'],'required':True}],targets=[target],profile_id='default'),
      'TaskState': state,
      'ConfigSnapshot': record('ConfigSnapshot',configuration_id='cfg-1',configuration_revision=1,
          captured_definitions=[{'kind':'PROFILE','reference':REF,'identity':HASH,
          'captured_path':'configuration/repo-profile.yaml'}],external_services=[],limitations=['none']),
      'TransitionRequest':record('TransitionRequest',subject_id='task-1',subject_kind='TASK',
          request_id='request-1',expected_state='NEW',expected_version=1,transition_id='DEV-001',
          configuration_id='cfg-1',accepted_identities=accepted,evidence_refs=[],review_refs=[],
          request_content_identity=HASH),
      'GateDecision':record('GateDecision',request_id='request-1',decision='BLOCKED',
          rule_findings=[{'rule_id':'RULE-02','result':'UNKNOWN','reason':'missing evidence',
          'evidence_refs':[]}],proposed_destination=None,resolution_route='BLOCKED'),
      'Event':event,
      'EventLog':record('EventLog',subject_id='task-1',subject_kind='TASK',events=[event]),
      'Invocation':record('Invocation',intent_id='intent-1',request_id='request-1',run_id='run-1',
          task_id='task-1',capability='build',expected_identities={'configuration_id':'cfg-1',
          'adapter_definition_id':HASH,'adapter':ADAPTER,'revision':HASH},
          inputs={'source':HASH,'targets':[target],'environment':'local','artifact':None,'test_source':None},
          dispatch_status='INTENT_RECORDED',external_handle=None,deadline='2026-10-04T13:00:00Z',
          counters={'calls':0,'elapsed_seconds':0,'call_budget':1,'time_budget_seconds':60},
          reconciliation_evidence_refs=[],cancellation_evidence_refs=[]),
      'CriterionReview':record('CriterionReview',task_id='task-1',revision=HASH,due_state='NEW',
          method='LLM_REVIEW',actor='coordinator',provenance='REVIEW',criteria=[{'criterion_id':'AC-01',
          'result':'PENDING','reason':'pending','evidence_refs':[],'unresolved_findings':['missing input']}]),
      'Observation':record('Observation',task_id='task-1',run_id='run-1',raw_reference=REF,
          diagnostics=['malformed result: missing status'],interpreted_outcome='UNKNOWN',
          observed_at=STAMP),
      'UpdateRecord':record('UpdateRecord',update_id='update-1',request_type='DRIFT_REVIEW',
          scope=['build'],request_identity=HASH,events=[upd_event],current=current),
      'InstallationRecord':record('InstallationRecord',installation_id='install-1',kit_version='1.0.0',
          mode='FRESH',target_identity=HASH,harness_root='.harness',generated_paths=[],owned_paths=[],
          discovered_facts=[],decisions=[],criterion_assessments=[assessment],
          checker_coverage={'status':'NOT_RUN','report_refs':[],'checked_ids':[],'uncovered_ids':['IS-01.1']},
          entry_point={'candidate':None,'activation_state':'STAGED','evidence_refs':[]},
          started_at=STAMP,updated_at=STAMP,completed_at=None),
      'CheckerReport':record('CheckerReport',checker='reference-checker',checker_version='1.0.0',
          assessed_configuration_id='cfg-1',platform={'os':'macOS','architecture':'arm64',
          'runtime':'Python 3.14','dependencies':{'jsonschema':'4.25.1'}},checked_assessments=[],
          uncovered_ids=['IS-01.1'],diagnostics=[],limitations=['shape checks only'],exit_code=0,
          structure_assessment='INCOMPLETE',integration_assessment='NOT_ASSESSED'),
      'ScenarioResult':record('ScenarioResult',case_id='CASE-01',scenario_id='S-14',
          mode='AUTOMATED',actor='unittest',actual_result='PENDING',observations=[],evidence_refs=[],
          limitations=['not executed'])}
    return deepcopy(shape)


def configured_profile_fixture():
    sample = profile_fixture()
    binding = sample['capabilities']['build']
    binding.update(
        configuration_status='CONFIGURED',
        adapter=result_fixture()['adapter'],
        input_schema=EVIDENCE['reference'],
        permissions={
            'filesystem_scopes': [],
            'external_actions': [],
            'secrets_policy': 'No credentials required.',
            'approval_policy': {
                'mode': 'RECORDED_POLICY', 'procedure': EVIDENCE['reference'],
            },
        },
        execution_environment={
            'id': 'local', 'description': 'fixture environment',
            'native_platforms': ['macOS'], 'evidence_refs': [EVIDENCE],
        },
        invocation={
            'procedure': EVIDENCE['reference'],
            'reconciliation': EVIDENCE['reference'],
            'deadline_seconds': 60, 'call_budget': 1,
        },
        normalization={
            'procedure': EVIDENCE['reference'], 'interface_version': '1.0.0',
            'artifact_consumed_downstream': True, 'test_source_required': False,
            'artifact_lineage_required': False, 'extensions_schema': None,
        },
    )
    return sample


def criteria_catalogue_fixture():
    return record('CriteriaCatalogue', catalogue_version='1.0.0', criteria=[{
        'id': 'IS-01.1', 'category': 'STRUCTURE', 'required': True,
        'description': 'typed fields', 'allowed_methods': ['AUTOMATED'],
        'applicability_rule': None, 'scenario_ids': ['S-45'],
    }])


def workflow_fixture():
    return record(
        'Workflow', workflow_id='development',
        states=[
            {'id': 'NEW', 'unresolved_route': 'BLOCKED',
             'stop_route': 'BLOCKED', 'resume_route': 'NEW'},
            {'id': 'COMPLETE', 'unresolved_route': None,
             'stop_route': None, 'resume_route': None},
        ],
        initial_state='NEW', terminal_states=['COMPLETE'], stop_states=['BLOCKED'],
        transitions=[{
            'id': 'DEV-001', 'from': 'NEW', 'to': 'COMPLETE',
            'profiles': ['default'], 'trigger': 'PASS', 'rule_ids': ['RULE-02'],
        }],
        resolution_routes=[],
    )


def conformance_catalogue_fixture():
    return record('ConformanceCatalogue', cases_version='1.0.0', cases=[{
        'case_id': 'CASE-01', 'scenario_id': 'S-14', 'requirement_ids': ['R-08'],
        'initial_state': 'BUILDING',
        'configuration': {'profile_id': 'default', 'configuration_id': 'cfg-1',
                          'fixture_reference': EVIDENCE['reference']},
        'input_evidence': [EVIDENCE],
        'action': {'kind': 'TRANSITION', 'description': 'malformed result',
                   'reference': None},
        'expected_decision': 'BLOCKED', 'expected_state': 'BLOCKED',
        'expected_records': [{'record_type': 'Observation',
                              'assertions': ['interpreted_outcome UNKNOWN']}],
        'forbidden_effects': ['invent result'],
        'coverage_parts': [{
            'id': 'shape', 'mode': 'AUTOMATED', 'check': 'reject malformed result',
            'expected_evidence': ['validation diagnostic'],
        }],
    }])
