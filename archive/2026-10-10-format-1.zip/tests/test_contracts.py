import copy
import json
import unittest
from urllib.parse import urlparse
from jsonschema.exceptions import ValidationError
from support import (SCHEMAS, schema_path, EVIDENCE, HASH, PENDING, fixtures, profile_fixture,
    result_fixture, validator, configured_profile_fixture, criteria_catalogue_fixture,
    workflow_fixture, conformance_catalogue_fixture)

class ContractTests(unittest.TestCase):

    def schema(self, name, definition=None):
        self.assertTrue(schema_path(name).is_file(), f'missing schema: {name}')
        return validator(name, definition)

    def test_pending_is_typed(self):
        check = self.schema('profile.schema.json')
        sample = profile_fixture()
        check.validate(sample)
        deadline = sample['capabilities']['build']['invocation']
        deadline['deadline_seconds'] = 'PENDING'
        with self.assertRaises(ValidationError):
            check.validate(sample)
        deadline['deadline_seconds'] = PENDING
        sample['capabilities']['build']['configuration_status'] = 'CONFIGURED'
        with self.assertRaises(ValidationError):
            check.validate(sample)

    def test_core_result_statuses(self):
        check = self.schema('result.schema.json')
        sample = result_fixture()
        for status in ['PASS', 'FAIL', 'BLOCKED', 'UNKNOWN']:
            with self.subTest(status=status):
                sample['status'] = status
                check.validate(sample)
        sample['status'] = 'SUCCESS'
        with self.assertRaises(ValidationError):
            check.validate(sample)
        sample = result_fixture()
        for field in ['interface_version', 'capability', 'adapter', 'run_id', 'task_id', 'revision', 'status', 'evidence', 'provenance', 'configuration_id', 'adapter_definition_id', 'targets']:
            broken = copy.deepcopy(sample)
            del broken[field]
            with self.subTest(missing=field), self.assertRaises(ValidationError):
                check.validate(broken)
        sample['extensions'] = {'artifact_consumed_downstream': True}
        with self.assertRaises(ValidationError):
            check.validate(sample)
        sample['artifact'] = {'identity': HASH, 'reference': EVIDENCE['reference']}
        check.validate(sample)
        sample['extensions']['test_source_required'] = True
        with self.assertRaises(ValidationError):
            check.validate(sample)
        sample['test_source'] = {'identity': HASH, 'reference': EVIDENCE['reference']}
        check.validate(sample)
        sample['extensions']['artifact_lineage_required'] = True
        with self.assertRaises(ValidationError):
            check.validate(sample)
        sample['test_source']['artifact_identity'] = HASH
        check.validate(sample)

    def test_record_shapes(self):
        for kind, sample in fixtures().items():
            check = self.schema('records.schema.json', kind)
            with self.subTest(record=kind):
                check.validate(sample)
            for field in sample:
                with self.subTest(record=kind, missing=field):
                    broken = copy.deepcopy(sample)
                    del broken[field]
                    with self.assertRaises(ValidationError):
                        check.validate(broken)
            broken = copy.deepcopy(sample)
            broken['invented_outcome'] = 'PASS'
            with self.assertRaises(ValidationError):
                check.validate(broken)
        observation = fixtures()['Observation']
        self.schema('records.schema.json', 'Observation').validate(observation)
        with self.assertRaises(ValidationError):
            self.schema('result.schema.json').validate(observation)
        observation['interpreted_outcome'] = 'PASS'
        with self.assertRaises(ValidationError):
            self.schema('records.schema.json', 'Observation').validate(observation)

    def test_schema_refs_are_local(self):
        expected = {'common', 'profile', 'workflow', 'result', 'criteria', 'records', 'task-report'}
        self.assertEqual({p.name.removesuffix('.schema.json') for p in SCHEMAS.glob('*.schema.json')}, expected)

        def visit(node, path):
            if isinstance(node, dict):
                if '$ref' in node:
                    ref = node['$ref']
                    self.assertFalse(urlparse(ref).scheme)
                    self.assertFalse(ref.startswith('/'))
                    file, _, fragment = ref.partition('#')
                    dest = (path.parent / file).resolve() if file else path
                    self.assertEqual(dest.parent, SCHEMAS.resolve())
                    doc = json.loads(dest.read_text())
                    if fragment:
                        self.assertTrue(fragment.startswith('/'))
                        for part in fragment[1:].split('/'):
                            doc = doc[part.replace('~1', '/').replace('~0', '~')]
                for value in node.values():
                    visit(value, path)
            elif isinstance(node, list):
                for value in node:
                    visit(value, path)
        from jsonschema import Draft202012Validator
        for path in SCHEMAS.glob('*.schema.json'):
            schema = json.loads(path.read_text())
            Draft202012Validator.check_schema(schema)
            visit(schema, path)

class ContractBoundaryTests(unittest.TestCase):

    def test_pending_decisions_and_target_selection_are_typed(self):
        install = fixtures()['InstallationRecord']
        install['decisions'] = [{'id': 'command-discovery', 'value': PENDING, 'reason': 'repository command unresolved', 'evidence_refs': []}]
        self.assertTrue(validator('records.schema.json', 'InstallationRecord').is_valid(install))
        install['decisions'][0]['value'] = 'PENDING'
        with self.assertRaises(ValidationError):
            validator('records.schema.json', 'InstallationRecord').validate(install)
        state = fixtures()['TaskState']
        state['selected_targets'] = PENDING
        validator('records.schema.json', 'TaskState').validate(state)
        state['selected_targets'] = 'PENDING'
        with self.assertRaises(ValidationError):
            validator('records.schema.json', 'TaskState').validate(state)

    def test_assessment_satisfaction_and_provenance(self):
        assessment = fixtures()['InstallationRecord']['criterion_assessments'][0]
        check = validator('criteria.schema.json', 'Assessment')
        for result in ['PASS', 'NOT_APPLICABLE']:
            sample = copy.deepcopy(assessment)
            sample['result'] = result
            with self.assertRaises(ValidationError):
                check.validate(sample)
            sample.update(method='LLM_REVIEW', actor='reviewer', evidence_refs=[copy.deepcopy(EVIDENCE)])
            check.validate(sample)
            sample['evidence_refs'][0]['provenance'] = 'ASSUMED'
            with self.assertRaises(ValidationError):
                check.validate(sample)
        sample = copy.deepcopy(assessment)
        sample['result'] = 'FAIL'
        with self.assertRaises(ValidationError):
            check.validate(sample)

    def test_replay_event_shape_and_subject_type(self):
        check = validator('records.schema.json', 'Event')
        sample = fixtures()['Event']
        sample['next_version'] = 2
        with self.assertRaises(ValidationError):
            check.validate(sample)
        sample = fixtures()['Event']
        sample['previous_version'] = 1
        with self.assertRaises(ValidationError):
            check.validate(sample)
        log = fixtures()['EventLog']
        log['subject_kind'] = 'UPDATE'
        with self.assertRaises(ValidationError):
            validator('records.schema.json', 'EventLog').validate(log)
        log = fixtures()['EventLog']
        log['events'][0]['post_state']['version'] = '1'
        with self.assertRaises(ValidationError):
            validator('records.schema.json', 'EventLog').validate(log)

    def test_local_paths_and_timestamp_shape(self):
        check = validator('common.schema.json', 'Reference')
        for bad in ['../secret', 'foo/../../secret', '/absolute', 'C:/secret', 'folder\\secret']:
            reference = {**EVIDENCE['reference'], 'path': bad}
            with self.subTest(path=bad), self.assertRaises(ValidationError):
                check.validate(reference)
        check.validate({'kind': 'EXTERNAL', 'uri': 'https://example.invalid/report', 'accessibility': 'UNAVAILABLE'})
        for stamp in ['2026-10-04', '2026-10-04T12:00:00+01:00', '2026-99-99T12:00:00Z']:
            event = fixtures()['Event']
            event['timestamp'] = stamp
            with self.subTest(timestamp=stamp), self.assertRaises(ValidationError):
                validator('records.schema.json', 'Event').validate(event)

    def test_catalogues_and_finite_workflow_triggers(self):
        catalogue = criteria_catalogue_fixture()
        check = validator('criteria.schema.json', 'Catalogue')
        check.validate(catalogue)
        catalogue['criteria'][0]['required'] = 'true'
        with self.assertRaises(ValidationError):
            check.validate(catalogue)

        workflow = workflow_fixture()
        check = validator('workflow.schema.json')
        check.validate(workflow)
        workflow['transitions'][0]['trigger'] = 'eval(status)'
        with self.assertRaises(ValidationError):
            check.validate(workflow)
        workflow['transitions'][0]['trigger'] = 'PASS'
        workflow['capabilities'] = {}
        with self.assertRaises(ValidationError):
            check.validate(workflow)

        cases = conformance_catalogue_fixture()
        check = validator('conformance.schema.json')
        check.validate(cases)
        cases['cases'][0]['actual_result'] = 'PASS'
        with self.assertRaises(ValidationError):
            check.validate(cases)

    def test_resolved_binding_and_scoped_applicability(self):
        sample = configured_profile_fixture()
        binding = sample['capabilities']['build']
        check = validator('profile.schema.json')
        check.validate(sample)
        binding['invocation']['deadline_seconds'] = 0
        with self.assertRaises(ValidationError):
            check.validate(sample)
        binding['invocation']['deadline_seconds'] = 60
        binding['configuration_status'] = 'NOT_APPLICABLE'
        with self.assertRaises(ValidationError):
            check.validate(sample)
        binding['applicability'] = {
            'rule': 'documentation profile excludes compiled build',
            'evidence_refs': [EVIDENCE],
        }
        check.validate(sample)

    def test_extensions_cannot_replace_core_fields(self):
        sample = result_fixture()
        sample['extensions'] = {'status': 'SUCCESS'}
        with self.assertRaises(ValidationError):
            validator('result.schema.json').validate(sample)
        sample = result_fixture()
        sample['extensions'] = {'artifact_consumed_downstream': False}
        sample['status'] = 'FAIL'
        validator('result.schema.json').validate(sample)

class ContractReviewRegressionTests(unittest.TestCase):

    def test_external_service_requires_version_or_meaningful_limitation(self):
        check = validator('records.schema.json', 'ConfigSnapshot')
        sample = fixtures()['ConfigSnapshot']
        sample['external_services'] = [{'id': 'service-1', 'version': '2026.10', 'limitations': [], 'evidence_refs': []}]
        check.validate(sample)
        service = sample['external_services'][0]
        service['version'] = None
        for limitations in [[], [''], ['   ']]:
            with self.subTest(limitations=limitations):
                service['limitations'] = limitations
                with self.assertRaises(ValidationError):
                    check.validate(sample)
        service['limitations'] = ['Provider exposes no version identifier.']
        check.validate(sample)

    def test_published_definitions_control_their_consumers(self):
        configured = configured_profile_fixture()
        consumers = [('criteria.schema.json', 'Definition', 'description', criteria_catalogue_fixture(), 'amended description'), ('conformance.schema.json', 'Case', 'case_id', conformance_catalogue_fixture(), 'CASE-99'), ('workflow.schema.json', 'Transition', 'id', workflow_fixture(), 'DEV-999'), ('profile.schema.json', 'InvocationPolicy', 'deadline_seconds', configured, 59), ('profile.schema.json', 'Normalization', 'interface_version', configured, '2.0.0')]
        for filename, definition, field, sample, changed in consumers:
            with self.subTest(definition=definition):
                validator(filename).validate(sample)
                amended = json.loads(schema_path(filename).read_text())
                amended['$defs'][definition]['properties'][field] = {'const': changed}
                check = validator(filename, overrides={filename: amended})
                with self.assertRaises(ValidationError):
                    check.validate(sample)

    def test_transition_ids_start_at_one(self):
        check = validator('workflow.schema.json')
        workflow = workflow_fixture()
        request_check = validator('records.schema.json', 'TransitionRequest')
        request = fixtures()['TransitionRequest']
        for prefix in ['DEV', 'MNT']:
            with self.subTest(prefix=prefix):
                workflow['transitions'][0]['id'] = f'{prefix}-001'
                check.validate(workflow)
                request['transition_id'] = f'{prefix}-001'
                request_check.validate(request)
                workflow['transitions'][0]['id'] = f'{prefix}-000'
                with self.assertRaises(ValidationError):
                    check.validate(workflow)
                request['transition_id'] = f'{prefix}-000'
                with self.assertRaises(ValidationError):
                    request_check.validate(request)
if __name__ == '__main__':
    unittest.main()
