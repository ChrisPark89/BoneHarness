"""Authoring checks of installed routing and retained procedural walkthrough records.

These inspect concrete recorded decisions; they do not implement a runtime writer.
"""
import copy
import hashlib
import json
import re
from pathlib import Path
import unittest
import yaml
from support import validator, FIXTURES
from test_development_definitions import graph_findings

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'builder-kit/templates/runtime'
SELECTORS = {'ADAPTER_CHANGE': 'adapter-change', 'FACT_CORRECTION': 'fact-correction',
             'DRIFT_REVIEW': 'drift-review', 'MIGRATION': 'migration'}


def identity(value):
    return 'sha256:' + hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def walkthroughs():
    encoded = json.loads((FIXTURES / 'maintenance-walkthroughs.json').read_text())
    def expand(value):
        if isinstance(value, dict):
            if set(value) == {'fixture_ref'}:
                return expand(copy.deepcopy(encoded['shared_fixtures'][value['fixture_ref']]))
            return {k: expand(v) for k, v in value.items()}
        if isinstance(value, list):
            return [expand(v) for v in value]
        return value
    return expand(encoded)


class MaintenanceDefinitionTests(unittest.TestCase):
    def workflow(self):
        w = yaml.safe_load((RUNTIME / 'framework/workflows/maintenance/maintenance-workflow.yaml').read_text())
        self.assertEqual(w.get('record_type'), 'Workflow')
        return w

    def edge(self, source, trigger, selector):
        matches = [e for e in self.workflow()['transitions']
                   if e['from'] == source and e['trigger'] == trigger and selector in e['profiles']]
        self.assertEqual(len(matches), 1, (source, trigger, selector))
        return matches[0]

    def test_distinct_request_routes_are_finite_and_schema_valid(self):
        w = self.workflow()
        validator('workflow.schema.json').validate(w)
        self.assertEqual(graph_findings(w), [])
        self.assertEqual(w['extensions']['request_type_profiles'], SELECTORS)
        self.assertEqual(len(set(SELECTORS.values())), len(SELECTORS))
        self.assertTrue(all(set(e['profiles']) <= set(SELECTORS.values()) for e in w['transitions']))
        p = yaml.safe_load((RUNTIME / 'framework/config/repo-profile.yaml').read_text())
        self.assertTrue(set(SELECTORS.values()).isdisjoint(x['id'] for x in p['workflow_profiles']))
        for kind, target in [('adapter-change', 'ADAPTER_COMPATIBLE'), ('fact-correction', 'SOURCE_VERIFIED'),
                             ('drift-review', 'DRIFT_ASSESSED'), ('migration', 'MIGRATION_CHECKED')]:
            self.assertEqual(self.edge('STAGED', 'PASS', kind)['to'], target)

    def test_no_drift_binding_promotion_and_two_promotion_routes(self):
        w = self.workflow()
        drift = [e for e in w['transitions'] if 'drift-review' in e['profiles']]
        self.assertFalse(any(e['to'] in ['PROMOTED', 'ADAPTER_COMPATIBLE', 'SOURCE_VERIFIED', 'MIGRATION_CHECKED'] for e in drift))
        self.assertEqual(self.edge('ADAPTER_COMPATIBLE', 'READY', 'adapter-change')['to'], 'PROMOTED')
        self.assertEqual(self.edge('SOURCE_VERIFIED', 'READY', 'fact-correction')['to'], 'PROMOTED')
        self.assertEqual(self.edge('MIGRATION_CHECKED', 'APPROVED', 'migration')['to'], 'PROMOTED')
        self.assertEqual(self.edge('DRIFT_ASSESSED', 'UNCHANGED', 'drift-review')['to'], 'STATUS_UPDATED')
        self.assertEqual(self.edge('DRIFT_ASSESSED', 'CHANGED', 'drift-review')['to'], 'ASSESSMENT_PUBLISHED')

    def test_stop_resolution_cannot_retry_rejected_or_failed_attempt(self):
        w = self.workflow()
        self.assertEqual(set(w['stop_states']), {'REJECTED', 'PENDING', 'HUMAN_REQUIRED', 'FAILED'})
        for selector in SELECTORS.values():
            self.assertEqual(self.edge('PENDING', 'RESOLVED', selector)['to'], 'INSPECTED')
            self.assertEqual(self.edge('HUMAN_REQUIRED', 'APPROVED', selector)['to'], 'INSPECTED')
            for state in ['REJECTED', 'FAILED']:
                self.assertFalse(any(e['from'] == state for e in w['transitions']))
                routes = [r for r in w['resolution_routes'] if r['from'] == state]
                self.assertEqual([r['to'] for r in routes], ['REQUESTED'])
                self.assertTrue(routes[0]['evidence_required'])
        for selector in ['adapter-change', 'migration']:
            self.assertEqual(self.edge('STAGED', 'REJECTED', selector)['to'], 'REJECTED')
            self.assertEqual(self.edge('STAGED', 'PENDING', selector)['to'], 'PENDING')
            self.assertEqual(self.edge('STAGED', 'BLOCKED', selector)['to'], 'HUMAN_REQUIRED')

    def test_update_template_is_typed_and_replayable(self):
        u = yaml.safe_load((RUNTIME / 'framework/templates/maintenance/harness-update-record.yaml').read_text())
        self.assertEqual(u.get('record_type'), 'UpdateRecord')
        validator('records.schema.json', 'UpdateRecord').validate(u)
        self.assertEqual(u['current'], u['events'][-1]['post_state'])
        self.assertEqual(u['events'][0]['previous_version'], 0)
        self.assertEqual(u['events'][0]['next_version'], 1)

    def data(self):
        path = FIXTURES / 'maintenance-walkthroughs.json'
        self.assertTrue(path.exists(), 'Concrete maintenance walkthrough records are not installed')
        return walkthroughs()

    def test_walkthrough_records_replay_complete_snapshots_and_use_declared_edges(self):
        d = self.data()
        validator('criteria.schema.json', 'Catalogue').validate(d['synthetic_criteria_catalogue'])
        self.assertEqual({c['scenario_id'] for c in d['cases']}, {f'S-{i}' for i in range(30, 40)})
        for c in d['cases']:
            with self.subTest(case=c['id']):
                validator('records.schema.json', 'ScenarioResult').validate(c['result'])
                self.assertEqual(c['result']['actual_result'], 'PASS')
                for u in c['updates']:
                    validator('records.schema.json', 'UpdateRecord').validate(u)
                    self.assertEqual(u['current'], u['events'][-1]['post_state'])
                    prior = None
                    for i, e in enumerate(u['events'], 1):
                        self.assertEqual((e['previous_version'], e['next_version']), (i-1, i))
                        self.assertEqual(e['subject_id'], u['update_id'])
                        self.assertEqual(e['post_state']['update_id'], u['update_id'])
                        self.assertEqual(e['post_state']['version'], i)
                        self.assertEqual(e['previous_state'], prior)
                        self.assertEqual(e['next_state'], e['post_state']['state'])
                        if prior:
                            trigger = e['post_state']['extensions']['accepted_trigger']
                            edge = self.edge(prior, trigger, SELECTORS[u['request_type']])
                            self.assertEqual(edge['to'], e['next_state'])
                        prior = e['next_state']
                for profile in c.get('profiles', []):
                    validator('profile.schema.json').validate(profile)

    def test_publication_identity_approval_and_immediate_readiness(self):
        for c in self.data()['cases']:
            for publication in c.get('publications', []):
                with self.subTest(case=c['id']):
                    before, after = publication['before'], publication['after']
                    u = next(u for u in c['updates'] if u['update_id'] == publication['update_id'])['current']
                    self.assertEqual(after['configuration_revision'], before['configuration_revision'] + 1)
                    self.assertNotEqual(after['configuration_id'], before['configuration_id'])
                    self.assertEqual(u['inspected_configuration_id'], before['configuration_id'])
                    self.assertEqual(u['prospective_configuration_id'], after['configuration_id'])
                    for check in after['assessments']:
                        self.assertEqual(check['assessed_configuration_id'], after['configuration_id'])
                        self.assertTrue(check['evidence_refs'])
                    self.assertEqual(publication['readiness_assessed_configuration_id'], after['configuration_id'])
                    self.assertEqual(publication['retained_assessments'], 'REVALIDATED_UNCHANGED_DEPENDENCIES')
                    for entry in u['publication_manifest']:
                        allowed = publication['after']['permissions']['filesystem_scopes']
                        self.assertIn({'scope': entry['scope'], 'path': entry['path'], 'access': 'WRITE'}, allowed)
                        self.assertEqual(entry['before_identity'], identity(publication['files_before'][entry['path']]))
                        self.assertEqual(entry['after_identity'], identity(publication['files_after'][entry['path']]))
                        self.assertIn(entry['ownership'], ['GENERATED', 'SHARED'])
                    self.assertEqual(publication['files_before']['shared/repo-profile.yaml'], before)
                    self.assertEqual(publication['files_after']['shared/repo-profile.yaml'], after)
                    if u['scoped_approval']:
                        a = u['scoped_approval']
                        self.assertEqual(a['candidate_identity'], u['candidate']['content_identity'])
                        self.assertEqual(a['base_configuration_id'], before['configuration_id'])
                        self.assertEqual(set(a['scope']), {x['path'] for x in u['publication_manifest']})
                        self.assertGreater(len(u['publication_manifest']), 1)
                    if u['promotion']['result'] == 'PROMOTED':
                        intent = u['promotion']['intent']
                        self.assertEqual(intent['manifest_identity'], identity(u['publication_manifest']))
                        self.assertEqual(intent['prospective_configuration_id'], after['configuration_id'])
                        self.assertEqual(u['promotion']['after_configuration_id'], after['configuration_id'])

    def test_publication_intent_is_committed_before_written_receipts(self):
        for c in self.data()['cases']:
            for u in c['updates']:
                for i, e in enumerate(u['events']):
                    cur = e['post_state']
                    if 'write_receipts' not in cur.get('extensions', {}):
                        continue
                    earlier = [x['post_state'] for x in u['events'][:i]]
                    self.assertTrue(any(x['promotion']['intent'] is not None or
                                        'assessment_intent' in x.get('extensions', {}) for x in earlier), u['update_id'])
                    receipts = cur['extensions']['write_receipts']
                    self.assertEqual(receipts['identity'], identity(receipts['records']))
                    for receipt in receipts['records']:
                        self.assertEqual(receipt['attempt_id'], u['update_id'])
                        self.assertEqual(receipt['writer'], cur['writer']['identity'])
                        entry = next(m for m in cur['publication_manifest'] if m['path'] == receipt['path'])
                        self.assertEqual(receipt['after_identity'], entry['after_identity'])

    def test_committed_events_have_matching_requests_and_gate_decisions(self):
        for c in self.data()['cases']:
            for u in c['updates']:
                self.assertTrue('extensions' in u, u['update_id'])
                requests = {r['request_id']: r for r in u['extensions']['requests']}
                decisions = {g['request_id']: g for g in u['extensions']['decisions']}
                for e in u['events'][1:]:
                    request, decision = requests[e['request_id']], decisions[e['request_id']]
                    validator('records.schema.json', 'TransitionRequest').validate(request)
                    validator('records.schema.json', 'GateDecision').validate(decision)
                    self.assertEqual(request['request_content_identity'], e['request_content_identity'])
                    self.assertEqual(request['expected_version'], e['previous_version'])
                    self.assertEqual(request['expected_state'], e['previous_state'])
                    self.assertEqual(decision['decision'], 'ALLOW')
                    self.assertEqual(decision['proposed_destination'], e['next_state'])
                    self.assertEqual(e['decision_ref']['identity'], identity(decision))
                    edge = next(x for x in self.workflow()['transitions'] if x['id'] == request['transition_id'])
                    findings = {f['rule_id']: f for f in decision['rule_findings']}
                    self.assertTrue(set(edge['rule_ids']) <= findings.keys())

    def test_compatibility_fixtures_and_stops_preserve_active_values(self):
        d = self.data()
        c = next(c for c in d['cases'] if c['id'] == 'ordinary')
        self.assertEqual({r['status'] for r in c['adapter_results']}, {'PASS', 'FAIL', 'BLOCKED', 'UNKNOWN'})
        for r in c['adapter_results']:
            validator('result.schema.json').validate(r)
            self.assertEqual(r['provenance'], 'FIXTURE')
        for id_, state in [('unsupported', 'REJECTED'), ('unsupported-interface', 'REJECTED'), ('missing-evidence', 'PENDING'),
                           ('policy', 'HUMAN_REQUIRED'), ('fact-guess', 'PENDING'),
                           ('stale-base', 'PENDING'), ('changed-candidate', 'HUMAN_REQUIRED')]:
            c = next(c for c in d['cases'] if c['id'] == id_)
            self.assertEqual(c['updates'][0]['current']['state'], state)
            self.assertEqual(c['active_before'], c['active_after'])
            self.assertEqual(c['publications'], [])

    def test_drift_isolated_impact_conflict_and_linked_update(self):
        d = self.data()
        for id_ in ['drift-changed', 'drift-missing', 'drift-inaccessible']:
            c = next(c for c in d['cases'] if c['id'] == id_)
            p = c['publications'][0]
            for capability in p['before']['capabilities']:
                self.assertEqual(p['before']['capabilities'][capability]['adapter'], p['after']['capabilities'][capability]['adapter'])
            self.assertEqual(p['after']['capabilities']['optional']['compatibility'], 'NEEDS_REVIEW')
            self.assertEqual(p['after']['workflow_profiles'][0]['readiness'], 'READY')
            u = c['updates'][0]['current']
            self.assertEqual(u['promotion']['result'], 'NOT_APPLICABLE')
            self.assertEqual(u['rollback']['status'], 'NOT_APPLICABLE')
        stale = next(c for c in d['cases'] if c['id'] == 'drift-stale')
        self.assertEqual(stale['active_before'], stale['active_after'])
        self.assertNotEqual(stale['updates'][0]['current']['inspected_configuration_id'], stale['active_after']['configuration_id'])
        linked = next(c for c in d['cases'] if c['id'] == 'drift-correction')
        self.assertEqual(linked['updates'][0]['current']['corrective_attempt_refs'][0]['path'],
                         'maintenance/updates/' + linked['updates'][1]['update_id'] + '.yaml')
        self.assertEqual(linked['updates'][1]['request_type'], 'ADAPTER_CHANGE')

    def test_recovery_preserves_newer_values_and_status_refresh_does_not_repromote(self):
        d = self.data()
        safe = next(c for c in d['cases'] if c['id'] == 'partial-restored')
        self.assertEqual(safe['files_after_recovery'], safe['files_before'])
        self.assertEqual(safe['updates'][0]['current']['rollback']['status'], 'RESTORED')
        for path in safe['restored_paths']:
            self.assertEqual(safe['files_at_failure'][path], safe['attempt_written'][path])
        unsafe = next(c for c in d['cases'] if c['id'] == 'partial-newer')
        self.assertEqual(unsafe['files_after_recovery'], unsafe['files_at_failure'])
        self.assertEqual(unsafe['updates'][0]['current']['rollback']['status'], 'FAILED')
        self.assertEqual(unsafe['integration'], 'BLOCKED')
        refresh = next(c for c in d['cases'] if c['id'] == 'status-refresh')
        self.assertEqual(refresh['canonical_before_refresh'], refresh['canonical_after_refresh'])
        self.assertEqual(refresh['status_after_configuration_id'], 'cfg-2')
        self.assertEqual(sum(e['next_state'] == 'PROMOTED' for e in refresh['updates'][0]['events']), 1)

    def test_migration_validates_real_staged_definitions_and_bound_evidence(self):
        c = next(c for c in self.data()['cases'] if c['id'] == 'migration')
        publication = c['publications'][0]
        files = publication['files_after']
        staged_workflow = files['development/workflow.yaml']
        self.assertTrue(validator('workflow.schema.json').is_valid(staged_workflow),
                        'Published migration workflow must be a complete valid definition')
        self.assertEqual(graph_findings(staged_workflow), [])
        rules = files['shared/verification-rules.md']
        self.assertIsInstance(rules, str)
        defined = set(re.findall(r'^### (RULE-\d+)$', rules, re.MULTILINE))
        self.assertTrue({r for e in staged_workflow['transitions'] for r in e['rule_ids']} <= defined)
        old_edge = next(e for e in publication['files_before']['development/workflow.yaml']['transitions'] if e['id'] == 'DEV-001')
        new_edge = next(e for e in staged_workflow['transitions'] if e['id'] == 'DEV-001')
        self.assertNotIn('RULE-08', old_edge['rule_ids'])
        self.assertIn('RULE-08', new_edge['rule_ids'])
        schema = files['shared/schemas/result.schema.json']
        from jsonschema import Draft202012Validator
        Draft202012Validator.check_schema(schema)
        evidence = c['affected_validation']
        overrides = {**evidence['schema_dependencies'], 'result.schema.json': schema}
        result_validator = validator('result.schema.json', overrides=overrides)
        good, bad = evidence['valid_result'], evidence['invalid_result']
        result_validator.validate(good)
        self.assertFalse(result_validator.is_valid(bad), 'Migrated extension type must reject integer audit values')
        self.assertEqual(good['extensions']['migration_audit'], 'owner-review-32')
        self.assertEqual(bad['extensions']['migration_audit'], 32)
        self.assertEqual(good['configuration_id'], publication['after']['configuration_id'])
        current = c['updates'][0]['current']
        self.assertEqual(current['candidate']['content_identity'], identity(files))
        self.assertEqual(evidence['candidate_identity'], identity(files))
        self.assertEqual(evidence['manifest_identity'], identity(current['publication_manifest']))
        self.assertEqual(evidence['definition_identities'], {p: identity(v) for p, v in files.items()})
        for report in evidence['checks']:
            self.assertEqual(report['candidate_identity'], evidence['candidate_identity'])
            self.assertEqual(report['manifest_identity'], evidence['manifest_identity'])
        checked = next(e['post_state'] for e in c['updates'][0]['events'] if e['next_state'] == 'MIGRATION_CHECKED')
        self.assertEqual(checked['extensions']['affected_validation_identity'], identity(evidence))
        for assessment in checked['checks']:
            if assessment['criterion_id'].startswith('M-') and assessment['criterion_id'] != 'M-DEPENDENCIES':
                self.assertTrue(any(e['identity'] == identity(evidence) for e in assessment['evidence_refs']))

    def test_revocation_input_refusal_stop_and_adoption_are_relational(self):
        c = next(c for c in self.data()['cases'] if c['id'] == 'pinned-tasks')
        self.assertTrue('current_authorization' in c, 'Revocation needs an observed authority change')
        observed, prior = c['current_authorization'], c['prior_authorization']
        self.assertEqual((prior['decision'], observed['decision']), ('GRANTED', 'REVOKED'))
        self.assertEqual(prior['authorization_id'], observed['authorization_id'])
        proposed = c['proposed_invocation']
        validator('records.schema.json', 'Invocation').validate(proposed)
        self.assertEqual(observed['adapter_definition_id'], proposed['expected_identities']['adapter_definition_id'])
        self.assertEqual(observed['capability'], proposed['capability'])
        self.assertEqual(proposed['expected_identities']['configuration_id'], 'cfg-1')
        self.assertEqual(proposed['counters']['calls'], 0)
        self.assertFalse(c['proposed_invocation_committed'])
        self.assertEqual(c['refusal']['request']['request_id'], proposed['request_id'])
        ordinary = next(x for x in self.data()['cases'] if x['id'] == 'ordinary')
        self.assertEqual(c['publication_reference']['publication_identity'], identity(ordinary['publications'][0]))
        self.assertEqual(c['profiles'][1], ordinary['publications'][0]['after'])
        refusal, stop = c['refusal'], c['stop']
        self.assertEqual(refusal['state_after'], c['old_task'])
        self.assertEqual(refusal['decision']['decision'], 'DENY')
        finding = next(f for f in refusal['decision']['rule_findings'] if f['rule_id'] == 'RULE-08')
        self.assertEqual(finding['result'], 'FAIL')
        self.assertIn(identity(observed), [e['identity'] for e in finding['evidence_refs']])
        self.assertNotEqual(refusal['request']['request_id'], stop['request']['request_id'])
        self.assertEqual(stop['decision']['decision'], 'ALLOW')
        self.assertEqual(stop['event']['post_state'], c['revoked_task'])
        for trace in [refusal, stop, *c['adoption_trace']]:
            validator('records.schema.json', 'TransitionRequest').validate(trace['request'])
            validator('records.schema.json', 'GateDecision').validate(trace['decision'])
            self.assertEqual(trace['request']['request_id'], trace['decision']['request_id'])
            development = c['captured_definitions']['configuration/development/workflow.yaml']
            edge = next(e for e in development['transitions'] + development['resolution_routes']
                        if e['id'] == trace['request']['transition_id'])
            self.assertEqual(edge['from'], trace['state_before']['state'])
            self.assertEqual(trace['request']['configuration_id'], trace['state_before']['configuration_id'])
            if trace['decision']['decision'] == 'ALLOW':
                self.assertEqual(edge['to'], trace['event']['next_state'])
            if 'event' in trace:
                event = trace['event']
                validator('records.schema.json', 'Event').validate(event)
                self.assertEqual(event['previous_version'], trace['request']['expected_version'])
                self.assertEqual(event['previous_state'], trace['state_before']['state'])
                self.assertEqual(event['next_version'], event['previous_version'] + 1)
                self.assertEqual(event['post_state']['version'], event['next_version'])
                self.assertEqual(event['request_id'], trace['request']['request_id'])
                self.assertEqual(event['decision_ref']['identity'], identity(trace['decision']))
        captured = c['captured_definitions']
        manifest = c['captured_snapshot']['captured_definitions']
        self.assertTrue({'PROFILE', 'WORKFLOW', 'RULES', 'SCHEMA', 'ADAPTER', 'CRITERIA'} <= {x['kind'] for x in manifest})
        self.assertEqual({x['captured_path'] for x in manifest}, set(captured))
        for entry in manifest:
            self.assertEqual(entry['identity'], identity(captured[entry['captured_path']]))
        self.assertEqual(identity(captured['configuration/adapters/build.json']),
                         c['captured_profile']['capabilities']['build']['adapter']['content_identity'])
        adoption = c['adoption_trace']
        self.assertEqual(adoption[0]['event']['post_state']['configuration_id'], 'cfg-2')
        self.assertEqual(adoption[1]['event']['post_state'], c['adopted_task'])
        self.assertEqual(adoption[2]['request']['expected_state'], 'IMPLEMENTED')
        self.assertEqual(adoption[2]['request']['configuration_id'], 'cfg-2')
        self.assertEqual(adoption[2]['decision']['decision'], 'BLOCKED')
        self.assertTrue({'D-PREFLIGHT', 'D-BUILD', 'D-TEST'} <= set(c['adoption_evidence']['invalidated_criteria']))
        self.assertEqual(c['adopted_task']['criterion_verdict_refs'], [])
        self.assertNotIn('preflight', c['profiles'][1]['capabilities'])
        self.assertEqual(c['adoption_evidence']['new_manifest_identity'], identity(c['new_config_snapshot']))
        changed = {path for path, value in c['captured_definitions'].items()
                   if c['new_captured_definitions'][path] != value}
        self.assertEqual(changed, set(c['adoption_evidence']['changed_definition_paths']))
        for entry in c['new_config_snapshot']['captured_definitions']:
            self.assertEqual(entry['identity'], identity(c['new_captured_definitions'][entry['captured_path']]))
        self.assertEqual(c['adopted_task']['invocation_counters'], c['old_task']['invocation_counters'])

    def test_pinning_explicit_adoption_and_current_revocation(self):
        c = next(c for c in self.data()['cases'] if c['id'] == 'pinned-tasks')
        for key in ['old_task', 'new_task', 'adopted_task', 'revoked_task']:
            validator('records.schema.json', 'TaskState').validate(c[key])
        self.assertEqual(c['old_task']['configuration_id'], 'cfg-1')
        self.assertEqual(c['new_task']['configuration_id'], 'cfg-2')
        self.assertEqual(c['adopted_task']['configuration_id'], 'cfg-2')
        self.assertEqual(c['adopted_task']['state'], 'IMPLEMENTED')
        self.assertEqual(c['revoked_task']['configuration_id'], 'cfg-1')
        self.assertEqual(c['revoked_task']['state'], 'BLOCKED')
        self.assertEqual(c['old_task']['invocation_counters'], c['revoked_task']['invocation_counters'])
        self.assertEqual(c['dispatch_after_revocation'], False)
        validator('records.schema.json', 'Invocation').validate(c['invocation'])
        validator('records.schema.json', 'ConfigSnapshot').validate(c['captured_snapshot'])
        self.assertEqual(c['captured_snapshot']['captured_definitions'][0]['identity'], identity(c['captured_profile']))
        self.assertEqual(c['invocation']['expected_identities']['configuration_id'], c['old_task']['configuration_id'])
        self.assertEqual(c['invocation']['expected_identities']['adapter'], c['captured_profile']['capabilities']['build']['adapter'])


if __name__ == '__main__':
    unittest.main()
