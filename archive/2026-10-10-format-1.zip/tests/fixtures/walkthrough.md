# Actual disposable walkthrough evidence

This report records Task 6 work on native macOS, using only disposable repositories. `FIXTURE` results demonstrate interface behavior. Procedural reviews demonstrate inspected decisions. Neither proves production execution or enforced runtime transitions. The private-repository pilot and native Windows/Linux runs remain pending.

## What was actually run

The generator created compiled, source-only, documentation and two-target repositories under `/private/tmp/harness-builder-20261004-efv7l2ai/task6 examples café`. Each contains every installed runtime file. Source-only uses `tools/harness café`; the others use `.harness`. Generation refuses existing content. All source identities come from file bytes, including a separate test-source manifest in multi-target.

The [native matrix](native-platform-matrix.yaml) records 16 actual checker subprocesses: four examples × LF/CRLF × native Python 3.11/3.14. Commands use argument arrays, absolute roots, a different working directory with spaces/Unicode and explicit dependencies. Every command, exit code, tool source identity, stdout/stderr location and before/after tree hash is retained. All 16 exit 0 and preserve the inspected trees. Their pending scaffolds remain INCOMPLETE/NOT_ASSESSED; zero is coverage success, not installation completion.

Separately, the reviewed examples have actual current review evidence. The compiled repository reports STRUCTURE_COMPLETE/PARTIAL because test discovery is still pending. Source-only, docs and multi-target report STRUCTURE_COMPLETE/READY for their synthetic interfaces. READY does not certify production tools. These four [reviewed reports](checks/reviewed-compiled.stdout.json) and adjacent invocation records include actual observations and read-only comparisons.

The [installed snapshot archive](checks/installed-walkthrough.zip) retains the complete four reviewed repositories, including exact candidate files, definitions, source manifests, typed requests/decisions/events, raw fixture outputs, installation snapshots, update receipts and review dossiers. It contains no production source or credentials. Paths below are relative to the compiled repository inside that archive.

## Install and activate

The coordinating reviewer was **Codex Task 6 procedural reviewer**. The authoring recorder was copied outside the builder; an audit hook denied all reads from the builder checkout throughout the walkthrough. `installed-only-audit.json` records zero attempted builder reads. Python dependencies and the fixed recorder itself were available; all harness instructions, rules, schemas, criteria, cases, adapter definitions and record templates came from the installed repositories.

1. The generated cfg-1 is a complete staged skeleton with pending semantic assessments. `installation/evidence/source-snapshot.json` identifies observed non-Git source bytes.
2. The reviewer inspected installed files, local references, ownership, discovery, records, rules, routing, applicability, outcome compatibility and criteria aggregation. The cfg-2 candidate publishes staged reviews with IS-08.provenance still PENDING. Other required structural criteria pass; known integration gaps remain explicit. `eligible-review.json`, the immutable cfg-1 profile/ledger, candidate and cfg-2 publication receipt are retained.
3. The reviewer records ACTIVATION_ELIGIBLE for the exact AGENTS.md candidate and absent before-value, writes the pointer, and rereads its exact bytes. This permission is separate from STRUCTURE_COMPLETE. `activation.json` records the actual write/reread and preserved user file.
4. The cfg-3 candidate includes the observed activation and a new dependency revalidation review. Actual unchanged instruction/workflow/schema/binding/policy/source identities are recorded. The recorder compares the active cfg-2 before publication and verifies the live cfg-3 bytes against the reviewed candidate. Final inventory is cfg-3; earlier profile/ledger snapshots remain immutable. Only `installation/installation-record.yaml` receives the exact mutable-ledger null-hash exception.

All semantic assessments are attributed LLM_REVIEW records. The installation ledger records the checker as NOT_RUN for this installed-only review path; the later externally run checker reports are separate retained evidence, not fabricated installation-time automated results.

## Develop, refuse fixture execution, replace and resume

The installed development entry point initializes `.harness/development/runs/SYNTHETIC-task/` and pins cfg-3. `config-snapshot.yaml` hashes captured profile, both workflows, rules, schemas, criteria, conformance cases and adapter definitions outside the hashed files. The request is a bounded inspection of synthetic fixture provenance, with no production code edit. Its task spec, explicit verification/implementation plan, source identity, due-stage reviews, requests and ALLOW decisions accompany each preparatory event.

The trace reaches PREFLIGHT with a durable invocation intent, absolute deadline and counters. A separate synthetic PASS envelope remains FIXTURE. RULE-05 denies success because real preflight execution is missing. The denial does not mutate state. A separate declared safe-stop request and ALLOW decision commit BLOCKED, retaining the original result, stopped-from stage, intent and counters. No production dispatch occurred; the adoption review records that observation rather than assuming an unknown external operation disappeared.

The installed maintenance entry point then handles `replace-build`:

- Capture cfg-3 before-values, policy, candidate B bytes and a manifest. The new adapter and its target-local procedure are GENERATED additions with null before identities; the existing profile has an exact prior hash.
- Inspect all four outcomes, unchanged interface, stdout-only side effects, target/environment fit, current authority, deadline and reconciliation. Fixture compatibility does not require production success.
- Persist publication intent in the ADAPTER_COMPATIBLE event before any actual file write. Recompare the active base and each affected before-value, write B/procedure/profile, and verify every candidate-to-live hash.
- Commit PROMOTED at cfg-4 with an immutable per-file receipt identifying attempt, writer, phase, scope, ownership and before/after bytes. The whole-inventory reviewer subsequently inspects the baseline, accepted intent, receipt and current endpoints; it is a semantic review, not an automated partial inventory PASS.
- Interrupt status refresh through PENDING, then record INSPECTED and the installed RECONCILED edge back to the already earned PROMOTED stage. The shared tree is unchanged throughout reconciliation. No second publication or revision is created; status regeneration then finishes the update.

Explicit task adoption captures cfg-4 under `configuration/adopted/`, preserves the cfg-3 snapshot and historical results, records the affected execution scope, and uses ADOPTED → RESUME_REVIEW → IMPLEMENTED. Accepted spec/design, targets and counters are retained. The task does not jump to BUILD_PASSED, TEST_PASSED or COMPLETE. The original undispatched intent remains historical with explicit no-dispatch reconciliation and cannot authorize a new dispatch after adoption.

## Inventoried rule/schema migration

`rule-schema-migration` reads installed criteria, cases, rules and schemas. Its exact cfg-4 base, candidate content identity and three affected paths are recorded: `shared/verification-rules.md`, `shared/schemas/result.schema.json`, and `shared/repo-profile.yaml`. The rule/schema change adds a local clarification that FIXTURE cannot become execution evidence; it deliberately leaves interface 1.0.0 and existing constraints intact.

Scoped approval is labelled **SYNTHETIC fixture approver (scenario premise)**. It is an input to this disposable approved-migration case, not a claim that a human approved a private repository or that the author may grant human authority. The actual disposable file writes were within the controller's authorized task.

Before publication, the installed staged schema is checked, all four actual generated fixture envelopes validate against it, unsupported status fails, and the reviewer records affected S-08/S-14/S-47 behavior and unchanged readiness obligations. The migration takes MIGRATION_CHECKED → PROMOTED via APPROVED, without being retested against the ordinary no-migration route. Exact before-values, candidate bytes, manifest, committed intent, actual write receipts and whole-inventory acceptance are retained. cfg-5 is published and status regenerated. The existing task remains explicitly pinned to its adopted cfg-4; no silent adoption occurs.

This example proves actual bounded file publication and inspection of the approved migration protocol. It does not claim a tested production interface expansion. The accepted Task 3 walkthrough evidence separately supplies the semantic interface/permission expansion and changed-candidate/base variants.

## Recovery, scenario variants and limits

[Resume inspection](checks/resume-inspection.json) records an actual interruption after exactly two generated files, a user edit, retained unchanged evidence and untouched runtime history. The reviewer preserves the edit and blocks activation pending reconciliation. [Live-harness inspection](checks/live-harness-inspection.json) records a complete existing installation, root/nested instruction identities and a proposed conflicting second pointer; the actual decision is installed maintenance/migration with activation withheld. [Dirty snapshot](checks/dirty-snapshot.json) records Git init/add/status in a separate disposable repository without a commit, then changed bytes that differ from its staged identity. No original workspace was initialized or committed.

The [scenario ledger](scenario-results.yaml) has separate typed results per evaluated obligation/variant. It imports the accepted Task 2/3 concrete walkthroughs with their original review attribution and immutable input identities. Their synthetic EXECUTION-valued premises remain hypothetical inputs, never actual execution evidence. Relational authoring tests check shape, request/decision/event agreement, replay, identities, lineage and preservation; those tests do not become a runtime gate engine. The exact S-42 target mixes, both S-20 failure origins, all S-22 stop variants, both S-43 lineage mismatches, stale/replay/adoption/drift/migration/rollback variants remain visible individually.

No whole-scenario pass is inferred from a partial check. Native Windows/Linux obligations remain PENDING with native reproduction commands. Final release assembly and the private pilot belong to Task 7 and remain pending here. Runtime TOOL enforcement and production tool quality are unclaimed.

The two checker inventory defects exposed by this actual walkthrough were repaired with failing-then-passing regressions: an INSPECTED/RECONCILED restoration cannot count as a second publication, and an explicitly inventoried new GENERATED path can enter the accepted owned history. Changed receipts, non-null claimed before-values for new paths, user ownership, duplicate additions and newer endpoint edits still fail or require unresolved review. The checker still leaves the whole post-maintenance inventory obligation uncovered; an actual permitted review supplies semantic satisfaction.


## Exact catalogue coverage and final evidence audit

The scenario ledger explicitly joins all 132 installed catalogue cases and all 163 declared coverage parts. Each join names its mode, retained result, source evaluations and bounded observations. There are 152 PASS parts and 11 PENDING parts; PASS for a structural check cannot substitute for a procedural decision. The ledger also retains independent observations and release obligations (335 typed results: 319 PASS, 16 PENDING).

Additional attributed reviews retain concrete inputs and typed, linked decision/event proposals for research invalidation back to NEW, positive test-origin repair with test counter 0→1, and rejection of stale cfg-4 migration approval against actual cfg-5 bytes. These are procedural proposals, not executed repairs or new publication. Exact four-case aggregation inputs/output are retained separately; all input objects remain unchanged.

Pending catalogue parts: S-17 exact/altered/stale replay in optional TOOL mode; S-44 Windows/Linux LF/CRLF; S-46 absent interpreter in AUTOMATED and WALKTHROUGH modes; S-48 release audit in AUTOMATED and WALKTHROUGH modes. Both local interpreters exist, so dependency-unavailable output is not absent-interpreter evidence. Private pilot and final documentation review also remain independently pending. Task 7 must update exact part results and the matching join after its actual review, preserving all other limitations.

Final whole suites ran 107 tests successfully on Python 3.14 and 3.11 before the final ledger/review additions. The final focused examples/conformance run then passed 13 tests on each interpreter. No historical timestamps were rewritten when the local calendar advanced.


## Task 6 review correction

The initial replacement compatibility dossier incorrectly paired A's definition identity with B's adapter identity. The corrected recorder stages replacement module/procedure bytes before review, reads the procedure-selected module, imports that exact source, and binds both envelope identities to its hash. Retained source/procedure paths and hashes identify what was inspected. cfg-4/cfg-5 review timestamps precede compatible/migration decisions and actual writes. All outcomes remain FIXTURE.

The corrected archive comes from `/private/tmp/harness-builder-20261004-efv7l2ai/task6 fix1 final examples café`. Its cfg-3/A baseline, first 10 task events, all initial capture files, and the other three examples remain exact (210 preserved files). The two affected maintenance attempts/adoption were rebuilt; this replaces the erroneous synthetic demonstration, not a production rollback. The [preservation record](checks/task6-fix1-preserved-history.json) and [new audit output](checks/task6-fix1-walkthrough.stdout.txt) retain actual observations. The compiled checker was rerun on both native interpreters, with unchanged trees. Original 16 baseline LF/CRLF matrix inputs and checker source are unaffected and were not relabeled or rerun.

The exact S-47 catalogue part now joins the accepted BUILDING→BUILD_PASSED denied review. The actual PREFLIGHT refusal remains separately retained supplemental evidence. Tests assert the requested edge as well as mode/result links. Task 6 fix-round verification is retained in `checks/task6-fix1-green-python*.txt`; earlier whole-suite results remain historical.
