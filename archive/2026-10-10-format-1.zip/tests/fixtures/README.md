# Test inputs

These immutable files are read by the builder project's regression tests. They are not installed into a user's repository.

| Content | Purpose |
|---|---|
| Scenario and walkthrough records | Expected decisions and recorded results |
| `checks/` | Referenced outputs and an installed-harness snapshot |
| `sources/` | Exact historical source bytes cited by records |
| `paths.json` | Resolves old recorded paths without rewriting evidence |

Most people can ignore this folder. Run tests using [the test guide](../README.md). Older authoring logs live in [the verification archive](../../archive/verification/README.md).
