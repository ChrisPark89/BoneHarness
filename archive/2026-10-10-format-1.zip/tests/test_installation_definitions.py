"""Authoring checks for installed definitions; these do not execute a runtime engine."""
import copy
import hashlib
import json
from pathlib import Path
import re
import unittest
import yaml
from support import validator, FIXTURES

KIT = Path(__file__).resolve().parents[1] / 'builder-kit'
RUNTIME = KIT / 'templates/runtime'
BASE = set('IS-01.files IS-01.schemas IS-02.local_refs IS-02.ownership IS-03.registry IS-03.separation IS-04.graph IS-04.routing IS-05.result_schema IS-05.evidence IS-06.records IS-06.recovery IS-07.sequence IS-07.applicability IS-08.inventory IS-08.assessment'.split())

def load(path):
    return yaml.safe_load((RUNTIME / path).read_text())

def refs(value):
    if isinstance(value, dict):
        if value.get('kind') == 'LOCAL':
            yield value
        for v in value.values():
            yield from refs(v)
    elif isinstance(value, list):
        for v in value:
            yield from refs(v)

class InstallationDefinitions(unittest.TestCase):
    def catalogue(self):
        return load('framework/workflows/verification-criteria.yaml')

    def test_catalogue_required_ids_and_fully_scoped_methods(self):
        c = self.catalogue()
        validator('criteria.schema.json', 'Catalogue').validate(c)
        ids = [x['id'] for x in c['criteria']]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertTrue(BASE <= set(ids))
        for d in c['criteria']:
            self.assertRegex(d['id'], r'^IS-0[1-8]\.[a-z_]+$|^II-x[0-9a-f]+-x[0-9a-f]+-x[0-9a-f]+$')
            self.assertNotIn('D-', d['id'])
            self.assertTrue(d['required'])
            self.assertTrue(d['scenario_ids'])
            self.assertGreater(len(d['description']), 90)
            if 'AUTOMATED' in d['allowed_methods']:
                self.assertIn('LLM_REVIEW', d['allowed_methods'])
                self.assertIn('HUMAN_REVIEW', d['allowed_methods'])
            self.assertIsNone(d['applicability_rule'])
        review_ids = {d['id'] for d in c['criteria'] if 'AUTOMATED' not in d['allowed_methods']}
        self.assertTrue({'IS-02.ownership', 'IS-05.evidence', 'IS-06.recovery', 'IS-07.applicability'} <= review_ids)
        self.assertTrue(BASE <= set(c['extensions']['automated_scope']) | review_ids)

    def test_activation_eligibility_is_distinct_from_completeness(self):
        catalogue = self.catalogue()
        contract = catalogue['extensions']['activation_contract']
        self.assertEqual(contract['deferred_until_after_activation'], ['IS-08.provenance'])
        self.assertIn('INCOMPLETE', contract['staged_gate'])
        self.assertIn('PENDING', contract['staged_gate'])
        self.assertIn('configuration_revision', contract['final_publication'])
        self.assertIn('completed_at', contract['failure'])
        criteria = {d['id']: d for d in catalogue['criteria']}
        self.assertTrue(criteria['IS-08.provenance']['required'])
        self.assertIsNone(criteria['IS-08.provenance']['applicability_rule'])
        self.assertIn('post-activation', criteria['IS-08.provenance']['description'])
        spec = (KIT / 'INSTALLER_SPEC.md').read_text() + (KIT / 'installer/installation-reference.md').read_text()
        self.assertNotIn('With structure complete and scope conflicts resolved', spec)
        self.assertIn('ACTIVATION_ELIGIBLE', spec)
        self.assertNotIn('Withhold activation for incomplete structure', (KIT/'installer/bootstrap-prompt.md').read_text())

    def test_integration_tuple_encoding_is_injective(self):
        c = self.catalogue()['extensions']
        self.assertEqual(c['integration_id_encoding'], 'x + lowercase hex of exact UTF-8 bytes per component; join three encoded components with hyphens after II-')
        tuples = [('a-b', 'c', 'd'), ('a', 'b-c', 'd'), ('a', 'b', 'c-d'), ('a_', 'b', 'é'), ('a_', 'b', 'e\u0301'), ('a', 'b', 'app/local')]
        ids = ['II-' + '-'.join('x' + s.encode('utf-8').hex() for s in t) for t in tuples]
        self.assertEqual(len(ids), len(set(ids)))
        for t, id_ in zip(tuples, ids):
            self.assertEqual(tuple(bytes.fromhex(s[1:]).decode('utf-8') for s in id_[3:].split('-')), t)
        self.assertEqual(c['integration_instances'], [])  # targets are undiscovered, not invented
        self.assertIn('dormant', c['workflow_selector_contract'])
        self.assertIn('ONLY against repo-profile.workflow_profiles', c['workflow_selector_contract'])
        profile = load('framework/config/repo-profile.yaml')
        workflow = load('framework/workflows/development/workflow.yaml')
        active = {p['id'] for p in profile['workflow_profiles']}
        examples = set(workflow['extensions']['profile_examples'])
        self.assertEqual(active, {'default'})
        self.assertTrue({'source-only', 'docs'} <= examples - active)
        for edge in workflow['transitions']:
            self.assertTrue(set(edge['profiles']) <= active | examples)

    def test_all_scenarios_variants_and_fixture_boundary(self):
        c = yaml.safe_load((KIT.parent / 'tests/conformance-cases.yaml').read_text())
        validator('conformance.schema.json').validate(c)
        self.assertEqual({x['scenario_id'] for x in c['cases']}, {f'S-{i:02}' for i in range(1, 49)})
        self.assertEqual(len({x['case_id'] for x in c['cases']}), len(c['cases']))
        expected = c['extensions']['variant_manifest']
        self.assertEqual({x['case_id'] for x in c['cases']}, {f'{s}.{v}' for s, vv in expected.items() for v in vv})
        self.assertEqual(len(c['cases']), 147)
        reporting=[case for case in c['cases'] if '.reporting-' in case['case_id']]
        self.assertEqual(len(reporting),15)
        self.assertTrue(all(case['scenario_id'] in ('S-10','S-48') for case in reporting))
        self.assertEqual(set(expected['S-17']), {r+'-'+m for r in ['exact-replay','altered-replay','stale-version'] for m in ['llm_protocol','tool']})
        self.assertEqual(set(expected['S-42']), {'pass-missing','pass-fail','pass-blocked','pass-pass','fail-missing','fail-blocked','fail-blocked-unknown','fail-running','targets-unknown'})
        self.assertEqual(set(expected['S-44']), {o+'-'+e for o in ['windows','macos','linux'] for e in ['LF','CRLF']})
        self.assertNotIn('actual_result', json.dumps(c))
        for x in c['cases']:
            self.assertEqual(x['configuration']['fixture_reference']['path'], 'tests/conformance-cases.yaml')
            self.assertTrue(all(e['provenance'] == 'FIXTURE' for e in x['input_evidence']))
            for evidence in x['input_evidence']:
                self.assertEqual(evidence['identity'], 'sha256:'+hashlib.sha256(evidence['summary'].encode()).hexdigest())
            self.assertTrue(x['expected_records'])
            self.assertTrue(x['forbidden_effects'])
            for part in x['coverage_parts']:
                self.assertTrue(part['expected_evidence'])
        self.assertIn('literal', c['extensions']['negative_input_policy'])
        for d in self.catalogue()['criteria']:
            self.assertTrue(set(d['scenario_ids']) <= set(expected))

    def test_inventory_and_typed_installation_record(self):
        r = load('framework/templates/installation/installation-record.yaml')
        validator('records.schema.json', 'InstallationRecord').validate(r)
        self.assertEqual(r['entry_point']['activation_state'], 'PENDING')
        self.assertEqual(r['checker_coverage']['status'], 'NOT_RUN')
        self.assertTrue(all(a['result'] == 'PENDING' for a in r['criterion_assessments']))
        self.assertEqual(set(a['criterion_id'] for a in r['criterion_assessments']), {x['id'] for x in self.catalogue()['criteria']})
        self.assertEqual(r['owned_paths'], [])
        self.assertEqual(r['generated_paths'], [])
        inventory = self.catalogue()['extensions']['required_runtime_files']
        self.assertEqual(set(inventory), {p.relative_to(RUNTIME).as_posix() for p in RUNTIME.rglob('*') if p.is_file() and '__pycache__' not in p.parts})
        self.assertEqual(len(inventory), len(set(inventory)))
        self.assertTrue(any(d['value']['status'] == 'PENDING_DISCOVERY' for d in r['decisions']))

    def test_target_only_active_references(self):
        for filename in ['framework/workflows/verification-criteria.yaml', 'framework/templates/installation/installation-record.yaml']:
            for r in refs(load(filename)):
                self.assertEqual(r['scope'], 'HARNESS')
                self.assertTrue((RUNTIME / r['path']).is_file(), r)
        for path in RUNTIME.rglob('*.md'):
            for target in re.findall(r'\]\(([^)#]+)(?:#[^)]*)?\)', path.read_text()):
                if '://' not in target:
                    resolved = (path.parent / target).resolve()
                    self.assertTrue(resolved.is_relative_to(RUNTIME.resolve()), (path, target))
                    if resolved == RUNTIME.resolve() / 'docs/setup.md':
                        resolved = RUNTIME / 'framework/templates/setup.md'
                    self.assertTrue(resolved.exists(), (path, target))

    def test_installer_entry_and_contracts(self):
        readme = (KIT / 'README.md').read_text()
        boot = (KIT / 'installer/bootstrap-prompt.md').read_text()
        spec = (KIT / 'INSTALLER_SPEC.md').read_text() + (KIT / 'installer/installation-reference.md').read_text()
        self.assertLess(len(readme.splitlines()), 65)
        self.assertLess(len(boot.splitlines()), 65)
        for term in ['FRESH', 'RESUME', 'EXISTING', 'post-activation', 'before_identity', 'profile.assessments', 'self-hash', 'request_type_profiles']:
            self.assertIn(term, spec)
        checklist = (KIT / 'installer/installation-checklist.md').read_text()
        for id_ in BASE:
            self.assertIn(id_, checklist)
        self.assertIn('canonical catalogue', checklist)
        self.assertIn('Structure status: `INCOMPLETE`', (RUNTIME/'framework/templates/setup.md').read_text())

class StagedInstallationWalkthrough(unittest.TestCase):
    """Disposable synthetic target; direct steps are a recorded review, not installer automation."""
    def test_staged_review_resume_conflict_and_builder_absence(self):
        import shutil
        import tempfile
        from support import STAMP
        review = (FIXTURES / 'installation-review.md').read_text()
        for definition in load('framework/workflows/verification-criteria.yaml')['criteria']:
            self.assertIn('| ' + definition['id'] + ' |', review)
        def digest(path):
            return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()
        def dump(path, value):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(value, indent=2) + '\n')
        observed = {}
        with tempfile.TemporaryDirectory(prefix='installation Unicode é ') as temp:
            repo = Path(temp)
            harness = repo / '.harness'
            shutil.copytree(RUNTIME, harness)
            (repo / 'AGENTS.md').write_text('Existing root guidance.\n')
            (repo / 'component').mkdir()
            (repo / 'component/AGENTS.md').write_text('Component scope: preserve local review.\n')
            (repo / 'build-skill.md').write_text('Synthetic build procedure: produces fixture outcomes only.\nNo production invocation performed.\n')
            (harness / 'artifacts/installation/evidence').mkdir(parents=True)
            (harness / 'docs').mkdir()
            evidence_path = harness / 'artifacts/installation/evidence/structure-review.md'
            evidence_path.write_text(review)
            evidence = {'reference': {'kind': 'LOCAL', 'scope': 'HARNESS', 'path': 'artifacts/installation/evidence/structure-review.md'}, 'provenance': 'REVIEW', 'summary': 'Actual authoring review of staged synthetic definitions, limits and scenario traces.', 'identity': digest(evidence_path)}
            profile = load('framework/config/repo-profile.yaml')
            profile['repository']['name'] = 'synthetic non-Git target'
            profile['repository']['identity'] = digest(repo / 'AGENTS.md')
            profile['repository']['instruction_files'] = [{'reference':{'kind':'LOCAL','scope':'REPOSITORY','path':p},'scope':'repository' if p=='AGENTS.md' else 'component','identity':digest(repo/p)} for p in ['AGENTS.md','component/AGENTS.md']]
            profile['workflow_profiles'][0]['required_targets'] = [{'target_id':'app/local','environment':'local'}]
            profile['extensions']['repository_discovery_complete'] = True
            # Discovery is a real read of this synthetic source; compatibility remains pending.
            profile['capabilities']['build']['evidence_refs'] = [{'reference': {'kind':'LOCAL','scope':'REPOSITORY','path':'build-skill.md'},'provenance':'REVIEW','summary':'Inspected synthetic procedure; production availability not asserted.','identity':digest(repo/'build-skill.md')}]
            profile['workflow_profiles'][0]['readiness'] = 'PARTIAL'
            record = load('framework/templates/installation/installation-record.yaml')
            record.update(installation_id='synthetic-install-1', target_identity=profile['repository']['identity'], started_at=STAMP, updated_at=STAMP)
            record['extensions']['template_only'] = False
            record['discovered_facts'] = [{'id':'build-source','claim':'Synthetic build procedure discovered; real execution remains unassessed.','classification':'FACT','evidence_refs':profile['capabilities']['build']['evidence_refs']}]
            root_instruction_bytes = (repo/'AGENTS.md').read_bytes()
            candidate = (harness/'README.md').read_bytes()
            record['entry_point']['candidate'] = {'path':'.harness/README.md','before_identity':digest(harness/'README.md'),'content_identity':digest(harness/'README.md')}
            record['entry_point']['activation_state'] = 'STAGED'
            definitions = load('framework/workflows/verification-criteria.yaml')['criteria']
            for assessment in record['criterion_assessments']:
                assessment.update(result='PENDING' if assessment['criterion_id']=='IS-08.provenance' else 'PASS',method='LLM_REVIEW',actor='Task4 authoring reviewer',evidence_refs=[copy.deepcopy(evidence)],reason='Await actual activation and reread.' if assessment['criterion_id']=='IS-08.provenance' else 'See individually inspected obligation '+assessment['criterion_id']+' in referenced review.')
            # Known target set creates exact tuple definitions and explicit pending integration assessments.
            catalogue = load('framework/workflows/verification-criteria.yaml')
            for capability in profile['workflow_profiles'][0]['required_capabilities']:
                parts = ('default', capability, 'app/local')
                id_ = 'II-' + '-'.join('x' + x.encode('utf-8').hex() for x in parts)
                catalogue['criteria'].append({'id':id_,'category':'INTEGRATION','required':True,'description':catalogue['extensions']['integration_obligation'],'allowed_methods':['AUTOMATED','LLM_REVIEW','HUMAN_REVIEW'],'applicability_rule':catalogue['extensions']['integration_applicability'],'scenario_ids':['S-01','S-09','S-30','S-34']})
                catalogue['extensions']['integration_instances'].append({'criterion_id':id_,'profile_id':parts[0],'capability_id':parts[1],'target_id':parts[2],'environment':'local'})
                record['criterion_assessments'].append({'schema_version':'1.0.0','record_type':'CriterionAssessment','catalogue_version':'1.0.0','criterion_id':id_,'result':'PENDING','method':'LLM_REVIEW','actor':'Task4 authoring reviewer','evidence_refs':[copy.deepcopy(evidence)],'reason':'Actual review finds pending binding/settings; synthetic procedure discovery does not establish real compatibility/access.','assessed_configuration_id':'cfg-1'})
                record['checker_coverage']['uncovered_ids'].append(id_)
            validator('criteria.schema.json','Catalogue').validate(catalogue)
            dump(harness/'framework/workflows/verification-criteria.yaml',catalogue)
            profile['assessments'] = copy.deepcopy(record['criterion_assessments'])
            validator('profile.schema.json').validate(profile)
            dump(harness/'framework/config/repo-profile.yaml', profile)
            (harness/'docs/setup.md').write_text('Configuration cfg-1 revision 1. INCOMPLETE. ACTIVATION_ELIGIBLE for installed entry-point loading only; IS-08.provenance PENDING. default PARTIAL; test PENDING_DISCOVERY; no production run.\n')
            # Preserve separate example history, then capture every completed generated definition.
            (harness/'development/runs/old-task').mkdir(parents=True)
            (harness/'development/runs/old-task/evidence.txt').write_text('Prior history: keep exactly.\n')
            old_history_hash = digest(harness/'development/runs/old-task/evidence.txt')
            for rel in load('framework/workflows/verification-criteria.yaml')['extensions']['required_runtime_files']:
                entry = {'scope':'HARNESS','path':rel,'ownership':'GENERATED','before_identity':None,'after_identity':None if rel=='artifacts/installation/installation-record.yaml' else digest(harness/rel)}
                record['generated_paths'].append(entry)
                record['owned_paths'].append(copy.deepcopy(entry))
            record['extensions']['mutable_ledger_reason']='MUTABLE_LEDGER'
            validator('records.schema.json','InstallationRecord').validate(record)
            dump(harness/'artifacts/installation/installation-record.yaml',record)
            structural_ids={d['id'] for d in definitions}
            deferred=set(catalogue['extensions']['activation_contract']['deferred_until_after_activation'])
            staged_results={a['criterion_id']:a['result'] for a in record['criterion_assessments'] if a['criterion_id'] in structural_ids}
            self.assertEqual({id_ for id_,result in staged_results.items() if result!='PASS'},deferred)
            self.assertEqual(staged_results['IS-08.provenance'],'PENDING')
            self.assertFalse(all(result=='PASS' for result in staged_results.values()))
            self.assertTrue(all(staged_results[id_]=='PASS' for id_ in structural_ids-deferred))
            self.assertIsNone(record['completed_at'])
            observed['S-01']={'staged_structure':'INCOMPLETE','activation_eligibility':'ACTIVATION_ELIGIBLE','staged_provenance':'PENDING','structure':'INCOMPLETE before activation','integration':'PARTIAL','test_status':profile['capabilities']['test']['configuration_status'],'test_procedure':profile['capabilities']['test']['invocation']['procedure'],'production_calls':0}
            self.assertIsNone(profile['capabilities']['test']['invocation']['procedure']['value'])
            self.assertTrue(all(a['method']=='LLM_REVIEW' for a in record['criterion_assessments']))
            observed['S-03']={'checker':record['checker_coverage']['status'],'automated_claims':0,'staged_satisfied_reviews':len(definitions)-1,'pending_post_activation_reviews':1,'pending_integration_reviews':len(record['criterion_assessments'])-len(definitions)}
            # Concrete graph defect: candidate stays unactivated despite file presence.
            graph = yaml.safe_load((harness/'framework/workflows/development/workflow.yaml').read_text())
            graph['transitions'][0]['to']='UNDEFINED'
            state_ids = {s['id'] for s in graph['states']}
            bad = [e['id'] for e in graph['transitions'] if e['to'] not in state_ids]
            self.assertTrue(bad)
            self.assertEqual((repo/'AGENTS.md').read_text(),'Existing root guidance.\n')
            failed_staged=copy.deepcopy(staged_results);failed_staged['IS-04.graph']='FAIL'
            self.assertFalse(all(failed_staged[id_]=='PASS' for id_ in structural_ids-deferred))
            observed['S-02']={'activation_eligibility':'WITHHELD','undefined_endpoint_transitions':bad,'activation':'STAGED','structure':'INCOMPLETE for mutated candidate'}
            # A review assertion has no real invocation: execution obligation remains pending.
            observed['S-04']={'supplied_provenance':'REVIEW','required_provenance':'EXECUTION','criterion':'PENDING','production_calls':0}
            self.assertNotEqual(evidence['provenance'],'EXECUTION')
            # Actual interrupted two-file example, including a user edit after snapshot.
            interrupted=repo/'interrupted'; interrupted.mkdir()
            for name in ['one.md','two.md']:(interrupted/name).write_text('Generated '+name+'\n')
            saved={n:digest(interrupted/n) for n in ['one.md','two.md']}
            (interrupted/'one.md').write_text('User edited one.\n')
            changed=[n for n,h in saved.items() if digest(interrupted/n)!=h]
            self.assertEqual(changed,['one.md'])
            resume_record=copy.deepcopy(record);resume_record['mode']='RESUME'
            resume_record['generated_paths']=[{'path':'interrupted/'+n,'scope':'REPOSITORY','ownership':'GENERATED','before_identity':None,'after_identity':h} for n,h in saved.items()]
            resume_record['owned_paths']=copy.deepcopy(resume_record['generated_paths'])
            resume_record['entry_point']={'candidate':None,'activation_state':'PENDING','evidence_refs':[]}
            resume_record['completed_at']=None
            for assessment in resume_record['criterion_assessments']:
                assessment.update(result='PENDING',method=None,actor=None,evidence_refs=[],reason='Interrupted installation: reinspection required. Retain prior snapshot as history.')
            resume_record['extensions']['retained_evidence']={'two.md':saved['two.md'],'reason':'Exact unchanged bytes; only this file evidence is retained, not whole-install PASS.'}
            resume_record['decisions'].append({'id':'edited-one','value':{'status':'PENDING_DISCOVERY','value':None,'reason':'User edit differs from saved generated bytes; merge decision needed.','stop_state':'HUMAN_REQUIRED'},'reason':'Preserve edit and unchanged second file.','evidence_refs':[]})
            validator('records.schema.json','InstallationRecord').validate(resume_record)
            dump(harness/'artifacts/installation/evidence/resume.json',resume_record)
            self.assertEqual((interrupted/'one.md').read_text(),'User edited one.\n')
            self.assertEqual(digest(interrupted/'two.md'),saved['two.md'])
            self.assertEqual(digest(harness/'development/runs/old-task/evidence.txt'),old_history_hash)
            observed['S-06']={'mode':'RESUME','conflicts':changed,'untouched_second_hash':saved['two.md'],'preserved_user_text':(interrupted/'one.md').read_text(),'history_hash':old_history_hash,'reused_evidence':'unchanged second-file identity only; affected review needs reinspection'}
            # Deliberately conflicting nested ownership: withhold entry-point loading.
            nested_before=digest(repo/'component/AGENTS.md')
            conflict=copy.deepcopy(record);conflict['entry_point']['activation_state']='CONFLICT'
            conflict['mode']='EXISTING'
            validator('records.schema.json','InstallationRecord').validate(conflict)
            self.assertEqual(digest(repo/'component/AGENTS.md'),nested_before)
            observed['S-07']={'mode':'EXISTING','route':'installed maintenance MIGRATION','activation':'CONFLICT for conflicting candidate','nested_preserved':nested_before,'duplicate_entry_points':0}
            # Retain the immutable staged ledger before activation; it cannot self-hash.
            staged_snapshot=harness/'artifacts/installation/evidence/staged-record.json'
            shutil.copyfile(harness/'artifacts/installation/installation-record.yaml',staged_snapshot)
            staged_snapshot_hash=digest(staged_snapshot)
            record['extensions']['prior_snapshot']={'reference':{'kind':'LOCAL','scope':'HARNESS','path':'artifacts/installation/evidence/staged-record.json'},'provenance':'REVIEW','summary':'Preserved staged ledger before activation.','identity':staged_snapshot_hash}
            # Load only the separately reviewed installed entry point, then reread it.
            self.assertEqual(digest(harness/'README.md'),record['entry_point']['candidate']['before_identity'])
            self.assertEqual((repo/'AGENTS.md').read_bytes(), root_instruction_bytes)
            self.assertEqual(digest(harness/'README.md'),record['entry_point']['candidate']['content_identity'])
            record['entry_point'].update(activation_state='ACTIVE',evidence_refs=[evidence])
            self.assertIsNone(record['completed_at'])
            self.assertEqual(next(a for a in record['criterion_assessments'] if a['criterion_id']=='IS-08.provenance')['result'],'PENDING')
            dump(harness/'artifacts/installation/installation-record.yaml',record)
            self.assertFalse((repo/'builder-kit').exists())
            # Negative branch: actual missing file after activation cannot yield completeness.
            failed_harness=repo/'failed-reread/.harness'
            shutil.copytree(harness,failed_harness)
            (failed_harness/'framework/workflows/development/workflow.yaml').unlink()
            missing=[rel for rel in catalogue['extensions']['required_runtime_files'] if not (failed_harness/rel).is_file()]
            self.assertEqual(missing,['framework/workflows/development/workflow.yaml'])
            failed_record=copy.deepcopy(record)
            next(a for a in failed_record['criterion_assessments'] if a['criterion_id']=='IS-08.provenance').update(result='FAIL',reason='Actual reread missing framework/workflows/development/workflow.yaml; completion withheld.')
            validator('records.schema.json','InstallationRecord').validate(failed_record)
            dump(failed_harness/'artifacts/installation/installation-record.yaml',failed_record)
            self.assertIsNone(failed_record['completed_at'])
            self.assertEqual(yaml.safe_load((failed_harness/'framework/config/repo-profile.yaml').read_text())['configuration_id'],'cfg-1')
            observed['post_activation_failure']={'missing':missing,'structure':'INCOMPLETE','completed_at':failed_record['completed_at'],'published_configuration':'cfg-1','final_publication_performed':False}
            # Actual successful reread: capture observed dependency bytes before final assessment.
            dependency_hashes={rel:digest(harness/rel) for rel in catalogue['extensions']['required_runtime_files'] if rel not in ['artifacts/installation/installation-record.yaml','docs/setup.md','framework/config/repo-profile.yaml']}
            for rel,identity in dependency_hashes.items():
                self.assertEqual(identity,next(e['after_identity'] for e in record['generated_paths'] if e['path']==rel))
            for source in profile['repository']['instruction_files']:
                self.assertEqual(digest(repo/source['reference']['path']),source['identity'])
            for source in profile['capabilities']['build']['evidence_refs']:
                self.assertEqual(digest(repo/source['reference']['path']),source['identity'])
            active_before=digest(harness/'framework/config/repo-profile.yaml')
            base_profile=copy.deepcopy(profile)
            dump(harness/'artifacts/installation/evidence/activated-cfg1-profile.json',base_profile)
            reread_path=harness/'artifacts/installation/evidence/post-activation-reread.json'
            dump(reread_path,{'observed_configuration_id':'cfg-1','profile_identity':active_before,'entry_point_identity':digest(harness/'README.md'),'dependency_hashes':dependency_hashes,'history_identity':digest(harness/'development/runs/old-task/evidence.txt'),'builder_present':False})
            reread_evidence={'reference':{'kind':'LOCAL','scope':'HARNESS','path':reread_path.relative_to(harness).as_posix()},'provenance':'REVIEW','summary':'Observed post-activation cfg-1 bytes, explicit installed entry point, installed dependencies and preserved history.','identity':digest(reread_path)}
            # Revalidate dependencies for prospective cfg-2; only assessment/revision fields change.
            revalidation_path=harness/'artifacts/installation/evidence/cfg2-dependency-review.json'
            dump(revalidation_path,{'inspected_configuration_id':'cfg-1','prospective_configuration_id':'cfg-2','changed_profile_fields':['configuration_revision','configuration_id','assessments'],'unchanged_definition_hashes':dependency_hashes,'unchanged_profile_fields':[k for k in profile if k not in ['configuration_revision','configuration_id','assessments']],'source_and_instruction_identities':profile['repository']['instruction_files'],'reason':'Actual reread establishes activation; compare every unchanged field and dependency before carrying prior reviews to prospective cfg-2.'})
            carry_evidence={'reference':{'kind':'LOCAL','scope':'HARNESS','path':revalidation_path.relative_to(harness).as_posix()},'provenance':'REVIEW','summary':'Explicit dependency revalidation from observed cfg-1 to prospective cfg-2.','identity':digest(revalidation_path)}
            profile.update(configuration_id='cfg-2',configuration_revision=2)
            for assessment in profile['assessments']:
                assessment['assessed_configuration_id']='cfg-2'
                assessment['evidence_refs'].append(copy.deepcopy(carry_evidence))
                if assessment['criterion_id']=='IS-08.provenance':
                    assessment.update(result='PASS',reason='Actual activation/reread observed; dependencies revalidated for prospective cfg-2.',evidence_refs=[copy.deepcopy(reread_evidence),copy.deepcopy(carry_evidence)])
            self.assertEqual({k for k in profile if profile[k]!=base_profile[k]}, {'configuration_revision','configuration_id','assessments'})
            for rel,identity in dependency_hashes.items():self.assertEqual(digest(harness/rel),identity)
            self.assertEqual(digest(harness/'framework/config/repo-profile.yaml'),active_before)
            self.assertEqual(digest(harness/'README.md'),record['entry_point']['candidate']['content_identity'])
            validator('profile.schema.json').validate(profile)
            candidate_profile=harness/'artifacts/installation/evidence/reviewed-cfg2-profile.json'
            dump(candidate_profile,profile)
            expected_final_hash=digest(candidate_profile)
            (harness/'framework/config/repo-profile.yaml').write_bytes(candidate_profile.read_bytes())
            # External final receipt confirms publication without mutating profile or relabelling evidence.
            self.assertEqual(digest(harness/'framework/config/repo-profile.yaml'),expected_final_hash)
            final_profile=yaml.safe_load((harness/'framework/config/repo-profile.yaml').read_text())
            self.assertEqual(final_profile['configuration_id'],'cfg-2')
            self.assertEqual({a['assessed_configuration_id'] for a in final_profile['assessments']},{'cfg-2'})
            self.assertTrue(all(a['result']=='PASS' for a in final_profile['assessments'] if a['criterion_id'] in structural_ids))
            for rel,identity in dependency_hashes.items():self.assertEqual(digest(harness/rel),identity)
            receipt_path=harness/'artifacts/installation/evidence/final-publication.json'
            dump(receipt_path,{'inspected_configuration_id':'cfg-1','assessed_configuration_id':'cfg-2','before_identity':active_before,'candidate_identity':expected_final_hash,'published_identity':digest(harness/'framework/config/repo-profile.yaml'),'entry_point_identity':digest(harness/'README.md'),'dependency_hashes':dependency_hashes,'result':'MATCH'})
            record['criterion_assessments']=copy.deepcopy(final_profile['assessments'])
            record['extensions']['final_publication_receipt']={'reference':{'kind':'LOCAL','scope':'HARNESS','path':receipt_path.relative_to(harness).as_posix()},'provenance':'REVIEW','summary':'Final cfg-2 exact bytes and dependencies reread against the reviewed candidate.','identity':digest(receipt_path)}
            (harness/'docs/setup.md').write_text('Configuration cfg-2 revision 2. STRUCTURE_COMPLETE after actual reread and final byte comparison. default PARTIAL; test PENDING_DISCOVERY.\n')
            for entries in [record['generated_paths'],record['owned_paths']]:
                for entry in entries:
                    if entry['path'] in ['framework/config/repo-profile.yaml','docs/setup.md']:entry['after_identity']=digest(harness/entry['path'])
            record['completed_at']=STAMP
            validator('records.schema.json','InstallationRecord').validate(record)
            self.assertEqual(digest(staged_snapshot),staged_snapshot_hash)
            self.assertEqual(next(a for a in yaml.safe_load(staged_snapshot.read_text())['criterion_assessments'] if a['criterion_id']=='IS-08.provenance')['result'],'PENDING')
            dump(harness/'artifacts/installation/installation-record.yaml',record)
            observed['S-01'].update(structure='STRUCTURE_COMPLETE after activation, reread, dependency review and final cfg-2 byte comparison',final_configuration_id='cfg-2',final_revision=2,final_provenance='PASS')
            # Instantiate development state and maintenance update solely from target templates.
            task=yaml.safe_load((harness/'framework/templates/development/task-state.yaml').read_text())
            task.update(configuration_id=profile['configuration_id'],task_id='new-task',input_snapshot=digest(repo/'AGENTS.md'),selected_targets=copy.deepcopy(profile['workflow_profiles'][0]['required_targets']))
            request_path=harness/'artifacts/installation/evidence/new-task-request.txt'
            request_path.write_text('Synthetic request: initialize a default-profile task; no execution authorized.\n')
            task['accepted_identities']['request']=digest(request_path)
            task['evidence_refs']=[copy.deepcopy(evidence)]
            validator('records.schema.json','TaskState').validate(task)
            self.assertEqual(task['selected_targets'],profile['workflow_profiles'][0]['required_targets'])
            dump(harness/'development/runs/new-task/state.yaml',task)
            update=yaml.safe_load((harness/'framework/templates/maintenance/harness-update-record.yaml').read_text())
            update_request=harness/'artifacts/installation/evidence/new-update-request.txt'
            update_request.write_text('Synthetic request: inspect replacement build adapter; no publication authorized.\n')
            update.update(update_id='new-update',request_type='ADAPTER_CHANGE',request_identity=digest(update_request))
            update['current'].update(update_id='new-update',inspected_configuration_id='cfg-2',prospective_configuration_id='cfg-3')
            update['current']['promotion']['before_configuration_id']='cfg-2'
            update['current']['promotion']['result']='PENDING'
            update['events'][0].update(subject_id='new-update',request_id='initialize-update',request_content_identity=digest(update_request),post_state=copy.deepcopy(update['current']))
            # Materialize initialization decisions and an authoritative task event from installed templates.
            log=yaml.safe_load((harness/'framework/templates/development/event-log.yaml').read_text())
            log['subject_id']='new-task'
            log['events'][0].update(subject_id='new-task',request_id='initialize-task',request_content_identity=digest(request_path),post_state=copy.deepcopy(task))
            for label,event,destination in [('task',log['events'][0],'NEW'),('update',update['events'][0],'REQUESTED')]:
                decision=yaml.safe_load((harness/'framework/templates/development/gate-decision.yaml').read_text())
                decision.update(request_id=event['request_id'],decision='ALLOW',proposed_destination=destination,resolution_route=None,rule_findings=[{'rule_id':r,'result':'PASS','reason':'Synthetic initialization: unique subject/version 0 to 1, validated shape, procedural writer and retained request. No dispatch or progression authorized.','evidence_refs':[copy.deepcopy(evidence)]} for r in ['RULE-01','RULE-02','RULE-11']])
                validator('records.schema.json','GateDecision').validate(decision)
                path=harness/('artifacts/installation/evidence/initialize-'+label+'-decision.json')
                dump(path,decision)
                event['decision_ref']={'reference':{'kind':'LOCAL','scope':'HARNESS','path':path.relative_to(harness).as_posix()},'provenance':'REVIEW','summary':'Actual synthetic initialization decision; no production action.','identity':digest(path)}
            validator('records.schema.json','EventLog').validate(log)
            dump(harness/'development/runs/new-task/events.yaml',log)
            self.assertEqual(log['events'][-1]['post_state'],task)
            self.assertEqual(update['events'][-1]['post_state'],update['current'])
            validator('records.schema.json','UpdateRecord').validate(update)
            dump(harness/'maintenance/updates/new-update.yaml',update)
            maintenance=yaml.safe_load((harness/'framework/workflows/maintenance/maintenance-workflow.yaml').read_text())
            trace={}
            for request_type,finish in [('ADAPTER_CHANGE','PROMOTED'),('MIGRATION','PROMOTED')]:
                selector=maintenance['extensions']['request_type_profiles'][request_type]
                route=['REQUESTED','INSPECTED','PLANNED','STAGED', 'ADAPTER_COMPATIBLE' if request_type=='ADAPTER_CHANGE' else 'MIGRATION_CHECKED','PROMOTED']
                edges=[]
                for a,b in zip(route,route[1:]):
                    matches=[e for e in maintenance['transitions'] if e['from']==a and e['to']==b and selector in e['profiles']]
                    self.assertEqual(len(matches),1,(request_type,a,b))
                    edges.append({'id':matches[0]['id'],'from':a,'to':b,'rules':matches[0]['rule_ids']})
                trace[request_type]=edges
            # Approval is an explicit review input for migration, never inferred by the edge walk.
            dump(harness/'artifacts/installation/evidence/builder-absent-traces.json',{'provenance':'REVIEW','routes':trace,'migration_approval':'Synthetic scoped approval required for exact candidate/base before last edge; this trace performs no publication.'})
            self.assertFalse((harness/'framework/workflows/conformance-cases.yaml').exists())
            self.assertFalse((harness/'framework/templates/schemas/conformance.schema.json').exists())
            observed['S-08']={'builder_present':False,'required_runtime_files':len(record['generated_paths']),'generated_paths_without_root_writes':len(record['generated_paths']),'project_cases_installed':False,'development_state':task['state'],'maintenance_state':update['current']['state'],'routes':trace,'history_preserved':digest(harness/'development/runs/old-task/evidence.txt')==old_history_hash,'publication_performed':False}
            observed['S-46']={'prerequisite_scenarios':['interpreter absent','dependency absent'],'checker':'UNAVAILABLE in hypothetical unavailable branches','actual_checker_invocations':0,'download_attempts':0,'manual_path':'18 actual definition reviews; no automatic completeness from covered checks'}
            print('TASK4_OBSERVED '+json.dumps(observed,sort_keys=True))

if __name__ == '__main__':
    unittest.main()
