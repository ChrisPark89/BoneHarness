"""Status precedence and supplied-assessment integrity."""
from copy import deepcopy
import importlib
from pathlib import Path
import sys
import unittest
from support import configured_profile_fixture, criteria_catalogue_fixture, EVIDENCE, record
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'builder-kit/checker'))

class AssessmentTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((Path(__file__).resolve().parents[1] / 'builder-kit/checker/harness_check/assessment.py').exists(), 'aggregator not implemented')
        self.summarize = importlib.import_module('harness_check.assessment').summarize
        self.catalogue = criteria_catalogue_fixture()
        self.profile = configured_profile_fixture()
        self.profile['capabilities']['build']['compatibility'] = 'COMPATIBLE'
        self.profile['workflow_profiles'][0]['required_targets'] = [{'target_id':'default','environment':'local'}]

    def claim(self, cid='IS-01.1', **kw):
        return record('CriterionAssessment', catalogue_version='1.0.0', criterion_id=cid,
                      result='PASS', method='AUTOMATED', actor='test', evidence_refs=[deepcopy(EVIDENCE)],
                      reason='Observed complete obligation', assessed_configuration_id='cfg-1', **kw)

    def integration(self, pid='default', cap='build', target='default'):
        cid = 'II-' + '-'.join('x' + x.encode().hex() for x in (pid,cap,target))
        self.catalogue['criteria'].append(dict(id=cid,category='INTEGRATION',required=True,
            description='compatibility',allowed_methods=['AUTOMATED','LLM_REVIEW'],applicability_rule=None,scenario_ids=['S-09']))
        self.catalogue.setdefault('extensions',{}).setdefault('integration_instances',[]).append(dict(criterion_id=cid,profile_id=pid,capability_id=cap,target_id=target,environment='local'))
        return cid

    def test_mixed_shape_pass_pending_review_remains_incomplete(self):
        self.catalogue['criteria'].append(dict(self.catalogue['criteria'][0],id='IS-review',allowed_methods=['HUMAN_REVIEW']))
        result = self.summarize(self.catalogue,[self.claim()],self.profile)
        self.assertEqual(result['structure_assessment'],'INCOMPLETE')
        self.assertEqual(result['integration_assessment'],'NOT_ASSESSED')

    def test_invalid_pass_duplicate_unknown_method_stale_and_na(self):
        for patch in [{'evidence_refs':[]},{'actor':None},{'method':'HUMAN_REVIEW'},
                      {'assessed_configuration_id':'cfg-0'},{'catalogue_version':'0'},
                      {'result':'NOT_APPLICABLE'},{'criterion_id':'unknown'}]:
            with self.subTest(patch=patch):
                a=self.claim(); a.update(patch)
                r=self.summarize(self.catalogue,[a],self.profile)
                self.assertEqual(r['structure_assessment'],'INCOMPLETE'); self.assertTrue(r['diagnostics'])
        r=self.summarize(self.catalogue,[self.claim(),self.claim()],self.profile)
        self.assertEqual(r['structure_assessment'],'INCOMPLETE'); self.assertTrue(r['diagnostics'])

    def test_integration_precedence_ready_partial_unassessed_blocked(self):
        cid=self.integration(); claim=self.claim(cid)
        r=self.summarize(self.catalogue,[claim],self.profile)
        self.assertEqual(r['integration_assessment'],'READY')
        self.profile['workflow_profiles'].append(dict(self.profile['workflow_profiles'][0],id='other'))
        self.assertEqual(self.summarize(self.catalogue,[claim],self.profile)['integration_assessment'],'PARTIAL')
        other=self.integration('other'); blocked=self.claim(other); blocked['result']='BLOCKED'
        self.assertEqual(self.summarize(self.catalogue,[claim,blocked],self.profile)['integration_assessment'],'BLOCKED')
        self.assertEqual(self.summarize(self.catalogue,[],self.profile)['integration_assessment'],'NOT_ASSESSED')

    def test_pending_unavailable_needs_review_override_pass(self):
        cid=self.integration()
        for field,value in [('configuration_status','UNAVAILABLE'),('compatibility','NEEDS_REVIEW'),('compatibility','INCOMPATIBLE')]:
            p=deepcopy(self.profile);p['capabilities']['build'][field]=value
            self.assertEqual(self.summarize(self.catalogue,[self.claim(cid)],p)['integration_assessment'],'PARTIAL')

    def test_tuple_collision_wrong_environment_and_missing_instance(self):
        cid=self.integration('default','build','default')
        self.catalogue['extensions']['integration_instances'][0]['environment']='wrong'
        r=self.summarize(self.catalogue,[self.claim(cid)],self.profile)
        self.assertNotEqual(r['integration_assessment'],'READY');self.assertTrue(r['diagnostics'])

    def test_execution_obligation_cannot_use_fixture_or_review_assertion(self):
        self.catalogue['criteria'][0]['extensions']={'required_provenance':'EXECUTION'}
        r=self.summarize(self.catalogue,[self.claim()],self.profile)
        self.assertEqual(r['structure_assessment'],'INCOMPLETE')
        self.assertTrue(r['diagnostics'])

    def test_optional_unused_tuple_cannot_block_supported_profile(self):
        required=self.integration();optional=self.integration('default','optional','default')
        block=self.claim(optional);block['result']='BLOCKED'
        r=self.summarize(self.catalogue,[self.claim(required),block],self.profile)
        self.assertEqual(r['integration_assessment'],'READY')

    def test_duplicate_criterion_definition_cannot_complete(self):
        self.catalogue['criteria'].append(deepcopy(self.catalogue['criteria'][0]))
        self.assertEqual(self.summarize(self.catalogue,[self.claim()],self.profile)['structure_assessment'],'INCOMPLETE')
