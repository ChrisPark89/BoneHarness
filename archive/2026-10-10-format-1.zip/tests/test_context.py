"""Read-only focused guidance checks; these tests are not installed in a harness."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from support import fixtures, SCHEMAS

FRAMEWORK = SCHEMAS.parents[1]
sys.path.insert(0, str(FRAMEWORK / 'tools'))
from context_reader import extract_context, context_page
from harness_io.journal import append_record, canonical_json, content_identity, publish_state
from harness_io.loader import parse_document


class ContextTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix='context ü ')
        self.addCleanup(temp.cleanup)
        self.repo = Path(temp.name).resolve()
        self.harness = self.repo / '.harness'
        shutil.copytree(FRAMEWORK, self.harness / 'framework', ignore=shutil.ignore_patterns('__pycache__'))

    def extract(self, **kwargs):
        return extract_context(str(self.repo), **kwargs)

    def task(self):
        """Small consistent NEW task, with captured guides and no execution claims."""
        files = [('PROFILE', 'config/repo-profile.yaml'), ('WORKFLOW', 'workflows/development/workflow.yaml'),
                 ('RULES', 'workflows/verification-rules.md'), ('SUPPORT', 'workflows/development/HARNESS.md'),
                 ('SUPPORT', 'workflows/recovery.md')]
        files += [('SCHEMA', p.relative_to(FRAMEWORK).as_posix()) for p in sorted(SCHEMAS.glob('*.json'))]
        mapping = {path: content_identity((FRAMEWORK / path).read_bytes()) for _, path in files}
        bundle = content_identity(canonical_json(mapping)).split(':')[1]
        config = fixtures()['ConfigSnapshot']
        config['captured_definitions'] = []
        for kind, path in files:
            target = self.harness / 'artifacts/configurations' / bundle / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((FRAMEWORK / path).read_bytes())
            config['captured_definitions'].append(dict(kind=kind,
                reference=dict(kind='LOCAL', scope='HARNESS', path='framework/' + path),
                identity=mapping[path], captured_path=target.relative_to(self.harness).as_posix()))
        history = self.harness / 'artifacts/development/task-1/history.jsonl'
        history.parent.mkdir(parents=True)
        schemas = self.harness / 'framework/templates/schemas'
        append_record(history, 'task-1', 'configuration', config, schemas)
        decision = fixtures()['GateDecision']
        decision.update(decision='ALLOW', proposed_destination='NEW', resolution_route=None)
        saved = append_record(history, 'task-1', 'initialize-decision', decision, schemas)
        event = fixtures()['Event']
        event['decision_ref'] = dict(reference=dict(kind='LOCAL', scope='HARNESS',
            path=history.relative_to(self.harness).as_posix(), entry_id='initialize-decision'),
            provenance='REVIEW', summary='Procedural initialization only', identity=saved['payload_identity'])
        append_record(history, 'task-1', 'initialize-event', event, schemas)
        publish_state(history, 'task-1', schemas)

    def test_setup_selects_complete_criterion_and_contracts(self):
        context = self.extract(situation='setup', criterion='IS-01.files')
        self.assertNotEqual('UNAVAILABLE', context['purpose'], context['diagnostics'])
        self.assertEqual(['IS-01.files'], [i['value']['id'] for i in context['items'] if i['kind'] == 'setup_criterion'])
        self.assertTrue(any(i['kind'] == 'setup_contract' for i in context['items']))

    def test_unknown_criterion_and_malformed_profile_are_explicit(self):
        self.assertEqual('UNAVAILABLE', self.extract(situation='setup', criterion='unknown')['purpose'])
        (self.harness / 'framework/config/repo-profile.yaml').write_text('{broken')
        self.assertEqual('UNAVAILABLE', self.extract(situation='setup')['purpose'])

    def test_task_uses_captured_configuration_after_live_profile_changes(self):
        self.task()
        before = self.extract(task_id='task-1')
        self.assertNotEqual('UNAVAILABLE', before['purpose'], before['diagnostics'])
        self.assertEqual('NEW', before['state'])
        (self.harness / 'framework/config/repo-profile.yaml').write_text('{broken')
        after = self.extract(task_id='task-1')
        self.assertEqual(before['context_id'], after['context_id'])

    def test_selected_transition_has_criteria_rules_and_no_authority(self):
        self.task()
        overview = self.extract(task_id='task-1')
        edges = next(i['value'] for i in overview['items'] if i['kind'] == 'candidate_transitions')
        edge = next(e['id'] for e in edges if e['to'] == 'BASELINED')
        context = self.extract(task_id='task-1', transition=edge)
        self.assertNotEqual('UNAVAILABLE', context['purpose'], context['diagnostics'])
        self.assertTrue(any(i['kind'] == 'stage_criterion' for i in context['items']))
        self.assertTrue(any(i['kind'] == 'required_rule' for i in context['items']))
        self.assertIn('not gate approval', context_page(context)['notice'])
        self.assertEqual('UNAVAILABLE', self.extract(task_id='task-1', transition='invented')['purpose'])

    def test_recovery_and_record_reference_read_saved_history(self):
        self.task()
        recovery = self.extract(situation='recovery', task_id='task-1')
        self.assertNotEqual('UNAVAILABLE', recovery['purpose'], recovery['diagnostics'])
        self.assertIn('RULE-11', recovery['required_sections'])
        record = self.extract(task_id='task-1', record_id='initialize-decision')
        self.assertEqual('REFERENCE_ONLY', record['purpose'])
        self.assertEqual('GateDecision', record['items'][0]['value']['record_type'])

    def test_state_mismatch_cannot_select_next_action(self):
        self.task()
        path = self.harness / 'artifacts/development/task-1/state.json'
        state = json.loads(path.read_text())
        state['state'] = 'COMPLETE'
        path.write_text(json.dumps(state))
        context = self.extract(task_id='task-1')
        self.assertEqual('UNAVAILABLE', context['purpose'])
        self.assertEqual([], context['items'])

    def test_recovery_preserves_uncertain_dispatch_details(self):
        self.task()
        invocation = fixtures()['Invocation']
        history = self.harness / 'artifacts/development/task-1/history.jsonl'
        append_record(history, 'task-1', 'initial-intent', invocation,
                      self.harness / 'framework/templates/schemas')
        invocation['dispatch_status'] = 'DISPATCH_UNRESOLVED'
        append_record(history, 'task-1', 'uncertain-call', invocation,
                      self.harness / 'framework/templates/schemas')
        context = self.extract(situation='recovery', task_id='task-1')
        self.assertNotEqual('UNAVAILABLE', context['purpose'], context['diagnostics'])
        actions = [i['value'] for i in context['items'] if i['kind'] == 'saved_action']
        self.assertEqual([invocation], actions)
        self.assertIn('RULE-12', context['required_sections'])

    def test_maintenance_stale_base_blocks_action_selection(self):
        update = fixtures()['UpdateRecord']
        path = self.harness / 'artifacts/maintenance/update-1/update.yaml'
        path.parent.mkdir(parents=True)
        profile_path = self.harness / 'framework/config/repo-profile.yaml'
        profile = parse_document(profile_path.read_bytes(), profile_path)
        update['current']['inspected_configuration_id'] = profile['configuration_id']
        update['events'][-1]['post_state'] = update['current']
        path.write_text(json.dumps(update))
        context = self.extract(situation='maintenance', update_id='update-1')
        self.assertNotEqual('UNAVAILABLE', context['purpose'], context['diagnostics'])
        edges = next(i['value'] for i in context['items'] if i['kind'] == 'candidate_transitions')
        self.assertTrue(edges)
        edge = edges[0]['id']
        self.assertNotEqual('UNAVAILABLE', self.extract(situation='maintenance', update_id='update-1', transition=edge)['purpose'])
        update['current']['inspected_configuration_id'] = 'cfg-999'
        path.write_text(json.dumps(update))
        context = self.extract(situation='maintenance', update_id='update-1', transition=edge)
        self.assertEqual('UNAVAILABLE', context['purpose'])
        self.assertIn('UPDATE_BASE_DIFFERS', [d['code'] for d in context['diagnostics']])

    def test_every_setup_criterion_has_available_context(self):
        overview = self.extract(situation='setup')
        index = next(i['value'] for i in overview['items'] if i['kind'] == 'setup_index')
        for row in index:
            with self.subTest(criterion=row['id']):
                context = self.extract(situation='setup', criterion=row['id'])
                self.assertNotEqual('UNAVAILABLE', context['purpose'], context['diagnostics'])

    def test_continuation_preserves_content_and_rejects_changed_context(self):
        context = self.extract(situation='setup', criterion='IS-01.files')
        first = context_page(context)
        self.assertGreater(first['pages'], 1)
        pages = [context_page(context, n, expected_context_id=first['context_id']) for n in range(1, first['pages'] + 1)]
        self.assertIsNone(pages[-1]['next_page'])
        for page in pages:
            self.assertLessEqual(sum(len(i['text'].split()) for i in page['content']), 250)
        with self.assertRaisesRegex(ValueError, 'Context changed'):
            context_page(context, 2, expected_context_id='different')
        for item in context['items']:
            selected = [b['text'] for page in pages for b in page['content'] if b['kind'] == item['kind'] and b['source'] == item['source']]
            expected = item['value'] if isinstance(item['value'], str) else json.dumps(item['value'], ensure_ascii=False, indent=2)
            self.assertEqual(''.join(expected.split()), ''.join(''.join(selected).split()))

    def test_cli_is_read_only_and_produces_parseable_pages(self):
        def fingerprint():
            return {p.relative_to(self.repo).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in self.repo.rglob('*') if p.is_file()}
        before = fingerprint()
        result = subprocess.run([sys.executable, '-B', str(self.harness / 'framework/tools/context.py'),
            '--repo-root', str(self.repo), '--situation', 'setup', '--format', 'json'], capture_output=True, text=True)
        self.assertEqual(0, result.returncode, result.stderr + result.stdout)
        self.assertEqual('OVERVIEW', json.loads(result.stdout)['purpose'])
        self.assertEqual(before, fingerprint())

    def test_invalid_selector_combinations_and_paths_are_rejected(self):
        for args in [dict(situation='recovery'), dict(task_id='../escape'),
                     dict(situation='maintenance', task_id='task-1'), dict(record_id='entry'),
                     dict(situation='setup', criterion='IS-01.files', contract='evidence_contract')]:
            with self.subTest(args=args):
                self.assertEqual('UNAVAILABLE', self.extract(**args)['purpose'])


if __name__ == '__main__':
    unittest.main()
