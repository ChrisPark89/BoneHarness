"""Local source snapshots and their integration into the existing reporter."""
from copy import deepcopy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from support import fixtures, HASH, SCHEMAS
import test_journal_reporting

sys.path.insert(0, str(SCHEMAS.parents[1] / 'tools'))
from harness_io.source_inventory import capture_inventory, collect_files, source_scope, validate_inventory
from harness_io.journal import content_identity, publish_state
from harness_io.loader import DocumentError
from reporting.evidence import capture_task, check_unchanged
from reporting.summary import derive_report
from reporting.render import template_parts


class SourceInventoryTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix='source scope ü ')
        self.addCleanup(temp.cleanup)
        self.repo = Path(temp.name).resolve()
        self.harness = self.repo / '.harness'
        self.harness.mkdir()
        (self.repo / 'src').mkdir()
        self.file = self.repo / 'src/a.js'
        self.file.write_text('export const answer = 42;\n')
        self.scope = dict(roots=['src'], exclude=[])

    def capture(self):
        return capture_inventory(self.repo, self.harness, 'task-1', self.scope)

    def test_stable_capture_is_read_only_and_valid(self):
        before = {p: p.read_bytes() for p in self.repo.rglob('*') if p.is_file()}
        first = self.capture()
        self.assertEqual(first, self.capture())
        self.assertEqual(self.scope, validate_inventory(first))
        self.assertEqual(before, {p: p.read_bytes() for p in self.repo.rglob('*') if p.is_file()})

    def test_changes_additions_and_deletions_change_identity(self):
        original = self.capture()
        self.file.write_text('changed')
        self.assertNotEqual(original['revision'], self.capture()['revision'])
        (self.repo / 'src/new.js').write_text('new')
        added = self.capture()
        self.assertEqual(2, len(added['files']))
        self.file.unlink()
        self.assertNotEqual(added['revision'], self.capture()['revision'])

    def test_comparison_accepts_empty_and_missing_scope_but_capture_refuses(self):
        self.file.unlink()
        self.assertEqual([], collect_files(self.repo, self.harness, self.scope, allow_missing=True))
        with self.assertRaises(DocumentError):
            self.capture()
        (self.repo / 'src').rmdir()
        self.assertEqual([], collect_files(self.repo, self.harness, self.scope, allow_missing=True))
        with self.assertRaises(DocumentError):
            self.capture()

    def test_explicit_exclusions_are_stable(self):
        self.scope['exclude'] = ['src/generated']
        first = self.capture()
        (self.repo / 'src/generated').mkdir()
        (self.repo / 'src/generated/out.js').write_text('ignored')
        self.assertEqual(first, self.capture())

    def test_unsafe_and_ambiguous_scopes_are_rejected(self):
        for scope in [dict(roots=['../outside'], exclude=[]), dict(roots=['src','src/a.js'], exclude=[]),
                      dict(roots=['src'], exclude=['elsewhere']), dict(roots=['src/*'], exclude=[]),
                      dict(roots=[], exclude=[])]:
            with self.subTest(scope=scope), self.assertRaises(DocumentError):
                source_scope(scope)
        self.scope = dict(roots=['.'], exclude=[])
        with self.assertRaises(DocumentError):
            self.capture()

    def test_external_symlink_is_not_read(self):
        with tempfile.TemporaryDirectory() as temp:
            outside = Path(temp) / 'secret'
            outside.write_text('outside scope')
            (self.repo / 'src/link').symlink_to(outside)
            with self.assertRaises(DocumentError):
                self.capture()

    def test_bad_digest_and_duplicate_paths_are_rejected(self):
        inventory = self.capture()
        inventory['revision'] = HASH
        with self.assertRaises(DocumentError):
            validate_inventory(inventory)
        inventory = self.capture()
        inventory['files'].append(deepcopy(inventory['files'][0]))
        with self.assertRaises(DocumentError):
            validate_inventory(inventory)

    def test_cli_returns_parseable_record_and_explicit_error(self):
        command = [sys.executable, '-B', str(SCHEMAS.parents[1] / 'tools/source.py'),
                   '--repo-root', str(self.repo), '--task-id', 'task-1', '--root', 'src']
        completed = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(0, completed.returncode, completed.stderr)
        self.assertEqual(self.capture(), json.loads(completed.stdout))
        failed = subprocess.run(command[:-1] + ['../outside'], capture_output=True, text=True)
        self.assertEqual(2, failed.returncode)
        self.assertIn('SOURCE_INVENTORY_UNAVAILABLE', failed.stderr)


class SourceReportTests(unittest.TestCase):
    def setUp(self):
        self.fixture = test_journal_reporting.JournalReportingTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.repo, self.harness = self.fixture.repo, self.fixture.harness
        (self.repo / 'src').mkdir()
        self.source = self.repo / 'src/a.js'
        self.source.write_text('export const answer = 42;\n')
        self.scope = dict(roots=['src'], exclude=[])
        self.inventory = capture_inventory(self.repo, self.harness, 'task-1', self.scope)

    def prepare(self, *, missing=False, late=False, different_scope=False):
        f = self.fixture
        f.history.unlink()
        (f.run / 'state.json').unlink()
        f.append('configuration', f.configuration)
        if not missing and not late:
            f.append('source-inventory', self.inventory)
        spec = fixtures()['TaskSpec']
        spec['extensions'] = {'source_scope': dict(roots=['other'], exclude=[]) if different_scope else self.scope}
        evidence = dict(reference=dict(kind='LOCAL', scope='HARNESS', path='docs/development/task-1/spec.md'),
                        provenance='REVIEW', summary='Test fixture review only',
                        identity=content_identity((f.docs / 'spec.md').read_bytes()))
        spec['acceptance_authority']['evidence_refs'] = [evidence]
        f.append('specification', spec)
        decision = fixtures()['GateDecision']
        decision.update(decision='ALLOW', proposed_destination='NEW', resolution_route=None)
        saved = f.append('initialize-decision', decision)
        event = fixtures()['Event']
        event['decision_ref'] = dict(reference=f.ref('initialize-decision'), provenance='REVIEW',
                                    summary='Test initialization', identity=saved['payload_identity'])
        event['post_state']['accepted_identities'].update(specification=HASH, design=HASH)
        event['post_state']['input_snapshot'] = self.inventory['revision']
        f.append('initialize-event', event)
        if late:
            f.append('source-inventory', self.inventory)
        review = fixtures()['CriterionReview']
        review['revision'] = self.inventory['revision']
        review['criteria'][0]['evidence_refs'] = [evidence]
        f.append('review', review)
        publish_state(f.history, 'task-1', f.schemas)

    def capture(self):
        return capture_task(self.repo, self.harness, 'task-1')

    def inventory_check(self, capture):
        return next(r for r in capture['coverage']['checks'] if r['check_id'] == 'source_content_inventory')

    def test_matching_source_is_checked_without_claiming_completion(self):
        self.prepare()
        capture = self.capture()
        self.assertEqual('CHECKED', self.inventory_check(capture)['status'], capture['diagnostics'])
        self.assertNotIn('REPORT_SOURCE_CONTENT_MISMATCH', [d['code'] for d in capture['diagnostics']])
        report = derive_report(capture, generated_at='2026-10-08T12:00:00Z')
        self.assertEqual('NOT_RECORDED_COMPLETE', report['completion_support'])
        self.assertEqual([], check_unchanged(capture))

    def test_changed_added_and_deleted_sources_stale_evidence(self):
        self.prepare()
        original = self.source.read_bytes()
        actions = ('changed', 'added', 'deleted', 'root-deleted')
        for action in actions:
            with self.subTest(action=action):
                self.source.parent.mkdir(exist_ok=True)
                self.source.write_bytes(original)
                extra = self.source.parent / 'new.js'
                extra.unlink(missing_ok=True)
                if action == 'changed': self.source.write_text('changed')
                elif action == 'added': extra.write_text('new')
                elif action == 'deleted': self.source.unlink()
                else: shutil.rmtree(self.source.parent)
                capture = self.capture()
                self.assertEqual('CHECKED', self.inventory_check(capture)['status'])
                self.assertIn('REPORT_SOURCE_CONTENT_MISMATCH', [d['code'] for d in capture['diagnostics']])
                reviews = [r for rows in capture['record_index']['CriterionReview'].values() for r in rows]
                self.assertFalse(reviews[0]['valid'])
                self.assertIn('REPORT_EVIDENCE_STALE', reviews[0]['diagnostic_codes'])

    def test_missing_inventory_remains_unchecked(self):
        self.prepare(missing=True)
        self.assertEqual('UNCHECKED', self.inventory_check(self.capture())['status'])

    def test_different_scope_remains_unchecked(self):
        self.prepare(different_scope=True)
        check = self.inventory_check(self.capture())
        self.assertEqual('UNCHECKED', check['status'])
        self.assertIn('scope differs', ' '.join(check['limitations']))

    def test_late_inventory_cannot_retroactively_support_execution(self):
        self.prepare(late=True)
        check = self.inventory_check(self.capture())
        self.assertEqual('UNCHECKED', check['status'])
        self.assertIn('recorded after', ' '.join(check['limitations']))

    def test_changes_after_capture_are_detected_before_publication(self):
        self.prepare()
        capture = self.capture()
        (self.source.parent / 'new.js').write_text('new')
        self.assertIn('REPORT_SOURCE_CHANGED', [d['code'] for d in check_unchanged(capture)])

    def test_report_cli_publishes_matching_and_stale_source_diagnostics(self):
        self.prepare()
        first = self.fixture.report()
        self.assertEqual(1, first.returncode, first.stdout + first.stderr)
        report = json.loads((self.fixture.run / 'report.json').read_text())
        self.assertEqual('CHECKED', self.inventory_check(report)['status'])
        self.assertNotIn('Source inventory and user-skip authority remain unchecked',
                         (self.fixture.docs / 'report.md').read_text())
        template = (SCHEMAS.parents[1] / 'templates/development/task-report.md').read_text()
        legacy = template.replace('See diagnostics for unchecked or failed evidence.',
                                  'Source inventory and user-skip authority remain unchecked.')
        self.assertEqual(template_parts(template), template_parts(legacy))
        self.source.write_text('changed')
        stale = self.fixture.report()
        self.assertEqual(1, stale.returncode, stale.stdout + stale.stderr)
        report = json.loads((self.fixture.run / 'report.json').read_text())
        self.assertIn('REPORT_SOURCE_CONTENT_MISMATCH', [d['code'] for d in report['diagnostics']])


if __name__ == '__main__':
    unittest.main()
