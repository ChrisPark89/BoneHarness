"""Read-only consistency check for the revision's authoring documents.

This is not the shipped installation checker or a runtime scenario runner.
"""

from pathlib import Path
import re
import json


def main():
    root = Path(__file__).resolve().parents[1]
    spec = root / "docs/specification.md"
    cases = root / "docs/acceptance-scenarios.md"
    frozen_candidate = root / "archive/2026-10-04-design-audit/candidate"
    documents = sorted(
        path for path in root.rglob("*.md")
        if frozen_candidate not in path.parents
        and root / "tests/fixtures" not in path.parents
        # Captured definitions retain their original relative links and bytes.
        # They are machine evidence, not documentation served from this location.
        and root / "tests/demo/.harness/artifacts" not in path.parents
        and not {".git", ".superpowers"}.intersection(path.relative_to(root).parts)
    )
    required_navigation = (
        "README.md", "builder-kit/README.md", "builder-kit/installer/bootstrap-prompt.md",
        "docs/verification.md", "docs/implementation-status.md",
        "docs/task-report-template.md", "docs/reporting-implementation-plan.md",
        "docs/builder-kit-explained.md",
        "builder-kit/templates/runtime/framework/templates/development/task-report.md",
        "docs/reviews/implementation-plan-review.md", "docs/reviews/implementation-review.md",
    )
    for path in required_navigation:
        if not (root / path).is_file():
            raise ValueError(f"Missing delivered navigation artifact: {path}")
    spec_text = spec.read_text(encoding="utf-8")
    case_text = cases.read_text(encoding="utf-8")
    requirements = re.findall(r"\*\*(R-\d+) —", spec_text)
    scenarios = re.findall(r"^\| (S-\d+) \|", case_text, re.M)
    if requirements != [f"R-{n:02}" for n in range(1, 25)]:
        raise ValueError("Expected 24 unique ordered requirement IDs")
    if scenarios != [f"S-{n:02}" for n in range(1, 49)]:
        raise ValueError("Expected 48 unique ordered scenario IDs")
    coverage = set()
    for line in case_text.splitlines():
        if not re.match(r"^\| S-\d+ \|", line):
            continue
        for lo, hi in re.findall(r"R-(\d+)(?:–R-(\d+))?", line.split("|")[2]):
            coverage.update(range(int(lo), int(hi or lo) + 1))
    if coverage != set(range(1, 25)):
        raise ValueError(f"Unexpected requirement coverage: {coverage}")
    runtime = root / 'builder-kit/templates/runtime'
    relocation = json.loads((root / 'builder-kit/installer/layout-map.json').read_text())
    def resolve_historical(destination):
        if destination in {runtime / 'shared/conformance-cases.yaml', runtime / 'framework/workflows/conformance-cases.yaml'}:
            return root / 'tests/conformance-cases.yaml'
        if destination in {runtime / 'shared/schemas/conformance.schema.json', runtime / 'framework/templates/schemas/conformance.schema.json'}:
            return root / 'tests/conformance.schema.json'
        if destination == runtime / 'docs/setup.md':
            return runtime / 'framework/templates/setup.md'
        try:
            relative = destination.relative_to(runtime).as_posix()
        except ValueError:
            return destination
        for old, new in sorted(relocation['paths'].items(), key=lambda item: -len(item[0])):
            if relative == old or relative.startswith(old + '/'):
                return runtime / (new + relative[len(old):])
        return destination
    local_links = 0
    for document in documents:
        text = document.read_text(encoding="utf-8")
        for target in re.findall(r"\]\(([^)]+)\)", text):
            if target.startswith(("https://", "http://", "#")):
                continue
            destination = (document.parent / target.split("#")[0]).resolve()
            if not destination.exists():
                destination = resolve_historical(destination)
            if not destination.exists():
                raise ValueError(f"Missing local link in {document}: {target}")
            local_links += 1
    for document in (spec, cases):
        text = document.read_text(encoding="utf-8")
        if text.count("```") % 2:
            raise ValueError(f"Unbalanced code fences: {document}")
        if re.search(r"\b(TODO|TBD|FIXME)\b", text):
            raise ValueError(f"Unresolved authoring marker: {document}")
    print("PASS: 24 unique requirements; 48 unique scenarios; all requirements mapped.")
    print(f"PASS: {len(documents)} documents, {local_links} local links resolved.")
    print("PASS: new specification/scenario fences and authoring-marker checks.")
    print("Scope: delivered document consistency only; .git/.superpowers, frozen candidate, immutable test inputs and generated demo artifacts excluded; no runtime scenario was executed.")


if __name__ == "__main__":
    main()
