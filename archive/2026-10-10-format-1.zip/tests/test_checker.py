"""Real subprocess checker boundary and structural mutations."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import yaml
from support import validator, FIXTURES

KIT = Path(__file__).resolve().parents[1] / 'builder-kit'
CHECK = KIT / 'checker/check.py'


def digest(path):
    return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()


def tree(root):
    return {str(p.relative_to(root)): (('link',os.readlink(p)) if p.is_symlink() else ('file',digest(p)) if p.is_file() else ('directory',None)) for p in root.rglob('*')}


class CheckerTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(CHECK.exists(), 'optional checker not implemented')
        self.tmp=tempfile.TemporaryDirectory(prefix='checker café ');self.addCleanup(self.tmp.cleanup)
        self.repo=Path(self.tmp.name).resolve();self.harness=self.repo/'.harness'
        shutil.copytree(KIT/'templates/runtime',self.harness)
        (self.harness/'artifacts/installation').mkdir(parents=True)
        (self.harness/'docs').mkdir()
        shutil.copyfile(self.harness/'framework/templates/installation/installation-record.yaml',self.harness/'artifacts/installation/installation-record.yaml')
        (self.harness/'docs/setup.md').write_text('Described configuration: `cfg-1`, revision `1`.\nStructure status: `INCOMPLETE`. Integration status: `NOT_ASSESSED`.\n')
        self.save_inventory()

    def load(self,path):
        return yaml.safe_load((self.harness/path).read_text())

    def write(self,path,value):
        (self.harness/path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

    def save_inventory(self):
        rec=self.load('artifacts/installation/installation-record.yaml')
        rec['extensions'].pop('template_only',None)
        rec['generated_paths']=[]
        for p in sorted(self.harness.rglob('*')):
            if not p.is_file(): continue
            name=p.relative_to(self.harness).as_posix()
            rec['generated_paths'].append(dict(scope='HARNESS',path=name,ownership='GENERATED',before_identity=None,
                after_identity=None if name=='artifacts/installation/installation-record.yaml' else digest(p)))
        rec['owned_paths']=deepcopy(rec['generated_paths'])
        self.write('artifacts/installation/installation-record.yaml',rec)

    def run_cli(self,*args,script=CHECK,python_args=()):
        env=dict(os.environ);env.pop('PYTHONDONTWRITEBYTECODE',None);env.pop('PYTHONPYCACHEPREFIX',None)
        cmd=[sys.executable,*python_args,str(script),'--repo-root',str(self.repo),'--harness-root','.harness','--format','json',*args]
        if getattr(self, 'legacy_layout', False): cmd.append('--legacy-layout')
        proc=subprocess.run(cmd,cwd=self.repo.parent,env=env,capture_output=True,text=True,timeout=60)
        self.assertTrue(proc.stdout.strip(),proc.stderr)
        report=json.loads(proc.stdout)
        self.assertEqual(proc.returncode,report['exit_code'])
        return report

    def test_valid_pending_installation_honest_report_and_read_only(self):
        before=tree(self.repo);r=self.run_cli();self.assertEqual(before,tree(self.repo))
        self.assertEqual(r['exit_code'],0,r['diagnostics'])
        self.assertEqual(r['structure_assessment'],'INCOMPLETE')
        self.assertEqual(r['integration_assessment'],'NOT_ASSESSED')
        self.assertIn('IS-03.separation',r['uncovered_ids']);self.assertIn('IS-08.assessment',r['uncovered_ids'])
        self.assertTrue(r['platform']['dependencies']);self.assertEqual(r['assessed_configuration_id'],'cfg-1')
        self.assertFalse(list(validator('records.schema.json','CheckerReport').iter_errors(r)))
        for a in r['checked_assessments']:
            if a['result']=='PASS': self.assertTrue(a['evidence_refs'])

    def test_checker_inside_inspected_repo_creates_no_bytecode(self):
        local=self.repo/'tools/builder-kit/checker'
        shutil.copytree(CHECK.parent,local,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        shutil.copytree(KIT/'templates/runtime/framework/tools/harness_io',
                        local.parent/'templates/runtime/framework/tools/harness_io',
                        ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        before=tree(self.repo);r=self.run_cli(script=local/'check.py')
        self.assertEqual(r['exit_code'],0,r['diagnostics']);self.assertEqual(before,tree(self.repo))
        self.assertFalse(list(local.rglob('*.pyc')))

    def test_dependency_absence_and_bad_invocation_json_exit_two(self):
        r=self.run_cli(python_args=('-S',));self.assertEqual(r['exit_code'],2)
        self.assertTrue(any(d['code'].startswith('PREREQUISITE_') for d in r['diagnostics']))
        self.assertEqual(self.run_cli('--record','../escape.yaml')['exit_code'],1)
        self.assertEqual(self.run_cli('--repo-root','relative')['exit_code'],2)

    def test_parser_graph_registry_and_schema_mutations(self):
        mutations=[('framework/workflows/development/workflow.yaml',lambda d:d['transitions'][0].update(to='UNDEFINED'),'GRAPH_'),
                   ('framework/workflows/development/workflow.yaml',lambda d:d['transitions'][0].update(rule_ids=['RULE-99']),'GRAPH_'),
                   ('framework/workflows/development/workflow.yaml',lambda d:d['transitions'].append(dict(d['transitions'][0],id='DEV-999')),'GRAPH_'),
                   ('framework/workflows/maintenance/maintenance-workflow.yaml',lambda d:d['extensions']['request_type_profiles'].update(DRIFT_REVIEW='adapter-change'),'REGISTRY_'),
                   ('framework/workflows/development/workflow.yaml',lambda d:d.update(capabilities={'invented':{}}),'SCHEMA_')]
        for path,mutation,code in mutations:
            with self.subTest(code=code):
                original=self.load(path);changed=deepcopy(original);mutation(changed);self.write(path,changed);self.save_inventory()
                r=self.run_cli();self.assertEqual(r['exit_code'],1,r)
                self.assertTrue(any(d['code'].startswith(code) for d in r['diagnostics']),r['diagnostics'])
                self.write(path,original)

    def test_current_assessment_invalid_evidence_fails_and_historical_claims_unused(self):
        profile=self.load('framework/config/repo-profile.yaml');rec=self.load('artifacts/installation/installation-record.yaml')
        a=deepcopy(rec['criterion_assessments'][0]);a.update(result='PASS',method='HUMAN_REVIEW',actor='reviewer',reason='assertion')
        profile['assessments']=[a];self.write('framework/config/repo-profile.yaml',profile);self.save_inventory()
        r=self.run_cli();self.assertEqual(r['exit_code'],1);self.assertEqual(r['structure_assessment'],'INCOMPLETE')

    def test_no_command_execution_and_unsafe_reference_never_read(self):
        sentinel=self.repo.parent/('outside-'+self.repo.name+'.yaml');sentinel.write_text('a: secret')
        self.addCleanup(sentinel.unlink)
        profile=self.load('framework/config/repo-profile.yaml')
        profile['repository']['instruction_files']=[{'kind':'LOCAL','scope':'HARNESS','path':'../../'+sentinel.name}]
        profile.setdefault('extensions',{})['command']='touch '+str(self.repo/'COMMAND_RAN')
        self.write('framework/config/repo-profile.yaml',profile);self.save_inventory()
        r=self.run_cli();self.assertEqual(r['exit_code'],1)
        self.assertFalse((self.repo/'COMMAND_RAN').exists());self.assertNotIn('secret',json.dumps(r))

    def test_inventory_hash_mismatch_and_exact_ledger_exception(self):
        (self.harness/'framework/workflows/development/HARNESS.md').write_text('changed')
        r=self.run_cli();self.assertEqual(r['exit_code'],1)
        self.assertTrue(any(d['code']=='REFERENCE_IDENTITY' for d in r['diagnostics']))
        self.save_inventory();rec=self.load('artifacts/installation/installation-record.yaml')
        for items in (rec['generated_paths'],rec['owned_paths']):
            items[0]['after_identity']=None
        self.write('artifacts/installation/installation-record.yaml',rec)
        self.assertEqual(self.run_cli()['exit_code'],1)

    def test_changed_config_without_lineage_never_inventory_pass(self):
        p=self.load('framework/config/repo-profile.yaml');p.update(configuration_id='cfg-2',configuration_revision=2)
        self.write('framework/config/repo-profile.yaml',p)
        r=self.run_cli()
        self.assertNotIn('IS-08.inventory',[a['criterion_id'] for a in r['checked_assessments'] if a['result']=='PASS'])
        self.assertIn('IS-08.inventory',r['uncovered_ids'])

    def test_default_sequence_matches_binding_specification(self):
        expected=['NEW','BASELINED','RESEARCHED','PATTERN_VERIFIED','SPEC_READY','TEST_READY','PLAN_READY','IMPLEMENTED','PREFLIGHT','PREFLIGHT_PASSED','BUILDING','BUILD_PASSED','TESTING','TEST_PASSED','SPEC_VERIFIED','READY_FOR_REVIEW','COMPLETE']
        self.assertEqual(self.load('framework/workflows/verification-criteria.yaml')['extensions']['default_sequence'],expected)
        self.assertEqual(self.load('framework/workflows/development/workflow.yaml')['extensions']['default_sequence'],expected)

    def adapt_repair(self):
        profile = self.load('framework/config/repo-profile.yaml')
        profile['extensions']['repair_policy']['build'].update(enabled=True, max_attempts=2)
        self.write('framework/config/repo-profile.yaml', profile)
        self.save_inventory()
        return profile

    def review_only(self, cid, *, change_text=True):
        catalogue = self.load('framework/workflows/verification-criteria.yaml')
        definition = next(d for d in catalogue['criteria'] if d['id'] == cid)
        definition['allowed_methods'] = ['LLM_REVIEW', 'HUMAN_REVIEW']
        if change_text:
            definition['description'] += ' Review the explicitly adopted bounded adaptation and its authority.'
        self.write('framework/workflows/verification-criteria.yaml', catalogue)
        self.save_inventory()

    def repair_review(self, profile):
        evidence = self.harness / 'artifacts/installation/repair-review.txt'
        evidence.write_text('Synthetic cfg-1 whole IS-07.sequence review: original defaults disabled; '
                            'build limit 2 adopted under fixture authority, scope and applicability reviewed; '
                            'full preflight route and sequence reviewed. No real repair execution.')
        assessment = deepcopy(self.load('artifacts/installation/installation-record.yaml')['criterion_assessments'][0])
        assessment.update(criterion_id='IS-07.sequence', result='PASS', method='HUMAN_REVIEW',
                          actor='fixture policy reviewer', reason='Whole sequence, authority and applicability review',
                          evidence_refs=[dict(reference=dict(kind='LOCAL', scope='HARNESS',
                              path='artifacts/installation/repair-review.txt'), identity=digest(evidence),
                              provenance='REVIEW', summary='Current whole sequence and repair authority review')])
        profile['assessments'] = [assessment]
        self.write('framework/config/repo-profile.yaml', profile)
        self.save_inventory()
        return assessment

    def test_repair_shipped_defaults_retain_automated_sequence_coverage(self):
        for policy in self.load('framework/config/repo-profile.yaml')['extensions']['repair_policy'].values():
            self.assertIs(policy['enabled'], False)
            self.assertEqual(policy['max_attempts'], 0)
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 0, report['diagnostics'])
        sequence = [a for a in report['checked_assessments'] if a['criterion_id'] == 'IS-07.sequence']
        self.assertEqual([a['result'] for a in sequence], ['PASS'])

    def test_repair_default_missing_guard_and_denied_review_stay_unsatisfied(self):
        original = self.load('framework/workflows/development/workflow.yaml')
        flow = deepcopy(original)
        flow['transitions'] = [e for e in flow['transitions']
                               if not (e['from'] == 'BUILD_FAILED' and e['trigger'] == 'repair_denied')]
        self.write('framework/workflows/development/workflow.yaml', flow)
        self.save_inventory()
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 1)
        self.assertTrue(any(d['code'] == 'GRAPH_REPAIR' for d in report['diagnostics']))
        self.write('framework/workflows/development/workflow.yaml', original)
        profile = self.adapt_repair()
        assessment = self.repair_review(profile)
        assessment.update(result='FAIL', reason='Fixture authority denied this repair policy adoption.')
        self.write('framework/config/repo-profile.yaml', profile)
        self.save_inventory()
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 0, report['diagnostics'])
        self.assertEqual(report['structure_assessment'], 'INCOMPLETE')
        self.assertEqual(report['extensions']['supplied_assessments'][0]['result'], 'FAIL')
        self.assertIn('IS-07.sequence', report['uncovered_ids'])

    def test_repair_enabled_bounded_policy_is_wholly_pending(self):
        self.adapt_repair()
        before = tree(self.repo)
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 0, report['diagnostics'])
        self.assertEqual(report['structure_assessment'], 'INCOMPLETE')
        self.assertIn('IS-07.sequence', report['uncovered_ids'])
        self.assertFalse(any(a['criterion_id'] == 'IS-07.sequence' for a in report['checked_assessments']))
        self.assertTrue(any('authority' in line and 'IS-07.sequence' in line for line in report['limitations']))
        self.assertEqual(before, tree(self.repo))

    def test_repair_current_review_is_attributable_and_not_automatic_permission(self):
        profile = self.adapt_repair()
        assessment = self.repair_review(profile)
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 0, report['diagnostics'])
        self.assertIn('IS-07.sequence', report['uncovered_ids'])
        self.assertEqual(report['extensions']['supplied_assessments'], [assessment])
        self.assertFalse(any(a['criterion_id'] == 'IS-07.sequence' for a in report['checked_assessments']))
        # A schema/shape tool claim cannot replace semantic authority review.
        profile['assessments'][0]['method'] = 'AUTOMATED'
        self.write('framework/config/repo-profile.yaml', profile)
        self.save_inventory()
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 0, report['diagnostics'])
        self.assertEqual(report['extensions']['supplied_assessments'][0]['result'], 'PENDING')

    def test_repair_review_only_adaptation_does_not_run_default_predicates(self):
        self.adapt_repair()
        self.review_only('IS-07.sequence')
        # This alternate sequence needs whole-obligation review; it must not be
        # rejected by the now-ineligible default sequence predicate.
        flow = self.load('framework/workflows/development/workflow.yaml')
        flow['extensions']['default_sequence'] = ['NEW', 'COMPLETE']
        self.write('framework/workflows/development/workflow.yaml', flow)
        self.save_inventory()
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 0, report['diagnostics'])
        self.assertIn('IS-07.sequence', report['uncovered_ids'])
        self.assertEqual(report['structure_assessment'], 'INCOMPLETE')

    def test_repair_invalid_policy_and_unapproved_claim_still_fail(self):
        profile = self.adapt_repair()
        self.review_only('IS-07.sequence')
        policy = profile['extensions']['repair_policy']['build']
        valid = deepcopy(policy)
        for change in ({'max_attempts': -1}, {'max_attempts': True}, {'max_attempts': '2'},
                       {'enabled': 'yes'}, {'route_after_repair': 'COMPLETE'}, {'shortcut_rule': 'RULE-99'}):
            with self.subTest(change=change):
                policy.clear()
                policy.update(valid, **change)
                self.write('framework/config/repo-profile.yaml', profile)
                self.save_inventory()
                report = self.run_cli()
                self.assertEqual(report['exit_code'], 1)
                self.assertTrue(any(d['code'] == 'SCHEMA_REPAIR_POLICY' for d in report['diagnostics']))
        policy.clear()
        policy.update(valid)
        self.repair_review(profile)
        profile['assessments'][0]['actor'] = None
        profile['assessments'][0]['evidence_refs'] = []
        self.write('framework/config/repo-profile.yaml', profile)
        self.save_inventory()
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 1)
        self.assertTrue(any(d['code'] == 'REFERENCE_ASSESSMENT' for d in report['diagnostics']))

    def test_eligibility_precedes_other_changed_obligation_predicates(self):
        # A valid extension to the template inventory is outside exact-ten
        # coverage, regardless of whether AUTOMATED remains an allowed method.
        original = self.load('framework/workflows/verification-criteria.yaml')
        for methods_only in (False, True):
            with self.subTest(methods_only=methods_only):
                self.write('framework/workflows/verification-criteria.yaml', original)
                catalogue = deepcopy(original)
                definition = next(d for d in catalogue['criteria'] if d['id'] == 'IS-06.records')
                if methods_only:
                    self.review_only('IS-06.records', change_text=False)
                    catalogue = self.load('framework/workflows/verification-criteria.yaml')
                else:
                    definition['description'] += ' Includes a reviewed additional persistence template.'
                catalogue['extensions']['template_record_definitions'].append('extra.yaml')
                self.write('framework/workflows/verification-criteria.yaml', catalogue)
                self.save_inventory()
                report = self.run_cli()
                self.assertEqual(report['exit_code'], 0, report['diagnostics'])
                self.assertIn('IS-06.records', report['uncovered_ids'])

    def test_eligibility_keeps_inventory_symlink_safety(self):
        self.review_only('IS-08.inventory')
        self.review_only('IS-02.local_refs')
        outside = self.repo / 'outside.txt'
        outside.write_text('outside content must not be read')
        (self.harness / 'escape.txt').symlink_to(outside)
        record = self.load('artifacts/installation/installation-record.yaml')
        record['generated_paths'].append(dict(scope='HARNESS', path='escape.txt',
            ownership='GENERATED', before_identity=None, after_identity='sha256:' + '0' * 64))
        self.write('artifacts/installation/installation-record.yaml', record)
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 1)
        self.assertTrue(any(d['code'] == 'PATH_SYMLINK' for d in report['diagnostics']))
        self.assertIn('IS-08.inventory', report['uncovered_ids'])
        self.assertNotIn('outside content must not be read', json.dumps(report))

    def test_eligibility_does_not_bypass_schema_parser_or_path_safety(self):
        self.review_only('IS-01.schemas')
        self.review_only('IS-02.local_refs')
        self.review_only('IS-06.records')
        profile = self.load('framework/config/repo-profile.yaml')
        profile['repository']['instruction_files'] = [dict(kind='LOCAL', scope='HARNESS', path='../../outside-secret')]
        self.write('framework/config/repo-profile.yaml', profile)
        template = self.load('framework/templates/development/task-state.yaml')
        template['version'] = 'invalid integer'
        self.write('framework/templates/development/task-state.yaml', template)
        self.save_inventory()
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 1)
        self.assertTrue(any(d['code'].startswith('PATH_') for d in report['diagnostics']))
        self.assertTrue(any(d['code'] == 'SCHEMA_INVALID' for d in report['diagnostics']))
        (self.harness / 'framework/templates/development/task-state.yaml').write_text('version: 1\nversion: 2\n')
        self.save_inventory()
        report = self.run_cli()
        self.assertEqual(report['exit_code'], 1)
        self.assertTrue(any(d['code'].startswith('PARSE_') for d in report['diagnostics']))

    def test_changed_criterion_scope_cannot_get_partial_automated_pass(self):
        cat=self.load('framework/workflows/verification-criteria.yaml')
        cat['criteria'][0]['description'] += ' Also prove reviewer approval of all file contents.'
        self.write('framework/workflows/verification-criteria.yaml',cat);self.save_inventory()
        r=self.run_cli()
        self.assertIn('IS-01.files',r['uncovered_ids'])

    def test_missing_core_criterion_and_unsafe_schema_fail(self):
        cat=self.load('framework/workflows/verification-criteria.yaml');cat['criteria']=[d for d in cat['criteria'] if d['id']!='IS-08.provenance']
        self.write('framework/workflows/verification-criteria.yaml',cat);self.save_inventory()
        r=self.run_cli();self.assertEqual(r['exit_code'],1)
        self.assertTrue(any(d['code']=='REFERENCE_CRITERIA' for d in r['diagnostics']))
        p=self.harness/'framework/templates/schemas/result.schema.json';d=json.loads(p.read_text());d['$defs']={'unused':{'$ref':'https://never.invalid/schema'}};p.write_text(json.dumps(d));self.save_inventory()
        r=self.run_cli();self.assertEqual(r['exit_code'],1)
        self.assertTrue(any(d['code'].startswith('SCHEMA_') for d in r['diagnostics']))

    def test_diagnostic_schema_backwards_compatible_and_actual_fail_report(self):
        self.assertTrue(validator('common.schema.json','Diagnostic').is_valid({'code':'OLD','message':'old runtime record','reference':None}))
        flow=self.load('framework/workflows/development/workflow.yaml');flow['transitions'][0]['to']='missing';self.write('framework/workflows/development/workflow.yaml',flow);self.save_inventory()
        r=self.run_cli();self.assertEqual(r['exit_code'],1)
        self.assertFalse(list(validator('records.schema.json','CheckerReport').iter_errors(r)))
        self.assertTrue(all('path' in d for d in r['diagnostics']))

    def test_exit_two_retains_prior_failures_and_never_reads_escaped_schema(self):
        from unittest.mock import patch
        sys.path.insert(0,str(CHECK.parent))
        from harness_check.checks import check_installation
        unreadable=self.harness/'framework/workflows/development/HARNESS.md'
        flow=self.load('framework/workflows/development/workflow.yaml');flow['transitions'][0]['to']='missing';self.write('framework/workflows/development/workflow.yaml',flow);self.save_inventory()
        original=Path.read_bytes
        def fail(path):
            if path==unreadable: raise PermissionError('unreadable fixture')
            return original(path)
        with patch.object(Path,'read_bytes',fail):
            r=check_installation(self.repo,self.harness,self.harness/'artifacts/installation/installation-record.yaml',self.harness/'framework/workflows/verification-criteria.yaml')
        self.assertEqual(r['exit_code'],2)
        self.assertTrue(any(d['code']=='GRAPH_ENDPOINT' for d in r['diagnostics']))
        with tempfile.TemporaryDirectory() as out:
            outside=Path(out).resolve();sentinel=outside/'result.schema.json';sentinel.write_text('{}')
            schema=self.harness/'framework/templates/schemas/result.schema.json';schema.unlink();schema.symlink_to(sentinel)
            def guarded(path):
                self.assertNotEqual(path.resolve(),sentinel,'outside schema content was read')
                return original(path)
            with patch.object(Path,'read_bytes',guarded):
                r=check_installation(self.repo,self.harness,self.harness/'artifacts/installation/installation-record.yaml',self.harness/'framework/workflows/verification-criteria.yaml')
            self.assertEqual(r['exit_code'],1)
            self.assertTrue(any(d['code']=='PATH_SYMLINK' for d in r['diagnostics']))

    def test_review_freshness_and_activation_evidence(self):
        profile=self.load('framework/config/repo-profile.yaml');rec=self.load('artifacts/installation/installation-record.yaml')
        evidence=self.harness/'artifacts/installation/review.txt';evidence.write_text('cfg-1 observed ownership scope and procedure trace')
        e=dict(reference=dict(kind='LOCAL',scope='HARNESS',path='artifacts/installation/review.txt'),identity=digest(evidence),provenance='REVIEW',summary='Observed scope review')
        a=deepcopy(rec['criterion_assessments'][0]);a.update(criterion_id='IS-02.ownership',result='PASS',method='HUMAN_REVIEW',actor='named reviewer',evidence_refs=[e],reason='Observed ownership trace')
        profile.update(configuration_id='cfg-2',configuration_revision=2);profile['assessments']=[dict(a,assessed_configuration_id='cfg-2')]
        rec['criterion_assessments']=[a]
        self.write('framework/config/repo-profile.yaml',profile);self.write('artifacts/installation/installation-record.yaml',rec)
        r=self.run_cli()
        current=r['extensions']['supplied_assessments'][0]
        self.assertEqual(current['result'],'PENDING','blind relabel must not satisfy current review')
        fresh=self.harness/'artifacts/installation/revalidated.txt';fresh.write_text('cfg-2 dependency revalidation: observed unchanged instruction/workflow/binding/policy/source dependencies; cfg-1 scope trace remains applicable.')
        profile['assessments'][0]['evidence_refs'].append(dict(e,reference=dict(e['reference'],path='artifacts/installation/revalidated.txt'),identity=digest(fresh),summary='Explicit dependency revalidation against cfg-2'))
        self.write('framework/config/repo-profile.yaml',profile)
        r=self.run_cli();self.assertEqual(r['extensions']['supplied_assessments'][0]['result'],'PASS')
        profile['assessments'][0]['criterion_id']='IS-08.provenance'
        self.write('framework/config/repo-profile.yaml',profile)
        r=self.run_cli();self.assertEqual(r['exit_code'],1)
        self.assertTrue(any(d['code']=='REFERENCE_ACTIVATION' for d in r['diagnostics']))

    def test_failure_envelopes_allow_unknown_config_only_for_nonzero_exit(self):
        from support import fixtures
        report=fixtures()['CheckerReport'];report['assessed_configuration_id']=None
        check=validator('records.schema.json','CheckerReport')
        report['exit_code']=0;self.assertFalse(check.is_valid(report))
        for code in (1,2):
            report['exit_code']=code;self.assertTrue(check.is_valid(report))
        self.assertTrue(check.is_valid(self.run_cli(python_args=('-S',))))

    def test_prose_receipts_leave_entire_inventory_uncovered_for_both_publications(self):
        from support import fixtures
        old_profile=self.load('framework/config/repo-profile.yaml');before=digest(self.harness/'framework/config/repo-profile.yaml')
        changed=dict(old_profile,configuration_id='cfg-2',configuration_revision=2)
        self.write('framework/config/repo-profile.yaml',changed);after=digest(self.harness/'framework/config/repo-profile.yaml')
        evidence=self.harness/'artifacts/installation/receipt.txt';evidence.write_text('Synthetic prose receipt; attempt/writer semantic acceptance needs review.')
        ev=dict(reference=dict(kind='LOCAL',scope='HARNESS',path='artifacts/installation/receipt.txt'),provenance='REVIEW',summary='Unstructured write receipt',identity=digest(evidence))
        for state,request_type,result in [('PROMOTED','ADAPTER_CHANGE','PROMOTED'),('ASSESSMENT_PUBLISHED','DRIFT_REVIEW','NOT_APPLICABLE')]:
            with self.subTest(state=state):
                u=fixtures()['UpdateRecord'];u['request_type']=request_type
                c=u['current'];c.update(state=state,version=1,evidence_refs=[ev],publication_manifest=[dict(scope='HARNESS',path='framework/config/repo-profile.yaml',ownership='GENERATED',before_identity=before,after_identity=after)])
                c['promotion'].update(result=result,evidence_refs=[ev])
                if state=='PROMOTED':
                    c['promotion'].update(after_configuration_id='cfg-2',intent=dict(request_id='receipt-1',candidate_identity=ev['identity'],base_configuration_id='cfg-1',prospective_configuration_id='cfg-2',manifest_identity=ev['identity']))
                e=u['events'][0];e.update(next_state=state,post_state=deepcopy(c),decision_ref=ev)
                # Recovery reuses the original publication, never adds a second one.
                last=deepcopy(e);last.update(request_id='reconcile-1',previous_version=1,next_version=2,previous_state=state,next_state='STATUS_UPDATED')
                last['post_state'].update(state='STATUS_UPDATED',version=2)
                last['post_state'].setdefault('extensions',{})['accepted_trigger']='RECONCILED'
                u['events'].append(last);u['current']=deepcopy(last['post_state'])
                self.assertTrue(validator('records.schema.json','UpdateRecord').is_valid(u))
                folder=self.harness/'artifacts/maintenance';folder.mkdir(exist_ok=True)
                self.write('artifacts/maintenance/update-1.yaml',u)
                r=self.run_cli()
                self.assertIn('IS-08.inventory',r['uncovered_ids'])
                self.assertFalse(any(a['criterion_id']=='IS-08.inventory' and a['result']=='PASS' for a in r['checked_assessments']))
                self.assertTrue(any('receipt' in line and 'wholly unresolved' in line for line in r['limitations']),r['limitations'])
                self.assertFalse(any(d['code'] in ('REFERENCE_ANCESTRY','REFERENCE_PUBLICATION') for d in r['diagnostics']),r['diagnostics'])
                u['events'][0]['post_state']['publication_manifest'][0]['before_identity']='sha256:'+'0'*64
                self.write('artifacts/maintenance/update-1.yaml',u)
                r=self.run_cli();self.assertEqual(r['exit_code'],1)
                self.assertTrue(any(d['code']=='REFERENCE_ANCESTRY' for d in r['diagnostics']))

    def test_stale_derived_status_diagnosed_without_changing_profile(self):
        status=self.harness/'docs/setup.md'
        status.write_text(status.read_text().replace('`cfg-1`','`cfg-999`'))
        self.save_inventory();before=digest(self.harness/'framework/config/repo-profile.yaml')
        r=self.run_cli();self.assertEqual(r['exit_code'],1)
        self.assertTrue(any(d['code']=='REFERENCE_STATUS' for d in r['diagnostics']))
        self.assertEqual(before,digest(self.harness/'framework/config/repo-profile.yaml'))

    def test_active_adapter_schema_dependencies_are_all_checked(self):
        profile=self.load('framework/config/repo-profile.yaml')
        profile['capabilities']['build']['input_schema']={'kind':'LOCAL','scope':'HARNESS','path':'framework/templates/schemas/adapter-input.schema.json'}
        self.write('framework/config/repo-profile.yaml',profile)
        schemas=self.harness/'framework/templates/schemas'
        self.write('framework/templates/schemas/adapter-input.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','$ref':'adapter-types.schema.json#/$defs/Input'})
        dependency={'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':{'Input':{'type':'object'}}}
        self.write('framework/templates/schemas/adapter-types.schema.json',dependency);self.save_inventory()
        r=self.run_cli();self.assertEqual(r['exit_code'],0,r['diagnostics'])
        for ref in ('https://never.invalid/input.schema.json','../outside.schema.json'):
            with self.subTest(ref=ref):
                changed=deepcopy(dependency);changed['$defs']['Input']={'$ref':ref}
                self.write('framework/templates/schemas/adapter-types.schema.json',changed);self.save_inventory()
                r=self.run_cli();self.assertEqual(r['exit_code'],1,r['diagnostics'])
                for cid in ('IS-01.schemas','IS-02.local_refs'):
                    self.assertFalse(any(a['criterion_id']==cid and a['result']=='PASS' for a in r['checked_assessments']))
                    self.assertTrue(any(d.get('criterion_id')==cid and d['code'].startswith(('SCHEMA_','PATH_')) for d in r['diagnostics']))

    def test_malformed_profile_and_schema_are_input_failures(self):
        for name in ('framework/config/repo-profile.yaml','framework/workflows/verification-criteria.yaml','artifacts/installation/installation-record.yaml','framework/workflows/development/workflow.yaml'):
            with self.subTest(root=name):
                before=(self.harness/name).read_bytes()
                try:
                    self.write(name,[])
                    r=self.run_cli();self.assertEqual(r['exit_code'],1,r['diagnostics'])
                    self.assertTrue(any(d['code'].startswith('SCHEMA_') for d in r['diagnostics']))
                    self.assertFalse(any(d['code']=='PREREQUISITE_INTERNAL' for d in r['diagnostics']))
                finally:
                    (self.harness/name).write_bytes(before)
        schema=self.load('framework/templates/schemas/result.schema.json');schema['type']=42
        self.write('framework/templates/schemas/result.schema.json',schema);self.save_inventory()
        r=self.run_cli();self.assertEqual(r['exit_code'],1,r['diagnostics'])
        self.assertTrue(any(d['code']=='SCHEMA_DEFINITION' for d in r['diagnostics']))
        self.assertFalse(any(d['code']=='PREREQUISITE_INTERNAL' for d in r['diagnostics']))

    def test_pending_external_evidence_stays_pending_without_access_failure(self):
        profile=self.load('framework/config/repo-profile.yaml');rec=self.load('artifacts/installation/installation-record.yaml')
        pending=deepcopy(next(a for a in rec['criterion_assessments'] if a['criterion_id']=='IS-02.ownership'))
        pending['evidence_refs']=[dict(reference=dict(kind='EXTERNAL',uri='https://never.invalid/review',accessibility='NOT_ASSESSED'),identity='sha256:'+'a'*64,provenance='REVIEW',summary='Review not yet available')]
        for accessibility in ('NOT_ASSESSED','UNAVAILABLE'):
            with self.subTest(accessibility=accessibility):
                pending['evidence_refs'][0]['reference']['accessibility']=accessibility
                profile['assessments']=[pending];self.write('framework/config/repo-profile.yaml',profile);self.save_inventory()
                r=self.run_cli();self.assertEqual(r['exit_code'],0,r['diagnostics'])
                self.assertEqual(r['structure_assessment'],'INCOMPLETE')
                self.assertEqual(r['extensions']['supplied_assessments'][0]['result'],'PENDING')
                self.assertFalse(any(d['code']=='REFERENCE_ACCESS' for d in r['diagnostics']))
                satisfied=deepcopy(pending);satisfied.update(result='PASS',method='HUMAN_REVIEW',actor='reviewer')
                profile['assessments']=[satisfied];self.write('framework/config/repo-profile.yaml',profile);self.save_inventory()
                self.assertEqual(self.run_cli()['exit_code'],1)
        malformed=deepcopy(pending);malformed['evidence_refs'][0]['reference']['accessibility']='maybe'
        profile['assessments']=[malformed];self.write('framework/config/repo-profile.yaml',profile);self.save_inventory()
        self.assertEqual(self.run_cli()['exit_code'],1)
        unsafe=deepcopy(pending);unsafe['evidence_refs'][0]['reference']=dict(kind='LOCAL',scope='HARNESS',path='../outside.txt')
        profile['assessments']=[unsafe];self.write('framework/config/repo-profile.yaml',profile);self.save_inventory()
        r=self.run_cli();self.assertEqual(r['exit_code'],1)
        self.assertTrue(any(d['code'].startswith('PATH_') for d in r['diagnostics']))

    def test_journal_entry_reference_uses_payload_identity_and_rejects_missing_entry(self):
        sys.path.insert(0, str(KIT/'checker'))
        import harness_check
        from harness_io.journal import make_entry, canonical_json
        from support import fixtures
        payload=fixtures()['GateDecision']
        snapshot=make_entry(fixtures()['ConfigSnapshot'],'task-1','configuration')
        entry=make_entry(payload,'task-1','decision-1',snapshot)
        history=self.harness/'artifacts/development/task-1/history.jsonl'
        history.parent.mkdir(parents=True)
        history.write_bytes(canonical_json(snapshot)+b'\n'+canonical_json(entry)+b'\n')
        profile=self.load('framework/config/repo-profile.yaml')
        assessment=deepcopy(self.load('artifacts/installation/installation-record.yaml')['criterion_assessments'][0])
        assessment['evidence_refs']=[dict(reference=dict(kind='LOCAL',scope='HARNESS',
            path='artifacts/development/task-1/history.jsonl',entry_id='decision-1'),
            identity=entry['payload_identity'],provenance='REVIEW',summary='Recorded journal decision')]
        profile['assessments']=[assessment]
        self.write('framework/config/repo-profile.yaml',profile);self.save_inventory()
        report=self.run_cli()
        self.assertEqual(report['exit_code'],0,report['diagnostics'])
        assessment['evidence_refs'][0]['reference']['entry_id']='absent'
        self.write('framework/config/repo-profile.yaml',profile);self.save_inventory()
        report=self.run_cli()
        self.assertEqual(report['exit_code'],1)
        self.assertTrue(any(item['code']=='REFERENCE_ENTRY' for item in report['diagnostics']))

    def use_retained_publication_walkthrough(self):
        """Actual Task 6 byte-publication trace, including new paths and recovery."""
        import zipfile
        archive=FIXTURES/'checks/installed-walkthrough.zip'
        self.assertTrue(archive.is_file())
        destination=self.repo/'retained'
        with zipfile.ZipFile(archive) as z:
            for item in z.infolist():
                if item.filename.startswith('compiled/'):
                    z.extract(item,destination)
        self.repo=destination/'compiled';self.harness=self.repo/'.harness'
        self.legacy_layout=True
        # This is a current-runtime test fixture derived from the immutable archive,
        # not a reissued historical installation or publication claim.
        histories={p:p.read_bytes() for p in (self.harness/'maintenance/updates').glob('*.yaml')
                   if yaml.safe_load(p.read_text()).get('record_type')=='UpdateRecord'}
        attested={item['path'] for raw in histories.values()
                  for event in yaml.safe_load(raw)['events']
                  for item in event['post_state']['publication_manifest']}
        self.assertNotIn('shared/verification-criteria.yaml',attested)
        endpoints={name:digest(self.harness/name) for name in attested}
        catalogue=self.load('shared/verification-criteria.yaml')
        sys.path.insert(0, str(KIT/"checker"))
        from harness_check.layout import legacy_path, NEW_ONLY
        current=yaml.safe_load((KIT/'templates/runtime/framework/workflows/verification-criteria.yaml').read_text())
        current['extensions']['required_runtime_files'] = [legacy_path(name) for name in current['extensions']['required_runtime_files'] if name not in NEW_ONLY]
        additions=[]
        for name in current['extensions']['required_runtime_files']:
            path=self.harness/name
            if not path.exists():
                path.parent.mkdir(parents=True,exist_ok=True)
                source_name=next(item for item in yaml.safe_load((KIT/'templates/runtime/framework/workflows/verification-criteria.yaml').read_text())['extensions']['required_runtime_files'] if legacy_path(item)==name)
                shutil.copyfile(KIT/'templates/runtime'/source_name,path)
                additions.append(dict(scope='HARNESS',path=name,ownership='GENERATED',
                                      before_identity=None,after_identity=digest(path)))
        catalogue['extensions']['required_runtime_files']=current['extensions']['required_runtime_files']
        self.write('shared/verification-criteria.yaml',catalogue)
        ledger=self.load('installation/installation-record.yaml')
        ledger.setdefault('extensions',{})['test_fixture_provenance']='Current runtime additions at fixture baseline; retained publication records and attested bytes unchanged.'
        for field in ('generated_paths','owned_paths'):
            for item in ledger[field]:
                if item['scope']=='HARNESS' and item['path']=='shared/verification-criteria.yaml':
                    item['after_identity']=digest(self.harness/item['path'])
            ledger[field].extend(deepcopy(additions))
        self.write('installation/installation-record.yaml',ledger)
        self.assertEqual({p:p.read_bytes() for p in histories},histories)
        self.assertEqual({name:digest(self.harness/name) for name in attested},endpoints)
        report=self.run_cli()
        self.assertEqual(report['exit_code'],0,report['diagnostics'])
        self.assertFalse(report['diagnostics'],report['diagnostics'])

    def test_legacy_inventory_schema_definition_still_validated(self):
        self.use_retained_publication_walkthrough()
        extra=self.harness/'shared/schemas/extra.schema.json'
        self.write('shared/schemas/extra.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','type':42})
        record=self.load('installation/installation-record.yaml')
        entry=dict(scope='HARNESS',path='shared/schemas/extra.schema.json',ownership='GENERATED',
                   before_identity=None,after_identity=digest(extra))
        record['generated_paths'].append(entry);record['owned_paths'].append(dict(entry))
        self.write('installation/installation-record.yaml',record)
        report=self.run_cli()
        self.assertEqual(report['exit_code'],1)
        self.assertTrue(any(row['code']=='SCHEMA_DEFINITION' for row in report['diagnostics']),report['diagnostics'])
        self.assertNotIn('IS-01.schemas',[row['criterion_id'] for row in report['checked_assessments'] if row['result']=='PASS'])

    def test_reconciled_publication_reuses_receipt_not_second_publication(self):
        self.use_retained_publication_walkthrough()
        r=self.run_cli()
        self.assertFalse(any(d['code']=='REFERENCE_ANCESTRY' and 'duplicate publication' in d['message'] for d in r['diagnostics']),r['diagnostics'])
        self.assertIn('IS-08.inventory',r['uncovered_ids'])
        update=self.load('maintenance/updates/replace-build.yaml')
        restored=next(e for e in update['events'] if e['next_state']=='PROMOTED' and e['previous_state']=='INSPECTED')
        restored['post_state']['promotion']['intent']['candidate_identity']='sha256:'+'0'*64
        self.write('maintenance/updates/replace-build.yaml',update)
        r=self.run_cli()
        self.assertTrue(any(d['code']=='REFERENCE_PUBLICATION' for d in r['diagnostics']),r['diagnostics'])

    def test_new_owned_path_chains_null_before_and_rejects_mismatch(self):
        self.use_retained_publication_walkthrough()
        r=self.run_cli()
        self.assertFalse(any(d['code']=='REFERENCE_ANCESTRY' and 'synthetic_adapter_B.py' in d['path'] for d in r['diagnostics']),r['diagnostics'])
        self.assertIn('IS-08.inventory',r['uncovered_ids'])
        self.assertFalse(any(a['criterion_id']=='IS-08.inventory' and a['result']=='PASS' for a in r['checked_assessments']))
        original=self.load('maintenance/updates/replace-build.yaml')
        update=deepcopy(original)
        for event in update['events']:
            for item in event['post_state']['publication_manifest']:
                if item['path']=='shared/adapters/synthetic_adapter_B.py':item['before_identity']='sha256:'+'0'*64
        update['current']=deepcopy(update['events'][-1]['post_state'])
        self.write('maintenance/updates/replace-build.yaml',update)
        r=self.run_cli();self.assertEqual(r['exit_code'],1)
        self.assertTrue(any(d['code']=='REFERENCE_ANCESTRY' for d in r['diagnostics']))

        for mutation in ('unowned', 'duplicate', 'tampered-endpoint'):
            with self.subTest(mutation=mutation):
                update=deepcopy(original)
                if mutation=='tampered-endpoint':
                    (self.harness/'shared/adapters/synthetic_adapter_B.py').write_text('newer user content; do not overwrite')
                else:
                    for event in update['events']:
                        items=event['post_state']['publication_manifest']
                        item=next(x for x in items if x['path']=='shared/adapters/synthetic_adapter_B.py')
                        if mutation=='unowned':item['ownership']='USER'
                        else:items.append(deepcopy(item))
                update['current']=deepcopy(update['events'][-1]['post_state'])
                self.write('maintenance/updates/replace-build.yaml',update)
                before=tree(self.repo);r=self.run_cli()
                self.assertEqual(r['exit_code'],1)
                self.assertEqual(before,tree(self.repo),'checker must preserve conflicting newer/user values')
                self.assertTrue(any(d['code'] in ('REFERENCE_ANCESTRY','REFERENCE_IDENTITY') for d in r['diagnostics']))
