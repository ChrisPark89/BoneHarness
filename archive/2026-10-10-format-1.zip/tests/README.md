# Builder project tests

These tests check this project's schemas, workflow definitions, checker, examples and retained evidence. They are maintained outside the distributable `builder-kit/` package.

From the project root, with Python 3.11 or newer and the explicitly provisioned dependencies in [the checker lock](../builder-kit/checker/requirements.lock):

```text
python -m unittest discover -s tests -v
```

Check this project's documentation links and requirement mappings separately:

```text
python tests/check-documents.py
```

To verify a harness installed in another repository, follow [the installation checker instructions](../builder-kit/checker/README.md) and [installation checklist](../builder-kit/installer/installation-checklist.md).

[Fixtures](fixtures/README.md) contain the preserved records these tests read. `support.recorded_evidence_path` resolves their original paths using `fixtures/paths.json`; historical bytes and verdicts stay unchanged. Older development logs are in the [verification archive](../archive/verification/README.md).

The [demo](demo/README.md) contains one app and its installed `.harness/`. Automated tests use temporary copies of the app files. Historical test counts describe their recorded source, not later edits.

## Test layout

| Location | Purpose |
|---|---|
| `test_*.py` | Checks of the builder kit itself. |
| [conformance-cases.yaml](conformance-cases.yaml) | Full project scenario catalogue, parsed by tests; an LLM need only read relevant cases when maintaining the kit. |
| [conformance.schema.json](conformance.schema.json) | Shape of those project scenario definitions. |
| [check-documents.py](check-documents.py) | Documentation links, required files and requirement mappings. |
| [fixtures/](fixtures/README.md) | Immutable input data used by those checks. |
| [demo/](demo/README.md) | JavaScript app, trial runner and installed `.harness/`. |

These are project development materials, not part of the distributed builder kit. The conformance catalogue describes expected behaviour, not recorded installation status or proof of successful execution. Installed harnesses use their setup criteria/checker and normal task verification; they do not need this catalogue.
