# Harness builder

An installer kit that an LLM adapts to your repository. The installed harness guides development, records evidence and supports later tool changes.

**Kit 1.1.0:** the [layout](docs/artifact-layout.md) uses `docs/` for human reading, `framework/` for installed definitions and `artifacts/` for process records, all inside `.harness/`.

## Start here

| I want to… | Read |
|---|---|
| Understand the improved structure | [Layout and human pages](docs/artifact-layout.md) |
| See the task report layout | [Report template](docs/task-report-template.md) |
| Try the current installer | [Builder README](builder-kit/README.md) |
| Inspect a small harness trial | [Demo guide](tests/demo/README.md): real commands, labelled workflow fixtures. |
| Understand the current package files | [Kit explained](docs/builder-kit-explained.md) |
| Read the context command guide | [Selected context](builder-kit/templates/runtime/framework/workflows/context.md) |
| Review detailed requirements | [Specification](docs/specification.md) |
| Review expected behavior | [Acceptance scenarios](docs/acceptance-scenarios.md) |
| See implementation progress | [Status](docs/implementation-status.md) |

Only `builder-kit/` goes to the installing LLM. Subsequent work uses the generated harness in the target repository.

## Project material

| Location | Purpose |
|---|---|
| [Working guidelines](AGENTS.md) | Persistent instructions for agents maintaining this project |
| [Verification summary](docs/verification.md) | Short results and limitations |
| [Tests](tests/README.md) | Regression checks, fixtures and reusable demo |
| [Research](docs/research/README.md) | Original references |
| [CLI idea](docs/cli-idea.md) | Future commands and how to keep extraction reusable |
| [Archive](archive/README.md) | Historical designs and verification records |
