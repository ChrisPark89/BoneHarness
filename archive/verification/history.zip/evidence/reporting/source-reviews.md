# Task reporting source review log

Authoring evidence, 2026-10-05. These are source reviews, not executed tests or evidence from a user repository. Runtime validation is NOT_RUN.


---

## task-1-review.md

# Task 1 review

## Spec Compliance

**Verdict: Spec compliant within the assigned source scope.** No missing, extra or misunderstood Task 1 requirement was established from the supplied diff and the focused dependency reads below. Runtime validation is **NOT_RUN**, pending explicit user authorization; this verdict does not establish execution correctness.

Reviewed base `eb847a7` to head `275813d8dd18aa9f346eaec4e9033745da21f039` against `task-1-brief.md`, `execution-context.md`, `review-contract.md` and `task-1-report.md`.

| Requirement | Source assessment |
|---|---|
| Strict local phase/report/diagnostic/coverage contracts | Present in `builder-kit/templates/runtime/shared/schemas/task-report.schema.json:25`, `:101`, `:143`, `:802`, `:875`, `:1543`. Objects close their shape with `additionalProperties: false`; extension fields are explicit where admitted. Shared identities, references, timestamps and targets use local common definitions. |
| Preserve existing workflow authority | The workflow hunk only adds the comment and `extensions.reporting` subtree at `builder-kit/templates/runtime/development/workflow.yaml:242`. No state, transition, guard, resolution route, default sequence or profile activation is edited in the supplied diff. |
| Default phase inventory and repair/control roles | `builder-kit/templates/runtime/development/workflow.yaml:246` through `:259` maps twelve work rows, a separate repair row and five controls. Comparing this map to the existing state declarations at `:5` accounts for all twenty-four states once: nineteen phase states and five controls. Existing profile examples at `:302` agree with the selected profile names; inclusion in a display map does not activate a profile. |
| Catalogue of installed evidence methods | The sixteen rows at `builder-kit/templates/runtime/development/workflow.yaml:261` transcribe the installed RULE-06 catalogue at `builder-kit/templates/runtime/shared/verification-rules.md:87`. Due states and allowed methods agree. Execution is additionally required for D-PREFLIGHT/D-BUILD/D-TEST, and actual independent review remains required. D-COMPLETE remains catalogued despite its control-state destination. |
| Preserve task acceptance and PASS meaning | Separate task/stage criterion coverage appears at `builder-kit/templates/runtime/shared/schemas/task-report.schema.json:459` and `:499`. Installed reporting rules at `builder-kit/templates/runtime/shared/verification-rules.md:223` preserve accepted TaskSpec criteria, conditional replacement evidence and attribution. Report display statuses at schema `:6` do not modify tool envelopes. |
| Legacy-match contract | The shipped descriptor at `builder-kit/templates/runtime/shared/reporting-legacy-baseline.json:1` contains a fixed map and fingerprint. The installed rules at `builder-kit/templates/runtime/shared/verification-rules.md:242` require exact canonical whole-workflow matching, excluding only reporting metadata, with no live-map fallback and visible unsupported legacy coverage. The numeric fingerprint was not recomputed because execution probes are prohibited. |
| Unsupported skips and pending section 12 | Installed rules at `builder-kit/templates/runtime/shared/verification-rules.md:254` retain the integration dependency, unsupported-claim diagnostics, actual scoped user provenance and both mandatory specification states. The map grants no skip edge. |
| Relevant inert conformance definitions | Four definitions begin at `builder-kit/templates/runtime/shared/conformance-cases.yaml:8670`, `:8727`, `:8784` and `:8842`; they cover partition/custom phases/display status/unchanged permissions and are included in the S-10 variant manifest. They explicitly distinguish definitions from observed validation. Test authoring is correctly deferred under the controller ruling. |

## Strengths

- The reporting metadata is confined to the existing extension point (`builder-kit/templates/runtime/development/workflow.yaml:242`), preserving the workflow graph and authority boundaries.
- The report can express absent identities and unsupported claims without fabricating them; nullable scope/state fields, retained claims, diagnostic references and separate report/check/completion vocabularies are defined at `builder-kit/templates/runtime/shared/schemas/task-report.schema.json:210`, `:330` and `:1543`.
- Diagnostic code/message pairs are fixed at `builder-kit/templates/runtime/shared/schemas/task-report.schema.json:839` and `:875`, while typed references retain context. The rules explicitly separate hash identity from authorship, execution quality and semantic judgment (`builder-kit/templates/runtime/shared/verification-rules.md:300`).
- The implementation report accurately states **NOT_RUN** and keeps planned authoring cases pending; no test changes or historical observation records appear in the supplied diff.

## Issues

### Critical

None established.

### Important

None established.

### Minor

None established. No finding IDs were assigned.

## Cross-task items not established by this diff

- **CT-1 — Installation, Task 6:** Register the new schema and legacy descriptor, provide local schema/descriptor resolution, and install through a new configuration revision. This task introduces a cross-file reference at `builder-kit/templates/runtime/shared/schemas/workflow.schema.json:148` and the two new installed files; the installer/checker changes are outside this diff. Confirm catalogue parity checks are actually implemented, rather than merely documented at `builder-kit/templates/runtime/shared/verification-rules.md:222`.
- **CT-2 — Capture and derivation, Tasks 3–4:** Schema shape cannot prove unique phase IDs/orders, state partition, profile validity, catalogue joins, trustworthy skip authority, evidence consistency, coverage arithmetic or supported completion. Implement the checks documented in the PhaseMap, CriterionCoverage and TaskReport contracts at `builder-kit/templates/runtime/shared/schemas/task-report.schema.json:143`, `:459`, `:1543` and `builder-kit/templates/runtime/shared/verification-rules.md:210`. Preserve custom/unmapped states visibly and use only pinned definitions.
- **CT-3 — Legacy identity and validation:** Confirm the descriptor fingerprint at `builder-kit/templates/runtime/shared/reporting-legacy-baseline.json:4` matches the canonical baseline and that capture uses exactly the documented normalization. Source inspection establishes the declared contract and fixed map, not the correctness of the computed digest.
- **CT-4 — Authorized tests and native coverage:** The four brief cases (`test_every_state_is_mapped_or_control`, `test_custom_phase_is_preserved`, `test_report_status_is_not_tool_status`, `test_phase_map_does_not_authorize_skip`), schema validation and executable graph comparison remain pending. Generator behavior and native Windows/macOS/Linux support cannot be established by Task 1's declarative changes. No test/probe was run or added during this review.

## Focused unchanged-code reads and named risks

- **Risk: local references or extension composition could make the new schema incompatible with installed primitives.** Read the relevant `JsonValue`, `Extensions`, identity/path/timestamp/configuration/reference and target definitions in `builder-kit/templates/runtime/shared/schemas/common.schema.json:5` through `:217`. The referenced definitions exist, and the reporting property can satisfy the existing Extensions contract alongside the new PhaseMap refinement. No schema validator was run.
- **Risk: the new stage catalogue could weaken execution/review obligations or misstate installed allowed methods.** Read only RULE-06 and its catalogue at `builder-kit/templates/runtime/shared/verification-rules.md:78` through `:108`. The new stage rows preserve those requirements, including conditional human-execution/profile evidence rather than treating review as execution.
- **Risk: default mappings could omit a declared state or use a profile name absent from existing definitions.** Read the existing state declarations at `builder-kit/templates/runtime/development/workflow.yaml:1` through `:36`, profile examples at `:302` through `:314`, and focused profile-name matches. The declared state/profile inventory agrees with the new map by source inspection.
- **Risk: the appended conformance cases could violate the existing expected-record/state/action vocabulary.** Read the applicable Case fields in `builder-kit/templates/runtime/shared/schemas/conformance.schema.json:34` through `:225`. The introduced TaskReport record labels, descriptive expected state, REVIEW action and WALKTHROUGH coverage use admitted shapes. This is not executable conformance validation.

The supplied diff was inspected in bounded slices after the initial tool output truncated its middle. No changed implementation file was reread as a whole, no broader repository crawl was performed, and no Git state or tracked file was modified. Only this requested review artifact was written.

## Assessment

**Task quality: Approved for the Task 1 source gate.** The declarative interfaces and installed rules are coherent and keep reporting separate from workflow authority. No actual defect was established; execution, schema validation and the named integration obligations remain unverified as stated above.

**Validation: NOT_RUN.** Source and document inspection only; explicit user authorization for tests/verification remains pending.


---

## task-2-review.md

# Task 2 review

Spec compliance: **COMPLIANT on source inspection**. Task quality: **APPROVED on source inspection**. Runtime validation: **NOT_RUN**.

Reviewed base `275813d8dd18aa9f346eaec4e9033745da21f039` through head `bcb367d9e0afb9388d837c119899d72a401d23aa` using the supplied task brief, execution context, review contract, implementation report and diff package. The supplied diff was read once. No tests, execution probes, dependency installation, tracked-file edits, Git-state changes or agent dispatch were performed.

## Spec compliance

- The installed support package is provided in the runtime template at `builder-kit/templates/runtime/shared/python/harness_io/__init__.py:1`, `loader.py:1`, and `schemas.py:1`; the corresponding installed paths are the brief's `shared/python/harness_io/` paths. Its imports contain no builder, docs, tests or authoring-evidence dependency.
- `builder-kit/templates/runtime/shared/python/harness_io/loader.py:127` retains the checked read and delegates to `parse_document(content: bytes, source: Path)` at line 131. The helper parses the supplied bytes without file access. Comparing the removed implementation with the added implementation in the diff shows preserved suffix selection, strict JSON/YAML rejection logic, exception conversion and diagnostic source path (`loader.py:9`, `loader.py:73`, `loader.py:108`, `loader.py:119`, `loader.py:146`).
- The offline schema resolver is moved unchanged, including schema/reference restrictions and the registry's forbidden retrieval callback (`builder-kit/templates/runtime/shared/python/harness_io/schemas.py:27`, `schemas.py:53`, `schemas.py:77`).
- Checker compatibility modules explicitly re-export the loader API and schema API rather than duplicating their implementation (`builder-kit/checker/harness_check/loader.py:2`, `loader.py:12`, `builder-kit/checker/harness_check/schemas.py:2`, `schemas.py:9`). This preserves the canonical exception/class/function objects.
- Checker initialization binds the package through the single known relative runtime-template location, with explicit importlib loading and no ancestor search or fallback to an arbitrary package on `sys.path` (`builder-kit/checker/harness_check/__init__.py:9`, `__init__.py:14`, `__init__.py:18`). A preloaded package at another location is rejected, as stated in the implementation report.
- All seven exact dependency pins and the Python-version marker match the brief (`builder-kit/templates/runtime/shared/python/requirements.lock:1` through line 7): PyYAML 6.0.3, jsonschema 4.26.0, attrs 25.4.0, jsonschema-specifications 2025.9.1, referencing 0.37.0, rpds-py 0.30.0, and typing-extensions 4.15.0 for Python below 3.13. `builder-kit/checker/requirements.lock:2` includes this canonical lock by the correct relative path. No installation or upgrade is performed by the changed source.
- All eight task files have corresponding changes in the diff. The runtime-template location is the repository source location for the requested installed files, not a missing-file finding.

## Strengths

- The parser extraction is small and keeps scoped access separate from captured-byte parsing (`builder-kit/templates/runtime/shared/python/harness_io/loader.py:127`).
- Schema resolution is carried over without introducing a second implementation or widening retrieval permissions (`builder-kit/templates/runtime/shared/python/harness_io/schemas.py:27`).
- Dependency pins have one source of truth and compatibility imports preserve canonical object identity (`builder-kit/checker/requirements.lock:2`, `builder-kit/checker/harness_check/loader.py:2`).

## Issues

### Critical

None identified.

### Important

None identified.

### Minor

None identified.

Finding IDs: **none**.

## Focused unchanged-source check

Named risk: replacing the checker implementations with explicit exports could remove names used by existing checker callers. One focused import search in `builder-kit/checker/` and `tests/` found checker imports at `builder-kit/checker/harness_check/cli.py:36`, `checks.py:10`, and `checks.py:12`; all requested names remain exported. No other unchanged source was inspected. This establishes source-level compatibility for the visible direct imports, not every possible external consumer.

## Cross-task concerns and validation limits

- **CT-2-1, cross-task, unverified:** Actual installer inventory inclusion and copying to `<harness-root>/shared/python/` are outside this diff. The later installation task must include the four runtime support files and preserve the package location used by installed consumers. This is a integration dependency, not a defect assigned to Task 2.
- **CT-2-2, validation pending:** Existing loader cases, `test_installed_io_has_no_builder_dependency`, `test_parse_captured_bytes_matches_load`, compatibility-object identity and rejection of unrelated preloaded packages remain **NOT_RUN**, consistent with the explicit prohibition on tests/probes. Source inspection does not establish their execution outcomes.
- **CT-2-3, platform coverage pending:** Native Windows, macOS and Linux runtime/import behavior is unverified. The source introduces no evident platform-specific dependency, but this review cannot certify native coverage.

## Assessment

Task quality: **APPROVED on source inspection**. The extraction preserves the prior strict behavior and diagnostics in the diff, keeps the installed package independent of the builder, and uses explicit compatibility exports and exact canonical dependency pins. No task-scoped defect was identified; installation integration and runtime validation remain pending as declared above.


---

## task-3-review.md

# Task 3 review

## Spec compliance

**Issues found.** T3-R1 (Important) rejects the immutable invocation/status revisions required by the installed protocol. The requested capture and publication-check interfaces and both implementation files are present; proposed tests were correctly not added under the controller override.

**Cross-task requirements remain open:** CT3-1 (Task 5 publication staging), CT3-2 (source inventory protocol and Task 4 completion gating), and CT3-3 (downstream authority/coverage consumption). These are interface obligations, not assertions about unimplemented Task 4/5 behavior.

Reviewed base `bcb367d9e0afb9388d837c119899d72a401d23aa` to head `971e4c881f7cdc2ee58e6838ad81f85a853ec1d0`.

## Strengths

- `builder-kit/templates/runtime/development/reporting/evidence.py:116`, `:353`, `:955`, `:979`: capture uses scoped reads, inventories run entries, hashes actual evidence bytes, retains the inspected-input ledger, excludes the fixed outputs, and performs an end-of-capture stability comparison. The later publication check reuses the captured ledger.
- `builder-kit/templates/runtime/development/reporting/evidence.py:577`: committed history is evaluated in order with a retained invalid suffix, while the saved snapshot is checked separately. Scanned proposals receive no automatic committed status.
- `builder-kit/templates/runtime/development/reporting/evidence.py:353`, `:791`, `:947`: external and fixture evidence remain visibly unsupported, semantic judgments retain attribution, and the missing source-content protocol is represented as mandatory unchecked coverage rather than an invented successful check.

## Issues

### Critical

None established by source review.

### Important

**T3-R1 — Valid immutable invocation revisions are rejected as ID collisions.**

`builder-kit/templates/runtime/development/reporting/evidence.py:434` and `:445` group every Invocation by `intent_id` and invalidate every entry once a second document exists. Independently, `:844` joins a Result to every schema-valid Invocation with the same `run_id` and rejects any count other than one. Installed `builder-kit/templates/runtime/shared/verification-rules.md:27`, `:31`, and `:136` require preserving immutable intent/status/handle revisions and referencing the current revision through committed post-states. Those revisions represent one logical invocation and naturally retain its intent/run identity.

Consequently, a normal persisted intent followed by a committed RUNNING or COMPLETED status revision produces collision errors and invalidates the matching Result, even when each reference has the correct immutable hash. This breaks the requirement to preserve historical records while checking the selected execution evidence; the implementation report's conservative limitation does not resolve that protocol incompatibility.

Preserve all revisions under the logical ID, distinguish immutable document revisions from conflicting logical identities, and select the applicable revision through committed event/post-state references. Check invariant task/run/capability/input identities across revisions. Result joins must resolve the committed revision applicable to that outcome rather than counting all historical revisions. Do not choose by filename or timestamp. If revision authority remains ambiguous, expose that specific ambiguity as unchecked rather than declaring every repeated ID a conflict. Task 4 must receive the resulting revision/authority contract.

### Minor

None recorded.

## Cross-task items

**CT3-1 — Important integration requirement: agree how publication temporaries interact with input inventory.** `builder-kit/templates/runtime/development/reporting/evidence.py:116` excludes only the two final output names; `:998` compares the entire run inventory. `.superpowers/sdd/reporting-implementation-plan/task-5-brief.md:11` requires a stability check immediately before publication and `:12` requires temporary outputs inside the task directory. If Task 5 stages those files before its final check, this API necessarily reports its own staging files as a source change. The implementation report instead instructs staging outside the run, contradicting Task 5's agreed location. Task 5 is unimplemented, so no future control flow is claimed here. Resolve the interface before implementation: for example, explicitly register and exclude only this publisher's exact temporary output paths from evidence discovery and inventory checks, retaining detection of unrelated additions/removals. Alternatively, document a compliant sequencing design and its stability boundary. Do not broadly ignore filename patterns or treat temporary report content as evidence.

**CT3-2 — Source inventory clarification remains necessary for positive completion support.** `builder-kit/templates/runtime/development/reporting/evidence.py:947` emits mandatory `source_content_inventory: UNCHECKED` for every captured state. This truthfully implements the controller ruling: an opaque `input_snapshot` and matching referenced bytes cannot establish dirty/untracked inventory completeness. It is not a Task 3 defect to refrain from inventing the pending protocol. It does mean the reference implementation currently cannot support `SUPPORTED_BY_CHECKED_RECORDS` for such a state. Task 4 must enforce that block, and documentation must describe the limitation. Resolving it requires the user-approved portable format or a conforming repository-specific checker; it cannot be closed by tests alone.

**CT3-3 — Downstream derivation must consume validity and every coverage row.** `builder-kit/templates/runtime/development/reporting/evidence.py:791` performs outcome joins after structural history capture and may downgrade record validity without removing a structural prefix entry. Tasks 4/5 must not equate prefix membership or `history.complete` with supported execution. They must use committed authority plus applicable record/evidence validity, retain historical outcomes, and retain each mandatory unchecked coverage row even if another row with the same check ID is checked. This cannot be verified from the Task 3 diff.

## Review scope and validation

- **Validation: NOT_RUN.** No tests, executable probes, builds, dependency changes, network access, source edits, Git changes, or subagents. Only the requested ignored review report was written.
- Read the supplied full diff in three consecutive chunks, once for content. Used a subsequent symbol-line metadata extraction solely to establish finding line references; no changed source file was opened separately.
- Named unchanged-code checks: immutable revision compatibility was checked against the Invocation schema (`shared/schemas/records.schema.json:710`, `:798`) and installed RULE-01/10 text (`shared/verification-rules.md:27`, `:31`, `:136`); publication inventory compatibility was checked against `task-5-brief.md:11`–`:12`. The rules search also covered the explicitly named initialization/counter concern; no additional finding is asserted from it. An initial guessed rules path did not exist; the located file above was used. No broader codebase review was performed.
- Existing source-content protocol clarification and execution prohibitions were taken from the supplied execution context. Runtime import/schema handling, actual path-escape behavior, output stability under concurrency, and native Windows/macOS/Linux execution are unverified.
- Pending authorized cases: `test_missing_log`, `test_dirty_source_mismatch`, `test_wrong_target_or_artifact`, `test_altered_request_replay`, `test_stale_snapshot_keeps_valid_history`, `test_external_evidence_unchecked`, `test_inventory_changes_during_capture`, `test_path_escape_has_no_outside_read`. The invocation-revision and publication-staging scenarios above also need focused validation when authorized; no test is added here.

## Assessment

**Task quality: Needs fixes.** The capture/authority/coverage boundaries are explicit and useful, but rejecting required immutable invocation revisions prevents reliable interpretation of ordinary execution histories. Resolve T3-R1 and the Task 5 staging interface before depending on this capture contract; keep the source-inventory limitation explicit until its protocol is settled.


---

## task-3-rereview-1.md

- **T3-R1 — Valid immutable invocation revisions are rejected as ID collisions.** — ADDRESSED. `builder-kit/templates/runtime/development/reporting/evidence.py:450` exempts Invocation revisions from the blanket repeated-ID collision rule; `:796` compares logical invariants and preserves per-event committed revision selections, with explicit mandatory unchecked coverage for ambiguity. `:864` joins each committed Result to the selection at its first committed outcome reference rather than counting every historical Invocation sharing the run ID; `:972` retains selected-record validity and identity checks. No timestamp or filename ordering chooses a revision.
- **CT3-1 — Agree how publication temporaries interact with input inventory.** — ADDRESSED. `builder-kit/templates/runtime/development/reporting/evidence.py:1101` adds exact publisher-owned temporary registration without changing capture/check signatures. `:1121`, `:1124` and `:1130` reject initial inventory entries, captured attempted lookups, duplicate registrations, outputs, symlinks, non-files, outside/subdirectory paths and hard links. `:1157`, `:1166` and `:1169` subtract only the registered direct-child filename with matching device/inode and single-link identity; replacements and unrelated inventory changes remain detectable. The Round 1 report supplies the exclusive-creation, descriptor ownership, same-directory staging and cleanup-before-recapture contract required by execution-context.md:128–129.
- **New Critical/Important breakage in the fix diff:** None found by source inspection.
- **Out-of-scope observations:** None newly recorded. CT3-2 source-content inventory format remains pending, and CT3-3 remains a downstream consumption obligation. The fix preserves mandatory unchecked source-content coverage; no unapproved format expansion was assessed.
- **Validation:** NOT_RUN. No tests, probes, builds, dependency changes, network, source edits, Git mutations or subagents. Read the supplied fix diff once, the specified brief/review/context and latest Round 1 report; inspected only named unchanged dependencies for `_walk`, reference keys, record indexing, committed reachability, `scoped_path`, Invocation schema and the installed immutable-record rules. The implementer likewise reports NOT_RUN, with proposed scenarios rather than covering test output; runtime behavior and native platform coverage remain unverified.
- **Fix round:** All findings addressed; no new Critical/Important breakage found. Source review only, for base `971e4c881f7cdc2ee58e6838ad81f85a853ec1d0` and head `1da9101777cfbc042f5355eeceaf3abda35b72fa`.


---

## task-4-review.md

## Spec compliance

**❌ Issues found.** T4-R1 violates the requirement to count recorded attempts: separate repair entries are collapsed into one phase attempt. The remaining inspected Task 4 requirements are implemented conservatively, subject to the explicitly unsupported source-inventory and applicability formats below.

**Runtime validation: NOT_RUN.** No tests, imports, execution probes, builds, or Git mutations were performed. This verdict is based on source inspection of the supplied `1da9101777cfbc042f5355eeceaf3abda35b72fa..bc5436225fbbcc5e9958252ddd48e36f5e860fee` package.

## Strengths

- Current execution authority is selected separately from historical reachability. `builder-kit/templates/runtime/development/reporting/evidence.py:904` selects direct current Result references or direct current due-review basis, preserves ambiguity, and retains existing authority for same-state/restore cases only when there is no new assertion (`:955`). Summary consumes that capture selection instead of selecting the newest favorable Result (`summary.py:219`, `:489`).
- Capture diagnostics and repeated coverage obligations are retained. The stale-record exception is narrowly restricted to otherwise-valid stale Results/reviews with fresh replacements (`summary.py:377`), while record support and check classification continue to reject other invalid dependencies (`:197`, `:693`). Log-scoped findings that cannot be safely attributed remain current issues; this conservative limitation is documented rather than silently discarded.
- Saved state and canonical event/post-state completion claims remain visible independently of the structurally committed prefix (`summary.py:420`). Completion derivation requires accepted task criteria, final verification, mandatory checked obligations, and fixed wording for unsupported completion (`:611`).
- Derivation is in memory, copies its output, and validates against a closed captured-schema registry (`summary.py:104`, `:715`). No new source-writing or command-execution path appears in this diff.
- Criterion selection preserves historical claims, uses explicit post-state review selection, and does not choose conflicting verdicts by discovery order (`summary.py:269`). Execution support is checked separately from the review record (`:317`). The current unchanged CriterionReview schema restricts the method to LLM_REVIEW (`shared/schemas/records.schema.json:946`); its source-level contract prevents an AUTOMATED review object from satisfying this path under the installed schema.

## Issues

### Critical

None identified by source inspection.

### Important

**T4-R1 — Distinct repair cycles collapse into a single phase attempt.**

- Location: `builder-kit/templates/runtime/development/reporting/summary.py:586`; phase filtering occurs at `:547`.
- `attempt_count()` compares each entry with the previous entry in the already phase-filtered list. A committed sequence `BUILD_FAILED → REPAIRING → PREFLIGHT → … → BUILD_FAILED → REPAIRING` therefore produces repair attempts `[REPAIRING, REPAIRING]`, and the second entry is excluded as though it were a same-state replay. There were two separate repair entries. The top-level repair count at `:681` correctly counts both, so the derived report contradicts itself.
- This also affects repeated entries into other phases whose recorded mapped state is identical across separated visits. It violates Task 4's explicit attempt-count requirement and understates repeated work.
- Fix: determine a same-state continuation from the corresponding canonical event's actual `previous_state` and `next_state` (and any declared restore treatment), rather than adjacency within a phase-filtered list. Keep the immutable Invocation intent-ID counting for execution phases.
- Pending focused case, when tests are authorized: two repair cycles separated by preflight/build activity must have repair phase `attempt_count == 2`; a genuine `REPAIRING → REPAIRING` waiting event must not add an attempt.

### Minor

**T4-R2 — Repair activity retains an unqualified IN_PROGRESS display after exit.**

- Location: `builder-kit/templates/runtime/development/reporting/summary.py:466`, `:550`.
- REPAIRING is mapped to IN_PROGRESS and its last phase attempt remains the repair row's current display after the committed workflow leaves repair. The unchanged graph expressly returns REPAIRING to PREFLIGHT (`development/workflow.yaml:72`). A later completed task can consequently still present repair as IN_PROGRESS. The full event history preserves the truth, so this does not fabricate completion, but it is confusing for the promised compact status report.
- Fix: add a derived activity-ended detail and explicit exit event/next-attempt reference when a committed transition leaves repair. Do not invent a repair PASS or silently erase the activity. If IN_PROGRESS must remain as the historical claim, distinguish that claim from whether repair is currently active in the presentation contract.

## Named boundary checks and inspection scope

- **Historical stale diagnostics versus fresh repairs:** inspected `summary.py:197`, `:377`, `:693` and the unchanged freshness/record-join segment of `evidence.py:995`–`:1100`. The diff cuts `joins()` mid-function, so the focused source excerpt was necessary to establish how stale flags are created. Fresh replacements do not erase records; historical classification accepts only diagnostics scoped entirely to superseded documents. Remaining event-log findings stay conservative. No additional defect was established at this boundary.
- **Current outcome authority versus retained reachability:** inspected the changed `evidence.py:904` selection and the unchanged committed reachability segment at `:744` plus `invocation_for_result()` at `:864`, whose context is cut by the diff. Recursive reachability remains record membership; current outcome selection now has its own captured authority.
- **Complete-claim preservation:** inspected `summary.py:420` and `:611`; saved/invalid-suffix COMPLETE claims are retained and produce unsupported-completion wording even when the last committed state is earlier.
- **Repair exit and counting:** inspected `summary.py:466`, `:529`, `:580`, and the specific installed workflow repair/return edges. Findings T4-R1 and T4-R2 cover this boundary.
- **Criterion method/applicability contract:** inspected only the relevant TaskSpec, CriterionReview and CriterionVerdict schema definitions and RULE-05/06/reporting method rules to evaluate whether method permissions and N/A authority were being guessed. The installed criterion verdict has no typed applicability authority; unsupported N/A remains unresolved. The method rules define AUTOMATED as execution in addition to required review, so the presence-based execution fallback is not raised as a defect against those current rules.
- The supplied diff was reviewed in one sequential pass. A subsequent coordinate extraction supplied source line numbers for report citations; no second semantic diff review or Git commands were used. No Task 5/6 implementation was reviewed.

## Cross-task requirements and limitations

- **X4-1 — Source inventory:** mandatory `source_content_inventory` remains UNCHECKED. The current reference capture consequently cannot produce positively supported completion. This is the controller's explicit format-gap ruling, not an implementation shortcut. Task 6 must state the limitation, and a future authorized format/checker is required before positive completion is attainable.
- **X4-2 — Authorized NOT_APPLICABLE:** Task 4 safely rejects all current N/A claims because the installed records do not express the required scoped authority. The positive authorized-N/A branch in the broader brief is therefore not demonstrable with the current protocol. Document the limitation and resolve it through an explicitly supported contract, not an approval boolean or prose heuristic.
- **X4-3 — Consumer contract:** Task 5 must consume `extensions.reporting.summary`, state claims, evidence attribution, attempt/criterion metadata, and retained diagnostic indices without inventing a second verdict. It must handle `ReportDerivationError` without replacing an existing report with a fabricated success. This diff cannot establish renderer/CLI compliance.
- **X4-4 — Runtime evidence:** all eight brief review cases, deterministic repeated derivation, schema/import behavior and native-platform execution remain pending explicit testing authorization. No correctness claim here substitutes for those runs.

## Assessment

**Task quality: Needs fixes.** The derivation has clear safety boundaries and preserves adverse evidence, but the phase attempt-count algorithm loses distinct repair entries. Correct T4-R1 before accepting the task; T4-R2 is a presentation improvement that can be coordinated with the renderer contract.


---

## task-4-rereview-1.md

**T4-R1 — Distinct repair cycles collapse into a single phase attempt — ADDRESSED.** `builder-kit/templates/runtime/development/reporting/summary.py:589`–`:596` now uses each committed canonical event's previous/next state, so two BUILD_FAILED → REPAIRING entries separated by preflight/build activity both count. REPAIRING → REPAIRING adds zero. Invalid suffix attempts do not count. The execution branch at `:583`–`:587` retains unique logical Invocation intent-ID counting.

### New Breakage in the Fix Diff

**Important — T4-R3: Declared repair restoration is counted as another repair attempt.** `builder-kit/templates/runtime/development/reporting/summary.py:595` counts every state-changing visit, including RESUME_REVIEW → REPAIRING. For the declared sequence BUILD_FAILED → REPAIRING → RESUME_REVIEW → REPAIRING, it returns repair `attempt_count == 2`, although only the first entry records a repair attempt. The canonical capture requires a build/test-origin increment only on the failure-to-repair entry, and requires zero increment on restoration (`builder-kit/templates/runtime/development/reporting/evidence.py:719`–`:723`). RULE-09 likewise preserves counters on restart and rejects increments on replay (`builder-kit/templates/runtime/shared/verification-rules.md:129`–`:130`); the guarded restore recovers the recorded stage (`:145`, `:153`). DEV-128 and DEV-157 explicitly provide these routes (`builder-kit/templates/runtime/development/workflow.yaml:203`, `:232`). Before this fix, the phase-filtered REPAIRING entries counted once; the changed code introduces this overcount. The fix report documents visit-count semantics, but the exported field remains `attempt_count` and the requirement is to count attempts from records. This overstates repeated repair work; it does not itself fabricate PASS or authorize another repair. Preserve restore history/activity while counting new repairs from their recorded origin/counter increment, or separately label visit counts. Do not exclude genuine later repair cycles.

**Repair activity metadata — no new breakage identified by source inspection.** `builder-kit/templates/runtime/development/reporting/summary.py:604`–`:622` selects the latest committed REPAIRING record, finds its first later committed exit, exposes the exit state/event/record-valid flag and next history attempt, and bases active status on the last committed state. Same-state continuation, subsequent repair entry/restoration, exits to preflight or stop, no repair record and invalid suffix handling preserve structural activity facts without inventing repair PASS. Existing historical statuses and diagnostics are retained. T4-R2 actual rendering remains deferred to Task 5; only its input metadata contract was inspected here.

### Out-of-Scope Observations

None newly raised. Existing top-level repair counting and other untouched derivation behavior were not re-reviewed for acceptance.

### Checks

Source-only review of supplied `bc5436225fbbcc5e9958252ddd48e36f5e860fee..3d9c453309ffa8e47efa975f0c12d506422954d0` package and Round 1 report, with focused surrounding source and installed repair/restore record rules. The fix report explicitly reports no covering runtime command or test output. Validation: **NOT_RUN** under the controller's no-tests/no-probes ruling. No tests, imports, execution probes, builds, tracked source edits, Git commands/mutations or subagents.

Pending focused cases: separated repair cycles count twice; same-state continuation does not add an attempt; declared restoration with zero repair delta does not add a repair attempt; immutable Invocation revisions count once; repair exit/next-attempt metadata; subsequent active repair; invalid suffix does not establish exit.

### Verdict

**Fix round: Findings remain open — new Important T4-R3 (restore overcount).** T4-R1 is addressed. T4-R2 rendering remains assigned to Task 5.


---

## task-4-rereview-2.md

**T4-R3 — Declared repair restoration is counted as another repair attempt — ADDRESSED.** `builder-kit/templates/runtime/development/reporting/summary.py:604`–`:609` recognizes a new repair only for BUILD_FAILED/TEST_FAILED → REPAIRING with exactly the matching nonzero origin increment. This matches capture admission at `builder-kit/templates/runtime/development/reporting/evidence.py:709`–`:723` and RULE-09 counter preservation. The repair row's attempt count (`summary.py:591`–`:592`), phase repair totals (`:572`, `:611`–`:613`) and top-level history repair total (`:737`) use the same predicate.

**Separated repair cycles and restoration — consistent by source inspection.** Each genuine later failure-origin admission increments these shared totals independently. For BUILD_FAILED → REPAIRING (+build:1) → RESUME_REVIEW → REPAIRING (zero), the branches yield one repair attempt, two committed repair visits and one restore. REPAIRING → REPAIRING adds no attempt, visit or restore. Explicit zero delta entries are ignored consistently with capture; invalid suffix entries never enter the aggregate scan.

**Repair visit metadata — consistent by source inspection.** `summary.py:527`–`:531` retains NEW_ATTEMPT, RESTORED_ACTIVITY, CONTINUATION, RECORDED_VISIT and UNVERIFIED_VISIT labels separately from attempt counts. The uncommitted branch short-circuits before inspecting malformed suffix counter data. `:634`–`:637` counts committed state-changing repair visits and restore visits separately. Existing history records, status/diagnostics, latest activity and exit/next-attempt metadata remain intact. Execution attempt counting still uses unique logical Invocation intent IDs (`:585`–`:590`). T4-R2 rendering remains assigned to Task 5.

**New breakage in the fix diff — None identified by source inspection.**

**Out-of-scope observations — None newly raised.** Existing source-format/N/A/runtime limitations and untouched derivation behavior were not re-reviewed.

**Checks — NOT_RUN.** Read the supplied `3d9c453309ffa8e47efa975f0c12d506422954d0..43a86288f43c85da167c7761dc4a08a64facba11` diff once, task brief, execution context, prior finding and Round 2 report; inspected focused surrounding source and counter/restore rules. The implementer's report explicitly identifies pending cases and reports no runtime command or test output. No tests, imports, execution probes, builds, Git commands/mutations, tracked source edits or subagents were used. Only this process review artifact was written.

**Pending checks — NOT_RUN.** Restoration across phase/top-level totals; separated genuine cycles; self-continuation; explicit zero delta keys; invalid suffix retention/exclusion; visit labels; build/test origin attribution; logical Invocation revision counting; preserved repair activity exit metadata.

**Fix round — All findings addressed, no new Critical/Important breakage.** T4-R3 addressed; T4-R2 presentation remains Task 5 work. Validation remains NOT_RUN.


---

## task-5-review.md

# Task 5 review

## Spec compliance

**Issues found.** T5-R1 is an Important scope-safety defect in the second-change publication branch. The remaining reviewed Task 5 source implements the requested rendering, preservation, and publication rules. Runtime validation: **NOT_RUN** under the controller's explicit override; no tests, imports, validators, execution probes, or product changes were performed.

Reviewed base `43a86288f43c85da167c7761dc4a08a64facba11` to head `f36c6528e182c5d8617661fe415e293e8534eab7` using the supplied diff, read once in three nonoverlapping portions. Binding materials: review contract, Task 5 brief, execution context, implementation report, specification section 13 reproduced in the execution context, and approved `docs/task-report-template.md`.

## Strengths

- `builder-kit/templates/runtime/development/reporting/render.py:62`: template parsing permits one fixed repeat row and allowlisted tokens, checks the exact approved surrounding layout, and never evaluates template expressions. `render.py:53` escapes untrusted inline text; `render.py:117` constrains clickable external schemes and generates percent-encoded local paths from captured references.
- `builder-kit/templates/runtime/development/reporting/render.py:182`: ended repair activity is explicitly historical, keeps the recorded status/claim, and reports the exit state. `render.py:165` prioritizes actual exit-log, exit-metadata and next-attempt links. T4-R2 is satisfied by the inspected renderer and the focused unchanged repair metadata contract; no repair PASS is invented.
- `builder-kit/templates/runtime/development/reporting/summary.py:782`: second-change invalidation deep-copies the report, retains the original captured outcomes, preserves claims/history, invalidates current phase and criterion support, and keeps recorded COMPLETE unsupported. It derives no new semantic verdict and performs no source I/O.
- `builder-kit/templates/runtime/development/report.py:262`: JSON and Markdown are staged from the same report. `render.py:281` hashes the same canonical JSON plus LF written by the CLI. `report.py:290` publishes JSON before Markdown and then inspects the observed pair; no transactional atomicity is claimed.
- `builder-kit/templates/runtime/development/report.py:191`: caught-failure rollback checks both publication ownership and bytes before restoring/removing a path. The implementation preserves concurrent replacements and reports incomplete preservation. `report.py:343` defers optional imports until argument parsing and uses the installed shared runtime.

## Issues

### Critical

None identified by source review.

### Important

**T5-R1 — Recheck captured scope before second-change restaging.**

Location: `builder-kit/templates/runtime/development/report.py:280`–`286`, especially the `_stage(...)` calls at lines 285–286; the next `_check_run_scope(...)` is only at line 291.

When the second `check_unchanged(capture)` detects that the captured run directory has been redirected, this branch invalidates the report, cleans the first staging files, and creates new temporary files using the stale `run` path before checking containment again. `_stage` calls `_Temporary`, whose `tempfile.mkstemp(dir=run)` creates the file before `register_publication_temporary` can reject an unsafe scope. For example, a run with no prior report pair can be replaced with a symlink to an outside directory during the second attempt: missing-output comparisons can still return `None`, the stability check reports the input change, and restaging creates an outside-scope temporary before registration fails. This is an observed unsafe-directory case following the stability check, beyond the unavoidable final-check race already documented in the report.

Impact: generation can write outside the captured repository/run scope even though the second-change path is required to publish an inconsistency report only where output paths/staging remain safe. Subsequent rejection/cleanup does not undo the fact that an unauthorized-scope file was created.

Remediation: revalidate the captured repository/harness/run scope before second-change cleanup/restaging, and reject unsafe scope with exit 2 before creating any new temporary. Prefer routing every staging batch through one scope-checked entry point so this requirement cannot be omitted in the retry branch. Keep cleanup scope-aware and retain the documented best-effort bounds for concurrent replacement races.

Source basis outside the diff: `builder-kit/templates/runtime/development/reporting/evidence.py:1187` converts failed safe reinspection into change diagnostics; `evidence.py:1153` validates registration only after the caller creates a temporary; `builder-kit/templates/runtime/shared/python/harness_io/loader.py:21` checks resolved containment. These focused reads establish that the later registration check cannot prevent the earlier `mkstemp` side effect.

### Minor

None requiring a separate finding.

## Focused contract checks and limits

- Named risk: publisher-owned staging being mistaken for changed task inventory, or unrelated files being hidden. Inspected only `evidence.py:1153`–`1240`; exact new-file registration and device/inode checks match the CLI registration and cleanup-before-recapture contract. No filename-pattern exclusion was introduced.
- Named risk: pure invalidation producing contradictory current coverage counts. Inspected `summary.py:96`–`125`; `_counts` recomputes counts from invalidated criterion results and report validation uses captured schemas. No executable validation was run.
- Named risk: renderer inventing a repair exit or pointing to nonexistent next-attempt metadata. Inspected `summary.py:614`–`667`; committed-prefix exit metadata and attempt references match the renderer's consumed fields. Invalid suffixes cannot establish a new exit through this display logic.
- Named risk: scope rechecks accepting a redirected run before staging. Inspected the scoped loader and publication registration/stability helpers above; this produced T5-R1.
- Cross-task obligation: Task 6 installation inventory, handoff integration, prerequisite availability recording, and user documentation are outside this diff and remain for the controller to establish. The new source uses installed runtime paths, but a disposable installed-runtime invocation was NOT_RUN.
- All proposed CLI cases, actual byte publication/rollback behavior, native Windows/macOS/Linux behavior, and visual one-minute report review remain NOT_RUN. No executable correctness claim follows from this source review, and the authorized absence of tests is not itself a finding.

## Assessment

**Task quality: Needs fixes.**

The renderer, pure invalidation helper, and ownership-aware publication flow have clear boundaries and retain historical evidence. Fix T5-R1 before approval so the second-change recovery path applies the same scope gate as initial staging; execution validation remains explicitly pending.


---

## task-5-rereview-1.md

**T5-R1 — Recheck captured scope before second-change restaging — ADDRESSED.** `builder-kit/templates/runtime/development/report.py:293` checks captured scope before second-change cleanup/restaging. Every initial, backup and fallback creation now passes through `_stage`, whose scope check and captured-run equality gate precede `_Temporary`/`mkstemp` (`report.py:221`, `report.py:223`, `report.py:226`, `report.py:99`). A run already redirected when `check_unchanged` returns changes is rejected before fallback creation; the operational exception handler returns exit 2 and prints the stale-prior-report notice (`report.py:330`). This addresses the specific observed unsafe-directory defect by source review.

## New breakage in the fix diff

- **Critical:** None identified.
- **Important:** None identified.
- **Minor:** None requiring a finding.
- **Scope/cleanup check:** `_check_run_scope` checks harness containment, run containment within the captured harness, and canonical run resolution (`report.py:232`–`241`). Cleanup closes an outstanding descriptor before this gate and checks ownership/unlinks only after it succeeds (`report.py:130`–`138`). Existing `_cleanup_owned` exception handling prevents recapture when cleanup fails (`report.py:188`–`196`); final cleanup reports failure without following redirected filenames (`report.py:338`–`343`). The portable final-check race remains the explicitly reported best-effort boundary; this fix makes no locking claim.

## Out-of-scope observations

None. No cross-task conclusion was attempted.

## Checks and limits

- Read the supplied `review-f36c652..72e964c.diff` once, the T5-R1 finding, Round 1 implementation report, task brief, review contract, execution-context controller rulings and scoped re-review prompt. Fix base: `f36c6528e182c5d8617661fe415e293e8534eab7`; head: `72e964c213ee4e5ced973f86efdb604a28134145`.
- Focused unchanged-source checks were limited to named fix risks: cleanup exceptions/exit handling, installed loader containment semantics, capture root/inventory alias behavior, and publication registration occurring after creation. Source review supports the new gate's ordering; it does not establish execution correctness.
- **Runtime validation: NOT_RUN.** No tests, imports, probes, validators, builds, dependencies, network, subagents or Git mutations were performed. The implementation report lists pending focused cases and explicitly reports no covering runtime run, consistent with the controller override.

## Verdict

**Spec compliance:** Pass for the scoped T5-R1 fix; runtime validation remains NOT_RUN.

**Task quality:** Approved for the scoped fix; no new Critical/Important breakage identified.

**Fix round:** All findings addressed, no new Critical/Important breakage. Open findings: none.

---

## task-6-review.md

### Spec Compliance

- ❌ Issues found: T6-R1 — installed RULE-06 table policy can change without being represented in the phase map or becoming uncovered, allowing an automated IS-04.graph PASS. This misses the binding requirement that unknown/custom policy require explicit whole-obligation review (`builder-kit/checker/harness_check/checks.py:432`, `:437`, `:469`).
- ✅ The twelve runtime additions appear in both fixed/canonical inventories; snapshot additions and capture/schema kind allowlists agree (`builder-kit/checker/harness_check/checks.py:30`; `builder-kit/templates/runtime/shared/verification-criteria.yaml:407`; `builder-kit/templates/runtime/development/templates/config-snapshot.yaml:92`; `builder-kit/templates/runtime/development/reporting/evidence.py:295`; `builder-kit/templates/runtime/shared/schemas/records.schema.json:374`).
- ✅ Optional typed availability preserves legacy ledger shape; new installer guidance requires discovery separately from setup structure, with actual execution provenance required for COMPLETED validation (`builder-kit/templates/runtime/shared/schemas/records.schema.json:2104`; `builder-kit/templates/runtime/installation/installation-record.yaml:278`; `builder-kit/INSTALLER_SPEC.md:79`).
- ✅ Completed/unfinished/blocked handoffs, migration preserving old pins/history, user navigation, unsupported source inventory/N/A limits, and the pending skip integration checklist are documented (`builder-kit/templates/runtime/development/HARNESS.md:13`; `builder-kit/templates/runtime/development/task-spec.md:22`; `builder-kit/INSTALLER_SPEC.md:79`; `docs/builder-kit-explained.md:39`; `docs/implementation-status.md:46`).
- ⚠️ Source-only review cannot establish executable schema/hash correctness, actual installed-only operation, native platform behavior, availability discovery or full section 13 acceptance. These remain NOT_RUN rather than implementation defects. The Task 6/final-review pending labels correctly await controller updates (`docs/implementation-status.md:9`).

### Strengths

- The legacy fingerprint/map checks use immutable constants independent of the customized current workflow; display metadata cannot implicitly change the baseline (`builder-kit/checker/harness_check/checks.py:452`).
- Map validation checks phase ID/order uniqueness, exact state partition and criterion/due-state/profile joins. A custom criterion actually present in stage_criteria marks the whole obligation uncovered, and supplied automated PASS is demoted instead of laundering that gap (`builder-kit/checker/harness_check/checks.py:395`, `:469`, `:750`).
- Availability, validation and report existence are distinguished, and docs explicitly retain unsupported source-content and scoped N/A limitations instead of presenting them as merely unexecuted tests (`builder-kit/INSTALLER_SPEC.md:85`; `docs/implementation-status.md:64`).

### Issues

#### Critical (Must Fix)

- None found in the reviewed source.

#### Important (Should Fix)

- **T6-R1 — RULE-06 table changes bypass policy coverage.** `builder-kit/checker/harness_check/checks.py:432` removes every table row from the normative identity; `:434` reads only ID/due/method columns; `:437` discards nonbuilt-in IDs; and `:469` discovers custom policy only from the map. Consequently, adding an installed `D-SECURITY` table row while leaving the map at its sixteen built-ins leaves the normative hash, expected built-in comparison and custom-policy condition unchanged. The method returns True and the existing run_check/finish path can publish an automated IS-04.graph PASS even though that installed criterion is omitted. Similarly, strengthening an existing row's Minimum evidence to require additional execution does not affect coverage although execution_required is hard-coded. This violates truthful coverage and installation map/catalogue parity. Include all unparsed policy-bearing table content in the supported-policy identity (or otherwise conservatively detect its changes), and reconcile declared custom table IDs against mapped criteria. Any unsupported policy must leave the whole obligation uncovered and reject a supplied automated satisfaction claim; missing declared joins should be diagnosed. Preserve support for additional custom metadata through attributable review. After execution authorization, assess a custom table row absent from the map and a changed built-in Minimum evidence cell.

#### Minor (Nice to Have)

- None.

### Assessment

- **Task quality: Needs fixes.** Most installation/documentation integration is explicit and conservative, but T6-R1 permits false automated coverage when the installed policy table changes. Fix that gap before accepting Task 6.
- **Checks performed:** read the supplied brief, review contract, integration/execution context, implementation report and complete diff in portions. The first large output was truncated; only omitted portions were recovered. No Git commands or product edits were performed.
- **Focused unchanged-source checks:** inspected graph run_check/finish/supplied-assessment consumers to determine whether custom-policy PENDING could be overridden; inspected RULE-06 table/prose to establish that excluded Minimum evidence text carries policy; inspected the remainder of capture definitions for SUPPORT byte-reading versus importing/parsing and the local-reference walker/schema shape for the new descriptor. These checks address the new call/record contracts rather than broadening to a whole-branch review.
- **Runtime validation: NOT_RUN.** No tests, imports, execution probes, schema validators, document checker, repository builds or dependency changes. No subagents. Cross-task implementations are accepted inputs, not independently revalidated by this Task 6 review.

---

## task-6-rereview-1.md

**T6-R1 — RULE-06 table changes bypass policy coverage** — ADDRESSED. `builder-kit/checker/harness_check/checks.py:431-433` now hashes the full extracted installed RULE-06 section after CRLF normalization and outer-whitespace trimming; table rows, Minimum evidence and unparsed policy content are no longer discarded. Changed policy sets `reporting_policy_uncovered` and returns incomplete coverage at `:479-482`. This removes the source-level route by which an added custom table row or strengthened built-in evidence cell could retain automated coverage.

**T6-R1 declaration/map reconciliation** — ADDRESSED. `builder-kit/checker/harness_check/checks.py:434-443` retains arbitrary declared IDs, excludes the actual header/divider shapes and diagnoses duplicate declarations. `:445-451` diagnoses every extracted declaration missing from `stage_criteria` or differing in due state/allowed methods. The sixteen built-ins retain their full required metadata checks at `:452-463`; custom mapped metadata remains permitted with whole-obligation review at `:483-486`.

### New Breakage in the Fix Diff

- **Critical:** None found by source review.
- **Important:** None found by source review.
- **Minor:** None found by source review.

### Out-of-Scope Observations

- None.

### Verdict

- **Spec compliance:** PASS for the scoped T6-R1 source fix. Unsupported policy cannot inherit automated satisfaction, and missing declared custom joins are diagnosed.
- **Task quality:** PASS for the scoped fix; no new Critical/Important breakage found.
- **Fix round:** All findings addressed, no new Critical/Important breakage. Open findings: none.

### Checks

- **SOURCE_REVIEW:** Read the re-review prompt, review contract, Task 6 brief, original T6-R1 finding, latest fix report and relevant execution context. Read the supplied `a1e798f..3638012` diff once; both changed files were included.
- **SOURCE_REVIEW:** Inspected unchanged `graph`/`run_check` and supplied-assessment/finish consumers only to trace the amended coverage contract. `checks.py:137-156` maps incomplete clean coverage to PENDING and diagnosed joins to FAIL. `:764-770` demotes supplied automated PASS/NOT_APPLICABLE when policy is uncovered; `:821-840` emits no fresh automated assessment for PENDING and prevents a supplied PASS from replacing a fresh FAIL. Current attributable permitted review remains available when structural joins hold.
- **SOURCE_REVIEW:** Inspected the installed RULE-06 table and local StageCriterion schema references to confirm the full-section policy input, actual header/divider format and declared metadata shape. README guidance agrees with the amended source contract.
- **NOT_RUN:** All execution validation, tests, imports, probes, validators, document checker, schema/hash correctness and native/runtime behavior. The fix report explicitly records these as NOT_RUN; no covering test output is claimed. Source review does not establish executable correctness or the authored digest's equality to shipped bytes.
- **NOT_RUN:** No Git commands, product mutations or subagents. Only this review report was written.

---

## final-review.md

# Final reporting feature source review

Range: `eb847a7..3638012`. Review is read-only except this report. Disposition: **With fixes**; three Important and two Minor findings.

## Strengths

- Capture, derivation, rendering and publication have explicit boundaries. Derivation and rendering use captured values; schema retrieval is closed and external evidence remains unchecked.
- Immutable invocation revision selection and current Result selection are distinct from recursive historical reachability. The repaired attempt counters retain restoration metadata without treating restored repair activity as a new repair.
- Unsupported COMPLETE wording is fixed and prominent. Mandatory source inventory coverage blocks positive completion; fixture evidence, unsupported skips and scoped N/A claims are not silently accepted.
- Publication preserves original claims on the second input change, tracks exact owned staging files, checks the final pair, and conditionally restores previous outputs without overwriting detected concurrent edits. Generation/hash metadata makes the intentionally non-atomic pair inspectable.
- Installation guidance separates runtime structure, reporter availability and executed validation. Schema/configuration additions preserve legacy record compatibility, and author documentation distinguishes historical baseline results from this unexecuted update.

## Issues

### Critical

None established by source review.

### Important

**FR-1 — Capture rejects the shipped default phase map's dormant profile selectors.**

- File: `builder-kit/templates/runtime/development/reporting/evidence.py:512` and `:520`.
- The capture accepts phase profile selectors only from `repo-profile.workflow_profiles`. The shipped profile registers only `default` (`shared/repo-profile.yaml:330`), while most shipped phase definitions include `source-only` and `docs` (`development/workflow.yaml:246`). Those labels are valid dormant declarations in the workflow's `extensions.profile_examples`. Installation explicitly accepts them in `builder-kit/checker/harness_check/checks.py:401` and the installed selector contract.
- Impact: an ordinary default installation can pass installation mapping checks yet always produce `REPORT_PHASE_MAP_INVALID`, `UNVERIFIABLE` record checks and `UNVERIFIED` recorded phase outcomes. The same mismatch affects the bundled legacy map. This masks genuine evidence status and defeats useful default reporting.
- Fix: align capture's display-selector validation with the pinned workflow selector contract (canonical active profiles plus explicitly declared dormant examples). Keep actual task profile selection restricted to canonical active profiles; a dormant display selector must grant no activation or transition permission.

**FR-2 — Reporter coverage does not preserve the installation checker's unsupported policy boundary.**

- File: `builder-kit/templates/runtime/development/reporting/evidence.py:536` through `:559`; downstream `reporting/summary.py:318` and `:355`.
- Capture parses only the first three RULE-06 table columns and never checks the policy-bearing Minimum evidence cells or prose. Its `custom` set is defined as map IDs absent from the parsed table, so a new custom criterion declared in both the table and map is not treated as custom at all. By comparison, the final integration fix in `builder-kit/checker/harness_check/checks.py:428` through `:485` correctly leaves changed complete RULE-06 policy and additional stage criteria uncovered. The reporter neither reproduces nor consumes that coverage decision.
- Concrete trigger: add a custom required review criterion to both the table and map with `execution_required: false`/`independent_review_required: true`, or strengthen a built-in Minimum evidence cell without changing its ID/due state/methods. Capture can report `stage_catalogue: CHECKED` without any mandatory custom-policy coverage limitation, and a matching review can become SATISFIED and its phase PASS despite the unsupported policy. The unrelated mandatory source-inventory limitation prevents supported overall completion, but does not make those criterion/phase claims honest.
- Fix: retain an explicit supported policy boundary in captured reporting coverage, including custom criteria present in the table and policy-bearing text changes. Mark unsupported mechanical policy mandatory UNCHECKED with `REPORT_RULE_UNCHECKED`, and keep affected satisfaction/outcomes unresolved unless a supported attributable whole-obligation mechanism establishes the required support. Do not execute prose or silently infer that matching table metadata covers custom policy.

**FR-3 — Normal CLI imports write bytecode outside the two report outputs.**

- File: `builder-kit/templates/runtime/development/report.py:361` through `:368`.
- The CLI imports installed `harness_io` and `reporting` modules with Python's default bytecode writing enabled. No `sys.dont_write_bytecode`, `-B` requirement or equivalent suppression is installed by the advertised command.
- Impact: a normal first invocation in a writable installation creates `__pycache__/*.pyc` below `shared/python/harness_io/` and `development/reporting/`. This violates the fixed read-only source / derived-output-only contract and changes the user's repository during handoff, even if report generation later fails. This conclusion is from the import source path and standard Python import behavior; no probe was run.
- Fix: suppress bytecode generation before installed/local imports in the documented CLI path. Retain help/prerequisite handling and avoid relying on the user to know an undocumented interpreter flag. If library entry points have a different host responsibility, state it explicitly.

### Minor

**FR-4 — Failure totals count retained failure-state visits as additional failures.**

- File: `builder-kit/templates/runtime/development/reporting/summary.py:571` and `:736`.
- Both totals count every attempt whose state maps to a failure role. The workflow explicitly supports `BUILD_FAILED -> BUILD_FAILED` / `TEST_FAILED -> TEST_FAILED` continuation routes and `RESUME_REVIEW` restores to those same failures. Capture already preserves the original outcome authority for these cases (`evidence.py:950`), so they need not represent another failed execution.
- Impact: one failed build followed by a same-state update or restore can display two or more recorded failures, including after eventual recovery. The corrected invocation/repair attempt counts can consequently disagree with the failure total.
- Fix: count distinct recorded failure outcomes/attempts using their selected result or canonical new-failure admission, while retaining all continuation/restore visits in history. Preserve genuinely new failed executions and visible unsupported failure claims separately; do not drop their records.

**FR-5 — The getting-started limitation paragraph needs plain wording.**

- File: `docs/builder-kit-explained.md:43` (similar language in `builder-kit/README.md`).
- “Mandatory source-content enumeration” and “Scoped NOT_APPLICABLE authority” require readers trying the kit to decode implementation terminology before understanding what the report can establish.
- Impact: the most consequential current limitation is harder to understand than the surrounding concise guide.
- Fix: say, for example: “The reporter cannot yet confirm that the recorded source snapshot includes every current file, so it cannot confirm completion. It also cannot yet verify decisions that a requirement does not apply or that a user approved skipping a phase. These claims remain visible as unresolved.” Keep exact field names in the technical reference.

## Recommendations and validation scope

Resolve FR-1 through FR-3 before accepting the combined implementation. FR-4 is a bounded remaining history-count correction; FR-5 is user-guide wording polish. Keep the already accepted repair activity-ended presentation and new-repair counting behavior intact.

Inspected the complete new capture, summary, renderer and CLI sources; shared loader/schema source and checker compatibility binding; the changed installation mapping/coverage logic; pertinent report/record/workflow schema contracts; configuration capture/inventory changes; integration guidance; section 13 and the approved plan/context/ledger. Used the supplied diff package for cross-file integration and documentation changes, with targeted current-file reads for source tracing and line references. This is a cross-component source review, not an assertion that every declarative schema/conformance line was independently executed or validated.

**All runtime validation is NOT_RUN.** No tests, imports, probes, validators, document checker, repository commands, builds, dependency installation, network access or subagents were used. No product source, index, HEAD or branch mutation was performed. No tests were added.

The plan's named contract, loader, evidence, summary and CLI review cases remain pending, including `test_every_state_is_mapped_or_control`, `test_custom_phase_is_preserved`, `test_failed_then_passed_retains_both_attempts`, `test_runtime_without_builder`, `test_installed_io_has_no_builder_dependency`, `test_reporting_changes_only_outputs`, `test_complete_with_missing_log_is_unsupported`, `test_report_pair_mismatch_is_detected`, and all remaining cases/checks enumerated in Tasks 1–6. The findings above additionally identify default dormant-selector parity, custom pinned-policy coverage, bytecode side effects, and retained-failure counting as scenarios to check when execution is authorized.

## Declined to judge

- Runtime/import/schema/publication success and adversarial execution behavior: no execution is authorized; source observations do not establish these results.
- Native Windows/macOS/Linux support: all native execution for this update remains NOT_RUN; portable-looking source does not establish native coverage.
- A positive source-content completion path: the source inventory protocol is explicitly unresolved by controller ruling; mandatory UNCHECKED coverage is appropriate and must remain.
- Supported scoped NOT_APPLICABLE and user-skip paths: the required authority formats and separate section 12 integration are explicitly pending; unsupported claims are appropriately visible.
- Full arbitrary custom verifier execution, remote evidence retrieval and proof of reviewer/tool authorship or semantic correctness: explicitly outside this read-only reference generator. FR-2 concerns truthful declaration and consumption of this boundary, not implementing those mechanisms.
- Author status text still saying Task 6/final review pending: controller bookkeeping follows this review and was explicitly excluded as a defect at dispatch.

## Assessment

**Ready to merge? With fixes.** The feature's architecture and conservative completion limits are coherent, but default selector incompatibility, missing custom-policy coverage propagation and import-created source-tree files violate central requirements. Approval can only be source approval after corrections; runtime and native behavior remain unverified under the authorized review scope.

---

## final-fix-report.md

# Consolidated final-review correction report

Date: 2026-10-05. Base: `3638012`. Scope: FR-1 through FR-5 in `final-review.md`, plus the controller-requested author status updates. All edits are confined to the disposable worktree. No ledger, original workspace, archive, research or historical evidence edits were made.

## Implementation

### FR-1: pinned display selector parity

`evidence.py` accepts phase display selectors from the union of the pinned repo profile's active `workflow_profiles` IDs and explicitly declared keys in the pinned workflow's `extensions.profile_examples`. Both explicit and supported legacy maps pass through this same validation. An unknown selector still makes the map invalid. The existing duplicate active-profile check remains. `committed_history` still derives actual task profile permission solely from active `workflow_profiles`; dormant declarations grant no task activation or transition permission.

### FR-2: supported complete RULE-06 policy boundary

Capture now retains the same complete RULE-06 policy SHA-256 boundary as the installation checker: `1b40d31acc23fe2f91bb8466a1a78cb45faf97bad9f549b9167abfdd893ad69f`. CRLF is normalized and outer whitespace stripped; all remaining policy text, including Minimum evidence cells, added rows and prose, participates. The digest is a support boundary, not an interpreter for policy text or an authenticity claim.

Table parsing follows the existing installation checker's metadata grammar. Built-in policy flags still require their known values. Custom criteria are classified against the fixed built-in ID set, so declaration in both the RULE-06 table and phase map does not grant policy support. A map-only custom criterion is likewise unsupported. Metadata joins can remain checked while policy coverage is independently mandatory UNCHECKED.

New capture contract: `capture.phase_map.stage_policy` contains:

- `supported`: whether the entire normalized RULE-06 section matches the implemented contract; this does not itself cover additional map-only custom criteria.
- `unsupported_criterion_ids`: all mapped criterion IDs when the complete policy differs, or the additional custom stage IDs when the section matches.
- `references`: the captured pinned rule document reference, when available.
- `identity`: the normalized section's `sha256:` identity; the initial unavailable value is null.

The same object is copied to `report.extensions.reporting.stage_policy` for inspection. The capture retains mandatory `stage_policy` and, when applicable, `custom_stage_criteria` UNCHECKED coverage with `REPORT_RULE_UNCHECKED` diagnostics. The fixed diagnostic text and its schema constant were updated together to cover changed built-in policy as well as custom rules. Coverage/source references remain captured values; summary adds no I/O.

Summary consumes this contract. A changed whole policy leaves both stage and accepted task criterion claims UNRESOLVED, conservatively treating the unparsed policy as potentially affecting all of them. A custom stage criterion stays UNRESOLVED even when a matching otherwise valid review says PASS. Positive/active outcomes for the affected phase stay UNVERIFIED, including later phase success after an unsupported criterion due at an active state; optional custom metadata cannot silently grant coverage either. Final-specification support requires its derived supported attempt. Unsupported policy cannot mark old criterion reviews superseded. All raw verdicts, methods, actors, evidence and recorded claims remain visible. There is no new whole-obligation authority protocol or positive custom-policy escape hatch.

The existing mandatory `source_content_inventory` limitation remains unchanged and independent; either limitation is separately inspectable and blocks supported completion. Permitted semantic judgment under the supported policy remains attributable to its recorded reviewer.

### FR-3: CLI import side effects

The CLI sets `sys.dont_write_bytecode = True` after argument validation and before importing installed `harness_io` or `reporting` modules. `--help`, argument errors, root checks and prerequisite failure handling retain their ordering. This suppression does not depend on a user-supplied interpreter flag. The package docstring and technical implementation plan describe library host responsibility to disable bytecode before importing installed modules, including the package's own initial import.

### FR-4: distinct recorded failure outcomes

Summary assigns `history.attempts[*].extensions.reporting.failure_outcome_id` to failure visits. A uniquely selected, structurally valid failed Result uses its capability/run identity. Without a selected failed Result, a new failure admission in the structurally committed prefix contributes its canonical event attempt identity. Same-state continuation and `RESUME_REVIEW` restoration reuse the retained identity for the same failure state/source revision. Later result evidence for a previously unresolved admission is associated with that admission rather than adding a second count. Distinct selected failed execution identities and genuinely new failure admissions remain separate. Invalid suffix claims get null outcome identity and remain in history.

The top-level history failure total counts distinct non-null identities. A phase's earlier failure count counts distinct identities other than its currently displayed failure, so restoring the current failed outcome does not manufacture an earlier failure. All raw attempts/visits and original outcome-selection metadata remain. Both phase and history `extensions.reporting.unsupported_failure_claim_count` separately count UNVERIFIED failure visits, including invalid suffix assertions; these are claims, not additional proven executions. No repair-count, new-repair predicate, repair visit/restore metadata, or activity-ended code was changed.

### FR-5 and author status

The beginner guide and builder README now explain that the reporter cannot yet confirm every current file is in the recorded source snapshot, or verify not-applicable/user-skip decisions; these claims remain visible as unresolved. Exact internal field names remain in the technical plan.

`docs/reporting-implementation-plan.md` and `docs/implementation-status.md` say that all six implementation tasks have been source-reviewed and the combined review findings are corrected, with scoped final source review pending. Executable acceptance stays open. The task implementation/source-review checkbox is separated from pending final source review; no runtime review case was checked off.

## Source self-review and evidence

Read the complete final findings, execution and integration context, relevant approved plan and section 13 requirements, implementer prompt, and receiving-code-review skill. Traced the installation selector/policy boundary, capture map and actual profile admission, selected outcome retention, criterion/phase/final derivation, schema extension allowances and fixed diagnostic text, CLI import ordering, current repair methods, and documentation status. Inspected the source diff after editing, including follow-up corrections made during self-review.

Source reasoning covered these paths (not executed cases):

- Default active `default` with dormant `source-only`/`docs` selectors; unknown display label; attempted dormant actual task profile; shared handling for the legacy map.
- Unchanged RULE-06 policy; custom criterion in table plus map; custom criterion only in map; built-in Minimum evidence or prose change with unchanged table metadata; missing/mismatched metadata; unsupported optional criterion; unsupported active-state criterion followed by phase success; raw review/claim retention and independent source inventory coverage.
- CLI help/argument exits before optional imports; valid arguments before local imports; dependency failure after suppression; direct library import responsibility.
- One failed execution plus repeated same-state visits/restoration; recovery after failure; a distinct later failed execution; unresolved new failure admission and late evidence; unresolved continuation; malformed/invalid history claims. Distinct totals do not rewrite raw history. Repair semantics remain the existing implementation.
- History and phase extensions are admitted by the existing schema; new policy metadata is placed in the existing report extension object. The diagnostic schema constant matches the changed capture text by source inspection.

Self-review refinements: propagated custom policy across its entire phase rather than only the criterion's exact due state; made final-specification support consume the derived attempt; prevented late result evidence from double-counting an unresolved admission; preserved the beginner guide's existing trailing blank line to avoid unrelated formatting churn.

## Files changed

- `builder-kit/templates/runtime/development/reporting/evidence.py`
- `builder-kit/templates/runtime/development/reporting/summary.py`
- `builder-kit/templates/runtime/development/report.py`
- `builder-kit/templates/runtime/development/reporting/__init__.py`
- `builder-kit/templates/runtime/shared/schemas/task-report.schema.json`
- `builder-kit/README.md`
- `docs/builder-kit-explained.md`
- `docs/reporting-implementation-plan.md`
- `docs/implementation-status.md`
- This implementation/source-review report.

No new runtime inventory files were introduced.

## Validation and remaining concerns

**All runtime validation is NOT_RUN.** No tests were added or run. No imports, ad-hoc probes, validators, document checker, repository builds, dependency installs or network requests were run. TDD execution was explicitly overridden by the controller's no-tests instruction. Native Windows/macOS/Linux execution is NOT_RUN. Source review cannot establish runtime/import/schema/publication success.

The plan's named contract, loader, evidence, summary and CLI cases remain pending, including `test_every_state_is_mapped_or_control`, `test_custom_phase_is_preserved`, `test_failed_then_passed_retains_both_attempts`, `test_runtime_without_builder`, `test_installed_io_has_no_builder_dependency`, `test_reporting_changes_only_outputs`, `test_complete_with_missing_log_is_unsupported`, `test_report_pair_mismatch_is_detected`, and all remaining review cases in Tasks 1–6. The FR-1–FR-4 paths above also require execution when authorized.

The complete policy boundary is deliberately conservative: even an unsupported policy edit that appears harmless remains unresolved. The checker and installed reporter carry the same fixed policy digest in their separate deployment contexts and must be maintained together. Positive source-inventory completion, supported scoped NOT_APPLICABLE authority and user-approved skipping remain pending independently. No architecture/interface question or known source-review defect remains open for this bounded fix. Scoped independent final review remains pending; this report does not claim its approval.

## Commit handoff

Committed product/document changes as `f5d948a` (`fix: resolve final task reporting review findings`) with `git commit -q`; the existing Block Secrets hook remained enabled and the commit exited 0. The hook reported sandbox denial for its external cache log file; its output stated the commit was protected. This was not a runtime validation run. A subsequent `git status --short` returned no tracked/unignored changes. This report stays in the already excluded local `.superpowers` review directory; it is not a delivered runtime file. Final re-review range: `3638012..f5d948a`.

---

## final-rereview.md

# Scoped final re-review: FR-1–FR-5

Review range: `3638012..f5d948a`; source review only.

## Finding verdicts

- **FR-1 — Dormant display selectors** — **ADDRESSED**. `builder-kit/templates/runtime/development/reporting/evidence.py:518` accepts the union of active profile IDs and explicitly declared workflow example keys for phase display; both map origins reach this validation. Actual task admission still uses only active profile IDs at `evidence.py:623` and `:647`. This matches the installation selector boundary at `builder-kit/checker/harness_check/checks.py:402` without activating dormant profiles.
- **FR-2 — Complete supported policy boundary and honest claims** — **ADDRESSED**. `evidence.py:548` checks the normalized complete RULE-06 section against the same policy digest as the installation checker; `evidence.py:571` classifies custom IDs against the fixed built-in set, including table-declared custom criteria. `evidence.py:573` captures support, affected IDs, identity and references; `:576` and `:585` produce mandatory unchecked coverage, with `REPORT_RULE_UNCHECKED`. `builder-kit/templates/runtime/development/reporting/summary.py:360` forces affected criterion results to UNRESOLVED while retaining raw claims, reviewers and evidence; `:400` prevents unsupported policy from superseding prior criterion records. `summary.py:514` propagates the limitation across affected positive/active phase outcomes, including a custom criterion due earlier within the phase. `:760` makes final verification depend on its derived supported attempt. Report extensions preserve the captured policy. The diagnostic text and schema constant agree at `builder-kit/templates/runtime/shared/schemas/task-report.schema.json:1517`. No positive custom-policy authority is invented.
- **FR-3 — CLI bytecode side effects** — **ADDRESSED**. `builder-kit/templates/runtime/development/report.py:364` sets `sys.dont_write_bytecode` before the installed I/O and reporting imports at `:368`; argument/help and prerequisite handling remain ordered as before. Direct-library host responsibility is stated in `builder-kit/templates/runtime/development/reporting/__init__.py:3` and the technical implementation plan.
- **FR-4 — Distinct failure totals** — **ADDRESSED**. `summary.py:608` assigns selected failed executions their capability/run identity and otherwise identifies new committed failure admissions. Same-state continuations/restores reuse retained identities; later selected evidence for an unresolved admission is associated with that admission at `:637`. Invalid suffix visits retain null identity. `summary.py:592` counts distinct earlier failures per phase and `:811` counts distinct failures in history. Separate unsupported-claim counts preserve uncertainty; raw visits, claims and outcome authority remain available. Existing repair admission/count/activity logic is untouched.
- **FR-5 — Plain-language limitations** — **ADDRESSED**. `docs/builder-kit-explained.md:43` and `builder-kit/README.md:29` explain the missing current-file coverage and unresolved not-applicable/user-skip decisions in ordinary language.
- **Author status bookkeeping** — **ADDRESSED for this handoff stage**. `docs/reporting-implementation-plan.md:13` and `docs/implementation-status.md:13` retain scoped final source review as pending and executable/native acceptance as NOT_RUN. Updating that pending status is the controller's subsequent bookkeeping, not an open product finding.

## New breakage in the fix diff

- **Critical:** None established by source inspection.
- **Important:** None established by source inspection.
- **Minor:** None established by source inspection.

## Out-of-scope observations

- None newly identified. Existing source-inventory, scoped not-applicable authority, skip integration and execution limitations remain pending as documented; this review does not extend their scope.

## Checks and limits

- Inspected the supplied fix diff, prior findings, correction report, review contract and execution context; traced only the relevant policy, profile admission, result retention, derivation and import paths.
- **Runtime validation: NOT_RUN. Native Windows/macOS/Linux validation: NOT_RUN.** No tests, imports, probes, validators, document checker, builds, dependency installation, network operations, Git commands or subagents were used. No product or Git state was changed; only this review artifact was written.
- The named plan cases remain pending, including `test_every_state_is_mapped_or_control`, `test_custom_phase_is_preserved`, `test_failed_then_passed_retains_both_attempts`, `test_runtime_without_builder`, `test_installed_io_has_no_builder_dependency`, `test_reporting_changes_only_outputs`, `test_complete_with_missing_log_is_unsupported` and `test_report_pair_mismatch_is_detected`. The correction report accurately makes source claims rather than claiming execution results.

## Verdict

- **Spec compliance:** PASS within the scoped source-review boundary.
- **Task quality:** PASS within the scoped source-review boundary.
- **Fix round:** All five findings addressed; no new Critical/Important breakage established. No open finding IDs. This is source approval, not executable acceptance.
