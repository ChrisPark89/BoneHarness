# Reporting implementation decisions

Authoring notes. These decisions explain implementation choices and their limits; they are not runtime rules or task evidence.

## Rulings

1. Ruling: Use an isolated temporary Git checkout because original is not a Git repository — preserves original and permits scoped diff reviews — transfer must compare original hashes before writing.

2. Ruling: Do not add or run tests under current authorization — developer instructions and plan's conditional test steps require explicit test/verification request — runtime behavior remains unexecuted until authorized. Source review continues.

3. Ruling: Deliver reporting independently of pending phase-skipping changes — approved plan explicitly separates them — valid skip rendering cannot be declared complete before that integration.

4. Ruling: Shared input utilities can move into installed runtime with compatibility imports — avoids duplicating strict readers and keeps reporter independent of builder — checker import regression requires review and eventual execution.

5. Ruling: Task 1 adds shared/reporting-legacy-baseline.json containing the original workflow fingerprint (canonical JSON excluding only extensions.reporting) and fixed map — old pinned workflows must not inherit a customized current map — an overly strict fingerprint may leave otherwise compatible old workflows unmapped, safely visible as unverified.

6. Ruling: Keep genesis validation separate from ordinary transition requests — RULE-01 permits version 0/null to version 1/NEW while TransitionRequest requires version >=1 — absence of a nonexistent typed initialization request is not itself a malformed later transition; preserve explicit digest coverage limitations instead. If wrong, initialization authority needs a protocol follow-up before supported completion.

7. Ruling: First SPEC_READY compares newly accepted specification/design identities to captured acceptance evidence and the complete post-state, rather than requiring equality to pre-acceptance null — normal acceptance introduces these identities — arbitrary identity changes still fail and later reacceptance/adoption needs explicit reconciliation evidence. If wrong, request-side identity convention needs a documented protocol clarification. Genesis request digest coverage is nonmandatory UNCHECKED; all representable initialization invariants remain checked.

8. Ruling: Preserve same-directory publication staging and add exact temporary-output registration to the capture API — otherwise the final inventory check mistakes its own new files for evidence changes — only paths created by this publication may be excluded, never a filename pattern or an existing captured input. If wrong, unrelated file changes might be hidden; use scoped validation and initial-inventory exclusion checks.

9. Ruling: Task 4 includes a bounded capture correction for current outcome selection — recursive event reachability includes retained past failures and cannot itself identify the current result — select explicit current request/result or due-review basis, expose its document references for derivation, and leave multiple current selections unresolved. If wrong, insufficiently explicit selection remains unverified; never choose by PASS status, filename or timestamp.

10. Ruling: Preserve prior outputs on caught publication failures with an owned same-directory JSON backup and conditional rollback — publishing JSON then Markdown is not atomic — rollback/delete only if this invocation still owns the published inode and its bytes match; otherwise preserve concurrent edits and report failure. If wrong or interrupted, the pair may remain mismatched, which must be detectable and reported. Verify the observed final pair before claiming publication success.

11. Ruling: A second input change yields an explicitly inconsistent report where publication is safe — retain captured records/hashes, add mandatory unchecked capture-stability coverage, mechanically invalidate recorded phase outcomes to UNVERIFIED, and preserve unsupported-COMPLETE wording — renderer must not invent evidence verdicts. If wrong, the report is overly conservative; unsafe publication exits 2 and preserves prior files. A small pure summary invalidation helper may support this Task 5 integration.

12. Ruling: Extend configuration definition kinds for reporter support/template bytes and add optional typed reporter-availability metadata to installation records — installation must capture the new runtime and separate structure from executable prerequisites while reading legacy records — inconsistent allowlists would block migration, so schema/checker/capture must agree and current guidance requires explicit availability on new installs. Existing records remain valid without claiming availability.


## Unresolved choices and scope

- A common source-snapshot enumeration format is awaiting user direction. Until supported enumeration exists, the reference reporter cannot positively support completion.

- Test execution authorization remains pending. Source reviews and transfer hashes are not runtime tests.

- Scoped not-applicable authority and the separate user-approved skip protocol are not implemented by this reporting update.

- Runtime publication uses checked best-effort rollback; two output replacements are not atomic, and an unrestricted concurrent writer can still race path checks.


## Final review items outside the judged scope

- Runtime, import, schema and native-platform success remain unexecuted.

- Arbitrary custom verifier execution, remote retrieval and proof of semantic correctness or authorship are outside the reference reporter. Their absence cannot become positive mechanical coverage.

- Author review-status bookkeeping is updated after final source-review disposition.

## Final corrections

The accepted correction pass aligned dormant display-profile selectors, propagated unsupported policy into unresolved outcomes, suppressed CLI bytecode writes, distinguished new failures from retained visits, and simplified user-facing limitation wording. No new source-snapshot or skip authority protocol was inferred.
