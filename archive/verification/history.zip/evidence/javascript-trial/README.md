# Archived JavaScript trial

The old demo used the earlier harness layout. It was retired on 2026-10-06 so it cannot be mistaken for a demonstration of the [new design](../../docs/artifact-layout.md).

[Download the historical archive](../../archive/2026-10-06-legacy-javascript-trial.zip).

It contains the original demo source, demo-only tests, generated harness, scenario results and review records at their original relative paths. All 3,035 files were checked byte-for-byte before removing the expanded copies. The archive includes a SHA-256 manifest.

For historical inspection, extract into a separate directory and start at `evidence/javascript-trial/README.md`. Do not extract over the active project.

The retained results cover 45 scenarios and 24 development states on macOS. Lifecycle histories are fixtures; they do not establish live LLM behavior or completion support. No replacement demo or validation of the new layout has run.
