# Candidate reuse inventory

The live candidate is the reuse source. The frozen archive remains unchanged and is evidence only. Existing files are provisional until their owning implementation task is reviewed. Recorded earlier HEAD: `a280bd1276f7aa8f2ab3501717a1840d765c3166`; content hashes below include later installer edits.

## Scratch candidate before reuse

| Path | SHA-256 |
|---|---|
| `INSTALLER_SPEC.md` | `4959a8620c1ea2bf712ea463d567add7718b4ff6b8f7498553ff335c377f1892` |
| `README.md` | `778b900b9ce11a0b80f9e27d00a44d900b86781e65086f21417ce8c8114a7ab2` |
| `installer/bootstrap-prompt.md` | `52ce1ff1c6a8a677b5ed3d35376da7102ee7b0a8354729b7172e5f062b29834e` |
| `installer/installation-checklist.md` | `4cc8c543fc454074b99203e49838c9080f6afb1d05620a645d8901023e028b4e` |
| `templates/runtime/HARNESS.md` | `5e8e70ecada2ce1bb7073c912315f12297cc0bbae34978a307883edbfadaf815` |
| `templates/runtime/harness-status.md` | `930ea9d19f8aa261a7e3b4ce1961ec42d3a4ba2bee5677399ff080706f6f1d9f` |
| `templates/runtime/repo-profile.yaml` | `fb46b5a10d7b480eb0e41e04283615bf59d149c41996268b47f0d6c2cf24ddb2` |
| `templates/runtime/skill-contract.md` | `d2628bc8938990a3de93505a1aaa4784fa9964bb7910bfe338d6cac49df5f582` |
| `templates/runtime/task-spec.md` | `e8688b23f0d698667fa56b768a642e18b619b91dfa8e85d5af73fda847977a88` |
| `templates/runtime/workflow.yaml` | `b0ca47ff4489a2e36858b2e9129a776db4934c6d8f7dfd0cbce311af5542e93e` |

## Current live candidate

| Path | SHA-256 |
|---|---|
| `INSTALLER_SPEC.md` | `6079e59add57fd326b3517e1e44ef1a59c3e82a4017b5a49381954372a617dba` |
| `README.md` | `168e381634395898fa5d62894916e21097762054a8c37815a8767f54dd9a05e2` |
| `installer/bootstrap-prompt.md` | `8f871e999668cf400c3e2b95f006a0ecf01dcc09f3208be5e42490455ded55f5` |
| `installer/installation-checklist.md` | `5387b964e0b11430f227e0e837808687c986b9f797846d1d4e5485e32bfbe0f9` |
| `templates/runtime/development/HARNESS.md` | `23a4dedd61737c68578ee180d857446ac856929314afce25fbe55783a7af97fd` |
| `templates/runtime/development/task-spec.md` | `7bf237fd7858d8edf6b72f9c3bc4caaeea1b6430d990c2761655af564a07b51a` |
| `templates/runtime/development/workflow.yaml` | `cd3fa95a19ecfe093b4e4f3fb950b4a89538cbbb1f792a3625c81c024964765f` |
| `templates/runtime/maintenance/harness-maintenance.md` | `777231fcf92219feab339b9159b376b0cb0604a3ea2a7afd4a55262e3b326de4` |
| `templates/runtime/maintenance/maintenance-workflow.yaml` | `4df10168a522fb46e761d4100a2dc6bf03c621b015092b4614ac0b39488af0ce` |
| `templates/runtime/maintenance/templates/harness-update-record.yaml` | `c08407a06eb1112060f77cf11370f6ed9cda2bb8b70a22397e530302a9859190` |
| `templates/runtime/shared/harness-status.md` | `33cd1c281ba0e13b992b32a56dc96188e437a5fa27bfb342b090ffa2c2f1e7bd` |
| `templates/runtime/shared/repo-profile.yaml` | `f6885c089ac95bc28b25fc1664c2b43408f372716f33b5d89588a85070fb120c` |
| `templates/runtime/shared/skill-contract.md` | `bffa6c7651f5069dd1d48825f85d831491601db575268f8a63dfa73e4cf7c12b` |

## Frozen audit evidence

| Path | SHA-256 |
|---|---|
| `INSTALLER_SPEC.md` | `6079e59add57fd326b3517e1e44ef1a59c3e82a4017b5a49381954372a617dba` |
| `README.md` | `168e381634395898fa5d62894916e21097762054a8c37815a8767f54dd9a05e2` |
| `installer/bootstrap-prompt.md` | `8f871e999668cf400c3e2b95f006a0ecf01dcc09f3208be5e42490455ded55f5` |
| `installer/installation-checklist.md` | `5387b964e0b11430f227e0e837808687c986b9f797846d1d4e5485e32bfbe0f9` |
| `templates/runtime/development/HARNESS.md` | `23a4dedd61737c68578ee180d857446ac856929314afce25fbe55783a7af97fd` |
| `templates/runtime/development/task-spec.md` | `7bf237fd7858d8edf6b72f9c3bc4caaeea1b6430d990c2761655af564a07b51a` |
| `templates/runtime/development/workflow.yaml` | `cd3fa95a19ecfe093b4e4f3fb950b4a89538cbbb1f792a3625c81c024964765f` |
| `templates/runtime/maintenance/harness-maintenance.md` | `777231fcf92219feab339b9159b376b0cb0604a3ea2a7afd4a55262e3b326de4` |
| `templates/runtime/maintenance/maintenance-workflow.yaml` | `4df10168a522fb46e761d4100a2dc6bf03c621b015092b4614ac0b39488af0ce` |
| `templates/runtime/maintenance/templates/harness-update-record.yaml` | `c08407a06eb1112060f77cf11370f6ed9cda2bb8b70a22397e530302a9859190` |
| `templates/runtime/shared/harness-status.md` | `33cd1c281ba0e13b992b32a56dc96188e437a5fa27bfb342b090ffa2c2f1e7bd` |
| `templates/runtime/shared/repo-profile.yaml` | `f6885c089ac95bc28b25fc1664c2b43408f372716f33b5d89588a85070fb120c` |
| `templates/runtime/shared/skill-contract.md` | `bffa6c7651f5069dd1d48825f85d831491601db575268f8a63dfa73e4cf7c12b` |

## Decisions

| Current source file | Decision and owner |
|---|---|
| `INSTALLER_SPEC.md` | Adapted as `INSTALLER_SPEC.md`; active contract references renamed; provisional until Task 4 (installer). |
| `README.md` | Adapted as `README.md`; trim extra blank line at EOF; preserve newer live content; provisional until Task 4 (installer). |
| `installer/bootstrap-prompt.md` | Adapted as `installer/bootstrap-prompt.md`; active contract references renamed; provisional until Task 4 (installer). |
| `installer/installation-checklist.md` | Adapted as `installer/installation-checklist.md`; active contract references renamed; provisional until Task 4 (installer). |
| `templates/runtime/development/HARNESS.md` | Reused as `templates/runtime/development/HARNESS.md`; preserve newer live content; provisional until Task 2 (runtime). |
| `templates/runtime/development/task-spec.md` | Reused as `templates/runtime/development/task-spec.md`; preserve newer live content; provisional until Task 2 (runtime). |
| `templates/runtime/development/workflow.yaml` | Reused as `templates/runtime/development/workflow.yaml`; preserve newer live content; provisional until Task 2 (runtime). |
| `templates/runtime/maintenance/harness-maintenance.md` | Adapted as `templates/runtime/maintenance/harness-maintenance.md`; active contract references renamed; provisional until Task 3 (maintenance). |
| `templates/runtime/maintenance/maintenance-workflow.yaml` | Reused as `templates/runtime/maintenance/maintenance-workflow.yaml`; preserve newer live content; provisional until Task 3 (maintenance). |
| `templates/runtime/maintenance/templates/harness-update-record.yaml` | Reused as `templates/runtime/maintenance/templates/harness-update-record.yaml`; preserve newer live content; provisional until Task 3 (maintenance). |
| `templates/runtime/shared/harness-status.md` | Reused as `templates/runtime/shared/harness-status.md`; preserve newer live content; provisional until Task 2 (runtime). |
| `templates/runtime/shared/repo-profile.yaml` | Reused as `templates/runtime/shared/repo-profile.yaml`; preserve newer live content; provisional until Task 2 (runtime). |
| `templates/runtime/shared/skill-contract.md` | Adapted as `templates/runtime/shared/adapter-interface.md`; active contract references renamed; provisional until Task 2 (runtime). |

The six obsolete flat runtime copies were superseded and removed only after their separated replacements existed. New contracts/tests are Task 1 deliverables. No archive or research file was modified.

## Limits

Reuse preserves useful separation and installer discovery edits, not acceptance of the old sentinel values, workflow graph, interface, or unchecked claims. Later tasks replace these provisional bodies against the approved specification.
