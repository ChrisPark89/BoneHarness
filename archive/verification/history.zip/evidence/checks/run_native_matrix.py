"""Authoring-only native subprocess evidence capture; no simulated OS PASS."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import zipfile
import yaml


def hash_bytes(data):return 'sha256:'+hashlib.sha256(data).hexdigest()
def digest(path):return hash_bytes(path.read_bytes())
def tree(root):
    return {p.relative_to(root).as_posix():{'kind':'symlink','target':os.readlink(p)} if p.is_symlink() else {'kind':'file','identity':digest(p)} if p.is_file() else {'kind':'directory'} for p in sorted(root.rglob('*'))}
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--examples',required=True,type=Path);ap.add_argument('--scratch',required=True,type=Path);ap.add_argument('--python311',required=True);ap.add_argument('--python314',required=True)
    args=ap.parse_args();kit=Path(__file__).resolve().parents[2];out=kit/'evidence/checks';scratch=args.scratch.resolve();scratch.mkdir(exist_ok=False)
    cwd=scratch/'different working directory café';cwd.mkdir()
    check=kit/'checker/check.py';runs=[];host='macOS' if platform.system()=='Darwin' else platform.system()
    # LF/CRLF portability compares equivalent pending installations freshly copied from generated baseline cfg-1.
    for ending in ['LF','CRLF']:
        destination=scratch/(ending+' examples café')
        generated=subprocess.run([args.python314,str(kit/'examples/make_examples.py'),'--destination',str(destination)],cwd=cwd,capture_output=True,text=True)
        assert generated.returncode==0,generated.stderr
        for name,hroot in [('compiled','.harness'),('source-only','tools/harness café'),('docs','.harness'),('multi-target','.harness')]:
            repo=destination/name;h=repo/hroot
            if ending=='CRLF':
                # Convert only runtime YAML/Markdown with no typed content-identity evidence dependencies.
                for name2 in ['development/workflow.yaml','maintenance/maintenance-workflow.yaml','development/HARNESS.md','maintenance/harness-maintenance.md','shared/verification-rules.md']:
                    path=h/name2;path.write_bytes(path.read_bytes().replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'))
                ledger=yaml.safe_load((h/'installation/installation-record.yaml').read_text())
                for inventory in [ledger['generated_paths'],ledger['owned_paths']]:
                    for item in inventory:
                        if item['after_identity'] is not None:item['after_identity']=digest(h/item['path'])
                write(h/'installation/installation-record.yaml',ledger)
            for minor,python in [('3.11',args.python311),('3.14',args.python314)]:
                label=host+'-'+name+'-'+ending+'-python'+minor.replace('.','');before=tree(repo)
                command=[python,str(check),'--repo-root',str(repo),'--harness-root',hroot,'--format','json']
                proc=subprocess.run(command,cwd=cwd,capture_output=True,timeout=90)
                (out/(label+'.stdout.json')).write_bytes(proc.stdout);(out/(label+'.stderr.txt')).write_bytes(proc.stderr)
                after=tree(repo);report=json.loads(proc.stdout)
                write(out/(label+'.trees.json'),{'before':before,'after':after})
                runs.append({'id':label,'status':'PASS' if proc.returncode==0 and before==after else 'FAIL',
                    'os':host,'python_minor':minor,'runtime':report['platform']['runtime'],
                    'architecture':report['platform']['architecture'],'dependencies':report['platform']['dependencies'],
                    'checker_source_manifest':{str(x.relative_to(kit/'checker')):digest(x) for x in (kit/'checker').rglob('*.py')},'command':command,'cwd':str(cwd),'repository':str(repo),'harness_root':hroot,'line_endings':ending,
                    'exit_code':proc.returncode,'stdout':'builder-kit/evidence/checks/'+label+'.stdout.json','stderr':'builder-kit/evidence/checks/'+label+'.stderr.txt',
                    'input_tree_evidence':'builder-kit/evidence/checks/'+label+'.trees.json','before_tree':hash_bytes(json.dumps(before,sort_keys=True).encode()),'after_tree':hash_bytes(json.dumps(after,sort_keys=True).encode()),
                    'observed_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'structure_assessment':report['structure_assessment'],'integration_assessment':report['integration_assessment']})
    for name,hroot in [('compiled','.harness'),('source-only','tools/harness café'),('docs','.harness'),('multi-target','.harness')]:
        repo=args.examples/name;before=tree(repo);label='reviewed-'+name
        command=[args.python314,str(check),'--repo-root',str(repo),'--harness-root',hroot,'--format','json']
        proc=subprocess.run(command,cwd=cwd,capture_output=True,timeout=90)
        (out/(label+'.stdout.json')).write_bytes(proc.stdout);(out/(label+'.stderr.txt')).write_bytes(proc.stderr)
        after=tree(repo);write(out/(label+'.invocation.json'),{'command':command,'cwd':str(cwd),'exit_code':proc.returncode,'before':before,'after':after,'read_only':before==after})
    previous_path=kit/'evidence/native-platform-matrix.yaml'
    previous=yaml.safe_load(previous_path.read_text()) if previous_path.exists() else {'runs':[]}
    runs=[r for r in previous.get('runs',[]) if r['os']!=host]+runs
    observed_hosts={r['os'] for r in runs if r['status']=='PASS'}
    pending=[]
    for host in sorted({'Windows','macOS','Linux'}-observed_hosts):
        prefix='py -3.11' if host=='Windows' else 'python3.11'
        pending.append({'os':host,'status':'PENDING','python_versions':['3.11','3.14'],'dependencies':'Explicitly provision builder-kit/checker/requirements.lock; never implicit downloads.',
            'reason':'No native '+host+' host available in this session. macOS paths or emulation do not substitute.',
            'reproduction_commands':[prefix+' builder-kit/examples/make_examples.py --destination "<absolute empty root>/examples café"',
                prefix+' builder-kit/evidence/checks/run_native_matrix.py --examples "<absolute reviewed examples>" --scratch "<absolute new scratch>" --python311 "<native Python 3.11>" --python314 "<native Python 3.14>"'],
            'required_obligations':['Both native runtimes, four examples, LF/CRLF, spaces/Unicode, different cwd, exact command/deps/exit/stdout/stderr and identical before/after tree identities.']})
    write(kit/'evidence/native-platform-matrix.yaml',{'claims':'Actual native subprocesses only. Exit zero covers structural checks, not semantic completion.','runs':runs,'pending':pending})
    with zipfile.ZipFile(out/'installed-walkthrough.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(args.examples.rglob('*')):
            if p.is_file():archive.write(p,p.relative_to(args.examples).as_posix())
    print(json.dumps({'runs':len(runs),'passed':sum(r['status']=='PASS' for r in runs),'failed':[r['id'] for r in runs if r['status']!='PASS']}))


if __name__=='__main__':main()
