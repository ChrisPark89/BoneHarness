"""Fixed Task 6 review correction; restore disposable archived cfg-3 and retain history.

Only the two reviewed maintenance attempts and adoption are rebuilt. Existing source
and original installation/development history remain exact. No production activity.
"""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from run_native_matrix import tree


def digest(p):return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--destination',required=True,type=Path);ap.add_argument('--python311',required=True);args=ap.parse_args()
    out=Path(__file__).resolve().parent;kit=out.parents[1];root=args.destination.resolve();root.mkdir(exist_ok=False)
    archive=out/'installed-walkthrough.zip';old_archive=digest(archive)
    with zipfile.ZipFile(archive) as z:z.extractall(root)
    h=root/'compiled/.harness';run=h/'development/runs/SYNTHETIC-task'
    original={str(p.relative_to(root)):digest(p) for p in root.rglob('*') if p.is_file() and (
        p.relative_to(root).parts[0] in ['source-only','docs','multi-target'] or p.is_relative_to(run/'configuration/initial') or
        p==run/'config-snapshot.yaml' or p.is_relative_to(h/'installation/evidence') and p.name not in ['replace-build-review.json','rule-schema-migration-review.json'])}
    log=json.loads((run/'events.yaml').read_text());history=deepcopy(log['events'][:10]);assert history[-1]['next_state']=='BLOCKED'
    for p in (run/'configuration/initial').rglob('*'):
        if p.is_file():shutil.copyfile(p,h/p.relative_to(run/'configuration/initial'))
    for name in ['replace-build','rule-schema-migration']:
        shutil.rmtree(h/'maintenance/updates'/name);(h/'maintenance/updates'/(name+'.yaml')).unlink()
        (h/'installation/evidence'/(name+'-review.json')).unlink()
    for name in ['synthetic_adapter_B.py','procedure-B.md']:(h/'shared/adapters'/name).unlink()
    shutil.rmtree(run/'configuration/adopted');(run/'adopted-config-snapshot.yaml').unlink()
    for p in (run/'evidence').glob('adoption-*'):p.unlink()
    log['events']=history;write(run/'events.yaml',log);write(run/'state.yaml',history[-1]['post_state'])
    recorder=root.parent/(root.name+'-installed-recorder.py');shutil.copyfile(out/'installed_walkthrough.py',recorder)
    cwd=root.parent/(root.name+' different cwd café');cwd.mkdir(exist_ok=False)
    cmd=[sys.executable,str(recorder),'--examples',str(root),'--denied-builder',str(kit.parent),'--maintenance-only']
    proc=subprocess.run(cmd,cwd=cwd,capture_output=True);(out/'task6-fix1-walkthrough.stdout.txt').write_bytes(proc.stdout);(out/'task6-fix1-walkthrough.stderr.txt').write_bytes(proc.stderr)
    assert proc.returncode==0,proc.stderr.decode()
    after={name:digest(root/name) for name in original};assert original==after
    assert json.loads((run/'events.yaml').read_text())['events'][:10]==history
    write(out/'task6-fix1-preserved-history.json',{'original_archive_identity':old_archive,'command':cmd,'cwd':str(cwd),'exit_code':proc.returncode,'preserved_files':original,'after_files':after,'initial_ten_events_preserved':True,'limitations':['A corrected synthetic maintenance attempt replaces the invalid previous demonstration in the retained archive; original cfg-3/A and all other examples remain exact.']})
    for minor,python in [('314',sys.executable),('311',args.python311)]:
        label='reviewed-compiled' if minor=='314' else 'task6-fix1-reviewed-compiled-python311'
        before=tree(root/'compiled');command=[python,str(kit/'checker/check.py'),'--repo-root',str(root/'compiled'),'--harness-root','.harness','--format','json']
        proc=subprocess.run(command,cwd=cwd,capture_output=True);(out/(label+'.stdout.json')).write_bytes(proc.stdout);(out/(label+'.stderr.txt')).write_bytes(proc.stderr)
        after=tree(root/'compiled');write(out/(label+'.invocation.json'),{'command':command,'cwd':str(cwd),'exit_code':proc.returncode,'before':before,'after':after,'read_only':before==after})
        assert proc.returncode==0 and before==after,proc.stdout.decode()
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(root).as_posix())
    print(json.dumps({'preserved_files':len(original),'initial_events_preserved':10,'native_compiled_runs':2,'all_read_only':True,'archive_identity':digest(archive)}))


if __name__=='__main__':main()
