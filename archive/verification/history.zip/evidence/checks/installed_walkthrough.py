"""Authoring-only, one-shot recording of a reviewed disposable walkthrough.

This is NOT an installed state writer, gate implementation or general migration runner.
Its predetermined decisions below were reviewed against the installed rules by the
Task 6 author. It writes actual example files and immutable observations so those
procedural decisions can be independently inspected. Run only on fresh examples.
No builder imports or definitions are used. An audit hook denies builder reads.
"""
import argparse
from copy import deepcopy
from datetime import datetime, timezone, timedelta
import hashlib
import importlib.util
import json
import os
import re
from pathlib import Path
import shutil
import sys
import yaml
from jsonschema import Draft202012Validator
from referencing import Registry, Resource

sys.dont_write_bytecode=True
ACTOR='Codex Task 6 procedural reviewer'


def stamp():return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def digest(p):return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def identity(v):return 'sha256:'+hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def read(p):return yaml.safe_load(p.read_text(encoding='utf-8'))
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def ref(p):return {'kind':'LOCAL','scope':'HARNESS','path':p}
def record(kind,**v):return dict(schema_version='1.0.0',record_type=kind,**v)
def evidence(h,p,summary,provenance='REVIEW'):
    return dict(reference=ref(p),identity=digest(h/p),summary=summary,provenance=provenance)
def filemap(root):return {p.relative_to(root).as_posix():digest(p) for p in sorted(root.rglob('*')) if p.is_file() and '.git' not in p.parts}


def validate(h,value,schema,definition=None):
    root=h/'shared/schemas'
    registry=Registry().with_resources((p.as_uri(),Resource.from_contents(read(p))) for p in root.glob('*.json'))
    uri=(root/schema).as_uri()+(('#/$defs/'+definition) if definition else '')
    errors=list(Draft202012Validator({'$ref':uri},registry=registry).iter_errors(value))
    if errors:raise ValueError('\n'.join(str(e) for e in errors))


def ev_record(h,subject,kind,events,state,decision,request_id,request=None):
    previous=events[-1]['post_state'] if events else None
    state['version']=len(events)+1
    event=record('Event',subject_kind=kind,subject_id=subject,request_id=request_id,
        request_content_identity=request['request_content_identity'] if request else identity({'request':request_id,'before':previous,'after':state}),
        previous_version=len(events),next_version=len(events)+1,previous_state=previous['state'] if previous else None,
        next_state=state['state'],timestamp=stamp(),actor=ACTOR,decision_ref=decision,evidence_refs=[decision],
        counter_deltas={kind:{key:value-(previous or {}).get(field,{}).get(key,0) for key,value in state.get(field,{}).items() if value!=(previous or {}).get(field,{}).get(key,0)} for kind,field in [('repair','repair_counters'),('invocation','invocation_counters')]},post_state=deepcopy(state))
    validate(h,event,'records.schema.json','Event');events.append(event)


REVIEW_NOTES={
 'IS-01.files':'Compared every required_runtime_files path with actual installed regular files; development, maintenance and shared directories are distinct.',
 'IS-01.schemas':'Loaded installed schemas offline and validated the staged profile, catalogue, workflows, ledger and durable templates. Typed pending test binding remains valid without guessing commands.',
 'IS-02.local_refs':'Read target-local entry points and their relative links; adapter procedure, input schema, rules, cases and templates are installed. No builder reference is required.',
 'IS-02.ownership':'Fresh disposable repository has USER-NOTES.txt outside generated inventory; exact proposed AGENTS.md pointer has absent before-value and captured candidate hash. Preserve user/history paths.',
 'IS-03.registry':'Profile alone owns six capability bindings and selected workflow profile; workflow stage_capabilities only refers to IDs. Maintenance selectors remain distinct.',
 'IS-03.separation':'Development records are under development/runs; updates under maintenance/updates; shared holds definitions and derived status. Inspected both runtime entry points and record templates.',
 'IS-04.graph':'Read both workflows: endpoints, unique IDs, declared selectors and RULE-01 through RULE-17 resolve. Default sequence and explicit source/docs alternate edges are present.',
 'IS-04.routing':'Inspected installed RULE-01/05/06/09/10 and conformance cases S-11/12/14/20/22/25/26. Success refusal preserves state; separate failure/stop event; missing or uncertain result blocks, repair disabled.',
 'IS-05.result_schema':'Validated four emitted synthetic outcome envelopes against installed schema. PASS requires consumed artifact; FAIL does not invent one. Test lineage remains independently required by binding.',
 'IS-05.evidence':'Inspected RULE-03/04/05/06 and S-15/S-47. Invocation/input/config/adapter/target/lineage compare separately; FIXTURE establishes interface compatibility only. Actual run gates remain unresolved.',
 'IS-06.records':'Read ten installed record templates and schema definitions; full event post_state includes writer/config/spec/targets/counters/pending invocation/stop fields.',
 'IS-06.recovery':'Inspected RULE-10/11/12/14/15 and S-17/24/25/28/29/37/38. Reconciliation precedes new actions; stale versions refuse; exact replay adds nothing; rollback only still-owned bytes.',
 'IS-07.sequence':'Inspected exact 17-state default sequence, BUILD_FAILED/TEST_FAILED repair and HUMAN_REQUIRED edges. Both repair origins disabled with zero budgets.',
 'IS-07.applicability':'Inspected scoped synthetic definition and canonical selected profile. Source-only and docs use installed alternate edges with replacement evidence; product code invalidates docs exception. Both multi-target children are required.',
 'IS-08.inventory':'Compared exact file bytes with baseline inventory; only installation/installation-record.yaml has null self hash. Immutable progress snapshots and candidate/observed write receipts preserve installation and later attempt ownership.',
 'IS-08.assessment':'Joined each required catalogue ID once to permitted method, reviewer, exact evidence and prospective config. Integration compatibility is distinct from production outcome; provenance is deferred until activation reread; status is derived.',
 'IS-01.discovery':'Inspected actual source-snapshot.json content against source bytes and synthetic declared facts. No Git commit required. Test unknown in compiled example is a typed pending binding; no private facts inferred.',
 'IS-08.provenance':'Observed pointer activation and reread, preserved source/user files and immutable prior profile/ledger snapshots. Final staged candidate and dependency review identify prospective config; publication receipt confirms actual exact bytes.'}


def review(h,profile,phase,prior=None,provenance=False,staged_root=None):
    """Record actual scoped review of named installed inputs, not expected-output PASS."""
    catalogue=read(h/'shared/verification-criteria.yaml')
    def inspected_path(name):
        staged=staged_root/name if staged_root else None
        return staged if staged and staged.is_file() else h/name
    checked={p:digest(inspected_path(p)) for p in catalogue['extensions']['required_runtime_files'] if p!='installation/installation-record.yaml'}
    for filename, schema, definition in [('development/workflow.yaml','workflow.schema.json',None),
        ('maintenance/maintenance-workflow.yaml','workflow.schema.json',None),
        ('shared/verification-criteria.yaml','criteria.schema.json','Catalogue')]:
        validate(h,read(h/filename),schema,definition)
    validate(h,profile,'profile.schema.json')
    req=read(h.parents[0]/'fixture-request.json') if (h.parent/'fixture-request.json').exists() else None
    # Alternate-root request location is supplied by the installed source definition.
    repo=h
    root_parts=Path(profile['repository']['harness_root']).parts
    for _ in root_parts:repo=repo.parent
    req=read(repo/'fixture-request.json')
    outcomes=[];sources={}
    for cap,b in profile['capabilities'].items():
        if b['configuration_status']!='CONFIGURED':continue
        procedure=inspected_path(b['invocation']['procedure']['path'])
        module_names=set(re.findall(r'synthetic_adapter(?:_B)?\.py',procedure.read_text(encoding='utf-8')))
        assert len(module_names)==1,module_names
        module_path=inspected_path('shared/adapters/'+next(iter(module_names)))
        module_identity=digest(module_path)
        assert module_identity==b['adapter']['content_identity'],(cap,module_path)
        sources[cap]={'module':{'path':module_path.relative_to(h).as_posix(),'identity':module_identity},
            'procedure':{'path':procedure.relative_to(h).as_posix(),'identity':digest(procedure)},
            'source_identity':req['revision'],'inspected_at':stamp(),
            'execution':'Actual import of this exact module and emit calls below; output remains FIXTURE.'}
        module_spec=importlib.util.spec_from_file_location('installed_fixture_'+cap+'_'+phase,module_path)
        module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
        for outcome in ['PASS','FAIL','BLOCKED','UNKNOWN']:
            r=deepcopy(req);r.update(capability=cap,adapter=b['adapter'],adapter_definition_id=module_identity,configuration_id=profile['configuration_id'])
            r['requirements']={k:b['normalization'][k] for k in ['artifact_consumed_downstream','test_source_required','artifact_lineage_required']}
            if cap=='test':
                r['test_source']={'identity':profile['repository']['identity'],'reference':ref('installation/evidence/source-snapshot.json')}
                if b['normalization']['artifact_lineage_required']:
                    r['test_source']=read(repo/'fixture-test-request.json')['test_source']
            emitted=module.emit(r,outcome);validate(h,emitted,'result.schema.json')
            assert digest(module_path)==module_identity
            outcomes.append(emitted)
        b['compatibility']='COMPATIBLE'
    notes={cid:note for cid,note in REVIEW_NOTES.items()}
    if not provenance:notes['IS-08.provenance']='PENDING: pointer activation/reread not performed; all other eligible structural checks are separately reviewed.'
    dependency_paths=[p for p in checked if p not in ('shared/repo-profile.yaml','shared/harness-status.md')]
    dossier={'actor':ACTOR,'method':'LLM_REVIEW','provenance':'REVIEW','configuration_id':profile['configuration_id'],
        'inspected_configuration_id':prior or 'cfg-1','observed_at':stamp(),'phase':phase,'input_identities':checked,
        'dependency_revalidation':{p:checked[p] for p in dependency_paths},
        'changed_fields':['configuration_id','configuration_revision','assessments','capabilities compatibility','workflow_profiles readiness'],
        'findings':notes,'compatibility_fixture_observations':outcomes,'inspected_adapter_sources':sources,
        'limitations':['Procedural inspection, no runtime enforcement or production execution.',
            'Publication requires the separately retained exact candidate-to-live receipt; this review never writes or approves production resources.']}
    path='installation/evidence/'+phase+'-review.json';write(h/path,dossier)
    e=evidence(h,path,profile['configuration_id']+' explicit dependency revalidation and scoped installed-definition review')
    claims=[]
    for definition in catalogue['criteria']:
        cid=definition['id'];pending=cid=='IS-08.provenance' and not provenance
        if definition['category']=='INTEGRATION':
            item=next(x for x in catalogue['extensions']['integration_instances'] if x['criterion_id']==cid)
            b=profile['capabilities'][item['capability_id']]
            pending=b['configuration_status']!='CONFIGURED'
            reason=('Missing synthetic test binding, invocation and actual discovery; no command guessed.' if pending else
                'Reviewed installed fixture adapter source, explicit stdout-only policy, declared target/environment, deadlines and reconciliation; four emitted outcomes validated. Compatible format/routing only, not tool execution.')
        else:reason=notes[cid]
        claims.append(record('CriterionAssessment',catalogue_version='1.0.0',criterion_id=cid,result='PENDING' if pending else 'PASS',
            method=None if pending else 'LLM_REVIEW',actor=None if pending else ACTOR,evidence_refs=[] if pending else [e],
            reason=reason,assessed_configuration_id=profile['configuration_id']))
    profile['assessments']=claims
    readiness='PARTIAL' if any(b['configuration_status']=='PENDING_DISCOVERY' for cap,b in profile['capabilities'].items() if cap in profile['workflow_profiles'][0]['required_capabilities']) else 'READY'
    profile['workflow_profiles'][0]['readiness']=readiness
    profile['workflow_profiles'][0]['evidence_refs']=[e]
    return e


def render(h,p):
    complete=all(a['result']=='PASS' for a in p['assessments'] if a['criterion_id'].startswith('IS-'))
    (h/'shared/harness-status.md').write_text('# Synthetic installation status\n\nConfiguration: '+p['configuration_id']+'; revision: '+str(p['configuration_revision'])+'.\nStructure '+('STRUCTURE_COMPLETE' if complete else 'INCOMPLETE')+'; integration '+p['workflow_profiles'][0]['readiness']+'.\nProcedural review only; no production execution or private pilot.\n',encoding='utf-8')


def install(repo,h):
    initial=read(h/'shared/repo-profile.yaml');ledger=read(h/'installation/installation-record.yaml')
    before=filemap(repo)
    for phase,rev in [('eligible',2),('final',3)]:
        prior=read(h/'shared/repo-profile.yaml');profile=deepcopy(prior)
        write(h/f'installation/evidence/profile-cfg-{rev-1}.json',prior)
        write(h/f'installation/evidence/ledger-cfg-{rev-1}.json',ledger)
        profile.update(configuration_id=f'cfg-{rev}',configuration_revision=rev)
        if phase=='final':
            assert (repo/'AGENTS.md').read_bytes()==(repo/'ENTRYPOINT.candidate.md').read_bytes()
            assert digest(repo/'USER-NOTES.txt')==before['USER-NOTES.txt']
        e=review(h,profile,phase,prior['configuration_id'],phase=='final')
        candidate=h/f'installation/evidence/candidate-cfg-{rev}.json';write(candidate,profile)
        assert read(h/'shared/repo-profile.yaml')['configuration_id']==prior['configuration_id']
        old=digest(h/'shared/repo-profile.yaml');shutil.copyfile(candidate,h/'shared/repo-profile.yaml')
        assert digest(candidate)==digest(h/'shared/repo-profile.yaml')
        write(h/f'installation/evidence/publication-cfg-{rev}.json',{'actor':ACTOR,'attempt':'installation-'+phase,
            'inspected_configuration_id':prior['configuration_id'],'prospective_configuration_id':profile['configuration_id'],
            'before_identity':old,'after_identity':digest(h/'shared/repo-profile.yaml'),'candidate_identity':digest(candidate),
            'observed_at':stamp(),'reread_matches':True,'review':e})
        render(h,profile)
        ledger['criterion_assessments']=deepcopy(profile['assessments'])
        if phase=='eligible':
            assert next(a for a in profile['assessments'] if a['criterion_id']=='IS-08.provenance')['result']=='PENDING'
            assert all(a['result']=='PASS' for a in profile['assessments'] if a['criterion_id'].startswith('IS-') and a['criterion_id']!='IS-08.provenance')
            assert not (repo/'AGENTS.md').exists()
            shutil.copyfile(repo/'ENTRYPOINT.candidate.md',repo/'AGENTS.md')
            activation={'actor':ACTOR,'decision':'ACTIVATION_ELIGIBLE','configuration_id':'cfg-2','candidate_identity':digest(repo/'ENTRYPOINT.candidate.md'),
                'before_identity':None,'after_identity':digest(repo/'AGENTS.md'),'reread_matches':(repo/'AGENTS.md').read_bytes()==(repo/'ENTRYPOINT.candidate.md').read_bytes(),
                'provenance_criterion':'PENDING until final publication','review':e,'observed_at':stamp()}
            write(h/'installation/evidence/activation.json',activation)
            ledger['entry_point'].update(activation_state='ACTIVE',evidence_refs=[evidence(h,'installation/evidence/activation.json','Observed actual pointer write and reread')])
    ledger['updated_at']=stamp();ledger['completed_at']=stamp()
    ledger['generated_paths']=[]
    for path in sorted(h.rglob('*')):
        if not path.is_file() or path.is_relative_to(h/'installation/evidence'):continue
        relative=path.relative_to(h).as_posix()
        ledger['generated_paths'].append(dict(scope='HARNESS',path=relative,ownership='GENERATED',before_identity=None,
            after_identity=None if relative=='installation/installation-record.yaml' else digest(path)))
    ledger['generated_paths'].append(dict(scope='REPOSITORY',path='AGENTS.md',ownership='GENERATED',before_identity=None,after_identity=digest(repo/'AGENTS.md')))
    ledger['owned_paths']=deepcopy(ledger['generated_paths']);write(h/'installation/installation-record.yaml',ledger)
    validate(h,ledger,'records.schema.json','InstallationRecord')
    write(h/'installation/evidence/completed-baseline.json',ledger)
    return profile


def capture(h,run,p,name):
    manifest=[]
    paths=[('PROFILE','shared/repo-profile.yaml'),('WORKFLOW','development/workflow.yaml'),('WORKFLOW','maintenance/maintenance-workflow.yaml'),
        ('RULES','shared/verification-rules.md'),('CRITERIA','shared/verification-criteria.yaml'),('CONFORMANCE','shared/conformance-cases.yaml')]
    paths += [('SCHEMA',p.relative_to(h).as_posix()) for p in (h/'shared/schemas').glob('*.json')]
    paths += [('ADAPTER',p.relative_to(h).as_posix()) for p in (h/'shared/adapters').iterdir() if p.is_file()]
    for kind,path in paths:
        copied='configuration/'+name+'/'+path;target=run/copied;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(h/path,target)
        manifest.append(dict(kind=kind,reference=ref(path),identity=digest(target),captured_path=copied))
    snap=record('ConfigSnapshot',configuration_id=p['configuration_id'],configuration_revision=p['configuration_revision'],captured_definitions=manifest,external_services=[],limitations=['Synthetic installed definitions; no external services or production tools.'])
    # Loop variables above intentionally do not replace the profile parameter.
    write(run/('config-snapshot.yaml' if name=='initial' else name+'-config-snapshot.yaml'),snap)
    return snap


def task_start(repo,h,p):
    run=h/'development/runs/SYNTHETIC-task';run.mkdir(parents=True)
    snapshot=capture(h,run,p,'initial')
    state=read(h/'development/templates/task-state.yaml')
    state.update(task_id='SYNTHETIC-task',writer={'mode':'LLM_PROTOCOL','identity':ACTOR,'binding':None,'enforcement_evidence_refs':[]},
        configuration_id=p['configuration_id'],input_snapshot=p['repository']['identity'],selected_targets=p['workflow_profiles'][0]['required_targets'])
    state['accepted_identities']['request']=identity('Inspect disposable synthetic fixture provenance')
    events=[]
    notes={'actor':ACTOR,'rules':['RULE-01','RULE-03','RULE-05','RULE-06','RULE-11'],
        'request':'Inspect source and attempt synthetic preflight; no production task success requested.',
        'source_identity':state['input_snapshot'],'observations':['Source bytes match installation snapshot; no Git commit required.',
          'Research uses installed synthetic procedure; no reusable external pattern or production tool inferred.',
          'Fixture compatibility report cannot satisfy required preflight EXECUTION; BLOCKED stop preserves all work.'],
        'due_criteria':'Early request/planning reviews may use REVIEW; execution remains required at preflight.'}
    write(run/'evidence/initial-review.json',notes);e=evidence(h,'development/runs/SYNTHETIC-task/evidence/initial-review.json','Observed initial scoped work and fixture execution refusal')
    flow=read(h/'development/workflow.yaml');sequence=flow['extensions']['default_sequence'][:9]
    stage_ids={'NEW':'D-BASELINE','BASELINED':'D-BASELINE','RESEARCHED':'D-RESEARCH','PATTERN_VERIFIED':'D-PATTERN','SPEC_READY':'D-SPEC','TEST_READY':'D-VERIFY-PLAN','PLAN_READY':'D-IMPLEMENT-PLAN','IMPLEMENTED':'D-IMPLEMENT','PREFLIGHT':'D-PREFLIGHT-INTENT'}
    write(run/'evidence/plan.json',{'actor':ACTOR,'criterion_plan':{'AC-FIXTURE-REFUSAL':{'method':'LLM_REVIEW','inputs':['installed RULE-05','preserved fixture envelope','denied success decision'],'targets':state['selected_targets']}},'implementation_tasks':[{'criterion_id':'AC-FIXTURE-REFUSAL','action':'Inspect source and record fixture refusal without production code edit','changed_paths':[]}],'actual_diff':[],'source_identity':state['input_snapshot'],'missing_execution':'Synthetic fixture emitter supplies no production execution; stop at preflight success gate.'})
    for index,destination in enumerate(sequence):
        prior=deepcopy(state)
        state['state']=destination
        request=None
        if destination=='PREFLIGHT':
            invocation=read(h/'development/templates/invocation.yaml')
            invocation.update(intent_id='SYNTHETIC-preflight-intent',request_id='task-stage-8',run_id='SYNTHETIC-run-1',task_id=state['task_id'],capability='preflight',
                expected_identities={'configuration_id':p['configuration_id'],'adapter_definition_id':p['capabilities']['preflight']['adapter']['content_identity'],'adapter':p['capabilities']['preflight']['adapter'],'revision':state['input_snapshot']},
                inputs={'source':state['input_snapshot'],'targets':state['selected_targets'],'environment':'fixture-local','artifact':None,'test_source':None},
                dispatch_status='INTENT_RECORDED',external_handle=None,deadline=(datetime.now(timezone.utc)+timedelta(seconds=60)).isoformat().replace('+00:00','Z'),
                counters={'calls':0,'elapsed_seconds':0,'call_budget':1,'time_budget_seconds':60},reconciliation_evidence_refs=[],cancellation_evidence_refs=[])
            write(run/'invocations/preflight-intent.yaml',invocation)
            state['pending_invocation_refs']=[evidence(h,'development/runs/SYNTHETIC-task/invocations/preflight-intent.yaml','Persisted fixture-only intent; no production dispatch')]
            state['invocation_counters']['preflight']=1
        if destination=='SPEC_READY':
            spec=read(h/'development/templates/task-spec.yaml');spec.update(task_id=state['task_id'],request_identity=state['accepted_identities']['request'],
                specification_identity=identity('Synthetic specification v1'),design_identity=identity('Synthetic design v1'),
                acceptance_authority={'actor':'SYNTHETIC example requestor','evidence_refs':[e]},scope=['Inspect synthetic source and fixture refusal'],non_goals=['Production build/test success'],
                criteria=[{'id':'AC-FIXTURE-REFUSAL','due_state':'SPEC_VERIFIED','allowed_methods':['LLM_REVIEW'],'required':True}],targets=state['selected_targets'],profile_id='default')
            write(run/'task-spec.yaml',spec);state['accepted_identities'].update(specification=spec['specification_identity'],design=spec['design_identity'])
        review_record=record('CriterionReview',task_id=state['task_id'],revision=state['input_snapshot'],due_state=destination,method='LLM_REVIEW',actor=ACTOR,provenance='REVIEW',
            criteria=[{'criterion_id':stage_ids[destination],'result':'PASS','reason':'Observed scoped request/planning inputs in initial-review; no execution criterion asserted.','evidence_refs':[e],'unresolved_findings':[]}])
        write(run/f'evidence/stage-{index}-review.yaml',review_record)
        er=evidence(h,f'development/runs/SYNTHETIC-task/evidence/stage-{index}-review.yaml','Due-stage procedural review')
        state['criterion_verdict_refs'].append(er)
        if index:
            edge=next(x for x in flow['transitions'] if x['from']==prior['state'] and x['to']==destination and ('profiles' not in x or 'default' in x['profiles']))
            request=record('TransitionRequest',subject_id=state['task_id'],subject_kind='TASK',request_id=f'task-stage-{index}',expected_state=prior['state'],expected_version=len(events),transition_id=edge['id'],configuration_id=state['configuration_id'],accepted_identities=state['accepted_identities'],evidence_refs=[e],review_refs=[er],request_content_identity=identity({'stage':index,'input':state['input_snapshot']}))
            request['request_content_identity']=identity({k:v for k,v in request.items() if k!='request_content_identity'})
            write(run/f'evidence/stage-{index}-request.yaml',request)
        decision=record('GateDecision',request_id=f'task-stage-{index}',decision='ALLOW',rule_findings=[{'rule_id':rule,'result':'PASS','reason':'Scoped preparatory review and concrete plan/identity/intent; no production result claimed.','evidence_refs':[er]} for rule in (edge['rule_ids'] if index else ['RULE-01','RULE-02','RULE-11'])],proposed_destination=destination,resolution_route=None)
        write(run/f'evidence/stage-{index}-decision.yaml',decision)
        de=evidence(h,f'development/runs/SYNTHETIC-task/evidence/stage-{index}-decision.yaml','Inspected gate decision; procedural commit follows separately')
        ev_record(h,state['task_id'],'TASK',events,state,de,f'task-stage-{index}',request)
    request=read(repo/'fixture-request.json');request.update(capability='preflight',adapter=p['capabilities']['preflight']['adapter'],configuration_id=p['configuration_id'],task_id=state['task_id'])
    request['requirements']['artifact_consumed_downstream']=False
    module_spec=importlib.util.spec_from_file_location('installed_adapter',h/'shared/adapters/synthetic_adapter.py');module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
    result=module.emit(request,'PASS');write(run/'evidence/preflight-fixture.json',result)
    refusal=record('GateDecision',request_id='fixture-success-refused',decision='DENY',rule_findings=[{'rule_id':'RULE-05','result':'FAIL','reason':'FIXTURE cannot satisfy preflight execution obligation; preserved valid PASS fixture is only compatibility evidence.','evidence_refs':[e]}],proposed_destination=None,resolution_route='BLOCKED')
    write(run/'evidence/refusal.yaml',refusal)
    stopped=deepcopy(state);stopped.update(state='BLOCKED',stopped_from_state='PREFLIGHT',stop_reason='Required actual preflight execution missing; fixture provenance refused.')
    de=evidence(h,'development/runs/SYNTHETIC-task/evidence/refusal.yaml','RULE-05 refusal preserves state before separate stop')
    edge=next(x for x in flow['transitions'] if x['from']=='PREFLIGHT' and x['to']=='BLOCKED' and x['trigger']=='BLOCKED')
    stop_request=record('TransitionRequest',subject_id=state['task_id'],subject_kind='TASK',request_id='fixture-stop',expected_state=state['state'],expected_version=len(events),transition_id=edge['id'],configuration_id=state['configuration_id'],accepted_identities=state['accepted_identities'],evidence_refs=[de],review_refs=[e])
    stop_request['request_content_identity']=identity(stop_request);write(run/'evidence/stop-request.yaml',stop_request)
    stop_decision=record('GateDecision',request_id='fixture-stop',decision='ALLOW',rule_findings=[{'rule_id':rule,'result':'FAIL' if rule=='RULE-05' else 'PASS','reason':'Retain RULE-05 FIXTURE refusal; safe-stop admission checks current request, shape and writer and does not dispatch or earn success.','evidence_refs':[de]} for rule in edge['rule_ids']],proposed_destination='BLOCKED',resolution_route=None)
    write(run/'evidence/stop-decision.yaml',stop_decision)
    stop_e=evidence(h,'development/runs/SYNTHETIC-task/evidence/stop-decision.yaml','Separate safe-stop decision retaining fixture refusal')
    ev_record(h,state['task_id'],'TASK',events,stopped,stop_e,'fixture-stop',stop_request)
    write(run/'state.yaml',stopped);write(run/'events.yaml',record('EventLog',subject_id=state['task_id'],subject_kind='TASK',events=events))
    return run


def maintenance(repo,h,kind,update_id,migrate=False):
    base=read(h/'shared/repo-profile.yaml');rev=base['configuration_revision']+1;p=deepcopy(base);p.update(configuration_id=f'cfg-{rev}',configuration_revision=rev)
    path=h/'maintenance/updates'/update_id;path.mkdir(parents=True)
    old_values={'capabilities/build':deepcopy(base['capabilities']['build'])}
    changed={}
    if not migrate:
        adapter_path='shared/adapters/synthetic_adapter_B.py'
        changed[adapter_path]=(h/'shared/adapters/synthetic_adapter.py').read_bytes()+b'\n# SYNTHETIC replacement B: same fixture-only contract.\n'
        p['capabilities']['build']['adapter']={'identity':'SYNTHETIC-build-B','version':'1.0.0','content_identity':'sha256:'+hashlib.sha256(changed[adapter_path]).hexdigest()}
        changed['shared/adapters/procedure-B.md']=(h/'shared/adapters/procedure.md').read_bytes().replace(b'synthetic_adapter.py',b'synthetic_adapter_B.py')
        for key in ['procedure','reconciliation']:p['capabilities']['build']['invocation'][key]=ref('shared/adapters/procedure-B.md')
        p['capabilities']['build']['normalization']['procedure']=ref('shared/adapters/procedure-B.md')
    else:
        rule='shared/verification-rules.md';changed[rule]=(h/rule).read_bytes()+b'\nSynthetic local migration clarification: FIXTURE remains compatibility evidence only under RULE-05.\n'
        schema='shared/schemas/result.schema.json';d=read(h/schema);d['$comment']+=' Synthetic installed migration: no fixture upgrades to execution.'
        changed[schema]=(json.dumps(d,indent=2,ensure_ascii=False)+'\n').encode()
    staged_root=path/'evidence/candidate'
    for name,data in changed.items():
        staged=staged_root/name;staged.parent.mkdir(parents=True,exist_ok=True);staged.write_bytes(data)
    e=review(h,p,update_id,base['configuration_id'],True,staged_root)
    # Review the whole candidate inventory, then require immutable actual per-file receipts below.
    for a in p['assessments']:
        if a['criterion_id']=='IS-08.inventory':
            a['reason']='Prospective whole-obligation review of baseline ownership, prior accepted receipts, writer/attempt, candidate and before-values; acceptance is conditional on the separately retained actual publication receipt and post-publication whole-inventory review. No automated partial PASS.'
    changed['shared/repo-profile.yaml']=(json.dumps(p,indent=2,ensure_ascii=False)+'\n').encode()
    manifest=[]
    for name,data in changed.items():
        staged=path/'evidence/candidate'/name;staged.parent.mkdir(parents=True,exist_ok=True);staged.write_bytes(data)
        manifest.append(dict(scope='HARNESS',path=name,ownership='GENERATED',before_identity=digest(h/name) if (h/name).exists() else None,after_identity=digest(staged)))
    write(path/'evidence/manifest.json',manifest)
    if migrate:
        staged_schema=read(path/'evidence/candidate/shared/schemas/result.schema.json')
        Draft202012Validator.check_schema(staged_schema)
        schema_root=h/'shared/schemas'
        registry=Registry().with_resources((x.as_uri(),Resource.from_contents(staged_schema if x.name=='result.schema.json' else read(x))) for x in schema_root.glob('*.json'))
        verifier=Draft202012Validator({'$ref':(schema_root/'result.schema.json').as_uri()},registry=registry)
        checks=[]
        for outcome in ['PASS','FAIL','BLOCKED','UNKNOWN']:
            envelope=read(h/f'installation/evidence/fixture-{outcome}.json');errors=list(verifier.iter_errors(envelope));assert not errors,errors
            checks.append({'outcome':outcome,'schema_valid':True,'input_identity':digest(h/f'installation/evidence/fixture-{outcome}.json')})
        bad=deepcopy(envelope);bad['status']='UNSUPPORTED';assert list(verifier.iter_errors(bad))
        write(path/'evidence/migration-checks.json',{'actor':ACTOR,'staged_schema_identity':digest(path/'evidence/candidate/shared/schemas/result.schema.json'),'fixture_checks':checks,'unsupported_status_rejected':True,'rule_diff':'Appended clarification only; existing RULE-01 through RULE-17 and their gates unchanged.','scenario_reviews':['S-47 preserves FIXTURE refusal under RULE-05','S-14 unsupported status rejected; raw observation required','S-08 all definitions available locally'],'readiness':'Required compiled test binding remains pending; replacement adds no permission, target or tool capability.','authority':'Exact synthetic approval premise checked against candidate/base/scope; cannot waive unsupported format.'})
    candidate_identity=identity(manifest)
    review_data={'actor':ACTOR,'mode':'WALKTHROUGH','rules':['RULE-08','RULE-13','RULE-14','RULE-15'],
        'base_configuration_id':base['configuration_id'],'prospective_configuration_id':p['configuration_id'],
        'candidate_identity':candidate_identity,'manifest':manifest,'policy':'Disposable fixture-only records; no external action or permission expansion.',
        'findings':['Actual unchanged base and path before-identities compared immediately before write.',
            'Four synthetic outcomes are compatible; no production success required.',
            'Rules/schema migration is non-semantic comment clarification, installed versions remain 1.0.0; graph/outcome obligations unchanged.',
            'Whole current inventory acceptance requires post-publication receipt inspection below; no partial automation PASS.'],
        'scoped_approval_premise':'SYNTHETIC fixture approver approves exact candidate/base/scope; this is an inspected scenario premise, not a real human approval record.' if migrate else None}
    write(path/'evidence/review.json',review_data);re=evidence(h,f'maintenance/updates/{update_id}/evidence/review.json','Actual candidate/base inspection; synthetic approval premise if migration')
    update=read(h/'maintenance/templates/harness-update-record.yaml');current=deepcopy(update['current']);events=[]
    current.update(update_id=update_id,writer={'mode':'LLM_PROTOCOL','identity':ACTOR,'binding':None,'enforcement_evidence_refs':[]},
        inspected_configuration_id=base['configuration_id'],prospective_configuration_id=p['configuration_id'],permissions=p['permissions'],evidence_refs=[re],
        before_values=[{'path':name,'value':value,'identity':identity(value)} for name,value in old_values.items()],
        candidate={'source':ref(f'maintenance/updates/{update_id}/evidence/manifest.json'),'version':'1.0.0','content_identity':candidate_identity},publication_manifest=manifest,
        checks=deepcopy(p['assessments']),promotion={'intent':None,'result':'PENDING','before_configuration_id':base['configuration_id'],'after_configuration_id':None,'evidence_refs':[]})
    if migrate:current['scoped_approval']={'actor':'SYNTHETIC fixture approver (scenario premise)','candidate_identity':candidate_identity,'base_configuration_id':base['configuration_id'],'scope':list(changed),'evidence_refs':[re]}
    current['changed_values']=[{'path':'capabilities/build','before':base['capabilities']['build'],'after':p['capabilities']['build']}] if not migrate else []
    update.update(update_id=update_id,request_type=kind,scope=list(changed),request_identity=identity(review_data),events=events,current=current)
    flow=read(h/'maintenance/maintenance-workflow.yaml');selector=flow['extensions']['request_type_profiles'][kind]
    def commit(destination,trigger=None):
        old=events[-1]['next_state'] if events else None
        if old:
            edge=next(x for x in flow['transitions']+flow['resolution_routes'] if x['from']==old and x['to']==destination and selector in x['profiles'] and (trigger is None or x['trigger']==trigger))
            current.setdefault('extensions',{})['accepted_transition_id']=edge['id'];current['extensions']['accepted_trigger']=edge['trigger']
        current['state']=destination
        request_id=update_id+'-'+str(len(events)+1)
        request=None
        if old:
            request=record('TransitionRequest',subject_id=update_id,subject_kind='UPDATE',request_id=request_id,
                expected_state=old,expected_version=len(events),transition_id=edge['id'],configuration_id=base['configuration_id'],
                accepted_identities={'request':update['request_identity'],'specification':None,'design':None},evidence_refs=[re],review_refs=[re])
            request['request_content_identity']=identity(request)
            write(path/f'evidence/request-{len(events)+1}.yaml',request)
        decision=record('GateDecision',request_id=request_id,decision='ALLOW',rule_findings=[
            {'rule_id':rule,'result':'PASS','reason':'Reviewed exact candidate/base, declared route and complete single-writer snapshot; no execution claim. See review and receipt observations.','evidence_refs':[re]}
            for rule in (edge['rule_ids'] if old else ['RULE-01','RULE-02','RULE-11'])],proposed_destination=destination,resolution_route=None)
        write(path/f'evidence/decision-{len(events)+1}.yaml',decision)
        decision_e=evidence(h,f'maintenance/updates/{update_id}/evidence/decision-{len(events)+1}.yaml','Attributable decision for exact declared transition')
        ev_record(h,update_id,'UPDATE',events,current,decision_e,request_id,request)
        update['current']=deepcopy(current);write(h/f'maintenance/updates/{update_id}.yaml',update)
    for s in ['REQUESTED','INSPECTED','PLANNED','STAGED']:commit(s)
    current['promotion']['intent']={'request_id':update_id+'-publication','candidate_identity':candidate_identity,'base_configuration_id':base['configuration_id'],'prospective_configuration_id':p['configuration_id'],'manifest_identity':digest(path/'evidence/manifest.json')}
    write(path/'evidence/intent.json',current['promotion']['intent'])
    commit('MIGRATION_CHECKED' if migrate else 'ADAPTER_COMPATIBLE')
    assert read(h/'shared/repo-profile.yaml')['configuration_id']==base['configuration_id']
    for item in manifest:
        dest=h/item['path'];actual=digest(dest) if dest.exists() else None
        assert actual==item['before_identity'],item
    writes=[]
    for item in manifest:
        dest=h/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path/'evidence/candidate'/item['path'],dest)
        assert digest(dest)==item['after_identity']
        writes.append({'attempt':update_id,'writer':ACTOR,'phase':'OBSERVED_WRITTEN','observed_at':stamp(),**item})
    receipt={'attempt':update_id,'writer':ACTOR,'base_configuration_id':base['configuration_id'],'prospective_configuration_id':p['configuration_id'],'candidate_identity':candidate_identity,
        'manifest_identity':digest(path/'evidence/manifest.json'),'manifest':manifest,'writes':writes,'all_candidate_bytes_match':True}
    write(path/'evidence/receipt.json',receipt);receipt_e=evidence(h,f'maintenance/updates/{update_id}/evidence/receipt.json','Observed actual per-file publication and exact candidate reread')
    current['evidence_refs'].append(receipt_e);current['promotion'].update(result='PROMOTED',after_configuration_id=p['configuration_id'],evidence_refs=[receipt_e])
    commit('PROMOTED')
    whole_review={'actor':ACTOR,'method':'LLM_REVIEW','criterion_id':'IS-08.inventory','assessed_configuration_id':p['configuration_id'],'result':'PASS','baseline_identity':digest(h/'installation/evidence/completed-baseline.json'),'accepted_publication_receipt':receipt_e,'observed_path_endpoints':{x['path']:digest(h/x['path']) for x in manifest},'findings':['Actual attempt/writer matches committed intent and manifest; every before-value matched prior accepted configuration.','Each exact written byte identity matches reviewed candidate. Generated ownership authorizes only listed paths; user/history files were preserved.','The immutable baseline and prior accepted update receipts form one revision chain. Recovery restores already accepted stage and is not a second publication.','Only the exact installation ledger has null hash; derived status is separately regenerated. All other definition endpoint hashes remain required.'],'limitations':['This whole-obligation review is semantic and procedural, not checker enforcement.']}
    write(path/'evidence/whole-inventory-review.json',whole_review)
    if not migrate:
        # Exercise accepted publication recovery without a second write/revision.
        saved=filemap(h/'shared');current.update(stop_reason='Derived status refresh interrupted after accepted publication',stopped_from_state='PROMOTED')
        commit('PENDING');current['resolution_refs']=[receipt_e];commit('INSPECTED')
        assert filemap(h/'shared')==saved
        current.update(stop_reason=None,stopped_from_state=None);commit('PROMOTED','RECONCILED')
    render(h,p);commit('STATUS_UPDATED');commit('COMPLETE')
    validate(h,update,'records.schema.json','UpdateRecord')
    return p


def adopt(h,run,p):
    state=read(run/'state.yaml');log=read(run/'events.yaml');events=log['events'];before=deepcopy(state)
    capture(h,run,p,'adopted')
    review={'actor':ACTOR,'rules':['RULE-03','RULE-08','RULE-11','RULE-12'],'before_configuration_id':state['configuration_id'],'adopted_configuration_id':p['configuration_id'],
        'impact':'Build adapter A to B; invalidate execution-dependent evidence. Research/spec/targets remain unchanged; no production results existed.',
        'observed_invocations':'Preflight intent was recorded, but production dispatch never occurred: only separate compatibility emit() ran. Retain old intent and explicit no-dispatch reconciliation; it cannot authorize future dispatch after adoption.',
        'preserved_fields':{k:before[k] for k in ['accepted_identities','selected_targets','repair_counters','invocation_counters','pending_invocation_refs']},
        'decision':'Explicit ADOPTED to RESUME_REVIEW, then declared IMPLEMENTED target; no success-state jump.'}
    write(run/'evidence/adoption-review.json',review);e=evidence(h,'development/runs/SYNTHETIC-task/evidence/adoption-review.json','Explicit configuration adoption and dependency re-evaluation')
    flow=read(h/'development/workflow.yaml')
    for destination,trigger in [('RESUME_REVIEW','ADOPTED'),('IMPLEMENTED',None)]:
        edge=next(x for x in flow['transitions']+flow['resolution_routes'] if x['from']==state['state'] and x['to']==destination and ('profiles' not in x or 'default' in x['profiles']) and (trigger is None or x['trigger']==trigger))
        request=record('TransitionRequest',subject_id=state['task_id'],subject_kind='TASK',request_id='adoption-'+destination,expected_state=state['state'],expected_version=len(events),transition_id=edge['id'],configuration_id=state['configuration_id'],accepted_identities=state['accepted_identities'],evidence_refs=[e],review_refs=[e])
        request['request_content_identity']=identity(request);write(run/('evidence/adoption-'+destination+'-request.yaml'),request)
        state.update(state=destination,configuration_id=p['configuration_id'],resolution_refs=[e])
        if destination=='IMPLEMENTED':state.update(stop_reason=None,stopped_from_state=None)
        decision=record('GateDecision',request_id=request['request_id'],decision='ALLOW',rule_findings=[{'rule_id':rule,'result':'PASS','reason':'Explicit adoption; compare captured definitions/current authority, preserve accepted work and counters, return only to earliest execution-affected IMPLEMENTED stage.','evidence_refs':[e]} for rule in edge['rule_ids']],proposed_destination=destination,resolution_route=None)
        write(run/('evidence/adoption-'+destination+'-decision.yaml'),decision)
        de=evidence(h,'development/runs/SYNTHETIC-task/evidence/adoption-'+destination+'-decision.yaml','Separate adoption and resume decisions')
        state.setdefault('extensions',{})['accepted_transition_id']=edge['id']
        ev_record(h,state['task_id'],'TASK',events,state,de,'adoption-'+destination,request)
    write(run/'events.yaml',log);write(run/'state.yaml',state)
    for k in review['preserved_fields']:assert state[k]==before[k]


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--examples',required=True,type=Path);parser.add_argument('--denied-builder',required=True,type=Path)
    parser.add_argument('--maintenance-only',action='store_true',help='Use restored cfg-3/BLOCKED disposable archive baseline, preserving original history')
    args=parser.parse_args();root=args.examples.resolve();denied=str(args.denied_builder.resolve());attempts=[]
    def audit(event,values):
        if event=='open' and isinstance(values[0],(str,bytes,os.PathLike)):
            path=os.path.abspath(os.fsdecode(values[0]))
            if path==denied or path.startswith(denied+os.sep):
                attempts.append(path);raise PermissionError('Builder unavailable to installed-only walkthrough')
    sys.addaudithook(audit)
    if not args.maintenance_only:
        for name,hroot in [('compiled','.harness'),('source-only','tools/harness café'),('docs','.harness'),('multi-target','.harness')]:
            repo=root/name;h=repo/hroot;install(repo,h)
    repo=root/'compiled';h=repo/'.harness';p=read(h/'shared/repo-profile.yaml')
    if args.maintenance_only:
        run=h/'development/runs/SYNTHETIC-task'
        assert p['configuration_id']=='cfg-3' and read(run/'state.yaml')['state']=='BLOCKED'
    else:run=task_start(repo,h,p)
    p=maintenance(repo,h,'ADAPTER_CHANGE','replace-build');adopt(h,run,p)
    maintenance(repo,h,'MIGRATION','rule-schema-migration',True)
    write(root/'installed-only-audit.json',{'actor':ACTOR,'builder_denied_root':denied,'denied_builder_read_attempts':attempts,
        'input_definitions':'Only installed runtime files, installed adapter and example source bytes','observed_at':stamp(),
        'limitations':['Authoring recorder, not runtime enforcement. Synthetic human approval is an explicit fixture premise.','Current inventory satisfaction uses attributable prospective review plus separately retained actual whole-inventory acceptance; checker cannot certify arbitrary receipt semantics.']})
    print(json.dumps({'result':'completed disposable publication and procedural adoption','builder_reads':len(attempts),'final_configuration':'cfg-5'}))


if __name__=='__main__':main()
