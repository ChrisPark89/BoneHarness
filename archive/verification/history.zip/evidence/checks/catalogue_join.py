"""Explicit evidence index: no inferred runtime verdict from catalogue expectations."""
import json

# Catalogue variant -> already inspected concrete procedural evaluation.
WALKTHROUGHS={
'S-01.pending-test':'T6-pending-test-complete-structure',
'S-02.undefined-endpoint':'T6-undefined-graph-activation',
'S-03.checker-skipped':'T6-checker-skipped-permitted-reviews',
'S-06.user-edited-resume':'T6-interruption-edited-generated-file',
'S-07.live-harness':'T6-live-and-scoped-conflict','S-07.instruction-conflict':'T6-live-and-scoped-conflict',
'S-08.development':'T6-installed-only-full-publication','S-08.adapter-replacement':'T6-actual-byte-replacement','S-08.approved-migration':'T6-actual-rule-schema-publication',
'S-10.default-sequence':'S10-default-sequence',
'S-11.missing-criterion':'S11-pending','S-11.unmet-criterion':'S11-fail',
'S-12.tool-fail-review-pass':'S12-tool-fail-llm-pass','S-13.no-native-validation':'S13-optional-native-absent',
'S-14.missing-field':'S14-missing-field','S-14.unsupported-status':'S14-unsupported-status','S-14.absent-result':'S14-absent-result',
'S-15.wrong-run':'S15-run','S-15.wrong-target':'S15-target','S-15.wrong-config':'S15-config','S-15.wrong-source':'S15-source-dirty','S-15.wrong-dirty-content':'S15-source-dirty','S-15.wrong-adapter':'S15-adapter-content','S-15.wrong-test-source':'S15-test-source-revision',
'S-16.unknown-rule':'S16-unknown-rule','S-16.unresolved-verifier':'S16-unresolved-verifier','S-16.ambiguous-route':'S16-ambiguous-edge',
'S-17.exact-replay-llm_protocol':'S17-exact-replay','S-17.altered-replay-llm_protocol':'S17-altered-replay','S-17.stale-version-llm_protocol':'S17-stale-version',
'S-18.early-planning-review':'S18-early-request-review','S-18.future-test-not-due':'S18-future-test-not-due',
'S-19.spec-change':'S19-accepted-spec-changed','S-19.research-invalidated':'T6-additional-research-invalidated',
'S-20.build-disabled':'S20-build_failed','S-20.test-disabled':'S20-test_failed',
'S-21.build-repair':'S21-new-evidence-with-budget','S-21.test-repair':'T6-additional-test-origin-repair',
'S-23.no-validity-rule':'S23-shortcut-unconfigured','S-23.proved-valid-artifact':'S23-shortcut-declared-valid',
'S-24.saved-handle':'S24-restart-running','S-25.dispatch-handle-crash':'S25-dispatch-before-handle-crash',
'S-26.expired-deadline':'S26-deadline-this-session','S-26.restart-expired':'S26-deadline-after-restart',
'S-27.stale-build-result':'S27-late-old-source-result','S-27.external-early-change':'S27-unexpected-early-change','S-27.expected-edit':'S27-expected-implementation-edit',
'S-28.stale-snapshot':'S28-committed-log-lost-snapshot','S-28.corrupt-event':'S28-corrupt-event','S-28.competing-writer':'S28-competing-writer','S-28.uncommitted-proposal':'S28-uncommitted-proposal',
'S-29.explicit-adoption':'S29-config-adoption',
'S-31.unsupported-status':'MNT-unsupported','S-31.missing-evidence':'MNT-missing-evidence','S-31.permission-expansion':'MNT-policy',
'S-32.exact-approved':'T6-actual-rule-schema-publication','S-32.changed-candidate':'MNT-changed-candidate','S-32.changed-base':'T6-additional-migration-changed-base','S-32.unsupported-interface':'MNT-unsupported-interface',
'S-33.sourced-fact':'MNT-fact','S-33.unsupported-guess':'MNT-fact-guess',
'S-34.unchanged':'MNT-drift-unchanged','S-34.changed':'MNT-drift-changed','S-34.missing':'MNT-drift-missing','S-34.inaccessible':'MNT-drift-inaccessible','S-34.stale-A-review-after-B':'MNT-drift-stale',
'S-35.linked-update':'MNT-drift-correction',
'S-36.old-task-A':'S36-existing-pinned','S-36.new-task-B':'S36-new-task','S-36.explicit-adoption':'T6-actual-pinned-adoption','S-36.permission-revoked':'S36-current-revoked',
'S-37.stale-base':'MNT-stale-base','S-38.owned-rollback':'MNT-partial-restored','S-38.newer-values':'MNT-partial-newer','S-39.stale-status':'T6-actual-pending-inspected-reconciled',
'S-40.source-only':'S40-source-only','S-41.docs-only':'S41-docs-only','S-41.product-code-found':'S41-product-change-found',
'S-43.wrong-test-revision':'S43-wrong-test-source','S-43.wrong-artifact':'S43-wrong-artifact','S-43.all-match':'S43-matching-lineage',
'S-47.fixture-at-execution-gate':'S47-fixture-at-execution-gate',
}
for origin in ['build','test']:
    for variant,source in [('exhausted','exhausted'),('no-new-evidence','no-progress'),('out-of-scope','out-of-scope')]:
        WALKTHROUGHS[f'S-22.{origin}-{variant}']=f'S22-{origin}_failed-{source}'
for outcome in ['PASS','FAIL','BLOCKED','UNKNOWN']:WALKTHROUGHS['S-30.'+outcome+'-fixture']='T6-actual-byte-replacement'
for variant in ['pass-missing','pass-fail','pass-blocked','fail-missing','fail-blocked','fail-blocked-unknown','fail-running']:
    WALKTHROUGHS['S-42.'+variant]='S42-'+variant
WALKTHROUGHS.update({'S-42.pass-pass':'S42-all-pass','S-42.targets-unknown':'S42-targets-pending'})


def join(records,kit,evidence,make,ev):
    catalogue=json.loads((kit/'templates/runtime/shared/conformance-cases.yaml').read_text())
    for name in ['research-invalidated','test-origin-repair','migration-changed-base']:
        review=json.loads((evidence/'checks/additional-procedural'/name/'review.json').read_text())
        records.append(make('T6-additional-'+name,review['case_id'].split('.')[0],'WALKTHROUGH',review['actual_result'],review['observations'],
            [ev('checks/additional-procedural/'+name+'/'+p,'Concrete synthetic input/attributed rule decision and linked proposal') for p in ['inputs.json','review.json']],review['limitations'],actor=review['actor']))
    # These are actual reviewer decisions on the concrete inputs used by the named tests,
    # not a conversion of a mechanical test's result into semantic enforcement.
    reviews={
      'S-04.assertion-only':('T6-mechanical-S-04','test_execution_obligation_cannot_use_fixture_or_review_assertion',
        'Inspected test_assessment.py concrete criterion with required_provenance EXECUTION and REVIEW claim. Criterion cannot be PASS under installed assessment-contract required_provenance; retain INCOMPLETE and request execution evidence.'),
      'S-09.ready-docs-pending-code':('T6-mechanical-S-09','test_integration_precedence_ready_partial_unassessed_blocked',
        'Concrete required default tuple is PASS; second supported profile has no claim. Aggregate PARTIAL while first profile remains READY. Profile names do not alter the installed readiness_contract; docs/code are the scenario labels for these same independent tuples.'),
      'S-09.blocked-plus-unassessed':('T6-mechanical-S-09','test_integration_precedence_ready_partial_unassessed_blocked',
        'Inspected BLOCKED tuple and required unassessed tuple: readiness_contract gives BLOCKED precedence over unassessed. This additionally reviews that specific combination; no tuple assertion is invented.'),
      'S-09.all-unassessed':('T6-mechanical-S-09','test_integration_precedence_ready_partial_unassessed_blocked',
        'Empty claims on supported required tuples imply NOT_ASSESSED under readiness_contract; zero current verdicts cannot imply READY.'),
      'S-09.optional-unused':('T6-mechanical-S-09','test_optional_unused_tuple_cannot_block_supported_profile',
        'Concrete supported profile required tuple PASS and optional unused capability BLOCKED. readiness_contract excludes unused tuple from supported profile obligations; supported profile remains READY.'),
      'S-46.missing-dependency':('T6-mechanical-S-46','test_dependency_absence_and_bad_invocation_json_exit_two',
        'Inspected actual -S missing-dependency exit2 report. Checker cannot claim validation; use permitted LLM_REVIEW for remaining criteria without inventing automated PASS, as actual installed-only activation demonstrates.'),
      'S-46.covered-pass-review-pending':('T6-mechanical-S-46','test_mixed_shape_pass_pending_review_remains_incomplete',
        'Inspected covered shape PASS plus missing required review: assessment_contract requires all applicable structural subcriteria, therefore INCOMPLETE. Covered successes cannot satisfy IS-03/IS-08 semantics.'),
    }
    for cid,(source,test,observation) in reviews.items():
        rid='T6-part-review-'+cid
        records.append(make(rid,cid.split('.')[0],'WALKTHROUGH','PASS',[observation,'Concrete input source: '+test],
            [ev('checks/scenario-mechanical-python314.txt','Actual named mechanical observations, not the reviewer decision','EXECUTION'),
             {'reference':{'kind':'LOCAL','scope':'REPOSITORY','path':'builder-kit/tests/test_assessment.py'},'identity':__import__('hashlib').sha256((kit/'tests/test_assessment.py').read_bytes()).hexdigest(),'summary':'Inspected concrete aggregation/provenance inputs','provenance':'REVIEW'}],
            ['This attributed rule inspection is procedural. No tool or host enforces this decision.']))
        records[-1]['evidence_refs'][-1]['identity']='sha256:'+records[-1]['evidence_refs'][-1]['identity']
        if cid.startswith('S-09.'):
            records[-1]['evidence_refs'].append(ev('checks/aggregation-cases.json','Exact named synthetic inputs and actual pure checker output','EXECUTION'))
            records[-1]['observations'].append('Inspected exact retained aggregation-cases.json inputs/output for '+cid+'; input bytes unchanged.')
        WALKTHROUGHS[cid]=rid
    # Named structural/routing tests are bounded automatic coverage, never gate truth.
    structural={
      'S-01.pending-test':'test_reviewed_installations_keep_readiness_and_coverage_separate',
      'S-03.checker-skipped':'test_reviewed_installations_keep_readiness_and_coverage_separate',
      'S-08.development':'test_retained_events_replay_and_match_explicit_requests',
      'S-08.adapter-replacement':'test_retained_walkthrough_publishes_real_bytes_and_preserves_pins',
      'S-08.approved-migration':'test_retained_walkthrough_publishes_real_bytes_and_preserves_pins',
      'S-10.default-sequence':'test_exact_default_sequence_and_schema / test_default_trace_reports_match_pinned_inputs',
      'S-14.missing-field':'test_concrete_walkthroughs_cover_task2_variants',
      'S-14.unsupported-status':'test_concrete_walkthroughs_cover_task2_variants',
      'S-14.absent-result':'test_concrete_walkthroughs_cover_task2_variants',
      'S-16.unresolved-verifier':'test_concrete_walkthroughs_cover_task2_variants',
      'S-35.linked-update':'test_drift_isolated_impact_conflict_and_linked_update',
      'S-41.product-code-found':'test_alternate_profiles_have_explicit_edges / test_concrete_walkthroughs_cover_task2_variants',
    }
    for cid in [c['case_id'] for c in catalogue['cases'] if c['scenario_id']=='S-34']:
        structural[cid]='test_drift_isolated_impact_conflict_and_linked_update'
    for cid,test in structural.items():
        records.append(make('T6-part-structure-'+cid,cid.split('.')[0],'AUTOMATED','PASS',
          ['Actual named schema/declared routing/relational test: '+test],
          [ev('checks/full-suite-python314.txt','Actual full suite before final ledger additions; named tests pass','EXECUTION')],
          ['Only declared records/routes and structural boundaries are checked. WALKTHROUGH separately supplies the concrete semantic decision; no runtime enforcement.'],actor='unittest under native Python 3.14'))
    lookup={r['case_id']:r for r in records};joins=[]
    for case in catalogue['cases']:
      cid=case['case_id'];sid=case['scenario_id']
      for part in case['coverage_parts']:
        mode=part['mode'];source=None;pending=None
        if mode=='WALKTHROUGH':
          source=WALKTHROUGHS.get(cid)
          if source and not source.startswith('T6-'):source='T6-index-'+('S-'+source[1:] if source.startswith('S') else source)
        else:
          if cid in structural:source='T6-part-structure-'+cid
          elif sid in ['S-02','S-04','S-05','S-09','S-16','S-45']:source='T6-mechanical-'+sid
          elif sid in ['S-40','S-41']:source='T6-example-'+sid
          elif cid in ['S-46.missing-dependency','S-46.covered-pass-review-pending']:source='T6-mechanical-S-46'
          elif cid.startswith('S-44.macos-'):
            ending=cid.split('-')[-1]
            selected=[r['case_id'] for r in records if r['case_id'].startswith('T6-native-') and r['mode']=='AUTOMATED' and r['actual_result']=='PASS' and '; '+ending+';' in r['observations'][0]]
            source=selected
        if '-tool' in cid:pending='Optional TOOL-mode gate enforcement is not configured or executed in these examples. LLM_PROTOCOL replay evidence cannot satisfy TOOL authority.'
        elif cid.startswith(('S-44.windows','S-44.linux')):pending='Native '+('Windows' if 'windows' in cid else 'Linux')+' '+cid.split('-')[-1]+' execution unavailable; reproduce both Python versions using native-platform-matrix.yaml commands.'
        elif cid=='S-46.missing-interpreter':pending='Both available local interpreters are installed. No absent-interpreter environment was observed; actual missing-dependency output does not prove this case. Required native reproduction: invoke the documented checker on a host without Python, record shell failure and separately review permitted manual assessment.'
        elif cid=='S-48.release-audit':pending='Task 7 assembled release documentation/inventory review is outstanding; private pilot and Windows/Linux release evidence also pending. Update this exact part only after its actual bounded review or execution.'
        if pending:source=None
        sources=source if isinstance(source,list) else ([source] if source else [])
        assert pending or sources,('Unmapped case part',part['id'])
        linked=[lookup[r] for r in sources]
        assert all(r['mode']==mode and r['actual_result']=='PASS' for r in linked),(cid,sources)
        rid='T6-catalogue-'+part['id']
        observations=[pending] if pending else ['Exact catalogue part '+part['id']+' joins named observations '+', '.join(sources)+'.']+[o for r in linked for o in r['observations']]
        limitations=['Verdict applies only to this named '+mode+' part; catalogue expected text is not execution or observed gate enforcement.']+[l for r in linked for l in r['limitations']]
        evidence_refs=[]
        if sid=='S-09':evidence_refs.append(ev('checks/aggregation-cases.json','Exact named aggregation inputs/output, preserved unchanged','EXECUTION'))
        for r in linked:
          for e in r['evidence_refs']:
            if e not in evidence_refs:evidence_refs.append(e)
        records.append(make(rid,sid,mode,'PENDING' if pending else 'PASS',observations,evidence_refs,limitations,
          actor='Codex Task 6 evidence join reviewer' if mode=='WALKTHROUGH' else 'Task 6 mechanical evidence index',
          catalogue_case_id=cid,coverage_part_ids=[part['id']],source_result_ids=sources))
        joins.append(dict(case_id=cid,part_id=part['id'],mode=mode,result_id=rid,actual_result=records[-1]['actual_result']))
    return joins
