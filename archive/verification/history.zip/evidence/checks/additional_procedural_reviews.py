"""Three explicitly inspected synthetic case inputs and typed event proposals.

This records the author's procedural decisions; it does not implement runtime gates
or commit any event to an installed task/update. Scenario policy overrides are inputs.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import yaml

ROOT=Path('/private/tmp/harness-builder-20261004-efv7l2ai/task6 fix1 final examples café')
OUT=Path(__file__).resolve().parent/'additional-procedural'
ACTOR='Codex Task 6 procedural reviewer'


def read(p):return yaml.safe_load(p.read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def identity(v):return 'sha256:'+hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def evidence(p):return {'reference':{'kind':'LOCAL','scope':'REPOSITORY','path':'builder-kit/evidence/checks/additional-procedural/'+p.parent.name+'/'+p.name},'identity':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest(),'provenance':'REVIEW','summary':'Actual reviewer-inspected concrete synthetic inputs; not production execution'}
def rec(kind,**v):return dict(schema_version='1.0.0',record_type=kind,**v)


def proposal(state,edge,e,request_id,changes=None,cause=None):
    kind='TASK' if state['record_type']=='TaskState' else 'UPDATE';subject=state.get('task_id',state.get('update_id'))
    request=rec('TransitionRequest',subject_id=subject,subject_kind=kind,request_id=request_id,expected_state=state['state'],expected_version=state['version'],
        transition_id=edge['id'],configuration_id=state.get('configuration_id',state.get('inspected_configuration_id')),
        accepted_identities=state.get('accepted_identities',{'request':identity(subject),'specification':None,'design':None}),evidence_refs=[e],review_refs=[e])
    request['request_content_identity']=identity(request)
    decision=rec('GateDecision',request_id=request_id,decision='ALLOW',rule_findings=[{'rule_id':rule,'result':'FAIL' if cause and rule==cause else 'PASS',
        'reason':'Apply installed safe-stop diagnosis/preservation; original cause remains failed.' if cause else 'Inspected named rule against the supplied concrete inputs and single-writer snapshot; only this declared procedural proposal is allowed.','evidence_refs':[e]} for rule in edge['rule_ids']],proposed_destination=edge['to'],resolution_route=None)
    decision_path=OUT/e['reference']['path'].split('/')[-2]/(request_id+'-decision.json')
    write(decision_path,decision);decision_evidence=evidence(decision_path)
    after=deepcopy(state);after.update(state=edge['to'],version=state['version']+1);after.update(changes or {})
    event=rec('Event',subject_kind=kind,subject_id=subject,request_id=request_id,request_content_identity=request['request_content_identity'],previous_version=state['version'],next_version=after['version'],previous_state=state['state'],next_state=after['state'],timestamp=datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),actor=ACTOR,
        decision_ref=decision_evidence,evidence_refs=[e],counter_deltas={k:{x:v-state.get(f,{}).get(x,0) for x,v in after.get(f,{}).items() if v!=state.get(f,{}).get(x,0)} for k,f in [('repair','repair_counters'),('invocation','invocation_counters')]},post_state=after)
    return {'request':request,'gate_decision':decision,'event_proposal':event}


def main():
    compiled=ROOT/'compiled/.harness';flow=read(compiled/'development/workflow.yaml');edges=flow['transitions']+flow['resolution_routes']
    state=read(compiled/'development/templates/task-state.yaml');state.update(task_id='SYNTHETIC-research-change',state='TEST_PASSED',version=11,configuration_id='cfg-5',input_snapshot=read(compiled/'shared/repo-profile.yaml')['repository']['identity'])
    state['writer']['identity']=ACTOR
    state['accepted_identities']={'request':identity('old request'),'specification':identity('old spec'),'design':identity('old design')}
    inputs={'state':state,'old_spec_identity':state['accepted_identities']['specification'],'new_spec_identity':identity('revised spec requiring different external dependency'),'research_impact':'Previously accepted dependency research no longer applies; earliest invalidated baseline assumptions are unknown.',
        'old_reports_retained':['synthetic build/test reports for old specification'],'actual_decision':'Reject reuse of old acceptance reports; RULE-12 requires NEW after explicit invalidation review. Reaccept/research/replan; do not silently rewrite acceptance.',
        'assumptions':['The synthetic supplied state/history is coherent; no pending external operation. This is a procedural case, not an executed task.']}
    folder=OUT/'research-invalidated';write(folder/'inputs.json',inputs);e=evidence(folder/'inputs.json')
    first=next(x for x in edges if x['from']=='TEST_PASSED' and x['to']=='RESUME_REVIEW' and x.get('trigger')=='INVALIDATED')
    p1=proposal(state,first,e,'research-invalidation',{'stopped_from_state':'TEST_PASSED','resolution_refs':[e]})
    second=next(x for x in edges if x['from']=='RESUME_REVIEW' and x['to']=='NEW')
    p2=proposal(p1['event_proposal']['post_state'],second,e,'research-rebaseline',{'stop_reason':None,'stopped_from_state':None})
    write(folder/'review.json',{'case_id':'S-19.research-invalidated','actor':ACTOR,'rules':['RULE-06','RULE-11','RULE-12'],'input_evidence':e,'actual_result':'PASS','observations':['NEW is the earliest invalidated target for unknown research impact; old accepted identities/reports are preserved as historical and cannot satisfy revised criteria.','Decision proposals are separate from events; accepted spec is not silently replaced.'],'proposals':[p1,p2],'preserved_fields':['accepted_identities','selected_targets','repair_counters','invocation_counters','pending_invocation_refs'],'limitations':['Typed events are procedural proposals, not committed runtime events or executed verification.']})
    h=ROOT/'multi-target/.harness';profile=read(h/'shared/repo-profile.yaml');profile=deepcopy(profile)
    profile.update(configuration_id='cfg-99',configuration_revision=99,assessments=[]);profile['extensions']['repair_policy']['test'].update(enabled=True,max_attempts=2)
    state=read(h/'development/templates/task-state.yaml');state.update(task_id='SYNTHETIC-test-repair',state='TEST_FAILED',version=11,configuration_id='cfg-99',input_snapshot=profile['repository']['identity'],selected_targets=profile['workflow_profiles'][0]['required_targets']);state['writer']['identity']=ACTOR
    inputs={'state':state,'explicit_scenario_profile':profile,'policy_override_authority':'SYNTHETIC accepted test-repair policy premise; does not change any installed active profile.',
        'origin':'test','limit':2,'used':0,'previous_diagnostic':identity('old test assertion'),'new_diagnostic':identity('new isolated test-source fixture mismatch'),'hypothesis':'Correct only the identified synthetic test fixture within accepted source scope.','in_scope':True,'current_permission':'No production external action; declared synthetic adapter invocation parameters resolved.','unresolved_children':[],
        'actual_decision':'RULE-09 allows test-origin repair with new diagnostic and available budget. Commit proposal increments test once; build counter/call budgets unchanged. Full default preflight/build/test path remains required.'}
    folder=OUT/'test-origin-repair';write(folder/'inputs.json',inputs);e=evidence(folder/'inputs.json')
    edge=next(x for x in edges if x['from']=='TEST_FAILED' and x['to']=='REPAIRING' and x['trigger']=='repair_allowed')
    counters=deepcopy(state['repair_counters']);counters['test']=1
    p=proposal(state,edge,e,'test-repair-entry',{'repair_counters':counters})
    continuation=[]
    for a,b in [('REPAIRING','PREFLIGHT'),('PREFLIGHT','PREFLIGHT_PASSED'),('PREFLIGHT_PASSED','BUILDING'),('BUILDING','BUILD_PASSED'),('BUILD_PASSED','TESTING'),('TESTING','TEST_PASSED')]:
        route=next(x for x in edges if x['from']==a and x['to']==b and ('profiles' not in x or 'default' in x['profiles']));continuation.append({'transition_id':route['id'],'from':a,'to':b,'required_rules':route['rule_ids'],'actual_execution':'PENDING; no repair or tool call executed by this review'})
    write(folder/'review.json',{'case_id':'S-21.test-repair','actor':ACTOR,'rules':['RULE-08','RULE-09','RULE-10','RULE-11'],'input_evidence':e,'actual_result':'PASS','observations':['Positive test-origin guards inspected independently of build-origin case. Test counter is 1 in one proposed entry event; exact replay cannot increment again.','Full continuation is declared; no shortcut, budget reset or production verification result is supplied.'],'proposals':[p],'required_continuation':continuation,'preserved_fields':['accepted_identities','selected_targets','invocation_counters','pending_invocation_refs'],'limitations':['SYNTHETIC policy override and typed event proposal; not actual runtime enforcement or repair execution.']})
    old=read(compiled/'maintenance/updates/rule-schema-migration.yaml');state=deepcopy(next(x['post_state'] for x in old['events'] if x['next_state']=='MIGRATION_CHECKED'))
    state['update_id']='SYNTHETIC-stale-migration';profile=read(compiled/'shared/repo-profile.yaml')
    inputs={'state':state,'approved_base':state['scoped_approval']['base_configuration_id'],'actual_current_configuration_id':profile['configuration_id'],'actual_current_profile_identity':'sha256:'+hashlib.sha256((compiled/'shared/repo-profile.yaml').read_bytes()).hexdigest(),
        'approved_candidate_identity':state['scoped_approval']['candidate_identity'],'current_candidate_identity':state['candidate']['content_identity'],'actual_decision':'DENY stale promotion: approved cfg-4 base differs from actual cfg-5. Preserve cfg-5; require reinspection/restaging and renewed scoped approval.','current_profile':profile}
    folder=OUT/'migration-changed-base';write(folder/'inputs.json',inputs);e=evidence(folder/'inputs.json')
    refusal=rec('GateDecision',request_id='migration-stale-success',decision='DENY',rule_findings=[{'rule_id':'RULE-14','result':'FAIL','reason':'Exact approval identifies cfg-4; current installed bytes are cfg-5. Before-value/base conflict forbids publication or reuse of stale scoped approval.','evidence_refs':[e]}],proposed_destination=None,resolution_route='PENDING')
    mflow=read(compiled/'maintenance/maintenance-workflow.yaml');edge=next(x for x in mflow['transitions'] if x['from']=='MIGRATION_CHECKED' and x['to']=='PENDING')
    p=proposal(state,edge,e,'migration-stale-stop',{'stop_reason':'Scoped approval base cfg-4 differs from active cfg-5','stopped_from_state':'MIGRATION_CHECKED'},'RULE-14')
    write(folder/'review.json',{'case_id':'S-32.changed-base','actor':ACTOR,'rules':['RULE-08','RULE-11','RULE-14'],'input_evidence':e,'actual_result':'PASS','refused_success':refusal,'state_immediately_after_refusal':state,'observations':['Actual current cfg-5/profile bytes inspected; stale cfg-4 migration approval retained but cannot authorize a second/new publication.','Separate PENDING proposal preserves candidate/approval/history for reinspection. No active file is written and renewed approval is not fabricated.'],'proposals':[p],'preserved_fields':['candidate','scoped_approval','publication_manifest','inspected_configuration_id'],'limitations':['Review of real retained candidate/current bytes with a hypothetical new stale attempt; event remains a proposal.']})
    print(json.dumps({'procedural_cases':3,'production_calls':0,'installed_writes':0}))


if __name__=='__main__':main()
