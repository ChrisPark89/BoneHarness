"""Retain actual synthetic CLI observations, never production execution evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import yaml


def digest(p):return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--examples',required=True,type=Path);args=ap.parse_args()
    out=Path(__file__).resolve().parent;repo=args.examples/'compiled';h=repo/'.harness'
    profile=yaml.safe_load((h/'shared/repo-profile.yaml').read_text())
    request=json.loads((repo/'fixture-request.json').read_text());request.update(adapter=profile['capabilities']['build']['adapter'],configuration_id=profile['configuration_id'],adapter_definition_id=profile['capabilities']['build']['adapter']['content_identity'])
    write(out/'adapter-request.json',request)
    observations=[]
    for outcome in ['PASS','FAIL','BLOCKED','UNKNOWN']:
        command=[sys.executable,str(h/'shared/adapters/synthetic_adapter_B.py'),'--request',json.dumps(request,ensure_ascii=False),'--outcome',outcome]
        proc=subprocess.run(command,cwd=args.examples.parent,capture_output=True)
        stdout=out/('adapter-'+outcome+'.stdout.json');stderr=out/('adapter-'+outcome+'.stderr.txt')
        stdout.write_bytes(proc.stdout);stderr.write_bytes(proc.stderr)
        envelope=json.loads(proc.stdout);assert envelope['status']==outcome and envelope['provenance']=='FIXTURE' and proc.returncode==0
        observations.append({'command':command,'cwd':str(args.examples.parent),'exit_code':proc.returncode,'requested_outcome':outcome,
            'adapter_identity':digest(h/'shared/adapters/synthetic_adapter_B.py'),'request_identity':digest(out/'adapter-request.json'),
            'stdout':stdout.name,'stdout_identity':digest(stdout),'stderr':stderr.name,'stderr_identity':digest(stderr),
            'observed_status':envelope['status'],'provenance':envelope['provenance']})
    write(out/'adapter-cli-observations.json',{'actor':'Actual Python subprocesses, inspected by Codex Task 6 reviewer','runs':observations,'limitation':'Execution of fixture emitter only; its envelope remains FIXTURE and does not prove production work.'})


if __name__=='__main__':main()
