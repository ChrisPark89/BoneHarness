"""Capture actual pure checker aggregation calls; no runtime gate or repository writes."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform
import sys
KIT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(KIT/'tests'))
from test_assessment import AssessmentTests
rows=[]
for variant in ['ready-docs-pending-code','blocked-plus-unassessed','all-unassessed','optional-unused']:
    t=AssessmentTests();t.setUp()
    t.profile['workflow_profiles'][0]['id']='docs'
    t.profile['workflow_profiles'].append(dict(t.profile['workflow_profiles'][0],id='code'))
    docs=t.integration('docs');code=t.integration('code')
    claims=[]
    if variant=='ready-docs-pending-code':claims=[t.claim(docs)]
    elif variant=='blocked-plus-unassessed':
        claim=t.claim(docs);claim['result']='BLOCKED';claims=[claim]
    elif variant=='optional-unused':
        t.profile['workflow_profiles']=t.profile['workflow_profiles'][:1]
        optional=t.integration('docs','optional');claim=t.claim(optional);claim['result']='BLOCKED';claims=[t.claim(docs),claim]
    inputs={'catalogue':t.catalogue,'claims':claims,'profile':t.profile}
    before=json.dumps(inputs,sort_keys=True)
    result=t.summarize(t.catalogue,claims,t.profile)
    after=json.dumps(inputs,sort_keys=True)
    rows.append({'case_id':'S-09.'+variant,'inputs':deepcopy(inputs),'actual_output':result,'inputs_unchanged':before==after})
value={'actor':'actual harness_check.assessment.summarize native invocation','python':platform.python_version(),'executable':sys.executable,'source_identity':'sha256:'+hashlib.sha256((KIT/'checker/harness_check/assessment.py').read_bytes()).hexdigest(),'cases':rows,'limitations':['Pure status aggregation only; claims are synthetic inputs and do not become trusted tool execution.','Names docs/code identify independent supported tuples; each synthetic tuple uses the same declared build capability to isolate aggregation.']}
(KIT/'evidence/checks/aggregation-cases.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({r['case_id']:r['actual_output']['integration_assessment'] for r in rows}))
