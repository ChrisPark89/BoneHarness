"""Reproduce the bounded Task7 audit in its original scratch checkout only.

Fixed original/base paths are historical inspection inputs, not runtime tools.
No installed repository writes, adapters, dependencies or downloads are invoked.
Outputs go only to authoring evidence/checks in this scratch checkout.
"""
from pathlib import Path
import hashlib,json,subprocess,datetime,platform,sys
import yaml
root=Path.cwd();out=root/'builder-kit/evidence/checks';runtime=root/'builder-kit/templates/runtime';base='76b70ab1e8d3657d111815946102baaaf538a91f'
def identity(p):return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,data):(out/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
catalogue=yaml.safe_load((runtime/'shared/verification-criteria.yaml').read_text());cases=yaml.safe_load((runtime/'shared/conformance-cases.yaml').read_text())
expected=catalogue['extensions']['required_runtime_files'];actual=sorted(str(p.relative_to(runtime)) for p in runtime.rglob('*') if p.is_file())
assert sorted(expected)==actual and len(actual)==29
versions={'kit':{'path':'builder-kit/INSTALLER_SPEC.md','version':'1.0.0'},'adapter_interface':{'path':'builder-kit/templates/runtime/shared/adapter-interface.md','version':'1.0.0'},'criterion_catalogue':{'path':'builder-kit/templates/runtime/shared/verification-criteria.yaml','field':'catalogue_version','version':catalogue['catalogue_version']},'case_catalogue':{'path':'builder-kit/templates/runtime/shared/conformance-cases.yaml','field':'cases_version','version':cases['cases_version']}}
assert 'kit 1.0.0' in (root/versions['kit']['path']).read_text()
assert 'Interface version: "1.0.0"' in (root/versions['adapter_interface']['path']).read_text()
assert catalogue['catalogue_version']==cases['cases_version']=='1.0.0'
schemas=[]
for p in sorted((runtime/'shared/schemas').glob('*.json')):
 d=json.loads(p.read_text())
 def schema_versions(v):
  if isinstance(v,dict):
   if 'schema_version' in v.get('properties',{}):
    assert v['properties']['schema_version']['const']=='1.0.0'
   for value in v.values():schema_versions(value)
  elif isinstance(v,list):
   for value in v:schema_versions(value)
 schema_versions(d)
 schemas.append({'path':str(p.relative_to(root)),'identity':identity(p),'local_schema_name':p.name,'bundle_version':'1.0.0','note':'common.schema.json defines reusable types, not a record with its own schema_version field.' if p.name=='common.schema.json' else 'All schema_version fields use const1.0.0.'})
assert len(schemas)==7
preserved=[]
for prefix in ['archive','research','builder-kit/templates/runtime']:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'--',prefix],text=True).splitlines()
 for path in paths:
  before=subprocess.check_output(['git','show',base+':'+path]);before_id='sha256:'+hashlib.sha256(before).hexdigest();after_id=identity(root/path);assert before_id==after_id
  preserved.append({'path':path,'before_identity':before_id,'after_identity':after_id})
original=Path('/Users/jp/Documents/Codex/harness_engineering/docs/reviews/implementation-plan-review.md');copy=root/'docs/reviews/implementation-plan-review.md';assert original.read_bytes()==copy.read_bytes()
inputs=['README.md','builder-kit/README.md','builder-kit/INSTALLER_SPEC.md','builder-kit/installer/bootstrap-prompt.md','builder-kit/installer/installation-checklist.md','docs/specification.md','docs/acceptance-scenarios.md','docs/implementation-plan.md','docs/implementation-status.md','docs/reviews/implementation-plan-review.md','docs/reviews/implementation-review.md','builder-kit/pilot/README.md','builder-kit/pilot/report-template.yaml','builder-kit/evidence/release-assessment.md','builder-kit/evidence/native-platform-matrix.yaml','builder-kit/checker/README.md']
# The template is a private reporting aid, not an installed schema record.
pilot=yaml.safe_load((root/'builder-kit/pilot/report-template.yaml').read_text());assert pilot['status']=='PENDING';assert pilot['private_pilot_review']['result']=='PENDING'
for path in inputs:
 assert (root/path).is_file()
# Check only active public entry points; historical docs may describe earlier paths.
for path in ['README.md','builder-kit/README.md','builder-kit/INSTALLER_SPEC.md','builder-kit/installer/bootstrap-prompt.md']:
 text=(root/path).read_text();assert 'templates/HARNESS.md' not in text and 'templates/harness-maintenance.md' not in text and 'skill-contract.md' not in text
inventory={'record_type':'Task7ReleaseInventoryAudit','actor':'Codex final-review fix implementer','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z'),'command':'/private/tmp/harness-builder-20261004-efv7l2ai/venv/bin/python -B builder-kit/evidence/checks/task7_release_audit.py','cwd':str(root),'host':{'system':platform.system(),'machine':platform.machine(),'python':sys.version},'base_commit':base,'runtime_inventory_count':29,'runtime_inventory':[{'path':p,'identity':identity(runtime/p)} for p in actual],'versions':versions,'schemas':schemas,'inspected_inputs':[{'path':p,'identity':identity(root/p)} for p in inputs],'preserved':preserved,'original_plan_review':{'source':str(original),'delivered_path':str(copy.relative_to(root)),'source_identity':identity(original),'copied_identity':identity(copy)},'result':'PASS','limitations':['Assertions check shipped inventory/version/preservation/navigation definitions, not runtime enforcement, private pilot, Windows/Linux execution or final independent review.']}
dump('task7-release-inventory.json',inventory)
review={'record_type':'Task7ReleaseDocumentReview','actor':'Codex final-review fix implementer','observed_at':inventory['observed_at'],'inventory_ref':{'path':'builder-kit/evidence/checks/task7-release-inventory.json','identity':identity(out/'task7-release-inventory.json')},'inspected_inputs':inventory['inspected_inputs'],'decisions':[{'rule_ids':['RULE-02','RULE-11'],'finding':'PASS','observation':'29 actual runtime files equal installed required_runtime_files. Root/builder README routes to one bootstrap installation prompt; installer-only docs do not become runtime instructions. Development and maintenance use distinct canonical entry points and separate run/update records; shared has definitions and derived views. No runtime file changed.'},{'rule_ids':['RULE-03','RULE-12','RULE-14'],'finding':'PASS','observation':'Named kit/schema/interface/catalogue versions are1.0.0; config IDs/revisions remain separate. Pilot requests actual source/candidate/base identities, exact staged skill inspection, prospective publication and pinned-task adoption; missing facts stop. No repository facts or permissions were invented.'},{'rule_ids':['RULE-05','RULE-06','RULE-13','RULE-17'],'finding':'PASS','observation':'Release distinguishes nine automated baseline criterion IDs from unresolved review/report obligations and post-maintenance inventory semantics. Actual subprocesses, authored walkthroughs, FIXTURE compatibility and EXECUTION requirements remain distinct. Compiler example stays PARTIAL; exit0 does not certify all criteria. Adapted repair leaves IS-07.sequence wholly uncovered for current authority/applicability review; input safety remains checked. No tool accuracy or mechanical enforcement claim.'},{'rule_ids':['RULE-08','RULE-10','RULE-11','RULE-12'],'finding':'PASS','observation':'Pilot uses approved private area and repository permissions, persists history/intent/deadline/budgets, reconciles before new actions, preserves pinned A and explicitly adopts B with repeated affected gates. Source/evidence and completed reports stay private.'},{'rule_ids':['RULE-06','RULE-17'],'finding':'PASS','observation':'Native Windows/Linux, optional TOOL replay parts, actual absent-interpreter host and private pilot stay PENDING. S48 audit checks honest disclosure, not completion of those obligations. Tasks 1-7 and the initial final whole-kit review occurred. I-1 correction awaits scoped independent re-review; controller final validation/transfer remain PENDING.'}],'expected_state':'release assessment with limitations','actual_result':'PASS','preserved_summary':{'unmodified_paths':len(preserved),'unmodified_runtime_paths':29,'unchanged_original_plan_review':True,'no_runtime_or_original_edits':True},'limitations':['This is final-fix implementer procedural/self-review; it does not close the pending independent re-review or controller final validation/transfer. Named-rule inspection does not execute a runtime transition engine. No private/native-unavailable/pilot/TOOL obligation is satisfied.']}
dump('task7-release-review.json',review)
print(json.dumps({'runtime_files':29,'schemas':7,'catalogue_cases':len(cases['cases']),'catalogue_parts':sum(len(c['coverage_parts']) for c in cases['cases']),'preserved_paths':len(preserved),'result':'PASS'}))
