"""Index actual retained observations and accepted procedural reviews, with bounded claims."""
import hashlib
import json
from pathlib import Path
import yaml

KIT=Path(__file__).resolve().parents[2]
ROOT=KIT.parent
EVIDENCE=KIT/'evidence'


def ev(path,summary,provenance='REVIEW'):
    p=EVIDENCE/path
    return {'reference':{'kind':'LOCAL','scope':'REPOSITORY','path':p.relative_to(ROOT).as_posix()},
        'identity':'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest(),'summary':summary,'provenance':provenance}


def make(case,scenario,mode,result,observations,evidence,limitations,actor='Codex Task 6 procedural reviewer',**extension):
    return dict(schema_version='1.0.0',record_type='ScenarioResult',case_id=case,scenario_id=scenario,mode=mode,actor=actor,
        actual_result=result,observations=observations,evidence_refs=evidence,limitations=limitations,extensions=extension)


def main():
    records=[]
    for filename in ['development-walkthroughs.json','maintenance-walkthroughs.json']:
        source=json.loads((EVIDENCE/filename).read_text());shared=source['shared_fixtures']
        def expand(value):
            if isinstance(value,dict):
                if set(value)=={'fixture_ref'}:return expand(shared[value['fixture_ref']])
                return {k:expand(v) for k,v in value.items()}
            if isinstance(value,list):return [expand(v) for v in value]
            return value
        for raw in source['cases']:
            case=expand(raw);dev='gate_decision' in case;cid=case['case_id'] if dev else 'MNT-'+case['id']
            actor=case['actor'] if dev else case['result']['actor']
            if dev:
                observations=[case['reason'], 'Observed initial state '+case['state_before']['state']+'; gate '+case['gate_decision']['decision']+'. Decision preserves current state until a separately recorded allowed follow-up.',
                    'Named rules: '+', '.join(f['rule_id'] for f in case['gate_decision']['rule_findings'])]
                limits=case['limitations'];detail={'source_case_id':cid,'gate_decision':case['gate_decision']['decision'],'review_reuse':'Accepted Task 2 concrete inspection; indexed without reinterpreting fixtures as execution.'}
            else:
                observations=case['result']['observations']+['Committed update states: '+', '.join(u['current']['state'] for u in case['updates'])]
                limits=case['result']['limitations']+['Accepted Task 3 synthetic record inspection; profile/file values in these fixtures are authored premises, not actual installed-file writes. Task 6 archive separately retains actual publication.']
                detail={'source_case_id':case['id'],'review_reuse':'Accepted Task 3 concrete inspection; original reviewer attribution retained.'}
            records.append(make('T6-index-'+cid,case['scenario_id'],'WALKTHROUGH','PASS',observations,
                [ev(filename,'Accepted concrete procedural review for '+cid),ev('development-review.md' if dev else 'maintenance-review.md','Original attributed procedure review')],
                limits+['PASS evaluates only this named inspected procedural variant, never runtime enforcement or an unstated whole-scenario verdict.'],actor=actor,**detail))
    procedural={
        'S-01':('pending-test-complete-structure',['Actual cfg-3 post-activation installation review yields complete structure with compiled test still typed pending; later cfg-5 remains PARTIAL. No guessed test command.'],['checks/reviewed-compiled.stdout.json','checks/installed-walkthrough.zip']),
        'S-03':('checker-skipped-permitted-reviews',['Installed-only activation used actual attributed LLM_REVIEW for every required structural criterion; checker NOT_RUN remains historical. Later separately run checker reports do not fabricate installation-time automation.'],['checks/installed-walkthrough.zip','checks/reviewed-source-only.stdout.json']),
        'S-06':('interruption-edited-generated-file',['Exactly two generated files inventoried; one user-edited. Actual reread retains changed file, unchanged evidence and runtime history; activation blocked pending reconciliation.'],['checks/resume-inspection.json']),
        'S-07':('live-and-scoped-conflict',['Read complete existing live harness and root/nested instructions; proposal for second pointer conflicts with scoped instruction. Actual decision routes through maintenance and withholds activation.'],['checks/live-harness-inspection.json']),
        'S-08':('installed-only-full-publication',['Audit-denied builder reads; installed cfg-1→cfg-2 eligibility→activation/reread→cfg-3 final review; procedural task stops on fixture execution evidence; cfg-4 replacement and explicit adoption; exact approved synthetic rule/schema migration publishes cfg-5.'],['checks/installed-walkthrough.zip','checks/task6-fix1-walkthrough.stdout.txt','checks/task6-fix1-preserved-history.json']),
        'S-30':('actual-byte-replacement',['Actual source B/procedure/profile writes match committed intent, manifest, cfg-3 before-values and cfg-4 per-file receipts; all four emitted CLI envelopes remain FIXTURE.'],['checks/installed-walkthrough.zip','checks/adapter-cli-observations.json']),
        'S-32':('actual-rule-schema-publication',['Exact synthetic approval premise identifies candidate/base/scope. Staged schema validates four outcomes and rejects unsupported status before actual cfg-5 publication. Rule/schema clarification preserves existing interface constraints.'],['checks/installed-walkthrough.zip']),
        'S-36':('actual-pinned-adoption',['Original captured cfg-3 unchanged; explicit cfg-4 capture and ADOPTED/RESUME_REVIEW/IMPLEMENTED preserve accepted work/targets/counters. Later cfg-5 migration does not silently alter task cfg-4 pin.'],['checks/installed-walkthrough.zip']),
        'S-39':('actual-pending-inspected-reconciled',['After actual accepted cfg-4 publication, PENDING→INSPECTED→PROMOTED/RECONCILED restores already earned state; shared-tree hashes unchanged. No second publication; status then regenerated.'],['checks/installed-walkthrough.zip']),
        'S-47':('actual-fixture-refusal',['Actual fixture emitter outputs PASS/FIXTURE; installed RULE-05 procedural review refuses preflight success, followed by separate ALLOW safe-stop and BLOCKED event. Production work remains unresolved.'],['checks/installed-walkthrough.zip','checks/adapter-cli-observations.json'])}
    for sid,(variant,observations,paths) in procedural.items():
        records.append(make('T6-'+variant,sid,'WALKTHROUGH','PASS',observations,[ev(p,'Actual retained inputs/observations for '+variant) for p in paths],
            ['Attributable procedural review plus actual bounded file observations; no runtime gate engine, real human migration approval, or production execution claim.','Whole scenario coverage is the union of explicit obligations, with separately pending obligations retained.']))
    mechanical={
        'S-02':['Undefined graph endpoint fails the actual checker; structure is INCOMPLETE. Activation-withholding behavior is separately procedural.'],
        'S-04':['Actual assessment test rejects FIXTURE/REVIEW assertion for a criterion requiring EXECUTION.'],
        'S-05':['Actual workflow schema/registry mutation tests reject duplicate active binding authority.'],
        'S-09':['Actual pure aggregation tests exercise READY/PARTIAL/NOT_ASSESSED/BLOCKED precedence and optional-unused isolation.'],
        'S-14':['Actual schema/parser tests reject malformed envelopes/records; absence-to-Observation gate route is separately reviewed.'],
        'S-16':['Actual graph mutation diagnoses unknown rule or ambiguous route. Unresolved runtime verifier stays procedural.'],
        'S-34':['Actual freshness/assessment tests do not allow stale claims to satisfy current readiness; drift-source cases are separately reviewed.'],
        'S-45':['Actual loader tests reject unsafe paths/casing/symlink traversal, YAML/JSON duplicates, custom/merge tags, nonfinite/ambiguous values and malformed documents without remote schema fetching.'],
        'S-46':['Actual missing-dependency subprocess exits 2 without downloads. Covered-success reports remain INCOMPLETE until actual permitted reviews.'],
    }
    mechanical_log='checks/scenario-mechanical-python314.txt'
    text=(EVIDENCE/mechanical_log).read_text();assert '\nOK\n' in text,text[-500:]
    for sid,obs in mechanical.items():
        evidence=[ev(mechanical_log,'Actual targeted unittest output including named checks','EXECUTION')]
        if sid=='S-46':evidence += [ev('checks/unavailable-dependency.stdout.json','Actual -S dependency-unavailable report','EXECUTION'),ev('checks/unavailable-dependency.invocation.json','Exact dependency-unavailable invocation','EXECUTION')]
        records.append(make('T6-mechanical-'+sid,sid,'AUTOMATED','PASS',obs,evidence,
            ['Only the named checker/parser/aggregation behavior is automated; this does not certify procedural gate enforcement or whole-scenario completion.'],actor='unittest under native Python 3.14'))
    # Installation decision for undefined graph is concrete refusal, not a checker-made pointer action.
    records.append(make('T6-undefined-graph-activation','S-02','WALKTHROUGH','PASS',
        ['Inspected actual undefined-endpoint checker diagnostic and installed activation_contract: IS-04.graph FAIL prevents ACTIVATION_ELIGIBLE, so the reviewer withholds pointer write.'],
        [ev(mechanical_log,'Actual graph mutation diagnostic','EXECUTION'),ev('walkthrough.md','Attributable installed activation-rule inspection')],
        ['Checker does not activate or withhold files; this is the reviewer decision on concrete failed input.']))
    for sid,name in [('S-40','source-only'),('S-41','docs'),('S-42','multi-target'),('S-43','multi-target')]:
        records.append(make('T6-example-'+sid,sid,'AUTOMATED','PASS',
            ['Generated complete '+name+' layout with explicit profile/targets and pending/NA bindings; actual request/lineage CLI and archive relation tests pass. Scenario-specific gate decisions remain in the named accepted walkthrough variants.'],
            [ev('checks/walkthrough-relations-green.txt','Actual example/lineage/record-relation tests','EXECUTION'),ev('checks/reviewed-'+name+'.stdout.json','Actual current installed checker report','EXECUTION')],
            ['Tests validate generated artifacts and schema/lineage inputs; they are not a production scheduler or gate implementation.'],actor='unittest and reference-checker'))
    matrix=yaml.safe_load((EVIDENCE/'native-platform-matrix.yaml').read_text())
    for row in matrix['runs']:
        records.append(make('T6-native-'+row['id'],'S-44','AUTOMATED','PASS' if row['status']=='PASS' else 'FAIL',
            [row['os']+' '+row['runtime']+'; '+row['line_endings']+'; exit '+str(row['exit_code'])+'; before/after tree '+('equal' if row['before_tree']==row['after_tree'] else 'DIFFERENT')],
            [ev('native-platform-matrix.yaml','Exact native invocation and runtime/dependency/source identities','EXECUTION'),ev(row['stdout'].removeprefix('builder-kit/evidence/'),'Actual checker stdout','EXECUTION'),ev(row['input_tree_evidence'].removeprefix('builder-kit/evidence/'),'Actual before/after inspected tree','EXECUTION')],
            ['This native run does not verify other operating systems or real tool execution.'],actor='reference-checker native subprocess'))
    for host in matrix['pending']:
        records.append(make('T6-native-pending-'+host['os'],'S-44','AUTOMATED','PENDING',[host['reason']],[],
            host['required_obligations'],actor='Task 6 platform evidence audit',reproduction_commands=host['reproduction_commands']))
    for cid,obligation in [
        ('T6-release-document-review-pending','Task 7 final assembled README/installer/runtime navigation, versions, inventory, historical-label and release-claim review is not yet performed.'),
        ('T6-private-pilot-pending','Bounded private repository pilot and real tool integration evidence are unavailable; no pilot was performed.'),
        ('T6-release-native-platforms-pending','Native Windows/Linux execution remains absent; see both explicit S-44 pending matrix obligations.')]:
        records.append(make(cid,'S-48','WALKTHROUGH','PENDING',[obligation],[],['This exact release obligation remains pending; other evaluated checks do not certify it.']))
    covered={r['scenario_id'] for r in records}
    for n in range(1,49):
        sid=f'S-{n:02}'
        if sid not in covered:records.append(make('T6-uncovered-'+sid,sid,'WALKTHROUGH','PENDING',['No retained accepted evaluation has been joined for this scenario.'],[],['Its entire acceptance-scenario obligation remains pending.']))
    from catalogue_join import join
    joins=join(records,KIT,EVIDENCE,make,ev)
    value={'catalogue_part_coverage':joins,'schema_version':'1.0.0','claims':'Results are per named obligation or variant, not automatic whole-scenario verdicts. Imported walkthrough results retain original review attribution.','results':records}
    (EVIDENCE/'scenario-results.yaml').write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'records':len(records),'scenarios':len({r['scenario_id'] for r in records}),'pending':[r['case_id'] for r in records if r['actual_result']=='PENDING']}))


if __name__=='__main__':main()
