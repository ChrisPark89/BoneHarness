"""Retain actual bounded installation-recovery/dirty-input observations."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


def digest(p):return 'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scratch',required=True,type=Path);ap.add_argument('--installed',required=True,type=Path);args=ap.parse_args()
    root=args.scratch.resolve();root.mkdir(exist_ok=False);h=root/'.harness';(h/'development').mkdir(parents=True);(h/'shared').mkdir()
    owned=[]
    for name in ['development/HARNESS.md','shared/verification-rules.md']:
        shutil.copyfile(args.installed/name,h/name);owned.append({'path':name,'after_identity':digest(h/name)})
    write(root/'progress-before-interruption.json',{'generated_files':owned,'completed_evidence':[{'path':'shared/verification-rules.md','identity':owned[1]['after_identity']}],'activation':'STAGED'})
    history=h/'development/runs/preserved.txt';history.parent.mkdir(parents=True);history.write_text('SYNTHETIC prior runtime history; preserve\n')
    history_before=digest(history)
    with (h/'development/HARNESS.md').open('a',encoding='utf-8') as f:f.write('\nUSER EDIT: preserve this local note.\n')
    observed=[]
    for item in owned:
        actual=digest(h/item['path']);observed.append({**item,'observed_identity':actual,'decision':'REUSE after matching dependency inspection' if actual==item['after_identity'] else 'CONFLICT: preserve user edit; reconcile before activation'})
    assert digest(history)==history_before
    write(root/'resume-inspection.json',{'actor':'Codex Task 6 procedural reviewer','rules':['R-21','RULE-02','RULE-11'],'initial_generated_count':2,'inspected':observed,
        'actual_decision':'BLOCKED activation pending edited entry-point reconciliation; reused unchanged rules evidence by exact identity.',
        'history_before':history_before,'history_after':digest(history),'changed_file_preserved':True,'files_overwritten_on_resume':[]})
    live=root/'live repository';live.mkdir();shutil.copytree(args.installed,live/'.harness')
    (live/'AGENTS.md').write_text('Root instruction: use .harness/development/HARNESS.md\n',encoding='utf-8')
    (live/'nested').mkdir();(live/'nested/AGENTS.md').write_text('Nested instruction: do not change harness routing without scoped decision.\n',encoding='utf-8')
    write(root/'live-harness-inspection.json',{'actor':'Codex Task 6 procedural reviewer','initial':'Existing live harness and root/nested instructions',
        'existing_configuration_identity':digest(live/'.harness/shared/repo-profile.yaml'),'existing_ledger_identity':digest(live/'.harness/installation/installation-record.yaml'),'root_instruction_text':(live/'AGENTS.md').read_text(),'nested_instruction_text':(live/'nested/AGENTS.md').read_text(),'proposal':'Replace root routing with a second competing harness entry point for nested work.',
        'inputs':{'root_instruction':digest(live/'AGENTS.md'),'nested_instruction':digest(live/'nested/AGENTS.md'),'preserved_history':digest(history)},
        'rules':['R-01','R-21','RULE-08','RULE-14'],'actual_decision':'Route proposed changes to installed maintenance/migration. Nested routing conflict blocks pointer activation; no duplicate entry point.',
        'written_instructions_during_decision':[],'preserved_history':digest(history)})
    # Actual Git dirty tree uses no commit, hook, user identity or global configuration changes.
    gitroot=root/'dirty repository café';gitroot.mkdir();source=gitroot/'toy.txt';source.write_text('SYNTHETIC staged baseline\n')
    commands=[]
    for command in [['git','init','--quiet',str(gitroot)],['git','-C',str(gitroot),'add','toy.txt']]:
        p=subprocess.run(command,capture_output=True,text=True);commands.append({'command':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0
    staged=digest(source);source.write_text('SYNTHETIC changed dirty café bytes\n')
    command=['git','-C',str(gitroot),'status','--porcelain=v1'];p=subprocess.run(command,capture_output=True,text=True);commands.append({'command':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    write(root/'dirty-snapshot.json',{'actor':'Codex Task 6 procedural reviewer','observed_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'kind':'DIRTY_CONTENT_SNAPSHOT','commands':commands,
        'staged_identity':staged,'current_identity':digest(source),'actual_bytes':source.read_text(),'decision':'Use actual modified content identity; staged/base identity cannot satisfy current source gate.','git_commit_required':False})
    print(json.dumps({'scratch':str(root),'interruption':'edited file preserved; activation blocked','dirty_snapshot':digest(source)}))


if __name__=='__main__':main()
