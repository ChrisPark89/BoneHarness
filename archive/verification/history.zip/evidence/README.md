# Builder project evidence

Current layout implementation: [verification and limits](layout-update/README.md). Earlier results below remain historical.

This directory contains the results, logs and reviews produced while developing this builder kit. Start with the [release assessment](release-assessment.md), [scenario results](scenario-results.yaml) or [walkthrough](walkthrough.md).

The LLM needs `builder-kit/`. Verification of its generated harness uses that package's installation checklist and optional checker, followed by repository-specific evidence. These project results do not establish readiness in the target repository.

## Folder relocation — 2026-10-05

Project evidence moved from `builder-kit/evidence/` to `evidence/`, and authoring tests moved from `builder-kit/tests/` to `tests/`. Current navigation and test lookups use the new locations.

Recorded commands, source identities, result payloads, historical helper scripts and the installed walkthrough archive retain their original content. Paths inside these records describe the layout at recording time. Historical helper scripts can depend on their original scratch environment; they are retained evidence, not current installation commands.

The [relocation manifest](relocation/manifest.json) records the two directory moves and exact copies of cited source files whose navigation or test paths needed editing. Those copies use `.txt` suffixes under `relocation/previous/` to distinguish historical bytes from active instructions and tests. Existing result verdicts and their evidence hashes are preserved.

The release assessment describes verification performed before this relocation. The current authoring command is documented in [tests/README.md](../tests/README.md).
