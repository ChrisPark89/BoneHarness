# Harness setup

**Work can begin. All phases are connected.**

Configuration: `cfg-1` · Kit: `2.0.0` · Python: `.harness/.venv/bin/python` (3.14.0)

| Decision | Finding |
|---|---|
| Structure correct? | PASS — checker exit 0, all required files present |
| Python helpers ready? | PASS — venv at `.harness/.venv`; pip check clean |
| Entry guides loaded? | CONFIRMED — README.md and development guide loaded |
| Phases with gaps? | None — all six adapters COMPATIBLE |

**Adapter connections** (see [profile](../framework/config/repo-profile.yaml)):

- **research / final_review / pattern_search**: direct file inspection + `grep`
- **preflight**: `node --check src/calculator.js` (exit 0 observed)
- **build**: `npm run build` (exit 0, `Built dist/calculator.js` observed)
- **test**: `npm test` (1 pass, 0 fail observed)

No phase will wait. Specification acceptance and final verification are mandatory and cannot be skipped.

**Start a task:** tell the LLM —

> Follow `.harness/README.md` and its development guide for this task: …
