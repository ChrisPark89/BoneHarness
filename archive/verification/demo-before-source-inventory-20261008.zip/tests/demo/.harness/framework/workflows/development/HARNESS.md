# Repository development harness

Load this entry point explicitly for software tasks. For harness changes use [maintenance](../maintenance/harness-maintenance.md). Read existing repository instructions and respect their scopes; unresolved conflicts block activation.

1. Read the current [profile](../../config/repo-profile.yaml), [setup](../../../docs/setup.md), [workflow](workflow.yaml) and [rules](../verification-rules.md). Pending capability/policy values authorize no dispatch.
2. Create `docs/development/<task-id>/spec.md` from the [specification guide](../../templates/development/task-spec.md) when needed. Keep human pages within 200 visible words and link necessary details as evidence. Capture the request and accepted typed TaskSpec in the journal; no placeholder request/design files are required.
3. Pin configuration definitions once under `artifacts/configurations/`, reusing exact immutable bytes. Follow the [journal protocol](journal-protocol.md): append ConfigSnapshot and typed durable records to `artifacts/development/<task-id>/history.jsonl`. Initialize an Event at NEW/version 1. `state.json` is derived from the latest committed Event post_state.
4. At every gate separately review due criteria and applicable tool evidence. Append the transition request and gate decision, then let the single recorded writer append an allowed Event and refresh state. Denied/blocked decisions do not mutate state. Request the declared failure/stop route separately.
5. Before external action, append invocation intent, exact inputs, absolute deadline and budgets. Persist the returned handle before continuing. On restart validate the journal and reconnect pending work. Follow RULE-10–RULE-12 for uncertainty, invalidation, adoption and resume.

Preserve every failure/refusal and necessary raw evidence once under the owning artifact directory. Repair defaults to disabled and needs the canonical policy plus new evidence. Completion follows profile policy and grants no publication/merge authority. `LLM_PROTOCOL` enforcement is procedural; the journal helper is storage plumbing, not a gate evaluator or runtime state controller.

## Task report at handoff

Generate and link both derived reports at each handoff, including incomplete/blocked work, and regenerate on resume or evidence changes:

```text
python3 .harness/framework/tools/report.py --repo-root <absolute-path> --harness-root .harness --task-id <one-directory-name>
```

Open `docs/development/<task-id>/report.md`; follow its links to `artifacts/development/<task-id>/report.json` and evidence. The five default task files are spec.md, report.md, state.json, history.jsonl and report.json, created when needed. Necessary evidence/shared snapshots are additional. Do not persist routine reporter console logs.

Exit 0 means declared record checks are consistent; exit 1 produces a report with issues; exit 2 means REPORT_UNAVAILABLE and previous outputs may be stale. The tool requires Python 3.11+ and provisioned [dependencies](../../tools/requirements.lock), or a conforming replacement. No automatic downloads or hand-written generated reports.

The reporter cannot authorize transitions, approve skips or repair records. Mandatory source_content_inventory remains UNCHECKED, so positive completion support is unavailable. Scoped NOT_APPLICABLE authority and user-approved skips remain unsupported. Neither specification phase can be waived. Setup readiness and task progress remain separate.
