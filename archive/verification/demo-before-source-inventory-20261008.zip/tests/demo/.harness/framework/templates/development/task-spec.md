# Task specification

Task ID: (unique durable ID)
Request: (captured text and SHA-256 identity)
Acceptance authority: (actor and durable approval/policy evidence)

## Accepted scope and design

Describe observable behavior, source/component/environment scope, non-goals, design and dependencies. Capture specification/design identities in `task-spec.yaml`; preserve each accepted revision. Before acceptance, use request and installed stage criteria.

## Criteria and verification plan

| Criterion ID | Observable requirement | Required | Due state | Allowed method | Planned evidence |
|---|---|---|---|---|---|
| (ID) | (observable condition) | true | (stage) | AUTOMATED / LLM_REVIEW / HUMAN_REVIEW | (actual output/review reference) |

Retain the installed default development criteria D-BASELINE through D-COMPLETE in [RULE-06](../../workflows/verification-rules.md); add repository/task criteria from inspected instructions and accepted request with evidence minimums and authority. Record required target/environment set and the unique active profile. `TEST_READY` means each criterion has a verification plan. Review only criteria due at each stage; SPEC_VERIFIED reconciles all required criteria. Execution evidence and criterion-level LLM review remain distinct. NOT_APPLICABLE requires scope/policy authority and replacement evidence. Fixture evidence never proves task execution.

## Durable records

Create `docs/development/<task-id>/spec.md` (maximum 200 visible words) and append the accepted TaskSpec to `artifacts/development/<task-id>/history.jsonl`. Derive `state.json` from committed Event post-states; pin definitions under `artifacts/configurations/`. Use [typed examples](./) and replace fixture values. Capture dirty/non-Git contents and separate product/test-source/artifact identities where needed. Follow [installed rules](../../workflows/verification-rules.md) for intent, gate decisions, single-writer events, replay, deadlines, invalidation and explicit config adoption. Keep prior accepted specs and results as historical evidence.

## Reporting and configuration capture

Capture exact bytes of the installed report schema (SCHEMA), support source/lock/immutable legacy descriptor (SUPPORT) and declarative layout (REPORTING_TEMPLATE), using the expanded [snapshot template](config-snapshot.yaml). Preserve historical pins on maintenance; report generation never adopts current definitions on behalf of an old task.

At every completed or unfinished handoff, generate/link `docs/development/<task-id>/report.md` and `artifacts/development/<task-id>/report.json` using [the development entry point](../../workflows/development/HARNESS.md#task-report-at-handoff). Reporting adds no acceptance criterion or workflow state. Record REPORT_UNAVAILABLE if the generator cannot run. Mandatory source-content enumeration is currently unsupported, preventing positive completion support; scoped N/A authority and user-skip records also remain unsupported by the reference reporter.
