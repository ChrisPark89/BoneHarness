# Repository harness

| Start here | Purpose |
|---|---|
| [Setup](docs/setup.md) | Current configuration, readiness and missing requirements. |
| [Development](framework/workflows/development/HARNESS.md) | Load this entry point explicitly for software tasks. |
| [Maintenance](framework/workflows/maintenance/harness-maintenance.md) | Load this entry point explicitly for harness changes. |

Human task pages live in `docs/development/<task-id>/`: `spec.md` and `report.md`. Maintenance summaries live in `docs/maintenance/`.

`framework/` contains installed instructions, configuration, adapters, templates and tools. `artifacts/` contains process records and necessary evidence; it is usually unnecessary for routine reading. Each report links to its supporting records.

Respect existing repository instructions and their scopes. Installation makes no changes to repository instruction files. An unresolved instruction conflict blocks activation.

[Two-scenario trial](docs/trial.md)
