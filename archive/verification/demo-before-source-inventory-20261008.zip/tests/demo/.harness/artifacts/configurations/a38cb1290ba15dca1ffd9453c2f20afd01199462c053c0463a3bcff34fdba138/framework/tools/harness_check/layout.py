"""Explicit read-only path selection; no file migration or source-record rewriting."""
from .loader import DocumentError

LEGACY_PATHS = {
    'framework/config/repo-profile.yaml': 'shared/repo-profile.yaml',
    'framework/workflows/development/HARNESS.md': 'development/HARNESS.md',
    'framework/workflows/development/workflow.yaml': 'development/workflow.yaml',
    'framework/workflows/maintenance/harness-maintenance.md': 'maintenance/harness-maintenance.md',
    'framework/workflows/maintenance/maintenance-workflow.yaml': 'maintenance/maintenance-workflow.yaml',
    'framework/workflows/verification-rules.md': 'shared/verification-rules.md',
    'framework/workflows/verification-criteria.yaml': 'shared/verification-criteria.yaml',
    'framework/workflows/conformance-cases.yaml': 'shared/conformance-cases.yaml',
    'framework/workflows/reporting-legacy-baseline.json': 'shared/reporting-legacy-baseline.json',
    'framework/adapters/adapter-interface.md': 'shared/adapter-interface.md',
    'framework/templates/schemas': 'shared/schemas',
    'framework/templates/development/task-spec.md': 'development/task-spec.md',
    'framework/templates/development': 'development/templates',
    'framework/templates/maintenance': 'maintenance/templates',
    'framework/templates/setup.md': 'shared/harness-status.md',
    'docs/setup.md': 'shared/harness-status.md',
    'framework/templates/installation/installation-record.yaml': 'installation/installation-record.yaml',
    'artifacts/installation/installation-record.yaml': 'installation/installation-record.yaml',
    'framework/tools/report.py': 'development/report.py',
    'framework/tools/reporting': 'development/reporting',
    'framework/tools/requirements.lock': 'shared/python/requirements.lock',
    'framework/tools/harness_io': 'shared/python/harness_io',
    'artifacts/development': 'development/runs',
    'artifacts/maintenance': 'maintenance/updates',
}
NEW_ONLY = {'README.md', 'framework/tools/journal.py', 'framework/tools/harness_io/journal.py',
            'framework/workflows/development/journal-protocol.md'}


def legacy_path(name):
    for new, old in sorted(LEGACY_PATHS.items(), key=lambda item: -len(item[0])):
        if name == new or name.startswith(new + '/'):
            return old + name[len(new):]
    return name


def check_layout(harness, legacy):
    old = (harness / 'shared/repo-profile.yaml').exists()
    new = (harness / 'framework/config/repo-profile.yaml').exists()
    if old and new:
        raise DocumentError('LAYOUT_AMBIGUOUS', harness, 'Both legacy and current profile roots are present; explicit migration reconciliation required')
    if (legacy and not old) or (not legacy and not new):
        raise DocumentError('LAYOUT_MODE', harness, 'Requested layout does not match the installed profile; legacy inspection requires --legacy-layout')
