"""Render a captured TaskReport; no source reads or new evidence verdicts.

extensions.reporting.presentation carries captured template_text/template_identity,
template_reference, repo_root, harness_root, run_root, specification_refs, evidence_roles and
publication_diagnostics. CLI supplies this JSON-compatible context once.
"""
import hashlib
import html
import os
from pathlib import Path, PureWindowsPath
import re
from urllib.parse import quote, urlsplit

_START, _END = '{{#phases}}', '{{/phases}}'
_TOKENS = {'task_title', 'specification_link', 'derived_summary', 'recorded_state', 'check_result', 'previous_failure_count',
           'repair_count', 'tool_failure_count', 'attempt_history_link', 'diagnostics_link',
           'criteria_link', 'sources_link'}
_TOKEN = re.compile(r'{{([A-Za-z_]+)}}')
_METADATA = re.compile(r'<!-- task-report generation_id=([a-f0-9]{64}) json_sha256=([a-f0-9]{64}) -->')
_BEFORE_LINES = (
    '# Task report: {{task_title}}', '', '{{specification_link}}', '', '**Summary:** {{derived_summary}} Validated state: {{recorded_state}}.',
    '**Record checks:** {{check_result}}.', '',
    '| Phase | Result | Evidence |', '|---|---|---|',
)
_AFTER_LINES = (
    '', '**History:** {{previous_failure_count}} earlier failures; {{repair_count}} repairs; {{tool_failure_count}} tool failures. {{attempt_history_link}}.',
    '', '{{diagnostics_link}} · {{criteria_link}} · {{sources_link}}.',
    'Tool claims do not establish phase success. Source inventory and user-skip authority remain unchecked.',
)



class ReportRenderError(ValueError):
    """A declarative template or captured presentation context is unsafe."""


def escape_text(value):
    """One-line literal Markdown/table text, including HTML and controls."""
    text = str(value) if value is not None else 'Not recorded'
    text = ''.join(' ' if ord(char) < 32 or ord(char) == 127 or char in '\u2028\u2029'
                   else char for char in text)
    text = html.escape(text, quote=False)
    return re.sub(r'([\\`*_{}\[\]()#+.!|>~\-])', r'\\\1', text)


def template_parts(text):
    """Allow only the approved outer fields and one fixed phase-row repeat."""
    if not isinstance(text, str):
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: require a UTF-8 template.')
    # Grammar permits native CRLF; identity still hashes the exact captured bytes.
    text = text.replace('\r\n', '\n')
    if text.count(_START) != 1 or text.count(_END) != 1:
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: require one phase repeat section.')
    before, rest = text.split(_START)
    row, after = rest.split(_END)
    expected_row = '\n| {{phase_label}} | {{status}} | {{links}} |\n'
    if row != expected_row:
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: malformed fixed phase row.')
    outer = before + after
    tokens = _TOKEN.findall(outer)
    remainder = _TOKEN.sub('', outer)
    if set(tokens) != _TOKENS or any(tokens.count(token) != 1 for token in _TOKENS):
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: missing, repeated or unknown field.')
    if '{{' in remainder or '}}' in remainder:
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: unsupported template expression.')
    if before != '\n'.join(_BEFORE_LINES) + '\n' or after != '\n'.join(_AFTER_LINES) + '\n':
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: malformed report sections.')
    return before, row, after


def _fill(text, values):
    # One substitution pass: injected content is never parsed as template syntax.
    return _TOKEN.sub(lambda match: values[match.group(1)], text)


class _Renderer:
    def __init__(self, report, run_root):
        self.report = report
        self.metadata = report['extensions']['reporting']
        self.context = self.metadata['presentation']
        self.run = Path(run_root)
        if not self.run.is_absolute() or self.run != Path(self.context['run_root']):
            raise ReportRenderError('REPORT_UNAVAILABLE: run root differs from captured presentation.')
        self.roots = {name: Path(self.context[field]) for name, field in
                      (('HARNESS', 'harness_root'), ('REPOSITORY', 'repo_root'))}
        if any(not root.is_absolute() for root in self.roots.values()):
            raise ReportRenderError('REPORT_UNAVAILABLE: presentation roots must be absolute.')
        self.paths = {(item['scope'], item['path']) for item in report['source_manifest']}

    def link(self, ref, label):
        if not isinstance(ref, dict):
            return escape_text(label) + ' (reference unavailable)'
        if ref.get('kind') == 'EXTERNAL':
            address = ref.get('uri', '')
            try:
                parts = urlsplit(address)
                safe = (parts.scheme.lower() in ('http', 'https') and bool(parts.hostname)
                        and not parts.username and not parts.password and '\\' not in address
                        and not any(ord(c) < 33 or ord(c) == 127 for c in address))
            except ValueError:
                safe = False
            if safe:
                return '[' + escape_text(label + ' (external, unchecked)') + '](' + quote(address, safe=':/?#@%=&+;,') + ')'
            return escape_text(label) + ' (external link disallowed; unchecked)'
        scope, path = ref.get('scope'), ref.get('path')
        if (ref.get('kind') != 'LOCAL' or scope not in self.roots or not isinstance(path, str)
                or (scope, path) not in self.paths or path.startswith('/') or '\\' in path
                or PureWindowsPath(path).drive or ':' in path
                or any(part in ('', '.', '..') for part in path.split('/'))):
            return escape_text(label) + ' (not captured; see report data)'
        # Lexical roots are the captured checked roots, including nested harnesses.
        candidate = self.roots[scope] / path
        try:
            relative = Path(os.path.relpath(candidate, self.run)).as_posix()
        except ValueError:
            return escape_text(label) + ' (link unavailable)'
        fragment = '#entry=' + quote(ref['entry_id'], safe='') if 'entry_id' in ref else ''
        return '[' + escape_text(label) + '](' + quote(relative, safe='/') + fragment + ')'

    def render(self):
        template = self.context['template_text']
        identity = 'sha256:' + hashlib.sha256(template.encode('utf-8')).hexdigest()
        if identity != self.context['template_identity']:
            raise ReportRenderError('REPORT_TEMPLATE_INVALID: captured template identity differs.')
        before, row_template, after = template_parts(template)
        report_root = Path(self.context.get('report_root', self.context['run_root']))
        data_path = Path(self.context['run_root']) / 'report.json'
        data_url = quote(Path(os.path.relpath(data_path, report_root)).as_posix(), safe='/')
        def detail(label, pointer=''):
            return '[' + label + '](' + data_url + ('#' + pointer if pointer else '') + ')'
        self.run = report_root
        history = self.report['history']
        recorded = escape_text(' '.join(str(self.report['recorded_state'] or 'none').split()[:3]))
        supported = self.report['completion_support'] == 'SUPPORTED_BY_CHECKED_RECORDS'
        summary = ('Completion supported.' if supported else 'Recorded completion unsupported.'
                   if self.metadata.get('recorded_complete_claimed') else 'Task incomplete.')
        saved = next((claim for claim in self.metadata.get('state_claims', [])
                      if claim.get('origin') == 'SAVED_STATE'), None)
        if saved and (saved.get('state') != self.report['recorded_state'] or not saved.get('snapshot_consistent')):
            summary += ' Saved claim: ' + self.link(saved.get('reference'), saved['state']) + ' (unverified).'
        rows = []
        for index, phase in enumerate(self.report['phases']):
            label = escape_text(' '.join(phase['label'].split()[:4]))
            result = escape_text(phase['status'])
            if phase['status'] == 'UNVERIFIED' and phase.get('recorded_claim'):
                result += ' (' + escape_text(phase['recorded_claim']) + ')'
            refs = phase['evidence_refs']
            capability = {'preflight': 'preflight', 'build': 'build', 'testing': 'test'}.get(phase['phase_id'])
            tool_results = [r for r in self.metadata.get('recorded_results', [])
                            if capability and r['payload'].get('capability') == capability
                            and r['payload'].get('provenance') == 'EXECUTION']
            if tool_results and all(type(r.get('journal_sequence')) is int for r in tool_results):
                latest = max(tool_results, key=lambda r: r['journal_sequence'])
                result += '; tool ' + escape_text(latest['payload']['status'])
                refs = [latest['payload'].get('evidence', {}).get('reference')]
            elif tool_results:
                result += '; tool claims unordered'
            evidence = self.link(refs[0], 'record') if refs else detail('details', '/phases/' + str(index))
            rows.append(_fill(row_template, dict(phase_label=label, status=result, links=evidence)).strip('\n'))
        tool_failures = sum(r['payload'].get('status') == 'FAIL' and r['payload'].get('provenance') == 'EXECUTION'
                            for r in self.metadata.get('recorded_results', []))
        values = dict(task_title=escape_text(' '.join(self.report['task_id'].split()[:6])),
                      specification_link=self.link(self.context.get('human_spec_reference'), 'Specification'),
                      derived_summary=summary, recorded_state=recorded,
                      check_result=self.report['record_checks'],
                      previous_failure_count=str(history['earlier_failure_count']),
                      repair_count=str(history['repair_count']), tool_failure_count=str(tool_failures),
                      attempt_history_link=detail('Attempts', '/history'),
                      diagnostics_link=detail('Full diagnostics', '/diagnostics'),
                      criteria_link=detail('Criteria', '/specification_coverage'),
                      sources_link=detail('Sources', '/source_manifest'))
        text = [_fill(before, values).rstrip(), '\n'.join(rows), _fill(after, values).rstrip()]
        repair_claims = sum(a.get('state') == 'REPAIRING' and not a.get('extensions', {}).get('reporting', {}).get('committed')
                            for a in history['attempts'])
        failure_claims = history.get('extensions', {}).get('reporting', {}).get('unsupported_failure_claim_count', 0)
        if failure_claims:
            text.append(str(failure_claims) + ' recorded failure claims (unverified).')
        if repair_claims:
            text.append(str(repair_claims) + ' recorded repair claims (unverified); ' + detail('history', '/history') + '.')
        if self.context['publication_diagnostics']:
            text.append('Prior report pair mismatched; see diagnostics.')
        if self.metadata.get('captured_before_change'):
            text.append('Sources changed during capture; outcomes unverified.')
        body = '\n'.join(text)
        visible = re.sub(r'\[([^]]*)\]\([^)]*\)', r'\1', body)
        visible = re.sub(r'[#*|_`—-]', ' ', visible)
        if len(visible.split()) > 200:
            raise ReportRenderError('REPORT_SIZE: more than 200 visible words')
        from .evidence import canonical_json
        digest = hashlib.sha256(canonical_json(self.report) + b'\n').hexdigest()
        return body.rstrip() + '\n\n<!-- task-report generation_id=' + self.report['generation_id'] + ' json_sha256=' + digest + ' -->\n'


def render_markdown(report: dict, *, run_root: Path) -> str:
    """Render escaped captured values; report JSON retains every issue/claim."""
    return _Renderer(report, run_root).render()


def inspect_pair_metadata(markdown):
    """Return the sole fixed publication marker, or None for absent/ambiguous data."""
    matches = _METADATA.findall(markdown)
    return matches[0] if len(matches) == 1 else None
