"""Capture once; derive reports without reopening authority or evidence files.

No external retrieval, command execution, state repair, or dynamic verifier loading.
All document keys are ``SCOPE:path``. Record locations include a JSON pointer;
references remain ordinary installed Reference objects. See capture_task's contract.
"""
from copy import deepcopy
import hashlib
import json
import re
from pathlib import Path, PurePosixPath, PureWindowsPath
from urllib.parse import urljoin, urlsplit

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from referencing import Registry, Resource
from referencing.exceptions import Unresolvable
from referencing.jsonschema import DRAFT202012

from harness_io.loader import DocumentError, parse_document, read_bytes, scoped_path
from harness_io.schemas import FORMATS
from harness_io.journal import parse_history

_MESSAGES = {
    'REPORT_SOURCE_MISSING': 'A referenced source file is missing.',
    'REPORT_SOURCE_INACCESSIBLE': 'A referenced source file could not be read safely.',
    'REPORT_SOURCE_CHANGED': 'The captured source set changed before publication.',
    'REPORT_DOCUMENT_INVALID': 'A source document does not satisfy its installed record contract.',
    'REPORT_IDENTITY_MISMATCH': 'Recorded identities do not match the captured evidence.',
    'REPORT_RECORD_COLLISION': 'A stable record identity has multiple conflicting records.',
    'REPORT_RECORD_MISSING': 'A required supporting record is missing.',
    'REPORT_HISTORY_INVALID': 'The recorded event history has an invalid suffix.',
    'REPORT_SNAPSHOT_MISMATCH': 'The saved state does not match the validated committed history.',
    'REPORT_TRANSITION_UNCHECKED': 'A recorded transition could not be checked against pinned rules.',
    'REPORT_TRANSITION_INVALID': 'A recorded transition contradicts the pinned workflow.',
    'REPORT_PHASE_MAP_INVALID': 'The pinned phase map is incomplete or ambiguous.',
    'REPORT_STATE_UNMAPPED': 'An observed state has no unambiguous phase mapping.',
    'REPORT_LEGACY_MAP_UNSUPPORTED': 'The pinned legacy workflow does not match the supported baseline.',
    'REPORT_STOP_ORIGIN_MISSING': 'The recorded stop has no supported origin state.',
    'REPORT_EVIDENCE_MISSING': 'Required outcome evidence is missing.',
    'REPORT_EVIDENCE_STALE': 'Required outcome evidence has been invalidated or is stale.',
    'REPORT_EVIDENCE_UNCHECKED': 'The evidence format or retrieval method is unsupported.',
    'REPORT_FIXTURE_EVIDENCE': 'Fixture evidence cannot support a real task outcome.',
    'REPORT_RULE_UNCHECKED': 'A pinned rule or criterion policy is outside the generator check coverage.',
    'REPORT_SKIP_AUTHORITY_UNVERIFIED': 'The skip claim lacks independently identifiable user authority.',
    'REPORT_SKIP_UNSUPPORTED': 'The pinned workflow does not support this skip claim.',
    'REPORT_METHOD_UNSUPPORTED': 'The verification method lacks pinned permission or replacement evidence.',
    'REPORT_EXECUTION_REQUIRED': 'A required execution outcome lacks matching execution evidence.',
    'REPORT_REVIEW_REQUIRED': 'A required independent criterion review is missing.',
    'REPORT_CRITERION_UNRESOLVED': 'A required criterion lacks supported satisfaction.',
    'REPORT_CRITERION_CONFLICT': 'Conflicting verdicts have no recorded supersession.',
    'REPORT_ACCEPTANCE_UNRESOLVED': 'The accepted task acceptance matrix is empty, missing or unmapped.',
    'REPORT_NOT_APPLICABLE_UNSUPPORTED': 'A not-applicable claim lacks required authority or replacement evidence.',
    'REPORT_MANDATORY_PHASE_SKIPPED': 'A mandatory specification phase was claimed as skipped.',
    'REPORT_COMPLETION_UNSUPPORTED': 'Recorded completion lacks checked mandatory support.',
    'REPORT_UNAVAILABLE': 'Report generation could not complete safely.',
}
_ID_FIELDS = {'Event': 'request_id', 'TransitionRequest': 'request_id',
              'GateDecision': 'request_id', 'Invocation': 'intent_id', 'Result': 'run_id',
              'TaskSpec': 'task_id', 'TaskState': 'task_id', 'EventLog': 'subject_id',
              'ConfigSnapshot': 'configuration_id'}
_RECORD_TYPES = set(_ID_FIELDS) | {'CriterionReview', 'Observation'}
_OUTPUTS = {'report.md', 'report-data.json', 'report.json'}
_BUILTIN_CRITERIA = {
    'D-BASELINE', 'D-RESEARCH', 'D-PATTERN', 'D-SPEC', 'D-VERIFY-PLAN',
    'D-IMPLEMENT-PLAN', 'D-IMPLEMENT', 'D-PREFLIGHT-INTENT', 'D-PREFLIGHT',
    'D-BUILD-INTENT', 'D-BUILD', 'D-TEST-INTENT', 'D-TEST', 'D-SPEC-FULL',
    'D-FINAL-REVIEW', 'D-COMPLETE',
}
# Same complete RULE-06 policy boundary as the installation checker. Normalize
# CRLF and outer whitespace only; Minimum evidence cells and prose are policy.
_RULE06_POLICY_SHA256 = '1b40d31acc23fe2f91bb8466a1a78cb45faf97bad9f549b9167abfdd893ad69f'


def canonical_json(value):
    """The installed request/fingerprint canonical serialization, as UTF-8 bytes."""
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'),
                      allow_nan=False).encode('utf-8')


def content_identity(content):
    return 'sha256:' + hashlib.sha256(content).hexdigest()


def reference_key(reference):
    return (reference['scope'] + ':' + reference['path'] + ('#' + reference['entry_id'] if 'entry_id' in reference else '') if reference.get('kind') == 'LOCAL'
            else canonical_json(reference).decode('utf-8'))


def _target_set(value):
    return sorted(canonical_json(target) for target in value) if isinstance(value, list) else None


def diagnostic(code, references=(), *, phase_id=None, criterion_id=None, severity='ERROR'):
    return dict(code=code, severity=severity, phase_id=phase_id, criterion_id=criterion_id,
                references=list(references), message=_MESSAGES[code])


def _walk(value, pointer=''):
    if isinstance(value, dict):
        yield pointer, value
        for key, child in value.items():
            yield from _walk(child, pointer + '/' + key.replace('~', '~0').replace('/', '~1'))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from _walk(child, pointer + '/' + str(index))


def _relative(value):
    if (not isinstance(value, str) or not value or value.startswith('/') or '\\' in value
            or PureWindowsPath(value).drive or ':' in value
            or any(part in ('', '.', '..') for part in value.split('/'))):
        raise DocumentError('PATH_TRAVERSAL', str(value), 'Require a canonical scoped path', 2)
    return value


def _reference(scope, path):
    return {'kind': 'LOCAL', 'scope': scope, 'path': str(path)}


def _inventory(root):
    """Record directory entries as well as files; never traverse a symlink."""
    items = []
    def visit(directory):
        safe = scoped_path(directory, root, directory=True)
        for child in sorted(safe.iterdir(), key=lambda p: p.name):
            relative = child.relative_to(root).as_posix()
            if relative in _OUTPUTS:
                continue
            if child.is_symlink():
                # Even internal directory links can form cycles or alias record identities.
                raise DocumentError('PATH_SYMLINK', child, 'Run inventory forbids symlinks', 2)
            if child.is_dir():
                items.append(relative + '/')
                visit(child)
            else:
                scoped_path(child, root)
                items.append(relative)
    visit(root)
    return sorted(items)


class _Capture:
    def __init__(self, repo_root, harness_root, task_id):
        if not isinstance(task_id, str) or '/' in task_id:
            raise DocumentError('TASK_ID', str(task_id), 'Task ID must be one directory name', 2)
        _relative(task_id)
        repo = Path(repo_root)
        if not repo.is_absolute():
            raise DocumentError('PATH_SCOPE', repo, 'Repository root must be absolute', 2)
        repo = repo.resolve(strict=True)
        harness = Path(harness_root)
        harness = scoped_path(harness if harness.is_absolute() else repo / harness, repo, directory=True)
        modern = harness / 'artifacts' / 'development' / task_id
        legacy = harness / 'development' / 'runs' / task_id
        if modern.exists() and legacy.exists():
            raise DocumentError('LAYOUT_AMBIGUOUS', task_id, 'Both modern and legacy task layouts exist', 2)
        self.modern = modern.exists()
        run = scoped_path(modern if self.modern else legacy, harness, directory=True)
        self.paths = {'REPOSITORY': repo, 'HARNESS': harness}
        self.run = run
        self.prefix = run.relative_to(harness).as_posix()
        self.data = {
            'roots': {'repo_root': str(repo), 'harness_root': str(harness), 'run_root': str(run),
                      'task_id': task_id, 'run_path': self.prefix, 'inventory': _inventory(run),
                      'inspected_inputs': {}, 'definitions': {}, 'schema_sources': {},
                      'record_schema': None, 'report_schema': None, 'publication_temporaries': {}},
            'documents': {}, 'record_index': {}, 'source_manifest': [],
            'phase_map': {'value': None, 'origin': 'UNSUPPORTED', 'valid': False,
                          'state_roles': {}, 'unmapped_states': [], 'workflow': None,
                          'profile': None, 'rules': None,
                          'stage_policy': {'supported': False, 'unsupported_criterion_ids': [],
                                           'references': [], 'identity': None}},
            'history': {'events': [], 'committed_prefix': [], 'invalid_suffix': [],
                        'last_post_state': None, 'snapshot': None, 'snapshot_consistent': False,
                        'complete': False, 'authoritative_documents': [], 'invocation_revisions': {},
                        'outcome_results': {}},
            'evidence_checks': {}, 'diagnostics': [],
            'coverage': {'checks': [], 'semantic_reviews': [], 'platforms': [
                {'platform': name, 'status': 'NOT_RUN', 'references': [],
                 'limitations': ['No native platform execution is established by evidence capture.']}
                for name in ('WINDOWS', 'MACOS', 'LINUX')]}}
        self.raw = {}
        self.invalid_documents = set()
        self.schema_documents = {}
        self.registry = None
        self.scanned = set()
        self.entries = []
        self.entry_documents = {}
        self.event_documents = {}
        if self.modern:
            journal_ref = self.run_ref('history.jsonl')
            raw = self.read(journal_ref, parse=False)
            if raw is None:
                raise DocumentError('JOURNAL_MISSING', run, 'Consolidated layout requires history.jsonl', 2)
            self.data['roots']['human_spec_reference'] = _reference('HARNESS', 'docs/development/' + task_id + '/spec.md')
            self.read(self.data['roots']['human_spec_reference'], parse=False)
            self.entries = parse_history(raw, task_id)
            self.data['roots']['journal_entry_sequence'] = {
                entry['entry_id']: entry['sequence'] for entry in self.entries}
            if not self.entries:
                raise DocumentError('JOURNAL_EMPTY', run, 'Journal has no pinned configuration', 2)
            for entry in self.entries:
                ref = dict(journal_ref, entry_id=entry['entry_id'])
                key = reference_key(ref)
                self.entry_documents[key] = entry['payload']
                self.data['documents'][key] = entry['payload']
            self.data['documents'][reference_key(journal_ref)] = dict(schema_version='1.0.0',
                record_type='EventLog', subject_id=task_id, subject_kind='TASK',
                events=[entry['payload'] for entry in self.entries if entry['payload']['record_type'] == 'Event'])

    def issue(self, code, refs=(), **kwargs):
        item = diagnostic(code, refs, **kwargs)
        if item not in self.data['diagnostics']:
            self.data['diagnostics'].append(item)
        return code

    def check(self, check_id, checked, refs=(), *, mandatory=True, limitations=()):
        row = dict(check_id=check_id, status='CHECKED' if checked else 'UNCHECKED',
                   mandatory=mandatory, references=list(refs), limitations=list(limitations))
        if row not in self.data['coverage']['checks']:
            self.data['coverage']['checks'].append(row)

    def run_ref(self, path):
        if self.modern:
            if path == 'state.yaml':
                path = 'state.json'
            elif path == 'events.yaml':
                path = 'history.jsonl'
            elif path == 'config-snapshot.yaml':
                return dict(self.run_ref('history.jsonl'), entry_id=self.entries[0]['entry_id'])
        return _reference('HARNESS', self.prefix + '/' + _relative(path))

    def read(self, ref, *, parse=True, required=True):
        if not isinstance(ref, dict) or ref.get('kind') != 'LOCAL':
            self.issue('REPORT_EVIDENCE_UNCHECKED')
            return None
        scope, path = ref.get('scope'), _relative(ref.get('path'))
        if scope not in self.paths:
            raise DocumentError('PATH_SCOPE', path, 'Unknown reference scope', 2)
        key = reference_key(ref)
        if 'entry_id' in ref:
            if not self.modern or path != self.prefix + '/history.jsonl':
                raise DocumentError('JOURNAL_REFERENCE', path, 'Entry references must select this task journal', 2)
            value = self.entry_documents.get(key)
            if value is None:
                self.issue('REPORT_RECORD_MISSING', [ref])
                return None
            return value if parse else canonical_json(value)
        candidate = self.paths[scope] / path
        # Reject both spellings, aliases, and resolved aliases of report outputs.
        outputs = {self.run / name for name in _OUTPUTS}
        if self.modern:
            outputs.add(self.paths['HARNESS'] / 'docs/development' / self.data['roots']['task_id'] / 'report.md')
        if candidate in outputs or candidate.resolve() in {p.resolve() for p in outputs}:
            self.issue('REPORT_EVIDENCE_UNCHECKED', [ref])
            return None
        inspected = self.data['roots']['inspected_inputs']
        if key not in inspected:
            inspected[key] = {'reference': ref, 'identity': None, 'error': None}
            try:
                raw = read_bytes(candidate, self.paths[scope])
            except DocumentError as exc:
                if exc.code in ('PATH_SCOPE', 'PATH_TRAVERSAL', 'PATH_SYMLINK', 'PATH_CASE'):
                    raise
                inspected[key]['error'] = exc.code
                if required:
                    self.issue('REPORT_SOURCE_MISSING' if exc.code == 'PATH_MISSING'
                               else 'REPORT_SOURCE_INACCESSIBLE', [ref])
                return None
            self.raw[key] = raw
            identity = content_identity(raw)
            inspected[key]['identity'] = identity
            self.data['source_manifest'].append(dict(scope=scope, path=path, identity=identity))
        raw = self.raw.get(key)
        if raw is None:
            return None
        if parse and key not in self.data['documents']:
            try:
                self.data['documents'][key] = parse_document(raw, Path(path))
            except DocumentError:
                self.invalid_documents.add(key)
                self.issue('REPORT_DOCUMENT_INVALID', [ref])
                return None
        return self.data['documents'].get(key) if parse else raw

    def schema_registry(self):
        resources = {}
        for key, schema in self.schema_documents.items():
            ref = self.data['roots']['inspected_inputs'][key]['reference']
            uri = (self.paths[ref['scope']] / ref['path']).as_uri()
            try:
                Draft202012Validator.check_schema(schema)
                for _, node in _walk(schema):
                    if '$id' in node or ('$schema' in node and node['$schema'] !=
                                            'https://json-schema.org/draft/2020-12/schema'):
                        raise ValueError('Unsupported schema resource/dialect')
                    for field in ('$ref', '$dynamicRef'):
                        if field not in node:
                            continue
                        parts = urlsplit(node[field])
                        if parts.scheme or parts.netloc or parts.query or '%' in parts.path:
                            raise ValueError('Nonlocal schema reference')
                        if parts.path:
                            _relative(parts.path)
                        target = urljoin(uri, parts.path)
                        available = {(self.paths[x['scope']] / x['path']).as_uri()
                                     for x in self.data['roots']['schema_sources'].values()}
                        if target not in available:
                            raise ValueError('Reference is not an explicitly captured schema')
                        if parts.fragment and not parts.fragment.startswith('/'):
                            raise ValueError('Only JSON Pointer fragments are supported')
                resources[uri] = Resource.from_contents(schema, default_specification=DRAFT202012)
            except (ValueError, TypeError, SchemaError):
                self.issue('REPORT_DOCUMENT_INVALID', [ref])
                self.invalid_documents.add(key)
        def forbidden(uri):
            raise Unresolvable(ref=uri)
        self.registry = Registry(retrieve=forbidden).with_resources(resources.items())

    def validate(self, value, schema_ref, definition=None, refs=()):
        if schema_ref is None or reference_key(schema_ref) in self.invalid_documents:
            self.check('pinned_schema_validation', False, refs,
                       limitations=['A required captured schema is unavailable or invalid.'])
            return False
        uri = (self.paths[schema_ref['scope']] / schema_ref['path']).as_uri()
        if definition:
            uri += '#/$defs/' + definition
        try:
            validator = Draft202012Validator({'$ref': uri}, registry=self.registry,
                                              format_checker=FORMATS)
            valid = not any(validator.iter_errors(value))
        except (SchemaError, Unresolvable, ValueError, TypeError, KeyError, RecursionError):
            valid = False
        if not valid:
            self.issue('REPORT_DOCUMENT_INVALID', refs)
        return valid

    def definitions(self):
        manifest_ref = self.run_ref('config-snapshot.yaml')
        manifest = self.read(manifest_ref)
        manifest = manifest if isinstance(manifest, dict) else {}
        definitions = manifest.get('captured_definitions', [])
        definitions = definitions if isinstance(definitions, list) else []
        if self.modern:
            paths = [item.get('captured_path', '') for item in definitions if isinstance(item, dict)]
            bundles = {path.split('/')[2] for path in paths if path.startswith('artifacts/configurations/') and len(path.split('/')) > 3}
            if len(bundles) != 1 or len(paths) != len(definitions):
                raise DocumentError('CONFIGURATION_BUNDLE', manifest_ref['path'], 'One shared configuration bundle required', 2)
            bundle = next(iter(bundles))
            prefix = 'artifacts/configurations/' + bundle + '/'
            mapping = {item['captured_path'][len(prefix):]: item.get('identity') for item in definitions}
            if (any(not path.startswith(prefix) for path in paths) or len(mapping) != len(paths)
                    or content_identity(canonical_json(mapping)) != 'sha256:' + bundle):
                raise DocumentError('CONFIGURATION_BUNDLE', manifest_ref['path'], 'Configuration bundle identity mismatch', 2)
        for item in definitions:
            if (not isinstance(item, dict) or not isinstance(item.get('captured_path'), str)
                    or item.get('kind') not in ('PROFILE', 'WORKFLOW', 'RULES', 'SCHEMA',
                                                'ADAPTER', 'CRITERIA', 'CONFORMANCE',
                                                'SUPPORT', 'REPORTING_TEMPLATE')):
                self.issue('REPORT_DOCUMENT_INVALID', [manifest_ref])
                continue
            if not item['captured_path'].startswith('artifacts/configurations/' if self.modern else 'configuration/'):
                self.issue('REPORT_DOCUMENT_INVALID', [manifest_ref])
                continue
            ref = _reference('HARNESS', item['captured_path']) if self.modern else self.run_ref(item['captured_path'])
            key = reference_key(ref)
            raw = self.read(ref, parse=False)
            identity_ok = raw is not None and content_identity(raw) == item.get('identity')
            if not identity_ok:
                self.issue('REPORT_IDENTITY_MISMATCH', [manifest_ref, ref])
                self.invalid_documents.add(key)
            self.data['roots']['definitions'].setdefault(item.get('kind', 'UNKNOWN'), []).append(
                {'reference': ref, 'identity_valid': identity_ok, 'declared': item})
            if Path(ref['path']).suffix in ('.yaml', '.yml', '.json'):
                value = self.read(ref)
                if item.get('kind') == 'SCHEMA' and isinstance(value, dict) and identity_ok:
                    self.schema_documents[key] = value
                    self.data['roots']['schema_sources'][key] = ref
        # Reporting is a generator contract, never a substitute for a missing pinned record schema.
        for name in ('task-report.schema.json', 'common.schema.json'):
            ref = _reference('HARNESS', 'framework/templates/schemas/' + name)
            value = self.read(ref)
            if isinstance(value, dict):
                self.schema_documents[reference_key(ref)] = value
                self.data['roots']['schema_sources'][reference_key(ref)] = ref
            if name == 'task-report.schema.json':
                self.data['roots']['report_schema'] = ref
        self.schema_registry()
        schema_candidates = self.definition_refs('SCHEMA', 'records.schema.json')
        self.data['roots']['record_schema'] = schema_candidates[0] if len(schema_candidates) == 1 else None
        self.check('pinned_schema_validation', self.data['roots']['record_schema'] is not None,
                   schema_candidates)
        for kind, schema_name in (('WORKFLOW', 'workflow.schema.json'), ('PROFILE', 'profile.schema.json')):
            refs = self.definition_refs(kind)
            schemas = self.definition_refs('SCHEMA', schema_name)
            ref = refs[0] if len(refs) == 1 else None
            if ref is None:
                self.issue('REPORT_RECORD_MISSING', [manifest_ref])
                continue
            key = reference_key(ref)
            if not self.validate(self.data['documents'].get(key), schemas[0] if len(schemas) == 1 else None,
                                 refs=[ref]):
                self.invalid_documents.add(key)
            else:
                self.data['phase_map'][kind.lower()] = key
        rules = self.definition_refs('RULES')
        if len(rules) == 1:
            self.data['phase_map']['rules'] = reference_key(rules[0])
        else:
            self.issue('REPORT_RECORD_MISSING', [manifest_ref])

    def definition_refs(self, kind, filename=None):
        return [row['reference'] for row in self.data['roots']['definitions'].get(kind, [])
                if row['identity_valid'] and (filename is None or
                    PurePosixPath(row['reference']['path']).name == filename)]

    def inspect_evidence(self, evidence, owner):
        ref = evidence.get('reference')
        if not isinstance(ref, dict):
            return
        key = reference_key(ref)
        check = self.data['evidence_checks'].setdefault(key, {
            'reference': ref, 'identity': None, 'expected_identities': [], 'provenances': [],
            'owners': [], 'checked': False, 'valid': True, 'diagnostic_codes': []})
        if owner not in check['owners']:
            check['owners'].append(owner)
        expected = evidence.get('identity')
        if expected and expected not in check['expected_identities']:
            check['expected_identities'].append(expected)
        provenance = evidence.get('provenance')
        if provenance and provenance not in check['provenances']:
            check['provenances'].append(provenance)
        def fail(code):
            check['valid'] = False
            if code not in check['diagnostic_codes']:
                check['diagnostic_codes'].append(code)
            self.issue(code, [ref])
        if provenance == 'FIXTURE':
            fail('REPORT_FIXTURE_EVIDENCE')
        if ref.get('kind') != 'LOCAL':
            fail('REPORT_EVIDENCE_UNCHECKED')
            self.check('external_evidence:' + key, False, [ref],
                       limitations=['External evidence is never retrieved by this generator.'])
            return
        raw = self.read(ref, parse=False)
        if raw is None:
            fail('REPORT_EVIDENCE_MISSING')
            return
        check['identity'] = content_identity(raw)
        check['checked'] = True
        if expected and expected != check['identity']:
            fail('REPORT_IDENTITY_MISMATCH')
        if len(check['expected_identities']) > 1:
            fail('REPORT_IDENTITY_MISMATCH')
        # Parse referenced records only; arbitrary plain logs remain captured bytes.
        if 'entry_id' in ref or Path(ref['path']).suffix in ('.json', '.yaml', '.yml'):
            value = self.read(ref)
            if isinstance(value, dict) and value.get('record_type') in _RECORD_TYPES:
                self.index_document(key, value, ref)

    def index_document(self, key, value, ref):
        if key in self.scanned:
            return
        self.scanned.add(key)
        kind = value.get('record_type')
        if kind not in _RECORD_TYPES:
            return
        schema = self.data['roots']['record_schema']
        definition = kind
        if kind == 'Result':
            candidates = self.definition_refs('SCHEMA', 'result.schema.json')
            schema = candidates[0] if len(candidates) == 1 else None
            definition = None
        valid = key not in self.invalid_documents and self.validate(value, schema, definition, [ref])
        if not valid:
            self.invalid_documents.add(key)
        self.add_record(kind, value, key, ref, '', valid)
        # Only the canonical log contributes Event records; a discovered Event file is a proposal.
        if kind == 'EventLog' and key == reference_key(self.run_ref('events.yaml')):
            for index, event in enumerate(value.get('events', []) if isinstance(value.get('events'), list) else []):
                if isinstance(event, dict):
                    event_valid = self.validate(event, self.data['roots']['record_schema'], 'Event', [ref])
                    self.add_record('Event', event, key, ref, '/events/' + str(index), event_valid)
        # A configuration manifest's reference fields describe definition origins;
        # current live definitions are never inputs to a pinned task's derivation.
        if kind == 'ConfigSnapshot':
            return
        for _, node in _walk(value):
            if isinstance(node.get('reference'), dict):
                target = node['reference']
                if target.get('kind') == 'LOCAL' and target.get('scope') in self.paths and isinstance(target.get('path'), str):
                    self.inspect_evidence(node, key)
                elif target.get('kind') == 'EXTERNAL' and isinstance(target.get('uri'), str):
                    self.inspect_evidence(node, key)
                else:
                    self.issue('REPORT_DOCUMENT_INVALID', [ref])

    def add_record(self, kind, value, key, ref, pointer, valid):
        field = 'specification_identity' if self.modern and kind == 'TaskSpec' else _ID_FIELDS.get(kind)
        identity = value.get(field) if field else key + pointer
        if not isinstance(identity, str) or not identity:
            self.issue('REPORT_DOCUMENT_INVALID', [ref])
            return
        entries = self.data['record_index'].setdefault(kind, {}).setdefault(identity, [])
        entry = {'document': key, 'reference': ref, 'pointer': pointer, 'value': value,
                 'schema_valid': valid, 'valid': valid, 'committed': False, 'event_ids': [],
                 'diagnostic_codes': []}
        if kind == 'Invocation':
            entry['revision_identity'] = (content_identity(canonical_json(value)) if 'entry_id' in ref
                                          else self.data['roots']['inspected_inputs'][key]['identity'])
            entry['selected_event_ids'] = []
        entries.append(entry)
        # An intent retains its logical ID across immutable status/handle revisions.
        # Check invariants and committed selection after all documents are captured.
        if len(entries) > 1 and kind != 'Invocation':
            self.issue('REPORT_RECORD_COLLISION', [row['reference'] for row in entries])
            for row in entries:
                row['valid'] = False
                row['diagnostic_codes'].append('REPORT_RECORD_COLLISION')

    def discover(self):
        if self.modern:
            for entry in self.entries:
                ref = dict(self.run_ref('history.jsonl'), entry_id=entry['entry_id'])
                key = reference_key(ref)
                self.index_document(key, entry['payload'], ref)
                if entry['payload']['record_type'] == 'Event':
                    self.event_documents[entry['payload']['request_id']] = key
            ref = self.run_ref('state.yaml')
            value = self.read(ref)
            if isinstance(value, dict):
                self.index_document(reference_key(ref), value, ref)
            # Auxiliary evidence is read only through recorded references.
            return
        # Capture only task run documents; no directory scan grants commit authority.
        for path in self.data['roots']['inventory']:
            if path.endswith('/') or path.startswith('configuration/'):
                continue
            ref = self.run_ref(path)
            if Path(path).suffix not in ('.yaml', '.yml', '.json'):
                self.read(ref, parse=False)
                continue
            value = self.read(ref)
            if isinstance(value, dict):
                self.index_document(reference_key(ref), value, ref)
        for filename in ('config-snapshot.yaml', 'events.yaml', 'state.yaml'):
            ref = self.run_ref(filename)
            value = self.read(ref)
            if isinstance(value, dict):
                self.index_document(reference_key(ref), value, ref)
        # Config manifest references describe live origins, not extra current authority.
        # The snapshot was already inspected above; do not treat its origins as evidence.

    def unique(self, kind, identity):
        if not isinstance(identity, str):
            return None
        rows = self.data['record_index'].get(kind, {}).get(identity, [])
        return rows[0] if len(rows) == 1 and rows[0]['valid'] else None

    def phase_mapping(self):
        result = self.data['phase_map']
        workflow = self.data['documents'].get(result['workflow'], {})
        profile = self.data['documents'].get(result['profile'], {})
        mapping = workflow.get('extensions', {}).get('reporting')
        if mapping is None:
            baseline_ref = _reference('HARNESS', 'framework/workflows/reporting-legacy-baseline.json')
            baseline = self.read(baseline_ref)
            candidate = deepcopy(workflow)
            extensions = candidate.get('extensions')
            if isinstance(extensions, dict):
                extensions.pop('reporting', None)
            if (isinstance(baseline, dict) and self.validate(baseline,
                    self.data['roots']['report_schema'], 'ReportingLegacyBaseline', [baseline_ref])
                    and workflow and content_identity(canonical_json(candidate)) == baseline.get('workflow_identity')):
                mapping = baseline['phase_map']
                result['origin'] = 'LEGACY_BASELINE'
            else:
                self.issue('REPORT_LEGACY_MAP_UNSUPPORTED', [baseline_ref])
        else:
            result['origin'] = 'PINNED'
        result['value'] = mapping
        refs = [self.data['roots']['inspected_inputs'][result['workflow']]['reference']] if result['workflow'] else []
        if not mapping or not self.validate(mapping, self.data['roots']['report_schema'], 'PhaseMap', refs):
            self.issue('REPORT_PHASE_MAP_INVALID', refs)
            self.check('phase_map', False, refs)
            return
        states = [state['id'] for state in workflow.get('states', [])]
        profiles = [row['id'] for row in profile.get('workflow_profiles', [])]
        # Dormant examples are display selectors only. committed_history still
        # admits actual task profiles solely from the pinned active profile list.
        examples = workflow.get('extensions', {}).get('profile_examples', {})
        selectors = set(profiles) | (set(examples) if isinstance(examples, dict) else set())
        phases, criteria = mapping['phases'], mapping['stage_criteria']
        valid = (len(states) == len(set(states)) and len(profiles) == len(set(profiles))
                 and len({p['id'] for p in phases}) == len(phases)
                 and len({p['order'] for p in phases}) == len(phases)
                 and len({c['id'] for c in criteria}) == len(criteria))
        assignments = {}
        for phase in phases:
            valid &= bool(phase['profiles']) and set(phase['profiles']).issubset(selectors)
            for role in ('success', 'active', 'failure'):
                for state in phase[role + '_states']:
                    assignments.setdefault(state, []).append({'phase_id': phase['id'], 'role': role})
            due_states = phase['success_states'] + phase['active_states'] + phase['failure_states']
            for criterion_id in phase['criterion_ids']:
                matches = [c for c in criteria if c['id'] == criterion_id and c['due_state'] in due_states]
                valid &= len(matches) == 1
        for state in mapping['control_states']:
            assignments.setdefault(state, []).append({'phase_id': None, 'role': 'control'})
        valid &= set(assignments) == set(states) and all(len(a) == 1 for a in assignments.values())
        valid &= all(c['due_state'] in states for c in criteria)
        for criterion in criteria:
            if criterion['due_state'] not in mapping['control_states']:
                valid &= sum(criterion['id'] in p['criterion_ids'] for p in phases) == 1
        result['state_roles'] = {state: roles[0] for state, roles in assignments.items() if len(roles) == 1 and state in states}
        # Metadata joins do not establish policy coverage. Preserve the complete
        # supported section identity without executing or inferring prose rules.
        rules = self.raw.get(result['rules'], b'').decode('utf-8', errors='replace')
        normalized_rules = rules.replace('\r\n', '\n')
        section = normalized_rules.split('### RULE-06\n', 1)[-1].split('### RULE-07', 1)[0]
        policy_identity = hashlib.sha256(section.strip().encode('utf-8')).hexdigest()
        policy_supported = policy_identity == _RULE06_POLICY_SHA256
        catalogue = [(identifier.strip(), due.strip(), [m.strip() for m in methods.split('+')])
                     for identifier, due, methods in re.findall(
                         r'^\s*\|\s*([^|\n]+)\|\s*([^|\n]+)\|\s*([^|\n]+)\|', section, re.M)
                     if (identifier.strip(), due.strip(), methods.strip()) !=
                         ('ID', 'Due success state', 'Allowed methods') and
                     not all(re.fullmatch(r':?-+:?', field.strip()) for field in (identifier, due, methods))]
        catalogue_valid = (_BUILTIN_CRITERIA.issubset({row[0] for row in catalogue})
                           and len({row[0] for row in catalogue}) == len(catalogue))
        for identity, due, methods in catalogue:
            matches = [c for c in criteria if c['id'] == identity]
            catalogue_valid &= (len(matches) == 1 and matches[0]['due_state'] == due
                                and matches[0]['allowed_methods'] == methods)
            if identity in _BUILTIN_CRITERIA and len(matches) == 1:
                catalogue_valid &= (matches[0]['required'] is True
                    and matches[0]['independent_review_required'] is True
                    and matches[0]['execution_required'] == (identity in ('D-PREFLIGHT', 'D-BUILD', 'D-TEST')))
        if not catalogue_valid:
            valid = False
        custom = sorted({c['id'] for c in criteria} - _BUILTIN_CRITERIA)
        policy_refs = [self.data['roots']['inspected_inputs'][result['rules']]['reference']] if result['rules'] else []
        result['stage_policy'] = dict(supported=policy_supported,
            unsupported_criterion_ids=custom if policy_supported else sorted(c['id'] for c in criteria),
            references=policy_refs, identity='sha256:' + policy_identity)
        self.check('stage_policy', policy_supported, policy_refs,
                   limitations=[] if policy_supported else [
                       'The complete pinned RULE-06 policy differs from the supported contract. '
                       'Stage and task criterion policy remains unchecked; matching review metadata does not establish satisfaction.'])
        if not policy_supported:
            self.issue('REPORT_RULE_UNCHECKED', policy_refs, severity='WARNING')
        if custom:
            for identity in custom:
                self.issue('REPORT_RULE_UNCHECKED', refs + policy_refs, criterion_id=identity, severity='WARNING')
            self.check('custom_stage_criteria', False, refs + policy_refs,
                       limitations=['Additional stage criteria have unsupported policy, including criteria declared in the RULE-06 table.'])
        result['valid'] = bool(valid)
        self.check('phase_map', True, refs)
        self.check('stage_catalogue', catalogue_valid, refs)
        if not valid:
            self.issue('REPORT_PHASE_MAP_INVALID', refs)

    def record_problem(self, entry, code):
        entry['valid'] = False
        if code not in entry['diagnostic_codes']:
            entry['diagnostic_codes'].append(code)
        self.issue(code, [entry['reference']])

    def record_at(self, evidence, kind):
        ref = evidence.get('reference') if isinstance(evidence, dict) else None
        if not isinstance(ref, dict):
            return None
        key = reference_key(ref)
        check = self.data['evidence_checks'].get(key)
        if not check or not check['valid'] or not check['checked']:
            return None
        rows = [row for group in self.data['record_index'].get(kind, {}).values() for row in group
                if row['document'] == key and row['valid']]
        return rows[0] if len(rows) == 1 else None

    def committed_history(self):
        history = self.data['history']
        log_ref = self.run_ref('events.yaml')
        log = self.data['documents'].get(reference_key(log_ref), {})
        log = log if isinstance(log, dict) else {}
        events = log.get('events', [])
        events = events if isinstance(events, list) else []
        history['events'] = deepcopy(events)
        workflow = self.data['documents'].get(self.data['phase_map']['workflow'], {})
        config = self.data['documents'].get(reference_key(self.run_ref('config-snapshot.yaml')), {})
        config = config if isinstance(config, dict) else {}
        profile = self.data['documents'].get(self.data['phase_map']['profile'], {})
        profile_ids = {p['id'] for p in profile.get('workflow_profiles', [])}
        previous = None
        broken = log.get('subject_id') != self.data['roots']['task_id'] or log.get('subject_kind') != 'TASK'
        seen = set()
        for position, event in enumerate(events):
            if broken or not isinstance(event, dict):
                broken = True
                history['invalid_suffix'].append({'position': position, 'event': event,
                                                  'diagnostic_codes': ['REPORT_HISTORY_INVALID']})
                continue
            row = self.unique('Event', event.get('request_id'))
            post = event.get('post_state', {})
            version = previous['version'] if previous else 0
            state = previous['state'] if previous else None
            valid = (row is not None and (
                     row['document'] == self.event_documents.get(event.get('request_id')) if self.modern else
                     row['document'] == reference_key(log_ref) and row['pointer'] == '/events/' + str(position))
                     and isinstance(post, dict)
                     and event.get('subject_id') == self.data['roots']['task_id']
                     and event.get('subject_kind') == 'TASK'
                     and event.get('previous_version') == version
                     and event.get('next_version') == version + 1
                     and event.get('previous_state') == state
                     and post.get('state') == event.get('next_state')
                     and post.get('version') == event.get('next_version')
                     and post.get('task_id') == self.data['roots']['task_id']
                     and post.get('profile_id') in profile_ids
                     and event.get('request_id') not in seen)
            if not valid:
                broken = True
                history['invalid_suffix'].append({'position': position, 'event': event,
                                                  'diagnostic_codes': ['REPORT_HISTORY_INVALID']})
                continue
            seen.add(event['request_id'])
            decision = self.record_at(event.get('decision_ref'), 'GateDecision')
            valid &= bool(decision and decision['value']['request_id'] == event['request_id']
                          and decision['value']['decision'] == 'ALLOW'
                          and decision['value']['proposed_destination'] == post['state'])
            if decision is None:
                self.issue('REPORT_RECORD_MISSING', [log_ref])
            request = self.unique('TransitionRequest', event['request_id'])
            edge = None
            if previous is None:
                valid &= post['state'] == workflow.get('initial_state')
                # TransitionRequest.expected_version >= 1 cannot represent initialization.
                self.check('initialization_request', False, [log_ref],
                           mandatory=False,
                           limitations=['The installed request schema has no version-zero initialization request.'])
            elif request is None:
                valid = False
                self.issue('REPORT_RECORD_MISSING', [log_ref])
            else:
                req = request['value']
                digest = content_identity(canonical_json({k: v for k, v in req.items()
                                                           if k != 'request_content_identity'}))
                if digest != req['request_content_identity'] or digest != event['request_content_identity']:
                    valid = False
                    self.record_problem(request, 'REPORT_IDENTITY_MISMATCH')
                valid &= (req['subject_kind'] == 'TASK' and req['subject_id'] == post['task_id']
                          and req['expected_state'] == state and req['expected_version'] == version
                          and req['configuration_id'] == previous['configuration_id'])
                edges = [e for e in workflow.get('transitions', []) + workflow.get('resolution_routes', [])
                         if e.get('id') == req['transition_id']]
                edge = edges[0] if len(edges) == 1 else None
                first_acceptance = (post['state'] == 'SPEC_READY'
                                    and previous['accepted_identities']['specification'] is None)
                reconciliation = bool(edge and (edge.get('trigger') in ('INVALIDATED', 'ADOPTED')
                                                 or state == 'RESUME_REVIEW'))
                if first_acceptance:
                    specs = [r for rows in self.data['record_index'].get('TaskSpec', {}).values() for r in rows
                             if r['schema_valid'] and r['value']['task_id'] == post['task_id']]
                    matches = [r for r in specs if all(r['value'][field + '_identity'] ==
                               post['accepted_identities'][field] for field in ('request', 'specification', 'design'))]
                    valid &= (len(matches) == 1 and req['accepted_identities'] == post['accepted_identities']
                              and post['accepted_identities']['request'] == previous['accepted_identities']['request'])
                    actual = {entry['identity'] for entry in self.data['source_manifest']}
                    actual.update(content_identity(canonical_json(value)) for value in self.entry_documents.values())
                    accepted_bytes = all(post['accepted_identities'][field] in actual
                                         for field in ('specification', 'design'))
                    self.check('accepted_specification_bytes', accepted_bytes,
                               [r['reference'] for r in matches],
                               limitations=[] if accepted_bytes else ['Accepted specification/design bytes are not captured.'])
                    if not accepted_bytes:
                        self.issue('REPORT_EVIDENCE_UNCHECKED', [log_ref])
                elif reconciliation:
                    valid &= bool(post.get('resolution_refs'))
                    self.check('configuration_reacceptance', False, [log_ref],
                               limitations=['Impact, acceptance and invalidation semantics require repository-specific review.'])
                else:
                    valid &= (req['accepted_identities'] == previous['accepted_identities']
                              and post['accepted_identities'] == previous['accepted_identities']
                              and post['configuration_id'] == previous['configuration_id']
                              and post['profile_id'] == previous['profile_id'])
                edge_ok = bool(edge and edge.get('from') == state and edge.get('to') == post['state']
                               and ('profiles' not in edge or post['profile_id'] in edge['profiles']))
                if not edge_ok:
                    valid = False
                    self.issue('REPORT_TRANSITION_INVALID', [request['reference'], log_ref])
                if edge and decision:
                    findings = decision['value']['rule_findings']
                    ids = [f['rule_id'] for f in findings]
                    valid &= len(ids) == len(set(ids)) and set(edge.get('rule_ids', [])).issubset(ids)
                    safe_stop = post['state'] in workflow.get('stop_states', [])
                    required = {'RULE-01', 'RULE-02', 'RULE-11'} if safe_stop else set(edge.get('rule_ids', []))
                    if safe_stop and state in ('BUILD_FAILED', 'TEST_FAILED'):
                        required.add('RULE-09')
                    valid &= required.issubset(ids)
                    valid &= all(f['result'] == 'PASS' for f in findings if f['rule_id'] in required)
                    if edge.get('evidence_required') and not (req['evidence_refs'] or req['review_refs']):
                        valid = False
                    self.check('declared_gate_findings', True, [decision['reference']])
                    # Rule findings are claims. Do not relabel procedural/custom semantics as checked.
                    self.check('transition_rule_semantics', False, [decision['reference']], mandatory=False,
                               limitations=['Recorded rule judgments are retained; arbitrary guards are not executed.'])
                    if any(rule not in {'RULE-%02d' % n for n in range(1, 18)} for rule in edge.get('rule_ids', [])):
                        self.issue('REPORT_RULE_UNCHECKED', [request['reference']], severity='WARNING')
                        self.check('custom_transition_rules', False, [request['reference']])
            for family, field in (('repair', 'repair_counters'), ('invocation', 'invocation_counters')):
                before = previous.get(field, {}) if previous else {}
                after = post.get(field, {})
                deltas = event.get('counter_deltas', {}).get(family, {})
                if not all(isinstance(x, dict) for x in (before, after, deltas)):
                    valid = False
                    continue
                for name in set(before) | set(after) | set(deltas):
                    if after.get(name, 0) - before.get(name, 0) != deltas.get(name, 0) or deltas.get(name, 0) < 0:
                        valid = False
                if family == 'repair' and previous:
                    increments = {k: v for k, v in deltas.items() if v}
                    origin = {'BUILD_FAILED': 'build', 'TEST_FAILED': 'test'}.get(state)
                    expected = {origin: 1} if post['state'] == 'REPAIRING' and state != 'REPAIRING' and origin else {}
                    valid &= increments == expected
            if previous and post['state'] in workflow.get('stop_states', []):
                origin = previous.get('stopped_from_state') if state in workflow.get('stop_states', []) else state
                if not post.get('stopped_from_state') or post.get('stopped_from_state') != origin:
                    self.issue('REPORT_STOP_ORIGIN_MISSING', [log_ref])
                    valid = False
                for field in ('configuration_id', 'accepted_identities', 'input_snapshot', 'selected_targets',
                              'repair_counters', 'invocation_counters', 'pending_invocation_refs'):
                    valid &= post.get(field) == previous.get(field)
            if post.get('configuration_id') != config.get('configuration_id'):
                self.issue('REPORT_IDENTITY_MISMATCH', [log_ref, self.run_ref('config-snapshot.yaml')])
                valid = False
            if not valid:
                broken = True
                history['invalid_suffix'].append({'position': position, 'event': event,
                                                  'diagnostic_codes': ['REPORT_HISTORY_INVALID']})
                continue
            row['committed'] = True
            row['event_ids'].append(event['request_id'])
            history['committed_prefix'].append({'position': position, 'event': event,
                                                'reference': row['reference'], 'event_id': event['request_id']})
            previous = post
            # Reachability starts only from a validated event and its selected request.
            queue = [event] + ([request['value']] if request else [])
            reached = set()
            while queue:
                current = queue.pop()
                for _, node in _walk(current):
                    ref = node.get('reference')
                    if not isinstance(ref, dict):
                        continue
                    if ref.get('kind') == 'LOCAL' and not all(k in ref for k in ('scope', 'path')):
                        continue
                    key = reference_key(ref)
                    if key in reached:
                        continue
                    reached.add(key)
                    value = self.data['documents'].get(key)
                    if isinstance(value, dict) and value.get('record_type') in _RECORD_TYPES:
                        queue.append(value)
                    if key not in history['authoritative_documents']:
                        history['authoritative_documents'].append(key)
            if request:
                reached.add(request['document'])
                history['authoritative_documents'].append(request['document'])
            for kind, index in self.data['record_index'].items():
                if kind in ('Event', 'EventLog'):
                    continue
                for entries in index.values():
                    for record in entries:
                        if record['document'] in reached:
                            record['committed'] = True
                            if event['request_id'] not in record['event_ids']:
                                record['event_ids'].append(event['request_id'])
        history['last_post_state'] = deepcopy(previous)
        history['complete'] = bool(events) and not broken
        if broken or not events:
            self.issue('REPORT_HISTORY_INVALID', [log_ref])
        snapshot_ref = self.run_ref('state.yaml')
        snapshot = self.data['documents'].get(reference_key(snapshot_ref))
        history['snapshot'] = snapshot
        history['snapshot_consistent'] = bool(previous and history['complete'] and snapshot == previous)
        if not history['snapshot_consistent']:
            self.issue('REPORT_SNAPSHOT_MISMATCH', [snapshot_ref, log_ref])
        history['authoritative_documents'] = sorted(set(history['authoritative_documents']))
        self.check('committed_history', True, [log_ref])
        self.check('saved_snapshot', True, [snapshot_ref])
        observed = sorted({event.get('next_state') for event in events if isinstance(event, dict)
                           and isinstance(event.get('next_state'), str)})
        self.data['phase_map']['unmapped_states'] = [s for s in observed
            if s not in self.data['phase_map']['state_roles']]
        if self.data['phase_map']['unmapped_states']:
            self.issue('REPORT_STATE_UNMAPPED', [log_ref])

    def invocation_revisions(self):
        """Select revisions from direct committed references, never discovery order."""
        index = self.data['record_index'].get('Invocation', {})
        by_document = {}
        for intent_id, revisions in index.items():
            invariants = set()
            for row in revisions:
                by_document[row['document']] = row
                if not row['schema_valid']:
                    continue
                value = row['value']
                invariant = {key: value[key] for key in ('intent_id', 'request_id', 'run_id', 'task_id',
                             'capability', 'expected_identities', 'inputs', 'deadline')}
                invariant['budgets'] = {key: value['counters'][key]
                                       for key in ('call_budget', 'time_budget_seconds')}
                invariants.add(canonical_json(invariant))
            if len(invariants) > 1:
                for row in revisions:
                    self.record_problem(row, 'REPORT_RECORD_COLLISION')
            self.check('invocation_invariants:' + intent_id, True,
                       [r['reference'] for r in revisions])

        # Each map is the authority applicable at that committed version. A direct
        # post-state pending reference selects the current revision. Otherwise a
        # direct post-state/event/request reference can update it; absence carries
        # previous authority forward. Ambiguity remains until a later explicit pin.
        current = {}
        for item in self.data['history']['committed_prefix']:
            event, event_id = item['event'], item['event_id']
            post = event['post_state']
            request = self.unique('TransitionRequest', event_id)
            direct = [post, event.get('evidence_refs', [])]
            if request:
                direct += [request['value'].get('evidence_refs', []), request['value'].get('review_refs', [])]

            def candidates(values):
                groups = {}
                for _, node in _walk(values):
                    ref = node.get('reference')
                    if not isinstance(ref, dict) or ref.get('kind') != 'LOCAL':
                        continue
                    row = by_document.get(reference_key(ref))
                    finding = self.data['evidence_checks'].get(reference_key(ref), {})
                    if row and row['committed']:
                        if not finding.get('valid'):
                            for code in finding.get('diagnostic_codes') or ['REPORT_EVIDENCE_UNCHECKED']:
                                self.record_problem(row, code)
                        groups.setdefault(row['value']['intent_id'], set()).add(row['document'])
                return groups

            pending, explicit = candidates(post.get('pending_invocation_refs', [])), candidates(direct)
            for intent_id in sorted(set(pending) | set(explicit)):
                documents = sorted(pending.get(intent_id, explicit.get(intent_id, set())))
                selected = documents[0] if len(documents) == 1 else None
                current[intent_id] = {
                    'status': 'SELECTED' if selected else 'AMBIGUOUS',
                    'document': selected, 'candidates': documents, 'selected_at_event_id': event_id,
                    'origin': 'POST_STATE_PENDING' if intent_id in pending else 'DIRECT_COMMITTED_REFERENCE'}
            self.data['history']['invocation_revisions'][event_id] = deepcopy(current)
            for intent_id, selection in current.items():
                refs = [by_document[key]['reference'] for key in selection['candidates']]
                if selection['document']:
                    by_document[selection['document']]['selected_event_ids'].append(event_id)
                else:
                    self.issue('REPORT_EVIDENCE_UNCHECKED', refs)
                    self.check('invocation_revision_authority:' + event_id + ':' + intent_id, False, refs,
                               limitations=['Committed references identify multiple immutable revisions without a unique current revision.'])

    def invocation_for_result(self, result):
        """Resolve revision at the first committed reference to this immutable result."""
        events = [item for item in self.data['history']['committed_prefix']
                  if item['event_id'] in result['event_ids']]
        result['invocation_revision'] = None
        if not events:
            return None
        event_id = events[0]['event_id']
        selections = self.data['history']['invocation_revisions'].get(event_id, {})
        index = self.data['record_index'].get('Invocation', {})
        intents = [identity for identity, rows in index.items() if identity in selections and
                   any(row['schema_valid'] and row['value']['run_id'] == result['value']['run_id']
                       for row in rows)]
        if len(intents) != 1:
            known = [row for rows in index.values() for row in rows if row['schema_valid'] and row['committed']
                     and row['value']['run_id'] == result['value']['run_id']]
            if not intents and known:
                result['invocation_revision'] = {
                    'status': 'UNRESOLVED', 'document': None, 'candidates': sorted(r['document'] for r in known),
                    'intent_id': None, 'outcome_event_id': event_id, 'selected_at_event_id': None, 'origin': None}
                self.record_problem(result, 'REPORT_EVIDENCE_UNCHECKED')
                self.check('invocation_revision_authority:' + event_id + ':' + result['value']['run_id'], False,
                           [r['reference'] for r in known],
                           limitations=['Invocation revisions are reachable but no direct committed current-revision selection exists.'])
                return None
            self.record_problem(result, 'REPORT_RECORD_COLLISION' if intents else 'REPORT_RECORD_MISSING')
            return None
        intent_id = intents[0]
        selection = selections[intent_id]
        result['invocation_revision'] = dict(selection, intent_id=intent_id, outcome_event_id=event_id)
        if not selection['document']:
            self.record_problem(result, 'REPORT_EVIDENCE_UNCHECKED')
            return None
        matches = [row for row in index[intent_id] if row['document'] == selection['document']]
        if len(matches) == 1 and matches[0]['schema_valid']:
            return matches[0]
        self.record_problem(result, 'REPORT_DOCUMENT_INVALID')
        return None

    def outcome_results(self):
        """Select current outcomes separately from retained record reachability.

        Only direct current request/event Result references and the request's
        directly selected due-state review basis establish new outcome authority.
        Retained post-state evidence is history, not a competing current result.
        """
        outcomes = {'PREFLIGHT_PASSED': ('preflight', 'PASS'), 'PREFLIGHT_FAILED': ('preflight', 'FAIL'),
                    'BUILD_PASSED': ('build', 'PASS'), 'BUILD_FAILED': ('build', 'FAIL'),
                    'TEST_PASSED': ('test', 'PASS'), 'TEST_FAILED': ('test', 'FAIL')}
        results = [r for rows in self.data['record_index'].get('Result', {}).values() for r in rows]
        reviews = [r for rows in self.data['record_index'].get('CriterionReview', {}).values() for r in rows]
        retained = {}
        for item in self.data['history']['committed_prefix']:
            event, event_id = item['event'], item['event_id']
            expectation = outcomes.get(event['next_state'])
            if not expectation:
                continue
            capability, status = expectation
            requests = self.data['record_index'].get('TransitionRequest', {}).get(event_id, [])
            request = requests[0] if len(requests) == 1 and requests[0]['schema_valid'] and requests[0]['committed'] else None
            explicit = [event.get('evidence_refs', [])]
            if request:
                explicit.append(request['value'].get('evidence_refs', []))
            direct = {reference_key(node['reference']) for _, node in _walk(explicit)
                      if isinstance(node.get('reference'), dict)}
            review_basis = set()
            if request:
                selected_reviews = {reference_key(node['reference'])
                                    for _, node in _walk(request['value'].get('review_refs', []))
                                    if isinstance(node.get('reference'), dict)}
                for review in reviews:
                    if (review['document'] in selected_reviews and review['schema_valid'] and review['committed']
                            and event_id in review['event_ids'] and review['value']['due_state'] == event['next_state']
                            and review['value']['revision'] == event['post_state']['input_snapshot']):
                        review_basis.update(reference_key(node['reference'])
                                            for _, node in _walk(review['value']['criteria'])
                                            if isinstance(node.get('reference'), dict))
            asserted = [r for r in results if r['committed'] and event_id in r['event_ids']
                        and r['document'] in direct | review_basis and r['value'].get('capability') == capability]
            candidates = [r for r in asserted
                          if r['value'].get('revision') == event['post_state']['input_snapshot']]
            documents = sorted({r['document'] for r in candidates})
            selection = dict(status='SELECTED' if len(documents) == 1 else 'AMBIGUOUS' if documents else 'UNRESOLVED',
                             document=documents[0] if len(documents) == 1 else None, candidates=documents,
                             selected_at_event_id=event_id, expected_capability=capability, expected_status=status,
                             origin='DIRECT_CURRENT_REFERENCE' if any(d in direct for d in documents)
                             else 'DIRECT_REQUEST_REVIEW_BASIS' if documents else None)
            # A same-state record or declared restore does not earn another result.
            # With no new explicit assertion, preserve its previously selected authority.
            key = (capability, event['next_state'], event['post_state']['input_snapshot'])
            if not asserted and event['previous_state'] in ('RESUME_REVIEW', event['next_state']) and key in retained:
                selection = deepcopy(retained[key])
                selection['origin'] = 'RETAINED_OUTCOME_AUTHORITY'
            else:
                retained[key] = deepcopy(selection)
            self.data['history']['outcome_results'][event_id] = selection
            selected_rows = [r for r in results if r['document'] in selection['candidates']]
            refs = [r['reference'] for r in selected_rows]
            resolved = selection['status'] == 'SELECTED' and len(selected_rows) == 1
            self.check('outcome_result_authority:' + event_id, resolved, refs,
                       limitations=[] if resolved else ['Current outcome authority is missing or explicitly ambiguous.'])
            event_rows = self.data['record_index']['Event'].get(event_id, [])
            if len(event_rows) != 1:
                continue
            if not selection['candidates']:
                self.record_problem(event_rows[0], 'REPORT_EXECUTION_REQUIRED')
            elif not resolved:
                self.record_problem(event_rows[0], 'REPORT_RECORD_COLLISION')
            elif selected_rows[0]['value'].get('status') != status:
                self.record_problem(event_rows[0], 'REPORT_TRANSITION_INVALID')
            elif not selected_rows[0]['schema_valid'] or not selected_rows[0]['valid']:
                self.record_problem(event_rows[0], 'REPORT_EVIDENCE_UNCHECKED')

    def joins(self):
        latest = self.data['history']['last_post_state'] or {}
        task_id = self.data['roots']['task_id']
        profile = self.data['documents'].get(self.data['phase_map']['profile'], {})
        adapters = {row['declared']['identity'] for row in self.data['roots']['definitions'].get('ADAPTER', [])
                    if row['identity_valid']}
        for finding in self.data['evidence_checks'].values():
            if finding['checked'] and not finding['expected_identities']:
                finding['valid'] = False
                finding['diagnostic_codes'].append('REPORT_EVIDENCE_UNCHECKED')
                self.issue('REPORT_EVIDENCE_UNCHECKED', [finding['reference']])
                self.check('evidence_identity:' + reference_key(finding['reference']), False,
                           [finding['reference']], limitations=['Bytes were captured but no immutable expected identity was recorded.'])
        # Selected-revision validity must be settled before any Result join,
        # regardless of record discovery order or recursive reference order.
        for revisions in self.data['record_index'].get('Invocation', {}).values():
            for row in revisions:
                if not row['schema_valid']:
                    continue
                expected, inputs = row['value']['expected_identities'], row['value']['inputs']
                if (expected['configuration_id'] != latest.get('configuration_id')
                        or expected['adapter_definition_id'] not in adapters
                        or expected['revision'] != inputs['source']):
                    self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                for _, node in _walk(row['value']):
                    ref = node.get('reference')
                    if isinstance(ref, dict):
                        finding = self.data['evidence_checks'].get(reference_key(ref))
                        if finding and not finding['valid']:
                            for code in finding['diagnostic_codes']:
                                self.record_problem(row, code)
        for kind, index in self.data['record_index'].items():
            for entries in index.values():
                for row in entries:
                    value = row['value']
                    if value.get('task_id', task_id) != task_id:
                        self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                    if not row['schema_valid']:
                        continue
                    if kind in ('Result', 'CriterionReview') and value['revision'] != latest.get('input_snapshot'):
                        # Preserve historical records, but identify that they cannot support the current claim.
                        self.record_problem(row, 'REPORT_EVIDENCE_STALE')
                    if kind == 'TaskSpec':
                        accepted = latest.get('accepted_identities', {})
                        if (any(value[field + '_identity'] != accepted.get(field)
                                for field in ('request', 'specification', 'design'))
                                or value['profile_id'] != latest.get('profile_id')
                                or _target_set(value['targets']) != _target_set(latest.get('selected_targets'))):
                            self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                        self.check('acceptance_authority', False, [row['reference']],
                                   mandatory=False,
                                   limitations=['Local review bytes do not establish independently identifiable user authority.'])
                    if kind == 'CriterionReview':
                        for verdict in value['criteria']:
                            self.data['coverage']['semantic_reviews'].append({
                                'criterion_id': verdict['criterion_id'], 'method': value['method'],
                                'actor': value['actor'], 'recorded_claim': verdict['result'],
                                'references': [row['reference']],
                                'limitations': ['The reviewer judgment is attributed, not independently re-performed.'],
                                'extensions': {'committed': row['committed'], 'record_valid': row['valid']}})
                    if kind != 'Result':
                        continue
                    if value['provenance'] == 'FIXTURE':
                        self.record_problem(row, 'REPORT_FIXTURE_EVIDENCE')
                    invocation = self.invocation_for_result(row)
                    if invocation is None:
                        continue
                    intent = invocation['value']
                    expected, inputs = intent['expected_identities'], intent['inputs']
                    if (not invocation['valid'] or not invocation['committed']
                            or value['capability'] != intent['capability']
                            or value['task_id'] != intent['task_id']
                            or value['adapter'] != expected['adapter']
                            or value['revision'] != expected['revision']
                            or value['revision'] != inputs['source']
                            or value['configuration_id'] != expected['configuration_id']
                            or value['adapter_definition_id'] != expected['adapter_definition_id']
                            or _target_set(value['targets']) != _target_set(inputs['targets'])
                            or _target_set(value['targets']) != _target_set(latest.get('selected_targets'))):
                        self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                    binding = profile.get('capabilities', {}).get(value['capability'], {})
                    selected = [p for p in profile.get('workflow_profiles', [])
                                if p['id'] == latest.get('profile_id')]
                    targets = selected[0]['required_targets'] if len(selected) == 1 else None
                    if not isinstance(targets, list):
                        self.check('required_target_set:' + row['document'], False, [row['reference']],
                                   limitations=['The pinned profile required target set is unresolved.'])
                        self.record_problem(row, 'REPORT_EVIDENCE_UNCHECKED')
                    elif _target_set(targets) != _target_set(value['targets']):
                        self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                    if value['adapter'] != binding.get('adapter'):
                        self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                    environment = binding.get('execution_environment', {})
                    if inputs.get('environment') != environment.get('id'):
                        self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                    if value['capability'] in ('preflight', 'build', 'test') and value['provenance'] != 'EXECUTION':
                        self.record_problem(row, 'REPORT_EVIDENCE_UNCHECKED')
                    if value.get('extensions', {}).get('target_results'):
                        self.check('child_result_reduction:' + row['document'], False, [row['reference']],
                                   limitations=['Child terminal/running status reduction requires invocation reconciliation.'])
                    normalization = binding.get('normalization', {})
                    if not isinstance(normalization, dict) or 'artifact_lineage_required' not in normalization:
                        self.check('binding_lineage:' + row['document'], False, [row['reference']],
                                   limitations=['The captured capability has no concrete normalization contract.'])
                        self.record_problem(row, 'REPORT_EVIDENCE_UNCHECKED')
                        continue
                    selectors = value.get('extensions', {})
                    for field in ('artifact_consumed_downstream', 'test_source_required', 'artifact_lineage_required'):
                        if field in selectors and selectors[field] != normalization[field]:
                            self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                    artifact, test_source = value.get('artifact'), value.get('test_source')
                    artifact_required = normalization['artifact_lineage_required'] or (
                        value['capability'] == 'build' and value['status'] == 'PASS'
                        and normalization['artifact_consumed_downstream'])
                    if artifact_required and not artifact:
                        self.record_problem(row, 'REPORT_EVIDENCE_MISSING')
                    if (normalization['test_source_required'] or normalization['artifact_lineage_required']) and not test_source:
                        self.record_problem(row, 'REPORT_EVIDENCE_MISSING')
                    for field in ('artifact', 'test_source'):
                        if inputs.get(field) and value.get(field) != inputs[field]:
                            self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                    if normalization['artifact_lineage_required'] and artifact and test_source:
                        if test_source.get('artifact_identity') != artifact.get('identity'):
                            self.record_problem(row, 'REPORT_IDENTITY_MISMATCH')
                    self.check('result_identity:' + row['document'], True, [row['reference'], invocation['reference']])
        # Ensure every referenced outcome inherits missing/fixture/hash findings recursively.
        for index in self.data['record_index'].values():
            for entries in index.values():
                for row in entries:
                    for _, node in _walk(row['value']):
                        ref = node.get('reference')
                        if isinstance(ref, dict) and (ref.get('kind') != 'LOCAL' or all(k in ref for k in ('scope', 'path'))):
                            finding = self.data['evidence_checks'].get(reference_key(ref))
                            if finding and not finding['valid']:
                                for code in finding['diagnostic_codes']:
                                    self.record_problem(row, code)
                    extensions = row['value'].get('extensions', {})
                    if isinstance(extensions, dict) and any('skip' in key.lower() for key in extensions):
                        self.record_problem(row, 'REPORT_SKIP_UNSUPPORTED')
                        self.issue('REPORT_SKIP_AUTHORITY_UNVERIFIED', [row['reference']])
        self.outcome_results()
        # The installed protocol identifies input snapshots but defines no machine-readable
        # working-tree inventory/manifest format. Never infer clean/current source from Git or a digest.
        if latest:
            self.check('source_content_inventory', False, [self.run_ref('events.yaml')],
                       limitations=['Opaque input_snapshot identities lack an installed file-inventory contract; '
                                    'dirty/untracked source coverage cannot be mechanically established.'])
            self.issue('REPORT_EVIDENCE_UNCHECKED', [self.run_ref('events.yaml')], severity='WARNING')
        self.check('evidence_bytes', True, [c['reference'] for c in self.data['evidence_checks'].values()])


def capture_task(repo_root: Path, harness_root: Path, task_id: str) -> dict:
    """Capture pinned task records without mutation or external code execution.

    Missing/invalid records are diagnostics and nullable document/lookup results;
    unsafe roots/paths raise DocumentError (the CLI must produce REPORT_UNAVAILABLE).
    The nine keys are roots, documents, record_index, source_manifest, phase_map,
    history, evidence_checks, diagnostics, coverage. Values contain no live readers.
    ``roots.inspected_inputs`` and ``roots.inventory`` support check_unchanged.
    Only history.committed_prefix is authoritative; discovered records retain an
    explicit committed flag and all colliding entries. No report output is read.
    """
    capture = _Capture(repo_root, harness_root, task_id)
    capture.definitions()
    capture.discover()
    capture.phase_mapping()
    capture.committed_history()
    capture.invocation_revisions()
    capture.joins()
    capture.data['source_manifest'].sort(key=lambda row: (row['scope'], row['path']))
    for row in check_unchanged(capture.data):
        if row not in capture.data['diagnostics']:
            capture.data['diagnostics'].append(row)
    return capture.data


def register_publication_temporary(capture: dict, path: Path) -> None:
    """Register one publisher-owned, exclusively created file beside the outputs.

    The caller must have just created this file with exclusive creation, owns its
    descriptor and cleanup, and must remove all registered files before recapture.
    This function does not create/read/write/delete content or establish ownership
    on the caller's behalf. It rejects captured inputs, existing inventory entries,
    outputs, symlinks, other directories and duplicate registrations. Its exact
    file identity is retained so replacement cannot hide an unrelated new input.
    """
    roots = capture['roots']
    run = Path(roots['run_root'])
    candidate = Path(path)
    if not candidate.is_absolute():
        candidate = run / _relative(candidate.as_posix())
    if candidate.parent != run or candidate.name in _OUTPUTS or candidate.is_symlink():
        raise DocumentError('PATH_SCOPE', candidate, 'Temporary must be a new regular file beside report outputs', 2)
    safe = scoped_path(candidate, run)
    name = safe.name
    registered = roots.setdefault('publication_temporaries', {})
    if name in roots['inventory'] or name in registered:
        raise DocumentError('PATH_SCOPE', safe, 'Existing input or registration cannot become a temporary', 2)
    scopes = {'REPOSITORY': Path(roots['repo_root']), 'HARNESS': Path(roots['harness_root'])}
    for item in roots['inspected_inputs'].values():
        ref = item['reference']
        inspected = scopes[ref['scope']] / ref['path']
        if inspected == safe or inspected.resolve() == safe.resolve():
            raise DocumentError('PATH_SCOPE', safe, 'A captured source lookup cannot become a temporary', 2)
    info = safe.stat()
    if info.st_nlink != 1:
        raise DocumentError('PATH_SCOPE', safe, 'Temporary must not alias another file', 2)
    registered[name] = {'device': info.st_dev, 'inode': info.st_ino}


def check_unchanged(capture: dict) -> list[dict]:
    """Recheck read bytes, failed lookups and the full run inventory before publishing.

    Does not mutate capture. Missing inputs becoming available also count as a change.
    Failure to repeat a safe inspection is a change, never permission to publish stale data.
    """
    roots = capture['roots']
    paths = {'REPOSITORY': Path(roots['repo_root']), 'HARNESS': Path(roots['harness_root'])}
    changed = []
    for key, item in sorted(roots['inspected_inputs'].items()):
        ref = item['reference']
        try:
            raw = read_bytes(paths[ref['scope']] / _relative(ref['path']), paths[ref['scope']])
            identity, error = content_identity(raw), None
        except DocumentError as exc:
            identity, error = None, exc.code
        if identity != item['identity'] or error != item['error']:
            changed.append(diagnostic('REPORT_SOURCE_CHANGED', [ref]))
    try:
        run = Path(roots['run_root'])
        inventory = _inventory(run)
        owned = set()
        for name, expected in roots.get('publication_temporaries', {}).items():
            candidate = run / _relative(name)
            if candidate.parent != run or name in roots['inventory'] or name in _OUTPUTS:
                continue
            # A deleted temporary is harmless; a replacement must remain visible.
            if name not in inventory:
                continue
            safe = scoped_path(candidate, run)
            info = safe.stat()
            if not safe.is_symlink() and info.st_nlink == 1 and (info.st_dev, info.st_ino) == (
                    expected['device'], expected['inode']):
                owned.add(name)
        same_inventory = [path for path in inventory if path not in owned] == roots['inventory']
    except (DocumentError, OSError, RuntimeError):
        same_inventory = False
    if not same_inventory:
        changed.append(diagnostic('REPORT_SOURCE_CHANGED', [_reference('HARNESS', roots['run_path'])]))
    return changed
