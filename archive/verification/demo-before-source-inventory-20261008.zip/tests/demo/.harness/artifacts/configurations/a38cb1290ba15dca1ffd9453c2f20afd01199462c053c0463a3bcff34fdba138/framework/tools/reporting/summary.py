"""Pure TaskReport derivation from capture_task's immutable captured values.

No source reads, commands, repairs, clocks or authority inferred from discovery.
The renderer consumes extensions.reporting.summary and evidence_links. Schema
validation resolves only the captured schema dictionary, never the filesystem.
report.extensions.reporting holds summary, state_claims, recorded_complete_claimed,
final_specification_verified, accepted_task_matrix_supported, evidence_links,
superseded_record_documents, historical_diagnostic_indices, stage_policy and configuration_revision.
Phase and attempt counts/authority, and criterion review selections/claims, live
under their respective extensions.reporting objects; no root summary is admitted.
"""
from copy import deepcopy
import hashlib
import re
from urllib.parse import quote

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from referencing import Registry, Resource
from referencing.exceptions import Unresolvable
from referencing.jsonschema import DRAFT202012

from harness_io.schemas import FORMATS
from .evidence import canonical_json, diagnostic, reference_key

GENERATOR_VERSION = '1.1.0'
REPORT_VERSION = '1.0.0'
_OUTCOMES = {'PREFLIGHT_PASSED': ('preflight', 'PASS'),
             'PREFLIGHT_FAILED': ('preflight', 'FAIL'),
             'BUILD_PASSED': ('build', 'PASS'), 'BUILD_FAILED': ('build', 'FAIL'),
             'TEST_PASSED': ('test', 'PASS'), 'TEST_FAILED': ('test', 'FAIL')}
_STOPS = {'BLOCKED', 'HUMAN_REQUIRED'}
_AUTHORITY_CODES = {'REPORT_PHASE_MAP_INVALID', 'REPORT_LEGACY_MAP_UNSUPPORTED',
                    'REPORT_HISTORY_INVALID', 'REPORT_RECORD_COLLISION'}
_LIMITS = [
    'The report checks captured records, not tool quality or authorship.',
    'Semantic judgments remain attributed to their recorded reviewer.',
    'Source-content inventory has no installed common format; opaque source identities '
    'do not establish dirty or untracked content completeness.',
    'User-skip support is not installed; assertions of approval do not authorize skipping.',
    'Historical outcomes from earlier source revisions remain unverified when the '
    'capture only establishes freshness against the latest source revision.',
]


class ReportDerivationError(ValueError):
    """Captured schemas cannot validate a safe TaskReport (CLI exit 2)."""


def _objects(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from _objects(child)
    elif isinstance(value, list):
        for child in value:
            yield from _objects(child)


def _references(value):
    return _unique([node['reference'] for node in _objects(value)
                    if _reference_valid(node.get('reference'))])


def _reference_valid(ref):
    """Keep malformed source reference objects out of typed report link arrays.

    Their owning record and fixed capture diagnostic remain visible; filtering
    never makes an invalid record eligible for support.
    """
    if not isinstance(ref, dict):
        return False
    if ref.get('kind') == 'LOCAL' and set(ref) in ({'kind', 'scope', 'path'}, {'kind', 'scope', 'path', 'entry_id'}):
        path = ref.get('path')
        return bool(('entry_id' not in ref or (isinstance(ref['entry_id'], str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}', ref['entry_id']) and ref.get('path', '').endswith('/history.jsonl')))
                    and ref.get('scope') in ('REPOSITORY', 'HARNESS') and isinstance(path, str)
                    and path and not path.startswith('/') and '\\' not in path and '\x00' not in path
                    and not re.match(r'^[A-Za-z]:', path) and not any(p in ('.', '..') for p in path.split('/')))
    if ref.get('kind') == 'EXTERNAL' and set(ref) == {'kind', 'uri', 'accessibility'}:
        address = ref.get('uri')
        return bool(isinstance(address, str) and re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:', address)
                    and FORMATS.conforms(address, 'uri')
                    and ref.get('accessibility') in ('AVAILABLE', 'UNAVAILABLE', 'NOT_ASSESSED'))
    return False


def _unique(values):
    result, seen = [], set()
    for value in values:
        key = canonical_json(value)
        if key not in seen:
            seen.add(key)
            result.append(deepcopy(value))
    return result


def _counts(rows):
    required = [row for row in rows if row['required']]
    return dict(total_required=len(required),
                satisfied_required=sum(r['result'] in ('SATISFIED', 'NOT_APPLICABLE') for r in required),
                failed_required=sum(r['result'] == 'FAILED' for r in required),
                unresolved_required=sum(r['result'] == 'UNRESOLVED' for r in required), criteria=rows)


def _validate_report(report, capture):
    """Validate using an explicitly closed in-memory schema registry."""
    def uri(ref):
        return 'https://captured.invalid/' + ref['scope'] + '/' + quote(ref['path'], safe='/')
    def unavailable(address):
        raise Unresolvable(ref=address)
    resources = []
    try:
        for key, ref in capture['roots']['schema_sources'].items():
            schema = capture['documents'][key]
            try:
                Draft202012Validator.check_schema(schema)
            except SchemaError:
                # Invalid unrelated pinned authority schemas remain diagnosed.
                # Only an unavailable schema required by TaskReport blocks output.
                continue
            resources.append((uri(ref), Resource.from_contents(schema, default_specification=DRAFT202012)))
        registry = Registry(retrieve=unavailable).with_resources(resources)
        ref = capture['roots']['report_schema']
        validator = Draft202012Validator({'$ref': uri(ref)}, registry=registry, format_checker=FORMATS)
        if any(validator.iter_errors(report)):
            raise ReportDerivationError('REPORT_UNAVAILABLE: derived TaskReport violates its captured schema.')
    except ReportDerivationError:
        raise
    except Exception as exc:
        # Schema-library errors (including wrapped reference resolution errors)
        # are operational unavailability, never a fabricated valid report.
        raise ReportDerivationError('REPORT_UNAVAILABLE: captured report schemas cannot validate the report.') from exc


class _Derivation:
    def __init__(self, capture):
        self.capture = capture
        self.history = capture['history']
        self.last = self.history.get('last_post_state') or {}
        self.mapping = capture['phase_map']
        self.stage_policy = self.mapping.get('stage_policy', {})
        self.map_value = self.mapping.get('value')
        self.map_value = self.map_value if isinstance(self.map_value, dict) else {}
        catalogue = self.map_value.get('stage_criteria', [])
        self.catalogue = [c for c in catalogue if isinstance(c, dict)
                          and isinstance(c.get('id'), str) and isinstance(c.get('due_state'), str)
                          and isinstance(c.get('required'), bool) and isinstance(c.get('allowed_methods'), list)] if isinstance(catalogue, list) else []
        self.roles = self.mapping.get('state_roles', {})
        self.prefix = self.history.get('committed_prefix', [])
        self.event_order = {item['event_id']: i for i, item in enumerate(self.prefix)}
        self.records = {kind: sorted([row for rows in index.values() for row in rows],
                                    key=lambda row: (row['document'], row['pointer']))
                        for kind, index in capture['record_index'].items()}
        self.by_document = {}
        for kind, rows in self.records.items():
            for row in rows:
                self.by_document.setdefault(row['document'], []).append(row)
        self.diagnostics = deepcopy(capture['diagnostics'])
        for item in self.diagnostics:
            item['references'] = _unique(item['references'])
        # A list is deliberate: repeated check IDs can have different obligations.
        self.coverage = deepcopy(capture['coverage'])
        for group in ('checks', 'semantic_reviews', 'platforms'):
            for row in self.coverage[group]:
                row['references'] = _unique(row['references'])
        for review in self.coverage['semantic_reviews']:
            records = [r for ref in review['references'] for r in self.by_document.get(reference_key(ref), [])
                       if r['value'].get('record_type') == 'CriterionReview']
            if records:
                review.setdefault('extensions', {})['record_valid'] = all(r['schema_valid'] and r['valid'] for r in records)
        self.links = []
        self.superseded_documents = set()
        self.criterion_cache = {}
        self.spec = None
        self.acceptance_valid = False
        self.attempts = []
        modern = capture['roots']['run_path'].startswith('artifacts/development/')
        self.log_ref = dict(kind='LOCAL', scope='HARNESS', path=capture['roots']['run_path'] + ('/history.jsonl' if modern else '/events.yaml'))
        self.snapshot_ref = dict(kind='LOCAL', scope='HARNESS', path=capture['roots']['run_path'] + ('/state.json' if modern else '/state.yaml'))

    def issue(self, code, refs=(), *, phase_id=None, criterion_id=None, severity='ERROR'):
        item = diagnostic(code, _unique(refs), phase_id=phase_id, criterion_id=criterion_id, severity=severity)
        if item not in self.diagnostics:
            self.diagnostics.append(item)
        return code

    def check(self, check_id, supported, refs=(), *, mandatory=True, limitations=()):
        self.coverage['checks'].append(dict(check_id=check_id, status='CHECKED' if supported else 'UNCHECKED',
                                           mandatory=mandatory, references=_unique(refs), limitations=list(limitations)))

    def entries(self, kind, event_id=None):
        return [row for row in self.records.get(kind, [])
                if event_id is None or event_id in row.get('event_ids', [])]

    def evidence_supported(self, ref):
        finding = self.capture['evidence_checks'].get(reference_key(ref))
        return bool(finding and finding.get('checked') and finding.get('valid')
                    and finding.get('expected_identities') and 'FIXTURE' not in finding.get('provenances', []))

    def record_supported(self, row, seen=None):
        if not (row.get('schema_valid') and row.get('valid') and row.get('committed')):
            return False
        seen = set() if seen is None else seen
        token = (row['document'], row['pointer'])
        if token in seen:
            return True
        seen = seen | {token}
        for ref in _references(row['value']):
            if not self.evidence_supported(ref):
                return False
            for dependency in self.by_document.get(reference_key(ref), []):
                # A canonical EventLog's nested events are checked separately.
                if dependency['value'].get('record_type') not in ('Event', 'EventLog'):
                    if dependency['document'] in self.superseded_documents:
                        # Explicit fresh authority replaces this stale historical
                        # dependency, not its archived record or its validity.
                        continue
                    if not self.record_supported(dependency, seen):
                        return False
        return True

    def result_supported(self, row):
        selection = row.get('invocation_revision') or {}
        event_id, intent_id = selection.get('outcome_event_id'), selection.get('intent_id')
        authority = self.history.get('invocation_revisions', {}).get(event_id, {}).get(intent_id, {})
        outcome = self.event_entry(event_id)
        if (not self.record_supported(row) or selection.get('status') != 'SELECTED'
                or event_id not in self.event_order or event_id not in row.get('event_ids', [])
                or not outcome or not outcome.get('schema_valid') or not outcome.get('valid') or not outcome.get('committed')
                or authority.get('status') != 'SELECTED' or authority.get('document') != selection.get('document')
                or authority.get('selected_at_event_id') != selection.get('selected_at_event_id')
                or authority.get('origin') != selection.get('origin')):
            return False
        revisions = [r for r in self.entries('Invocation') if r['document'] == selection['document']]
        return bool(len(revisions) == 1 and self.record_supported(revisions[0])
                    and event_id in revisions[0].get('selected_event_ids', [])
                    and revisions[0]['value'].get('intent_id') == intent_id
                    and revisions[0]['value'].get('run_id') == row['value'].get('run_id'))

    def event_entry(self, event_id):
        rows = [row for row in self.entries('Event') if row['value'].get('request_id') == event_id]
        return rows[0] if len(rows) == 1 else None

    def event_supported(self, item):
        row = self.event_entry(item['event_id'])
        return bool(row and self.mapping.get('valid') and self.record_supported(row))

    def select_specification(self):
        accepted = self.last.get('accepted_identities', {})
        candidates = [row for row in self.entries('TaskSpec') if row.get('schema_valid')
                      and all(row['value'].get(name + '_identity') == accepted.get(name)
                              for name in ('request', 'specification', 'design'))]
        if len(candidates) == 1:
            self.spec = candidates[0]
            ids = [c['id'] for c in self.spec['value']['criteria']]
            states = set(self.roles)
            self.acceptance_valid = (self.record_supported(self.spec) and bool(ids)
                                     and len(ids) == len(set(ids))
                                     and all(c['due_state'] in states for c in self.spec['value']['criteria']))
            for criterion in self.spec['value']['criteria']:
                stage = [c for c in self.catalogue if c['id'] == criterion['id']]
                if stage:
                    self.acceptance_valid &= (len(stage) == 1
                        and all(criterion[field] == stage[0][field] for field in ('due_state', 'required'))
                        and set(criterion['allowed_methods']) == set(stage[0]['allowed_methods']))
        if not self.acceptance_valid and (candidates or accepted.get('specification')
                or any(item['event'].get('next_state') == 'SPEC_READY' for item in self.prefix)
                or self.complete_claimed()):
            self.issue('REPORT_ACCEPTANCE_UNRESOLVED', [r['reference'] for r in candidates])
        self.check('task_acceptance_matrix', True, [r['reference'] for r in candidates])

    def selected_reviews(self, definition, *, event_id=None, task=False):
        """Complete post-state references select current verdict documents per criterion.

        A later explicit matching selection supersedes earlier review claims. No
        timestamp, filename, discovery order or empty assertion chooses a winner.
        """
        identity = definition['id']
        candidates, historical = [], []
        for row in self.entries('CriterionReview'):
            value = row['value']
            if (row.get('committed') and row.get('schema_valid')
                    and (value.get('due_state') == definition['due_state']
                         or task and value.get('due_state') == 'SPEC_VERIFIED')
                    and any(v.get('criterion_id') == identity for v in value.get('criteria', []))):
                historical.append(row)
                if value.get('revision') != self.last.get('input_snapshot'):
                    continue
                if event_id is None or any(self.event_order.get(e, len(self.prefix)) <= self.event_order[event_id]
                                           for e in row.get('event_ids', [])):
                    candidates.append(row)
        selected, selected_at, selection_supported = None, None, False
        for item in self.prefix:
            if event_id is not None and self.event_order[item['event_id']] > self.event_order[event_id]:
                break
            refs = _references(item['event'].get('post_state', {}).get('criterion_verdict_refs', []))
            keys = {reference_key(ref) for ref in refs}
            current = [row for row in candidates if row['document'] in keys
                       and item['event_id'] in row.get('event_ids', [])]
            if current:
                selected, selected_at = current, item['event_id']
                row = self.event_entry(selected_at)
                selection_supported = bool(row and row.get('valid') and row.get('schema_valid')
                                           and all(self.evidence_supported(ref) for ref in refs
                                                   if reference_key(ref) in {r['document'] for r in current}))
        return (selected if selected is not None else candidates), historical, selected_at, selection_supported

    def criterion(self, definition, *, event_id=None, task=False):
        cache_key = (canonical_json(definition), event_id, task)
        if cache_key in self.criterion_cache:
            return deepcopy(self.criterion_cache[cache_key])
        identity, due = definition['id'], definition['due_state']
        selected, historical, selected_at, selection_supported = self.selected_reviews(definition, event_id=event_id, task=task)
        verdicts = [(row, v) for row in selected for v in row['value']['criteria'] if v['criterion_id'] == identity]
        claims = _unique([v['result'] for _, v in verdicts])
        refs = _unique([r['reference'] for r, _ in verdicts] + [ref for _, v in verdicts for ref in _references(v)])
        codes = []
        result = 'UNRESOLVED'
        claim = claims[0] if len(claims) == 1 else 'CONFLICTING_VERDICTS' if claims else None
        execution_required = definition.get('execution_required', 'AUTOMATED' in definition['allowed_methods'])
        reviews_supported = bool(verdicts) and all(self.record_supported(row) and not v['unresolved_findings']
                and bool(v['evidence_refs']) and all(self.evidence_supported(ref) for ref in _references(v))
                and row['value']['method'] in definition['allowed_methods'] for row, v in verdicts)
        if selected_at is not None:
            reviews_supported &= selection_supported
        elif verdicts:
            # A committed record can support an unambiguous claim without choosing
            # a newer review; conflicts below still require explicit selection.
            reviews_supported &= len(claims) == 1
        if len(claims) > 1 or any(len([v for v in r['value']['criteria'] if v['criterion_id'] == identity]) > 1 for r in selected):
            codes.append(self.issue('REPORT_CRITERION_CONFLICT', refs, criterion_id=identity))
        elif claim == 'NOT_APPLICABLE':
            # The installed source contracts do not type criterion-scoped policy /
            # replacement authority. Do not interpret arbitrary extension prose.
            codes.append(self.issue('REPORT_NOT_APPLICABLE_UNSUPPORTED', refs, criterion_id=identity))
            self.check('criterion_applicability:' + identity, False, refs,
                       limitations=['Criterion-scoped authority and replacement semantics have no checked installed format.'])
        elif claim and any(r['value']['method'] not in definition['allowed_methods'] for r, _ in verdicts):
            codes.append(self.issue('REPORT_METHOD_UNSUPPORTED', refs, criterion_id=identity))
        elif reviews_supported and claim == 'FAIL':
            result = 'FAILED'
        elif reviews_supported and claim == 'PASS':
            execution = []
            if execution_required:
                supporting_keys = {reference_key(ref) for _, v in verdicts for ref in _references(v)}
                execution = [r for r in self.entries('Result') if (r['document'] in supporting_keys
                             or any(reference_key(ref) in supporting_keys for ref in _references(r['value'].get('evidence', {}))))
                             and r['value'].get('revision') == self.last.get('input_snapshot')
                             and r['value'].get('status') == 'PASS' and r['value'].get('provenance') == 'EXECUTION'
                             and (event_id is None or self.event_order.get((r.get('invocation_revision') or {}).get('outcome_event_id'), len(self.prefix))
                                  <= self.event_order[event_id])
                             and self.result_supported(r)]
                expected = _OUTCOMES.get(due, (None, None))[0]
                if expected:
                    execution = [r for r in execution if r['value'].get('capability') == expected]
                if not execution:
                    codes.append(self.issue('REPORT_EXECUTION_REQUIRED', refs, criterion_id=identity))
            if not execution_required or execution:
                result = 'SATISFIED'
        elif definition.get('independent_review_required', True) and not verdicts and event_id is not None:
            codes.append(self.issue('REPORT_REVIEW_REQUIRED', refs, criterion_id=identity))
        if not self.criterion_policy_supported(identity, task=task):
            # A review can be attributable while its pinned policy remains
            # unsupported. Preserve its claim, never infer whole-policy coverage.
            result = 'UNRESOLVED'
            refs = _unique(refs + self.stage_policy.get('references', []))
            codes.append(self.issue('REPORT_RULE_UNCHECKED', refs, criterion_id=identity))
        due_recorded = any(item['event'].get('next_state') == due for item in self.prefix)
        if definition['required'] and result == 'UNRESOLVED' and (claim is not None or due_recorded or self.complete_claimed()):
            codes.append(self.issue('REPORT_CRITERION_UNRESOLVED', refs, criterion_id=identity))
        historical_claims = [dict(reference=r['reference'], revision=r['value']['revision'],
                                  method=r['value']['method'], actor=r['value']['actor'], recorded_claim=v['result'],
                                  selected=r in selected, record_valid=bool(r['valid']),
                                  evidence_refs=_references(v))
                             for r in historical for v in r['value']['criteria'] if v['criterion_id'] == identity]
        row = dict(criterion_id=identity, required=definition['required'], result=result, recorded_claim=claim,
                   evidence_refs=refs, diagnostic_refs=_unique(codes),
                   extensions={'reporting': {'due_state': due, 'revision': self.last.get('input_snapshot'),
                               'selection_event_id': selected_at, 'verdicts': historical_claims}})
        self.criterion_cache[cache_key] = row
        return deepcopy(row)

    def criterion_policy_supported(self, identity, *, task=False):
        return bool(self.stage_policy.get('supported') and
                    (task or identity not in self.stage_policy.get('unsupported_criterion_ids', [])))

    def complete_claimed(self):
        return any(claim['state'] == 'COMPLETE' for claim in self.state_claims())

    def mark_superseded_stale_records(self):
        """Recognize only explicit fresh replacements of otherwise stale records.

        Identity mismatches, collisions, unchecked evidence and invalid history
        never become harmless merely because a later record exists.
        """
        replacements = {}
        definitions = [(c, False) for c in self.catalogue]
        if self.spec:
            definitions += [(c, True) for c in self.spec['value']['criteria']
                            if c['id'] not in {d['id'] for d in self.catalogue}]
        for definition, task in definitions:
            if not self.criterion_policy_supported(definition['id'], task=task):
                continue
            selected, _, selected_at, authority_supported = self.selected_reviews(definition, task=task)
            if selected_at and authority_supported and selected and all(self.record_supported(r)
                    and r['value']['method'] in definition['allowed_methods']
                    and len([v for v in r['value']['criteria'] if v['criterion_id'] == definition['id']]) == 1
                    for r in selected):
                claims = [v for r in selected for v in r['value']['criteria'] if v['criterion_id'] == definition['id']]
                if claims and len({v['result'] for v in claims}) == 1 and all(
                        v['result'] in ('PASS', 'FAIL') and not v['unresolved_findings'] and v['evidence_refs'] for v in claims):
                    replacements[definition['id']] = self.event_order[selected_at]
        fresh_results = [r for r in self.entries('Result') if self.result_supported(r)]
        for kind in ('Result', 'CriterionReview'):
            for row in self.entries(kind):
                if (not row.get('schema_valid') or not row.get('committed')
                        or set(row.get('diagnostic_codes', [])) != {'REPORT_EVIDENCE_STALE'}):
                    continue
                first = min((self.event_order[e] for e in row.get('event_ids', []) if e in self.event_order), default=len(self.prefix))
                if kind == 'Result':
                    replaced = any(r['value']['capability'] == row['value']['capability']
                                   and self.event_order[(r.get('invocation_revision') or {})['outcome_event_id']] > first
                                   for r in fresh_results)
                else:
                    replaced = bool(row['value']['criteria']) and all(
                        replacements.get(v['criterion_id'], -1) > first for v in row['value']['criteria'])
                if replaced:
                    self.superseded_documents.add(row['document'])

    def historical_diagnostic_indices(self):
        return [i for i, issue in enumerate(self.diagnostics)
                if issue['code'] == 'REPORT_EVIDENCE_STALE' and issue['references']
                and all(reference_key(ref) in self.superseded_documents for ref in issue['references'])]

    def state_claims(self):
        claims = []
        snapshot = self.history.get('snapshot')
        if isinstance(snapshot, dict) and isinstance(snapshot.get('state'), str) and snapshot['state']:
            claims.append(dict(origin='SAVED_STATE', state=snapshot['state'], reference=self.snapshot_ref,
                               snapshot_consistent=bool(self.history.get('snapshot_consistent'))))
        for i, event in enumerate(self.history.get('events', [])):
            if isinstance(event, dict):
                state = event.get('next_state')
                if isinstance(state, str) and state:
                    row = self.event_entry(event.get('request_id'))
                    claims.append(dict(origin='EVENT', state=state, reference=self.log_ref,
                                       event_id=event.get('request_id'), position=i,
                                       structurally_committed=i < len(self.prefix),
                                       record_valid=bool(row and row.get('schema_valid') and row.get('valid'))))
                post = event.get('post_state')
                if isinstance(post, dict) and isinstance(post.get('state'), str) and post['state'] and post['state'] != state:
                    claims.append(dict(origin='EVENT_POST_STATE', state=post['state'], reference=self.log_ref,
                                       event_id=event.get('request_id'), position=i,
                                       structurally_committed=False, record_valid=False))
        return claims

    def phase_for_state(self, state):
        if not isinstance(state, str):
            return None
        role = self.roles.get(state)
        return role.get('phase_id') if role else None

    def attempt(self, item, *, committed):
        event = item['event']
        event_id = item.get('event_id', event.get('request_id'))
        post = event.get('post_state')
        post = post if isinstance(post, dict) else {}
        state = event.get('next_state')
        if not isinstance(state, str) or not state:
            return None
        role = self.roles.get(state, {})
        historical_revision = bool(committed and post.get('input_snapshot') != self.last.get('input_snapshot'))
        phase_id = role.get('phase_id')
        if state in _STOPS:
            phase_id = self.phase_for_state(post.get('stopped_from_state'))
        if role.get('role') == 'control' and state not in _STOPS:
            return None
        claim = state
        skip = state in ('USER_SKIPPED', 'SKIPPED') or any('skip' in key.lower()
                for node in _objects([post.get('extensions', {}), event.get('extensions', {})]) for key in node)
        status = {'success': 'PASS', 'failure': 'FAIL', 'active': 'IN_PROGRESS'}.get(role.get('role'), 'UNVERIFIED')
        if state in _STOPS:
            status = 'BLOCKED'
        refs = _references(event)
        codes = []
        supported = committed and self.event_supported(item)
        event_row = self.event_entry(event_id)
        if event_row:
            codes += event_row.get('diagnostic_codes', [])
        if historical_revision:
            supported = False
            codes += [code for kind in ('Result', 'CriterionReview') for r in self.entries(kind, event_id)
                      for code in r.get('diagnostic_codes', [])]
        if skip:
            claim = 'USER_SKIPPED'
            codes += [self.issue('REPORT_SKIP_UNSUPPORTED', refs, phase_id=phase_id),
                      self.issue('REPORT_SKIP_AUTHORITY_UNVERIFIED', refs, phase_id=phase_id)]
            if state in ('SPEC_READY', 'SPEC_VERIFIED'):
                codes.append(self.issue('REPORT_MANDATORY_PHASE_SKIPPED', refs, phase_id=phase_id))
            supported = False
        expectation = _OUTCOMES.get(state)
        results = []
        if expectation:
            capability, expected_status = expectation
            selection = self.history.get('outcome_results', {}).get(event_id, {})
            results = [r for r in self.entries('Result') if r['document'] in selection.get('candidates', [])]
            supported &= (selection.get('status') == 'SELECTED' and len(results) == 1
                          and results[0]['document'] == selection.get('document')
                          and results[0]['value'].get('capability') == capability
                          and results[0]['value'].get('revision') == post.get('input_snapshot')
                          and results[0]['value'].get('status') == expected_status
                          and results[0]['value'].get('provenance') == 'EXECUTION' and self.result_supported(results[0]))
            refs = _unique(refs + [r['reference'] for r in results] + [ref for r in results for ref in _references(r['value'])])
            if not supported and not historical_revision:
                codes.append(self.issue('REPORT_EXECUTION_REQUIRED', refs, phase_id=phase_id))
        if role.get('role') in ('success', 'active') and committed and not historical_revision:
            policy_unchecked = (not self.stage_policy.get('supported') or
                any(self.phase_for_state(c['due_state']) == phase_id and not self.criterion_policy_supported(c['id'])
                    for c in self.catalogue))
            if policy_unchecked:
                supported = False
                refs = _unique(refs + self.stage_policy.get('references', []))
                codes.append(self.issue('REPORT_RULE_UNCHECKED', refs, phase_id=phase_id))
            definitions = [c for c in self.catalogue if c['due_state'] == state and c['required']]
            if self.spec:
                definitions += [c for c in self.spec['value']['criteria'] if c['due_state'] == state
                                and c['required'] and c['id'] not in {d['id'] for d in self.catalogue}]
            for definition in definitions:
                criterion = self.criterion(definition, event_id=item['event_id'], task=definition not in self.catalogue)
                refs = _unique(refs + criterion['evidence_refs'])
                codes += criterion['diagnostic_refs']
                supported &= criterion['result'] in ('SATISFIED', 'NOT_APPLICABLE')
        if not committed:
            codes.append(self.issue('REPORT_HISTORY_INVALID', [self.log_ref], phase_id=phase_id))
        if not self.mapping.get('valid') or state not in self.roles:
            supported = False
            codes.append(self.issue('REPORT_STATE_UNMAPPED', refs, phase_id=phase_id))
        if not supported:
            status = 'UNVERIFIED'
            if not codes:
                codes.append(self.issue('REPORT_EVIDENCE_STALE' if historical_revision else 'REPORT_EVIDENCE_MISSING', refs, phase_id=phase_id))
        identifier = 'event:' + str(item['position']) + ':' + str(event.get('request_id', 'unidentified'))
        result = dict(attempt_id=identifier, phase_id=phase_id, state=state, status=status, recorded_claim=claim,
                      evidence_refs=refs, event_refs=[self.log_ref], diagnostic_refs=_unique(codes), superseded_by=None,
                      extensions={'reporting': {'committed': committed, 'event_id': event.get('request_id'),
                                  'position': item['position'], 'source_revision': post.get('input_snapshot'),
                                  'result_refs': [r['reference'] for r in results],
                                  'outcome_result_authority': deepcopy(self.history.get('outcome_results', {}).get(event_id))}})
        if state == 'REPAIRING':
            result['extensions']['reporting']['repair_activity_kind'] = (
                'UNVERIFIED_VISIT' if not committed else 'NEW_ATTEMPT' if self.new_repair(event)
                else 'RESTORED_ACTIVITY' if event['previous_state'] == 'RESUME_REVIEW'
                else 'CONTINUATION' if event['previous_state'] == 'REPAIRING' else 'RECORDED_VISIT')
        return result

    def phases(self):
        for item in self.prefix:
            attempt = self.attempt(item, committed=True)
            if attempt:
                self.attempts.append(attempt)
        for item in self.history.get('invalid_suffix', []):
            if isinstance(item.get('event'), dict):
                attempt = self.attempt(item, committed=False)
                if attempt:
                    self.attempts.append(attempt)
        self.failure_outcomes()
        phases = []
        definitions = self.map_value.get('phases', [])
        definitions = definitions if isinstance(definitions, list) else []
        definitions = sorted([p for p in definitions if isinstance(p, dict)
                              and isinstance(p.get('id'), str) and p['id']],
                             key=lambda p: (p['order'] if isinstance(p.get('order'), int) else 0, p['id']))
        for definition in definitions:
            phase_id = definition['id']
            attempts = [a for a in self.attempts if a['phase_id'] == phase_id]
            # Preserve every later unsupported claim rather than falling back to
            # an earlier PASS and hiding the discrepancy.
            latest = attempts[-1] if attempts else None
            for earlier, later in zip(attempts, attempts[1:]):
                if (later['status'] != 'UNVERIFIED' and later['extensions']['reporting']['committed']
                        and later['state'] != earlier['state']):
                    earlier['superseded_by'] = later['attempt_id']
            status, claim = (latest['status'], latest['recorded_claim']) if latest else ('NOT_RECORDED', None)
            detail = 'REPORT_OUTCOME_SUPPORTED' if latest and status != 'UNVERIFIED' else 'REPORT_OUTCOME_UNVERIFIED' if latest else 'REPORT_NOT_RECORDED'
            codes = _unique([code for a in attempts for code in a['diagnostic_refs']])
            label = definition.get('label')
            label = label if isinstance(label, str) and label else phase_id
            profiles = definition.get('profiles')
            profiles = profiles if isinstance(profiles, list) else []
            phases.append(dict(phase_id=phase_id, label=label, status=status, recorded_claim=claim,
                               detail_code=detail, evidence_refs=_unique([ref for a in attempts for ref in a['evidence_refs']]),
                               attempt_refs=[a['attempt_id'] for a in attempts], diagnostic_refs=codes,
                               extensions={'reporting': {'attempt_count': self.attempt_count(phase_id, attempts),
                                           'earlier_failure_count': len(self.failure_ids(attempts) - self.failure_ids(attempts[-1:])),
                                           'unsupported_failure_claim_count': self.unsupported_failure_claim_count(attempts),
                                           'repair_count': self.repair_count(phase_id),
                                           'profile_selected': self.last.get('profile_id') in profiles}}))
            if phase_id == 'repair':
                phases[-1]['extensions']['reporting'].update(self.repair_activity(attempts))
        # A stop can originate at a declared control state (for example NEW),
        # which has no phase. Retain its history attempt without inventing an
        # unmapped phase for a state explicitly classified by the pinned map.
        unmapped = sorted(set(self.mapping.get('unmapped_states', [])) | {
            a['state'] for a in self.attempts if a['phase_id'] is None
            and self.roles.get(a['state'], {}).get('role') != 'control'})
        for state in unmapped:
            attempts = [a for a in self.attempts if a['state'] == state and a['phase_id'] is None]
            code = self.issue('REPORT_STATE_UNMAPPED', [self.log_ref])
            phases.append(dict(phase_id='unmapped:' + state, label='Unmapped state: ' + state, status='UNVERIFIED',
                               recorded_claim=state, detail_code='REPORT_STATE_UNMAPPED', evidence_refs=[self.log_ref],
                               attempt_refs=[a['attempt_id'] for a in attempts], diagnostic_refs=[code]))
        return phases

    def failure_outcomes(self):
        """Identify distinct recorded failures without discarding retained visits.

        A uniquely selected failed Result identifies its execution. Without one,
        only a new failure admission in the committed prefix contributes an
        outcome; same-state continuations/restores retain that admission's ID.
        Invalid suffixes remain claims, never invented executions.
        """
        retained, result_outcomes = {}, {}
        for attempt in self.attempts:
            if self.roles.get(attempt['state'], {}).get('role') != 'failure':
                continue
            metadata = attempt['extensions']['reporting']
            identity = None
            if metadata['committed']:
                event = self.prefix[metadata['position']]['event']
                authority = metadata.get('outcome_result_authority') or {}
                results = [r for r in self.entries('Result') if r['document'] == authority.get('document')
                           and r['schema_valid'] and r['value'].get('status') == 'FAIL'
                           and r['value'].get('capability') == authority.get('expected_capability')]
                key = (attempt['state'], metadata['source_revision'])
                continuation = event['previous_state'] in (attempt['state'], 'RESUME_REVIEW')
                if authority.get('status') == 'SELECTED' and len(results) == 1:
                    result = results[0]['value']
                    result_id = 'result:' + result['capability'] + ':' + result['run_id']
                    # Later evidence for an unresolved admission must not turn
                    # that admission plus its continuation into two failures.
                    prior = retained.get(key)
                    identity = result_outcomes.get(result_id)
                    if identity is None:
                        identity = (prior if continuation and prior and prior.startswith('event:')
                                    and prior not in result_outcomes.values() else result_id)
                        result_outcomes[result_id] = identity
                elif not continuation:
                    identity = attempt['attempt_id']
                else:
                    identity = retained.get(key)
                if identity:
                    retained[key] = identity
            metadata['failure_outcome_id'] = identity

    @staticmethod
    def failure_ids(attempts):
        return {a['extensions']['reporting']['failure_outcome_id'] for a in attempts
                if a['extensions']['reporting'].get('failure_outcome_id')}

    def unsupported_failure_claim_count(self, attempts):
        return sum(self.roles.get(a['state'], {}).get('role') == 'failure' and a['status'] == 'UNVERIFIED'
                   for a in attempts)

    def attempt_count(self, phase_id, attempts):
        capabilities = {'preflight': 'preflight', 'build': 'build', 'testing': 'test'}
        capability = capabilities.get(phase_id)
        if capability:
            return len({r['value'].get('intent_id') for r in self.entries('Invocation')
                        if r.get('schema_valid') and r.get('committed') and r['value'].get('capability') == capability})
        if phase_id == 'repair':
            return self.repair_count(phase_id)
        count = 0
        for attempt in attempts:
            metadata = attempt['extensions']['reporting']
            if metadata['committed']:
                event = self.prefix[metadata['position']]['event']
                # Phase filtering removes intervening visits to other phases.
                # Only the canonical event can identify a same-state continuation.
                count += event['previous_state'] != event['next_state']
        return count

    @staticmethod
    def new_repair(event):
        """Count only installed failure-origin repair admissions with an increment."""
        origin = {'BUILD_FAILED': 'build', 'TEST_FAILED': 'test'}.get(event['previous_state'])
        deltas = event.get('counter_deltas', {}).get('repair', {})
        increments = {name: value for name, value in deltas.items() if value}
        return bool(origin and event['next_state'] == 'REPAIRING' and increments == {origin: 1})

    def repair_count(self, phase_id=None):
        return sum(self.new_repair(item['event']) and (phase_id in (None, 'repair')
                   or self.phase_for_state(item['event']['previous_state']) == phase_id) for item in self.prefix)

    def repair_activity(self, attempts):
        """Describe the last committed repair activity without inventing a PASS.

        Flags describe the structural committed prefix, not completion support.
        The original phase/attempt statuses and invalid suffix claims stay intact.
        """
        repairs = [a for a in attempts if a['state'] == 'REPAIRING' and a['extensions']['reporting']['committed']]
        latest = repairs[-1] if repairs else None
        exit_item = None
        if latest:
            position = latest['extensions']['reporting']['position']
            exit_item = next((item for item in self.prefix if item['position'] > position
                              and item['event']['previous_state'] == 'REPAIRING'
                              and item['event']['next_state'] != 'REPAIRING'), None)
        next_attempt = next((a for a in self.attempts if exit_item and a['extensions']['reporting']['committed']
                             and a['extensions']['reporting']['position'] >= exit_item['position']), None)
        exit_row = self.event_entry(exit_item['event_id']) if exit_item else None
        return dict(activity_authority='COMMITTED_PREFIX', activity_active=bool(latest and self.last.get('state') == 'REPAIRING'),
                    activity_ended=bool(exit_item), activity_entry_attempt_ref=latest['attempt_id'] if latest else None,
                    repair_visit_count=sum(self.prefix[a['extensions']['reporting']['position']]['event']['previous_state'] != 'REPAIRING'
                                           for a in repairs),
                    repair_restore_count=sum(self.prefix[a['extensions']['reporting']['position']]['event']['previous_state'] == 'RESUME_REVIEW'
                                             for a in repairs),
                    activity_exit_event_id=exit_item['event_id'] if exit_item else None,
                    activity_exit_event_position=exit_item['position'] if exit_item else None,
                    activity_exit_state=exit_item['event']['next_state'] if exit_item else None,
                    activity_exit_event_refs=[self.log_ref] if exit_item else [],
                    activity_exit_record_valid=bool(exit_row and exit_row['schema_valid'] and exit_row['valid']) if exit_item else None,
                    activity_next_attempt_ref=next_attempt['attempt_id'] if next_attempt else None)

    def evidence_links(self):
        for kind in ('Result', 'CriterionReview', 'Invocation'):
            for row in self.entries(kind):
                value = row['value']
                method = 'AUTOMATED' if kind == 'Result' and value.get('provenance') == 'EXECUTION' else value.get('method')
                category = 'EXECUTION' if kind == 'Result' and value.get('provenance') == 'EXECUTION' else 'REVIEW' if kind == 'CriterionReview' or value.get('provenance') == 'REVIEW' else 'INVOCATION' if kind == 'Invocation' else 'FIXTURE'
                metadata = dict(reference=row['reference'], category=category, method=method,
                                actor=value.get('actor'), committed=bool(row.get('committed')),
                                record_valid=bool(row.get('valid')), checked_support=self.result_supported(row) if kind == 'Result' else self.record_supported(row),
                                evidence_refs=_references(value), diagnostic_refs=_unique(row.get('diagnostic_codes', [])))
                if kind == 'Result':
                    metadata['invocation_revision'] = deepcopy(row.get('invocation_revision'))
                    metadata['recorded_claim'] = value.get('status')
                if kind == 'CriterionReview':
                    metadata['criterion_claims'] = [dict(criterion_id=v.get('criterion_id'), recorded_claim=v.get('result'))
                                                     for v in value.get('criteria', []) if isinstance(v, dict)] if isinstance(value.get('criteria'), list) else []
                if kind == 'Invocation':
                    metadata['revision_identity'] = row.get('revision_identity')
                    metadata['selected_event_ids'] = deepcopy(row.get('selected_event_ids', []))
                self.links.append(metadata)
        return self.links

    def report(self, generated_at):
        self.select_specification()
        self.mark_superseded_stale_records()
        phases = self.phases()
        stage_rows = [self.criterion(c) for c in self.catalogue]
        task_defs = self.spec['value']['criteria'] if self.spec else []
        stage_ids = {c['id'] for c in self.catalogue}
        task_rows = [self.criterion(c, task=True) for c in task_defs if c['id'] not in stage_ids]
        if not task_rows:
            self.acceptance_valid = False
            if self.spec or self.last.get('accepted_identities', {}).get('specification') or self.complete_claimed():
                self.issue('REPORT_ACCEPTANCE_UNRESOLVED', [self.spec['reference']] if self.spec else [])
        coverage = dict(task_acceptance=_counts(task_rows), stage_progression=_counts(stage_rows))
        final_items = [item for item in self.prefix if item['event'].get('next_state') == 'SPEC_VERIFIED']
        final_verified = False
        if final_items and self.acceptance_valid:
            final = final_items[-1]
            final_rows = self.entries('CriterionReview', final['event_id'])
            final_keys = {reference_key(ref) for ref in _references(final['event']['post_state'].get('criterion_verdict_refs', []))}
            reconciled = [r for r in final_rows if r['document'] in final_keys and r['value'].get('due_state') == 'SPEC_VERIFIED'
                          and r['value'].get('revision') == self.last.get('input_snapshot') and self.record_supported(r)]
            final_supported = any(a['state'] == 'SPEC_VERIFIED' and a['status'] == 'PASS'
                                  and a['extensions']['reporting']['event_id'] == final['event_id'] for a in self.attempts)
            final_verified = (final_supported and self.event_supported(final) and bool(reconciled) and
                all(any(v['criterion_id'] == c['criterion_id'] and v['result'] in ('PASS', 'NOT_APPLICABLE')
                        and not v['unresolved_findings'] for r in reconciled for v in r['value']['criteria'])
                    for c in task_rows if c['required']))
        self.check('final_specification_verification', True, [self.log_ref])
        complete = self.complete_claimed()
        checks = self.record_checks()
        remaining = sum(section['failed_required'] + section['unresolved_required'] for section in coverage.values())
        completion_supported = bool(complete and self.last.get('state') == 'COMPLETE' and self.history.get('complete')
            and self.history.get('snapshot_consistent') and self.mapping.get('valid') and self.acceptance_valid
            and final_verified and remaining == 0 and checks == 'CONSISTENT'
            and self.event_supported(self.prefix[-1])
            and all(not row['mandatory'] or row['status'] != 'UNCHECKED' for row in self.coverage['checks'])
            and any(a['state'] == 'SPEC_READY' and a['status'] == 'PASS' for a in self.attempts)
            and all(phase['status'] != 'UNVERIFIED' for phase in phases))
        if complete and not completion_supported:
            self.issue('REPORT_COMPLETION_UNSUPPORTED', [self.snapshot_ref, self.log_ref])
        checks = self.record_checks()
        support = 'SUPPORTED_BY_CHECKED_RECORDS' if completion_supported else 'UNSUPPORTED' if complete else 'NOT_RECORDED_COMPLETE'
        recorded_state = self.last.get('state')
        if complete and not completion_supported:
            summary = 'Completion is recorded, but supporting evidence is incomplete or inconsistent.'
        elif completion_supported:
            summary = 'Recorded completion is supported by the checked records.'
        else:
            summary = 'Recorded state: ' + (recorded_state or 'NOT_RECORDED') + '. ' + str(remaining) + ' required criteria remain unresolved or failed.'
        accepted = self.last.get('accepted_identities', {})
        config_key = 'HARNESS:' + self.capture['roots']['run_path'] + '/config-snapshot.yaml'
        configuration = self.capture['documents'].get(config_key, {})
        configuration = configuration if isinstance(configuration, dict) else {}
        configuration_identity = self.capture['roots']['inspected_inputs'].get(config_key, {}).get('identity')
        if self.capture['roots']['run_path'].startswith('artifacts/development/'):
            configs = self.entries('ConfigSnapshot')
            if len(configs) == 1:
                configuration = configs[0]['value']
                configuration_identity = 'sha256:' + hashlib.sha256(canonical_json(configuration)).hexdigest()
        targets = self.last.get('selected_targets', [])
        scope = dict(profile_id=self.last.get('profile_id'), configuration_id=self.last.get('configuration_id'),
                     configuration_identity=configuration_identity, request_identity=accepted.get('request'),
                     specification_identity=accepted.get('specification'), source_revision=self.last.get('input_snapshot'),
                     description=deepcopy(self.spec['value']['scope']) if self.spec else [],
                     targets=deepcopy(targets) if isinstance(targets, list) else [])
        manifest = sorted(deepcopy(self.capture['source_manifest']), key=lambda r: (r['scope'], r['path']))
        generation_id = hashlib.sha256(canonical_json(dict(source_manifest=manifest, generated_at=generated_at,
            generator_version=GENERATOR_VERSION, report_version=REPORT_VERSION))).hexdigest()
        last_event = self.prefix[-1]['event'] if self.prefix else {}
        limitations = _unique(_LIMITS + [text for check in self.coverage['checks'] for text in check['limitations']])
        report = dict(record_type='TaskReport', report_version=REPORT_VERSION, generation_id=generation_id,
            generated_at=generated_at, generator=dict(name='harness-task-report', version=GENERATOR_VERSION, report_version=REPORT_VERSION),
            task_id=self.capture['roots']['task_id'], scope=scope, source_manifest=manifest, recorded_state=recorded_state,
            record_checks=checks, completion_support=support, phases=phases, specification_coverage=coverage,
            history=dict(last_event_id=last_event.get('request_id'), last_event_version=last_event.get('next_version'),
                         committed_prefix_length=len(self.prefix),
                         earlier_failure_count=len(self.failure_ids(self.attempts)),
                         repair_count=self.repair_count(), attempts=self.attempts,
                         extensions={'reporting': {'unsupported_failure_claim_count': self.unsupported_failure_claim_count(self.attempts)}}),
            diagnostics=self.diagnostics, coverage=self.coverage, limitations=limitations,
            extensions={'reporting': dict(summary=summary, state_claims=self.state_claims(),
                stage_policy=deepcopy(self.stage_policy),
                recorded_complete_claimed=complete, final_specification_verified=final_verified,
                accepted_task_matrix_supported=self.acceptance_valid, evidence_links=self.evidence_links(),
                superseded_record_documents=sorted(self.superseded_documents),
                historical_diagnostic_indices=self.historical_diagnostic_indices(),
                configuration_revision=configuration.get('configuration_revision'),
                recorded_results=[dict(reference=r['reference'], payload=deepcopy(r['value']),
                    journal_sequence=self.capture['roots'].get('journal_entry_sequence', {}).get(r['reference'].get('entry_id')),
                    valid=r['valid'], committed=r['committed'], diagnostic_codes=r['diagnostic_codes'])
                    for r in self.entries('Result')])})
        return report

    def record_checks(self):
        # Unreadable or ambiguous authority prevents derivation. Unsupported
        # outcome mechanics are diagnosable issues, even if no ERROR was emitted.
        authority_refs = {reference_key(self.log_ref), reference_key(self.snapshot_ref)}
        authority_refs |= {key for key in (self.mapping.get('workflow'), self.mapping.get('profile')) if key}
        historical = set(self.historical_diagnostic_indices())
        for i, issue in enumerate(self.diagnostics):
            if i in historical:
                continue
            if issue['code'] in _AUTHORITY_CODES:
                return 'UNVERIFIABLE'
            if issue['code'] in ('REPORT_SOURCE_MISSING', 'REPORT_SOURCE_INACCESSIBLE', 'REPORT_DOCUMENT_INVALID'):
                if any(reference_key(ref) in authority_refs for ref in issue['references']):
                    return 'UNVERIFIABLE'
        if not self.mapping.get('valid') or not self.prefix:
            return 'UNVERIFIABLE'
        if (any(issue['severity'] == 'ERROR' for i, issue in enumerate(self.diagnostics) if i not in historical)
                or any(row['mandatory'] and row['status'] == 'UNCHECKED' for row in self.coverage['checks'])):
            return 'ISSUES_FOUND'
        return 'CONSISTENT'


def derive_report(capture: dict, *, generated_at: str) -> dict:
    """Return a deterministic schema-validated report without mutating capture.

    The supplied UTC timestamp is the only time input. Missing/malformed captured
    report schemas raise ReportDerivationError; no schema/source is reopened.
    Display extensions are documented in the Task 4 implementer report.
    """
    report = deepcopy(_Derivation(capture).report(generated_at))
    _validate_report(report, capture)
    return report


def invalidate_changed_capture(report: dict, capture: dict, changes: list[dict]) -> dict:
    """Expose mechanical staleness after the second publication stability failure.

    No recapture or semantic judgment: retain claims, history and captured hashes,
    invalidate all current outcomes/criteria, and validate with captured schemas.
    The original captured outcomes remain under reporting.captured_before_change.
    """
    result = deepcopy(report)
    metadata = result['extensions']['reporting']
    metadata['captured_before_change'] = dict(
        phases=deepcopy(result['phases']),
        specification_coverage=deepcopy(result['specification_coverage']),
        record_checks=result['record_checks'], completion_support=result['completion_support'])
    for item in changes:
        if item not in result['diagnostics']:
            result['diagnostics'].append(deepcopy(item))
    refs = _unique([ref for item in changes for ref in item['references']])
    result['coverage']['checks'].append(dict(check_id='capture_stability', status='UNCHECKED',
        mandatory=True, references=refs,
        limitations=['Inputs changed twice during generation; all current outcomes are stale.']))
    for phase in result['phases']:
        if phase['status'] != 'NOT_RECORDED':
            phase['status'] = 'UNVERIFIED'
            phase['detail_code'] = 'REPORT_OUTCOME_UNVERIFIED'
            phase['diagnostic_refs'] = _unique(phase['diagnostic_refs'] + ['REPORT_SOURCE_CHANGED'])
    for name in ('task_acceptance', 'stage_progression'):
        rows = result['specification_coverage'][name]['criteria']
        for row in rows:
            row['result'] = 'UNRESOLVED'
            row['diagnostic_refs'] = _unique(row['diagnostic_refs'] + ['REPORT_SOURCE_CHANGED'])
        result['specification_coverage'][name].update(_counts(rows))
    for item in metadata['evidence_links']:
        item['checked_support'] = False
    metadata['final_specification_verified'] = False
    metadata['accepted_task_matrix_supported'] = False
    metadata['summary'] = ('Completion is recorded, but supporting evidence is incomplete or inconsistent.'
        if metadata['recorded_complete_claimed'] else 'Inputs changed during report generation; captured outcomes are unverified.')
    result['record_checks'] = 'UNVERIFIABLE'
    result['completion_support'] = 'UNSUPPORTED' if metadata['recorded_complete_claimed'] else 'NOT_RECORDED_COMPLETE'
    result['limitations'].append('Captured before detected source changes; this report is an inconsistent snapshot, not current support.')
    _validate_report(result, capture)
    return result


def validate_report(report: dict, capture: dict) -> None:
    """Check publication extensions against captured schemas without new verdicts."""
    _validate_report(report, capture)
