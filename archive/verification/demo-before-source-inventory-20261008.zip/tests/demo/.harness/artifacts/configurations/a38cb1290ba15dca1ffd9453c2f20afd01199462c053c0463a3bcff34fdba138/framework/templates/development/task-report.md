# Task report: {{task_title}}

{{specification_link}}

**Summary:** {{derived_summary}} Validated state: {{recorded_state}}.
**Record checks:** {{check_result}}.

| Phase | Result | Evidence |
|---|---|---|
{{#phases}}
| {{phase_label}} | {{status}} | {{links}} |
{{/phases}}
**History:** {{previous_failure_count}} earlier failures; {{repair_count}} repairs; {{tool_failure_count}} tool failures. {{attempt_history_link}}.

{{diagnostics_link}} · {{criteria_link}} · {{sources_link}}.
Tool claims do not establish phase success. Source inventory and user-skip authority remain unchecked.
