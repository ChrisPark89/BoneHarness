# JavaScript harness demo

This directory is the demo project. There is one copy of the app.

| Path | Purpose |
|---|---|
| `src/` | Calculator source |
| `test/` | JavaScript tests |
| `scripts/`, `package.json` | Build and test commands |
| `dist/` | Generated build output |
| `.harness/` | Installed harness, reports and saved records |
| `run.py` | Two-scenario harness trial runner |

From this directory, run `npm run build` and `npm test` for the app.

For a fresh harness trial, use Python with the [declared dependencies](../../builder-kit/templates/runtime/framework/tools/requirements.lock) and Node.js. From the builder project root:

```sh
python tests/demo/run.py
```

The runner refuses an existing `.harness/`. Preserve any records you need before explicitly removing it for another installation.

The scenarios cover success and an intentional test failure followed by repair. The runner restores the original source in `finally`; forced termination can prevent restoration. Save changes in version control or a backup before experiments. This authoring workspace currently has no Git history.

Start reviewing at [.harness/README.md](.harness/README.md). The retained harness was moved here unchanged; its records describe the earlier installation, not a new run. Trial workflow approvals are simulated.
