# Retained JavaScript demo — format 1

This is the earlier two-scenario trial. Its installed harness and evidence are preserved with their original tools.

| Path | Purpose |
|---|---|
| `src/` | Calculator source |
| `test/` | JavaScript tests |
| `scripts/`, `package.json` | Build and test commands |
| `dist/` | Generated output |
| `.harness/` | Historical harness, reports and records |
| `run.py` | Historical trial runner; requires the matching format 1 kit |

The app remains reusable: run `npm run build` and `npm test` here.

Read the saved [trial](.harness/docs/trial.md). Workflow approvals were simulated, so passing commands did not establish supported task completion.

Do not run `run.py` with the current kit. To reproduce the old trial, extract [the complete format 1 snapshot](../../archive/2026-10-10-format-1.zip) separately. Current format 2 checks use disposable repositories and preserve this demo’s records.
