# JavaScript harness trial implementation

Status: **DONE_WITH_CONCERNS** (documented unsupported completion/protocol and native-host limits), reviewed fix source frozen at `ef7390e0dbd26643b92fc2f45d9b00f30b24aefc`; final17-test trial module **PASS**. Initial implementation `d5d0d5e0724fce50a4a71078ad224ad0fd3ad6ec` extends baseline `69fc0803778cb9477b967bcb897009d47502ce9b`. Scoped independent re-review accepted both P2 corrections with no new breakage; controller transferred reviewed source and runs the retained trial. Fix worktree remains clean. Existing Block Secrets pre-commit hook stayed enabled and approved the commit; its cache-log writes outside the sandbox printed permission warnings.

## Interfaces and bounded design

Entry point: `demo/README.md`. `demo/run.py --output ABSOLUTE_EMPTY_DIRECTORY`, repeated optional `--case NAME`, and `--list`. Python interface: `run_trial(output: Path, *, node_executable: str = 'node', case_names: list[str] | None = None) -> dict`. Output refuses occupied destinations, symlink ancestry and source directories. Arguments are arrays; commands have bounded local-only subprocess timeouts. Python packages must match the canonical lock; Node20+ must already be available. No network or installs.

The sample is a two-function ESM calculator with `node:test`/`node:assert/strict`. The build checks syntax, removes stale dist output, and copies source to dist. Tests import dist. npm scripts use portable Node commands. It has no application framework, server, UI or downloaded package.

One disposable repository has installed runtime copied unchanged except repository profile bindings; scenarios have separate task directories and exact pinned definitions. The runner records actual local Node logs, per-call source files/hashes, artifact/test-source identities, exit codes and stdout/stderr. Prior failed executions retain their original revisions and captured source bytes after corrections.

Lifecycle/transition/gate/acceptance/reviewer records are simulated inputs, labelled SCENARIO FIXTURE by actor, extensions, source README and output index. CriterionReview has a schema-mandated REVIEW provenance enum; explicit fixture actor/extensions and FIXTURE basis evidence prevent that field becoming a claim of actual semantic review. Only actual Node commands/logs/result envelopes use EXECUTION. Fixture binding/repair policy is no real approval, activation or live policy enforcement. Installation checker output is retained without relabelling its pending compatibility/semantic obligations.

`summary.md` has one row and report/data/log links per case. `results.json` keeps every assertion, intentional tool failure, reporter exit/result, recorded state versus completion support, covered/uncovered states, installation assertions and actual native host. Expected reporter exit1 can coexist with scenario PASS. COMPLETE stays UNSUPPORTED due to absent supported source inventory and fixture semantic claims. N/A and user skipping are unresolved and explicitly diagnosed.

## Matrix

45 cases: 24 explicit checkpoints for every installed default workflow state; 9 named histories (build/test repair, disabled/exhausted repair, missing tool/blocked, resume, same-state wait, failure wait/resume, repair wait/resume); 12 negatives (missing build/test logs, stale result, snapshot mismatch, illegal edge, malformed/duplicate-key record, missing acceptance criterion, unsupported COMPLETE, fixture execution, N/A, skip).

State names are derived from the installed workflow; explicit routes must cover its exact declared state set. Coverage requires assertion PASS, correct recorded prefix, the exact thirteen installed phase IDs and state-specific status/claim/attempt associations (see review-wave correction). Positive cases reject diagnostics outside a narrow fixture/staleness/source-inventory list; schema, identity, map, history, collisions and snapshot errors cannot be hidden by the known completion limit. Negative cases match exact diagnoses; fixture Result diagnosis is checked on its own path and the missing acceptance review has no recorded verdict. Historical attempts, failure admission counts, repair admissions and active/ended repair flags are checked.

## Product corrections

1. `reporting/evidence.py`: build artifact required only for build PASS when consumed downstream. A truthful failed syntax build produces no artifact. Supplied artifact checks and test artifact lineage remain required.
2. `reporting/summary.py`: a declared control stop from NEW retains its history attempt without fabricating an unmapped phase. Unknown/unmapped states are still diagnosed.

## Existing-test compatibility corrections

The immutable baseline had 120 tests and six failures (controller `baseline-complete.log`, 206.130s). Test setups were stale after reporting integration:

- Relocated checker now includes its canonical sibling harness_io support package. No-bytecode/full-tree read-only assertions remain.
- Publication fixture extracts the archive in temporary space, adds current runtime files to an explicitly labelled fixture baseline, updates only the unattested catalogue ownership hash, and preserves every existing publication record/attested endpoint hash. Its positive precondition must have no diagnostics before deliberate ancestry/receipt mutations. Original archive bytes are unchanged.
- Schema inventory includes the task-report schema; conformance catalogue checks 147 variants, including 15 reporting variants.
- Current catalogue parts are partitioned exactly into historical covered joins and the explicit 15 reporting walkthrough parts not assessed by the old ledger. No historical evidence was altered and no new conformance PASS is fabricated.

## Files

- New: `demo/README.md`, `demo/run.py`, `demo/records.py`, `demo/javascript/package.json`, `demo/javascript/src/calculator.js`, `demo/javascript/test/calculator.test.js`, `demo/javascript/scripts/build.js`, `tests/test_javascript_trial.py`.
- Changed: root/tests README navigation; reporting evidence/summary; checker/conformance/contracts/installation-definition test compatibility.
- No original workspace edits, new Git repository in original, dependency install, network call or worker subagents.

## RED / GREEN evidence

Interpreter: `/private/tmp/harness-builder-20261004-efv7l2ai/venv311/bin/python` (3.11.16). Actual Node found by local PATH: v24.10.0 (do not substitute the brief's available-version estimate).

- Initial focused unittest discover: missing runner assertion, exit1. Node calculator test: missing built module, exit1.
- `python -B -m unittest test_javascript_trial.ReporterArtifactRegression`: artifact RED (`build-fail-artifact-red.log`, one test failed, 11.497s), then GREEN (`build-fail-artifact-green.log`, one test passed, 11.057s).
- Control-stop regression: RED (`control-stop-red.log`, 14 vs expected13 phase rows, 5.253s), GREEN (`control-stop-green.log`, one test passed, 5.094s).
- Initial full new-test run: `python -B -m unittest discover -s tests -p test_javascript_trial.py -v`, 7 tests, 301.632s, three RED failures (artifact defect and control-stop coverage plus cascaded trial status). `trial-focused-initial.log`. This run predates those fixes and is not final success evidence.
- Three checker compatibility cases: GREEN, 3 tests, 46.776s (`fixture-compatibility-green.log`).
- Schema/catalogue compatibility cases: GREEN, 3 tests, 0.910s (`catalogue-compatibility-green.log`).
- Portable setup/CLI tests: GREEN, 3 tests, 5.659s (`setup-portability-green.log`).
- Probe5 generated `/private/tmp/harness-js-probe5`, three tightened negative/control cases, scenario PASS (`trial-probe5.log`). Scratch-only artifact; controller retains the final complete user run after review/transfer.
- `full-final.log` is **pre-freeze**: code/test edits occurred while it was running. Its result cannot establish frozen-source success.
- Frozen full suite started against commit d5d0d5e: `python -B -m unittest discover -s tests -v`, 900-second bound, output `full-frozen.log`, metadata `full-frozen.json`: **130 tests, 567.538s, two failures**. All120 existing tests passed; failure-wait-resume fixture prefix/state assertions failed, with the overall-status test cascading. See the fix-wave diagnosis below.

## Limits and concerns

No supported source inventory format, criterion N/A authority or user-skip protocol was invented. Completion therefore remains unsupported. All lifecycle/semantic reviews are fixtures, not agent behavior or real approval. Formal reporting conformance walkthrough parts remain unassessed by the historical ledger. Publication race stress and native Windows/Linux runs are not covered. The suite checks local spaces/Unicode, source/read-only behavior, metadata/hash agreement, regeneration, prior-pair mismatch, unsafe task/output paths and missing dependencies; symlink-specific subtests skip truthfully if their host cannot create links. Temporary test roots use resolved native tempfile directories.

Independent review is controller-owned. User-facing retained full trial output is controller-owned after transfer. Final verification status and exact counts will be appended.

### Pre-freeze run disposition

The obsolete `full-final.log` run was terminated through its own exec session with Ctrl-C, exit130, while the JavaScript class fixture was still running. Earlier test modules had passed, but the run is incomplete and not frozen-source evidence. Only `full-frozen.log`/metadata can establish final frozen-source status. Independent review has identified an output-path lexical-parent bypass; source remains frozen pending the controller's complete fix dispatch.


## Review correction wave (isolated fix worktree)

Independent review identified two P2 findings. Corrections live in `/private/tmp/harness-js-trial-emr1ib2s/fix`; initial worktree stays byte-frozen at d5d0d5e for reliable pre-fix full-suite evidence. No additional product/runtime change is made in this wave.

- Output guard rejects any parent-traversal component before writes. Regressions exercise both demo and builder-kit escapes, asserting no intermediate or destination directory is created; occupied/symlink protections remain.
- Phase assertions now compare the exact ordered installed IDs, every relevant attempt's event/state/phase/claim/position/status, and each phase's exact associated attempts, last claim and status. Visited fixture phases/attempts must be UNVERIFIED; untouched phases must be NOT_RECORDED. NEW/RESUME_REVIEW/COMPLETE controls do not fabricate phases. Unsupported skip's claim is asserted explicitly. Negative affected phases cannot become supported PASS. Expectations use literal routes and declared phase maps, never production report derivation. Mutation tests demonstrate wrong duplicate IDs, control-only false PASS, visited false PASS/wrong claim, and incorrectly attached attempts are rejected.
- Full frozen suite's history failure exposed two generated-fixture errors: restoration from RESUME_REVIEW omitted required resolution references, and repair waiting selected the INVALIDATED DEV-350 edge instead of ordinary DEV-128. Fixtures now retain a labelled resolution basis and use the ordinary repair wait route; reporting validation and diagnostic allowances are unchanged. Prefix15/16, prior failure1, repair0/1 and active repair assertions remain exact.
- Negative illegal-transition initially used schema-invalid DEV-INVALID, obscuring the intended transition diagnosis. It now supplies a shape-valid existing BASELINED→RESEARCHED edge at NEW→BASELINED. Exact TRANSITION_INVALID, valid prefix1, recorded NEW and absence of DOCUMENT_INVALID are tested.
- Main matrix test aggregates every failed case and observation rather than stopping at the first case, so unrelated failures remain visible.

### Review-wave evidence

Commands use the pinned3.11 interpreter above, from fix/tests; logs stay outside checkout.

- `python -B -m unittest test_javascript_trial.ReviewRegressionTests -v`: RED5tests/6failed subcases13.617s (`review-fixes-red.log`); GREEN5tests13.547s (`review-fixes-green.log`).
- `python -B -m unittest test_javascript_trial.ResumptionFixtureRegression.test_failure_and_repair_restores_record_required_resolution_basis -v`: RED1test20.833s (`resume-fixture-red.log`). Partial restoration fix still failed repair-wait prefix14/16,1test20.828s (`resume-fixture-green.log`, filename is not a success claim). Retained repair probe confirms DEV-350 invalidation was selected; corrected ordinary route is covered by the combined GREEN below.
- `python -B -m unittest test_javascript_trial.ResumptionFixtureRegression.test_illegal_edge_is_shape_valid_and_diagnosed_as_transition_invalid -v`: RED1test5.558s (`illegal-fixture-red.log`). The earlier three-case `review-edge-probe.log` was FAIL due to this same schema-invalid illegal edge; it is not GREEN evidence.
- `python -B -m unittest test_javascript_trial.ResumptionFixtureRegression test_javascript_trial.ReviewRegressionTests -v`: **GREEN7tests40.530s**, exit0 (`review-fixtures-green.log`). Covers all five review regressions and both fixture regressions at latest edited contents.
- All21 histories/negatives diagnostic probe: **PASS**, exit0, no failed observations (`all-history-negative-probe.log`), scratch output `/private/tmp/harness-js-all-history-negative-probe`. Both restore prefixes15/16 and illegal prefix1 are valid at frozen fix source; this run verifies the formerly hidden later cases together, and is diagnostic evidence rather than a second retained user run.
- Frozen post-fix full trial module: **PASS,17tests372.802s,exit0 at ef7390e0dbd26643b92fc2f45d9b00f30b24aefc**, clean fix worktree. Command `python -B -m unittest discover -s tests -p test_javascript_trial.py -v`,900-second bound; `postfix-trial.log` and `postfix-trial.json` record result, exact command/commit and SHA256 identities of all three changed files. No source changes during this run. Full45-case matrix reported PASS:24states,68real Node executions,12intentional tool failures; Darwin arm64/Python3.11.16/Nodev24.10.0. No symlink tests skipped on this host.

Fix commit: `ef7390e0dbd26643b92fc2f45d9b00f30b24aefc` (three bounded files), based on reviewed `d5d0d5e0724fce50a4a71078ad224ad0fd3ad6ec`. Hook enabled and commit protected by IBM Vault Radar; hook logging to its out-of-sandbox cache emitted permission warnings but commit succeeded. `git diff --check` and clean-tree status verified before handoff for review.


## Final verification and handoff

Final fix worktree HEAD `ef7390e0dbd26643b92fc2f45d9b00f30b24aefc` is clean after the complete module run; initial implementation commit is `d5d0d5e0724fce50a4a71078ad224ad0fd3ad6ec`. Scoped independent re-review accepted both findings. Controller has transferred the reviewed16-file change, preserving289 historical files, and owns the retained user trial/status-doc updates.

Evidence should be read as two exact source runs, not a fabricated single full-suite PASS: pre-fix full suite130tests/2fail (all120existing tests passed), then final fixed complete trial module17tests/PASS. Only demo fixture/assertion/output-guard files changed after the full suite; unchanged legacy modules were not rerun per controller direction. Post-fix log/metadata retain command, commit, elapsed time and the exact SHA256 identities of all three correction files. No additional broad suite or retained trial was run by this worker.

The21-case aggregate diagnostic probe uses `run_trial(output, case_names=HISTORIES+list(NEGATIVES))` and reports the full failed-observation mapping `{}`. Its scratch output is not the user-facing retained evidence. Every17 final-module test passed, including the45-case matrix, unsafe path/setup handling, pair regeneration/read-only checks, execution lineage, two original runtime regressions, review mutation regressions and fixture restoration/illegal-edge regressions.

Final concerns remain the stated limits, not failing tests: lifecycle/semantic records are fixtures; source enumeration lacks a supported protocol; COMPLETE is UNSUPPORTED; N/A/skip authority is unresolved; current reporting conformance walkthrough parts remain unassessed; native Windows/Linux and publication-race stress were not run. There were no dependency installs/network calls, original-workspace edits by this worker, or worker subagents.
