# Independent JavaScript trial review

Reviewed frozen HEAD `d5d0d5e0724fce50a4a71078ad224ad0fd3ad6ec` against baseline `69fc0803778cb9477b967bcb897009d47502ce9b`. This review covers the implementation contract and the entire change, including the two product corrections and existing-test fixture adjustments. The worktree remained clean. No implementation or historical evidence was edited.

## Verdicts

- **Spec compliance: CHANGES REQUIRED.** The intended application, real execution, fixture provenance, state routes, repair histories, unsupported completion, and historical-evidence boundaries are implemented. Two explicit requirements still need correction: protected output paths and meaningful phase assertions for checkpoint coverage.
- **Code quality: CHANGES REQUIRED.** The product changes are small and coherent, and the helper split is reasonable for this bounded trial. The output guard has a reproducible lexical-path bypass. The assertion framework also permits false passes for materially incorrect phase reports.

## Findings

### P2 — Normalize or reject parent traversal before checking protected output roots

Location: `demo/run.py:265-273`, specifically the `absolute()` and `is_relative_to()` checks at lines 266-268.

`Path.absolute()` preserves `..` components. As a result, an output such as `<ROOT>/review-nonexistent-hop/../demo/review-output-must-be-rejected` passes `safe_output()` even though it resolves inside the protected `demo/` source directory. The later `mkdir(parents=True)` can create the intervening directory and then place the trial underneath source. The same construction bypasses the `builder-kit/` restriction. This violates both the documented output boundary and the brief's requirement that generated evidence stay outside builder-kit.

A read-only probe imported the frozen runner and passed exactly that path to `safe_output()`. It returned the path; `Path.resolve()` showed `<ROOT>/demo/review-output-must-be-rejected`. No directories were created for this probe.

Smallest correction: reject any `..` path component with a friendly setup error, or retain the symlink-ancestry rejection and apply the protected-root checks to a normalized path before any write. Add a focused regression for traversal into each protected root, checking that no output or intermediate directory is created. Keep the existing symlink and occupied-directory checks.

### P2 — Check phase identities and state-specific report meaning before awarding checkpoint coverage

Location: `demo/run.py:208-245` and `407`; corresponding test assertions at `tests/test_javascript_trial.py:36-45`.

The checkpoint assertions verify the state, committed-prefix length, allowed diagnostics and a phase count of thirteen, but never verify which phase IDs survived, their statuses, their recorded claims, or the checkpoint's relevant attempt. Except for repair activity, the framework can award a state coverage PASS when every phase reports a fabricated successful outcome. The blanket diagnostic allowance does not prevent this because those same diagnostics can coexist with wrong phase summaries.

Focused proof is retained in `phase-assertion-probe.json`. Starting with the retained `checkpoint-BLOCKED` report, the probe changed all thirteen phase statuses from `NOT_RECORDED` to `PASS` and replaced all twelve non-repair phase IDs with the same nonexistent ID. It supplied a matching temporary output hash/generation pair and called the frozen `check_case()`. **Every assertion still passed**, including “all thirteen phase rows retained.” Existing retained artifacts were read only; the modified pair lived in an automatically removed temporary directory.

Smallest correction: compare the exact ordered or unique phase-ID collection with the installed phase map and add explicit checkpoint expectations for relevant phase status, recorded claim and attempt association, including control-only checkpoints and unvisited phases. The expectations should preserve the legitimate `UNVERIFIED` outcomes from fixture authority and unsupported evidence. Negative evidence cases should also assert that the affected result cannot produce a supported successful phase. Add a small mutation regression showing that wrong IDs and wrong statuses each fail the assertions. No new protocol or enforcement engine is needed.

## Accepted aspects of the change

- The calculator remains two functions; Node's built-in tests consume the copied build artifact. There are no npm dependencies or download commands.
- Actual commands, exit codes, stdout/stderr, captured source files and artifact/test-source identities are recorded separately from conspicuously labelled fixture lifecycle and review claims.
- The runner derives declared state coverage from the installed workflow and uses explicit graph routes. It preserves historical repair/failure executions and states the difference between scenario assertion success and unsupported task completion.
- The failed-build correction only relaxes the absent produced-artifact requirement for non-PASS builds. Supplied artifact validation, required consumed lineage and test-source checks remain in place in the surrounding capture logic.
- The control-state correction excludes declared control stops from fabricated unmapped phase rows; unknown states still reach the map/history diagnostics.
- Existing compatibility changes are limited to temporary test fixtures and exact catalogue expectations. Publication record bytes and attested endpoint hashes are explicitly preserved, and the unmutated fixture must have no diagnostics before the old mutation assertions run. The full-tree read-only assertion remains. Fifteen reporting conformance obligations are explicitly unassessed rather than assigned invented historical PASS coverage.
- The README is a short usable entry point and openly identifies source inventory, N/A, skip, installation semantic/compatibility, native-platform and enforcement limitations.

## Evidence and limits

Read the review and implementation briefs, draft implementation report, baseline diagnosis, execution ledger, complete diff and relevant source. Inspected retained focused-test evidence and the ongoing frozen-suite log rather than launching another long suite. Performed the two focused probes described above; verified the supplied commit and clean worktree directly.

At review completion, `full-frozen.log` was still progressing through checker tests and `full-frozen.json` had not yet been produced. Therefore this report makes **no frozen full-suite PASS claim**. The controller should record that result separately, then rerun the scoped tests after the two corrections and obtain focused re-review. The earlier pre-freeze suite cannot establish final-source success. No native Windows/Linux run or OS race testing was performed, and no broader protocol conformance is inferred.
