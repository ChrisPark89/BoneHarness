# Repository development harness

Use this entry point for normal work. For harness changes or drift, use [maintenance](../maintenance/harness-maintenance.md).

1. Read the current [profile](../shared/repo-profile.yaml), [derived status](../shared/harness-status.md), [workflow](workflow.yaml) and [installed rules](../shared/verification-rules.md). Pending capability/policy values authorize no dispatch.
2. Create `development/runs/<task-id>/` with [record templates](templates/) and a [task specification](task-spec.md). Capture a content baseline (Git is optional), pin configuration definitions, and initialize `events.yaml` at NEW/version 1. Before SPEC_READY use request and stage criteria; then capture accepted spec/design and criterion methods.
3. Follow the default sequence or an explicitly installed profile. At every gate separately review the due criteria and applicable tool evidence, record a transition request and gate decision, then let the single recorded writer commit an allowed event and refresh `state.yaml`.
4. Before external action, persist intent, exact inputs, absolute deadline and budgets; save the returned handle. On restart reconcile history and reconnect pending work. Use [RULE-10–RULE-12](../shared/verification-rules.md) for uncertainty, invalidation, adoption and resume.
5. Preserve every failure and refusal. A denied/blocked request does not mutate state; request its declared failure/stop route separately. Repair is disabled by default and needs the canonical profile policy plus new evidence.

`events.yaml` is authority; snapshots are derived. Default `LLM_PROTOCOL` enforcement is procedural. No runtime state writer is supplied. A configured TOOL must satisfy the installed conformance obligations. Report current state, changed scope, actual checks and provenance, evidence, pending limits and requested resolution. Completion follows the profile policy and grants no publication/merge authority.

## Task report at handoff

Generate and link the report at every handoff, including incomplete, blocked and completed tasks, and regenerate on resume or relevant evidence changes:

```text
python <harness-root>/development/report.py --repo-root <absolute-path> --harness-root <repo-relative-path> --task-id <one-directory-name>
```

Open `development/runs/<task-id>/report.md`; follow `report-data.json`, logs, reviews and earlier attempts for details. Exit 0 means declared record checks are consistent, not that the task is complete; exit 1 produces a report with issues; exit 2 is REPORT_UNAVAILABLE and previous outputs may be stale. The reference tool needs Python 3.11+ and provisioned [pinned dependencies](../shared/python/requirements.lock), or use the installation's conforming replacement. Do not install prerequisites automatically or fill a supposedly generated report by hand.

Reporting is an output obligation, not a development phase. It writes only derived reports; it cannot commit events, change state, approve skips, repair history or invoke development tools. Saved COMPLETE and supporting evidence are displayed separately. Mandatory source_content_inventory remains UNCHECKED until a supported source enumeration format is supplied, so the reference reporter currently cannot support a positive completion claim. Scoped NOT_APPLICABLE authority and user-approved skips remain unsupported and visible as unresolved/unverified; neither specification phase can be waived. Keep harness setup status separate from the task report.
