# Installed verification rules

Version: "1.0.0". These are procedural definitions. The default writer is `LLM_PROTOCOL`; no state tool or universal runtime engine is supplied. A configured `TOOL` must demonstrate the conformance requirements below. Schema checks establish record shape; comparisons, authorization, and truth of execution remain separate obligations.

For every request, record one `GateDecision` with findings for every applicable rule. `ALLOW` permits the single writer to commit the specifically requested edge against the expected version. `DENY` identifies a demonstrated failure and preserves state. `BLOCKED` identifies unresolved prerequisites and preserves state. Refusal is not a state transition. A stop/failure route needs its own request, evidence, decision, and committed event. Unknown rule IDs, unresolved verifier bindings, or ambiguous routes block progression. Rule findings use `PASS`, `FAIL`, `UNKNOWN`, or `BLOCKED`; criterion results use their separate five-value vocabulary.

## Finite triggers and resolution routes

`READY` means stage evidence and due review are satisfied, or dispatch prerequisites and durable intent are ready; it never means a guessed tool outcome. `PASS` and `FAIL` describe the validated matching invocation outcome, including target reduction, at execution stages. `UNKNOWN` records unresolved/malformed/absent terminal outcome. `BLOCKED` requests the declared safe stop for either an adapter BLOCKED outcome or a documented gate/prerequisite failure; it does not relabel an adapter PASS. The original Result and criterion/permission/budget findings remain unchanged. At other stages BLOCKED likewise identifies recorded unresolved prerequisites. `PENDING` is a known still-running invocation within its original deadline; it keeps the running state and grants no success. `DENIED` is the explicit request for the human-resolution route with diagnostics (including preflight failure); it is not automatic reinterpretation of any denied gate. `COMPLETED` means the recorded completion policy is satisfied. `RESOLVED` takes a stopped task to `RESUME_REVIEW` with specific resolution evidence. `repair_allowed` and `repair_denied` are mutually exclusive labels computed by RULE-09, never expressions evaluated as code.

Maintenance interprets finite labels through RULE-13–16: PASS is a satisfied compatibility/source/drift review, PENDING is missing evidence or a publication conflict, BLOCKED requests HUMAN_REQUIRED for policy, and REJECTED is known incompatibility. FAILED records interrupted publication. PENDING RESOLVED and HUMAN_REQUIRED APPROVED resume through INSPECTED. These maintenance outcomes do not reinterpret development adapter outcomes. The destination-aware no-action stop contract also applies to maintenance PENDING, REJECTED and FAILED: retain the cause findings and immutable inputs; do not require the failed success guard to pass merely to record its stop.

The remaining schema labels (`APPROVED`, `PENDING`, `RECONCILED`, `UNCHANGED`, `CHANGED`, `MISSING`, `INACCESSIBLE`, `INVALIDATED`, `ADOPTED`, `REQUESTED`, `CANCELLED`, `REJECTED`, `NOT_APPLICABLE`) belong only to explicitly declared consuming edges; an enum member alone creates no edge. `workflow.yaml` supplies concrete named `resolution_routes`: state pointers identify waiting, stopping, and resume procedures. A waiting route retains state and creates no new success or external action. An already stopped task retains its stop until resolution; a stop procedure for an active stage selects the declared stop transition; at build/test failure it must use the RULE-09 pair. A resume pointer requires the explicit `RESOLVED` transition from a stop first, or reevaluation in the current active stage. It cannot be committed as an arbitrary jump.

After `RESUME_REVIEW`, a request may name a concrete restore resolution route by its `DEV-...` ID in `transition_id`. RULE-11/12 permit only the recorded stopped-from stage, with all previously earned evidence still valid. A change enters RESUME_REVIEW through the declared INVALIDATED or ADOPTED transition, preserving its prior stage and impact evidence. A named review resolution route can then select an invalidation target only after RULE-12 establishes that exact earliest affected target. Failure states first take their exact repair-denied human stop route before invalidation review. These named procedures are selected by explicit ID and matching guards, not by searching several edges with the same outcome trigger. A route to a future or newly earned success is refused. Route self-entries do not count as another attempt; unresolved work remains stopped or retained. `COMPLETE` is historical and has no invalidation/resume edge; start a linked new task.

## Destination-aware safe-stop admission

Admission depends on the requested destination. A success, dispatch, repair-allowed or resume transition requires its relevant success guards to pass. For a declared transition into BLOCKED or HUMAN_REQUIRED, RULE-01 must validate the new request/current version and unique exact edge, RULE-02 must validate the stop request/decision/observation/post-state shapes (not require an invalid raw tool envelope to become valid), and RULE-11 must validate a coherent single-writer event history and preservation. The request must name the recorded cause, diagnostics, stopped-from state and required resolution. A corrupt authority or failed request/shape/writer check still prevents any commit.

For this safe-stop request, retain each original cause finding as FAIL/UNKNOWN/BLOCKED with its evidence. RULE-03–RULE-10 and RULE-12 assess diagnosis/preservation only: missing identity/criterion/applicability, revoked permission, exhausted/pending budget or unresolved operation need not become successful prerequisites merely to record the stop. They do not authorize actions. An ALLOW stop decision can therefore retain non-PASS cause findings, while the three admission rules pass. Unknown extension rules are diagnostic evidence rather than executed stop guards; only a fully installed, uniquely selected stop edge can commit. No stop dispatches/cancels/resubmits work, earns success, adopts configuration, changes accepted inputs, clears unresolved handles or increments repair/invocation counters. Preserve all results and historical verdicts; explicit later reconciliation/invalidation remains separate.

At BUILD_FAILED/TEST_FAILED, RULE-09 additionally verifies the recorded repair_denied selection and its concrete reasons. RULE-08 FAIL or RULE-10 UNKNOWN can be those reasons; they cannot veto a no-action HUMAN_REQUIRED stop. The repair_allowed edge still requires current permissions and execution budgets. A matching tool FAIL may record only its declared failure edge (with matching invocation identity and no execution); it cannot become PASS. A tool PASS plus missing criterion separately selects the existing BLOCKED edge with the criterion cause, never fabricates a tool BLOCKED Result.

## Records and writer protocol

Store runs under `development/runs/<task-id>/`: `task-spec.md`, accepted `task-spec.yaml`, derived `state.yaml`, authoritative `events.yaml`, `config-snapshot.yaml`, captured `configuration/`, `requests/`, `invocations/`, and `evidence/`. Before SPEC_READY the request plus installed stage criteria are authoritative; the accepted TaskSpec does not exist yet. Typed templates are examples, with fixture evidence, not execution records. Content identities are SHA-256 of captured bytes; define the request digest from deterministic JSON-compatible content excluding its own `request_content_identity`. Immutable referenced payloads have identities. Never mutate an invocation payload already referenced by a committed event: retain immutable intent/status revisions and reference the current revision in the next post-state.

Capture profile, workflows, rules, schemas, criteria and adapter definitions under `configuration/`; `config-snapshot.yaml` is the separate manifest, outside hashed definitions. Record external service versions or explicit limitations. Git is optional: capture a content manifest, relevant dirty/untracked files and working-tree inventory. Pin a configuration ID and definition identities per task. External definition changes require adoption or a stop. Publication of any canonical profile change, including readiness-only publication, advances both configuration revision and ID through maintenance. Existing tasks remain pinned; current permissions/access still govern every action.

Persist an invocation intent with request/run/task IDs, all inputs, an absolute UTC deadline, budgets and an immutable evidence reference before dispatch. Commit the intent reference and invocation counter in a complete task post-state before the external call; a running stage can therefore begin with intent and then record handle/status updates as versioned same-stage events. Count each submit/query/poll/cancel call under the declared call budget; elapsed time includes downtime. Use a service idempotency key when available. Save the handle immediately; intent-to-handle uncertainty remains `DISPATCH_UNRESOLVED`. Reconnect or reconcile by request ID, retaining every attempt. Never blindly resubmit an unresolved dispatch. Cancellation does not prove effects were undone.

For a commit, reread authority, apply each rule according to the requested destination and the safe-stop admission contract, verify unique writer, compare expected version, append one complete Event, then refresh state.yaml from its post_state. Initialization is previous version 0 to version 1 with null previous state. Each later event advances exactly one version, matches previous state/version/subject, has UTC time, unique request identity, actor, evidence, counter deltas and complete typed post_state. Deltas must equal post-state counter differences; repair entry increments only its origin once. Store decisions/refusals in requests; only committed events are authority. The complete post-state includes config adoption, accepted identities, input snapshot, targets, reviews, repair/invocation counters, pending invocation references, stop data, writer and evidence. A lost snapshot is restored by validating the complete committed sequence and copying its final post-state, comparing every field. Uncommitted proposals, torn records and conflicting histories cannot be promoted by conversation guesses.

Writer handoff requires a quiescent task, no unresolved dispatch or competing writes, old/new writer identities, latest version, and recorded transfer evidence in a same-stage event. Stop on conflict. `LLM_PROTOCOL` detects/reports inconsistencies but provides no atomic locking or bypass prevention. A `TOOL` binding must be resolved, versioned and policy accepted, serialize compare-and-append, preserve atomic committed history, validate schemas and all applicable rules, deduplicate exact replay, reject altered replay/stale versions, reconcile snapshots and immutable identities, preserve counters/deadlines, detect conflict, and expose durable refusal/decision evidence. Action adapters cannot write state. Host/CI enforcement and exactly-once external execution are not supplied by these definitions.

### RULE-01
Maintenance selector namespace: resolve UpdateRecord.request_type through maintenance-workflow.yaml extensions.request_type_profiles, a complete one-to-one mapping. Maintenance transition profiles must be known selectors in that mapping; development still resolves profiles through canonical repo-profile.workflow_profiles. Unknown/ambiguous selectors block. Rejected/failed corrective resolution creates a new linked update ID, not a transition on the old attempt.
Inputs: Request, committed log/current snapshot, selected transition or named resolution route, request digest and writer identity.
Method: Schema-aware comparison plus explicit route selection; inspect every applicable `(from, profile, trigger)` for uniqueness. Check request ID before current-version comparison for exact committed replay.
PASS: Exact replay returns the original event/outcome with no new event, invocation or counter. New request matches subject, current state/version, selected profile, route source and pinned identities.
FAIL: Altered reuse of ID, stale version, wrong state/subject, or changed immutable payload. No mutation.
UNKNOWN: Unknown rule, ambiguous edge, unknown request identity or unresolved configured verifier.
Route: DENY for demonstrated mismatch; BLOCKED for unresolved configuration. Any declared stop is requested separately. Both writer modes follow the same replay semantics.

### RULE-02
Inputs: Raw bytes, installed local schemas/version, scoped roots and durable references.
Method: Parse JSON-compatible YAML/JSON safely, rejecting duplicate/string-invalid keys, merge keys, tags, cycles, nonfinite numbers; validate schema and semantic UTC date-time. Resolve exact-case `/` paths within the declared root before reads; no remote schema retrieval. Check required fields and version/discriminator.
PASS: Record shape, typed booleans, version and readable permitted references are valid.
FAIL: Demonstrably invalid record/path/type/version; preserve raw bytes and diagnostics.
UNKNOWN: Missing/unreadable result or validator prerequisite unavailable. An absent/malformed envelope stays an Observation with interpreted_outcome UNKNOWN; do not synthesize a Result.
Route: Refuse the success request; request development BLOCKED or maintenance PENDING with raw observation/remediation. A parser/checker is optional; record actual alternative review coverage and limitations.

### RULE-03
Inputs: Intent and immutable status records, request, pinned manifest/binding, result, current task/source content identity and evidence accessibility.
Method: Compare task/run/capability, configuration ID, adapter identity/version/content identity, adapter_definition_id, revision and request accepted identities to captured inputs. Include relevant dirty/untracked content; a matching Git base alone is insufficient.
PASS: All expected identities match and evidence is usable; existing task uses captured configuration A even when canonical B exists.
FAIL: Any run/config/source/diff/adapter/spec identity mismatch; retain stale result for diagnosis.
UNKNOWN: Missing identity, inaccessible external service version with material effect, changed uncaptured definitions or unresolved drift impacting invocation.
Route: DENY a proven mismatch, otherwise BLOCKED; separately stop/reconcile and invalidate under RULE-12. Never consume a late result for different inputs.

### RULE-04
Inputs: Pinned binding normalization, invocation inputs, selected required target/environment set, every child result, build artifact and separate product/test-source identities.
Method: Compare exact required sets (no silent exclusion), environments, source/test identities and artifact identities/references. Trusted pinned binding requirements govern even when returned selector fields are absent or false. A contradictory selector blocks. Successful build needs artifact when consumed downstream; test binding can require test_source and its artifact_identity even if no local selector was returned. Source-only tests compare source identity without inventing a build artifact.
PASS: Complete matching lineage and required target coverage, including both repositories for cross-repo tests. No irrelevant future-stage artifact is required.
FAIL: Demonstrated target/environment/test revision/consumed artifact mismatch or denied scope selection.
UNKNOWN: Unresolved targets or required lineage missing/unreadable. Target reduction: a known running child retains running status within deadline, before reducing terminal outcomes. Once terminal outcomes are due, missing/malformed/mismatched/UNKNOWN wins, then BLOCKED, then FAIL, otherwise PASS. Preserve every child result and all findings. No repair while a child is unresolved.
Route: Unknown targets block planning. Deny mismatches, retain diagnostics, request BLOCKED stop/reconciliation. Only a complete matching reduced FAIL may reach its failure state and then repair policy.

### RULE-05
Inputs: Required execution obligations, matching adapter outcome/provenance, criterion method and actual output evidence.
Method: Inspect tool-reported status without upgrading it; compare evidence origin to obligation. FIXTURE establishes interface compatibility only; real invocation needs EXECUTION, actual permitted review needs REVIEW.
PASS: Matching actual PASS supports execution criterion and independent LLM review is satisfied; a valid matching FAIL supports only its failure edge. Optional unavailable native validation is explicitly absent.
FAIL: FAIL presented as success, fixture substituted for actual execution, or LLM opinion replacing required execution.
UNKNOWN: BLOCKED/UNKNOWN/missing outcome or provenance/actual evidence unresolved.
Route: DENY false success; a valid FAIL requests respective failure state separately, then RULE-09 (preflight uses human resolution). Unknown outcomes stop BLOCKED separately. Never fabricate optional native validation.

### RULE-06
Inputs: Request/installed stage criteria before SPEC_READY; accepted TaskSpec afterward, due-stage matrix, criterion-level LLM review and applicable tool/native results.
Method: Join criteria by ID/version, check due_state, allowed method, evidence, required flag and unresolved findings. Independently inspect actual work/diff against each due criterion; copying a tool summary is insufficient. SPEC_VERIFIED reconciles every required criterion.
PASS: For advancement, every required due criterion has justified PASS or permitted NOT_APPLICABLE with evidence, alongside every required execution result. For a safe-stop request, record the due criterion failure/missing coverage unchanged as its cause; admission uses the safe-stop contract, not satisfaction of that criterion. TEST_READY means a verification plan exists; build review does not demand later test evidence.
FAIL: Demonstrated unmet criterion, disallowed method or blanket unsupported approval.
UNKNOWN: Missing coverage, PENDING/BLOCKED criterion, insufficient evidence or unresolved finding.
Route: DENY demonstrated failure or BLOCKED insufficient evidence; retain valid tool PASS. Request separate BLOCKED stop with criterion ID/remediation, without committing success.


Default development stage criteria (version "1.0.0", all required) are installed here. They are independent of the installation criteria catalogue. Before SPEC_READY assess these against the captured request and repository evidence; afterward include them with task acceptance criteria. LLM_REVIEW always means actual independent criterion-level REVIEW evidence. AUTOMATED means the applicable binding's actual EXECUTION report in addition to that review; an explicitly policy-accepted human execution binding may declare HUMAN_REVIEW with actual invocation evidence. Method permission never permits review opinion to replace a required execution result. A pending future execution binding can be exposed in a complete planning record; dispatch/success still blocks at its own gate. Review only criteria due at the proposed success destination, including task criteria due there. SPEC_VERIFIED reconciles the full required task acceptance matrix; later D-FINAL-REVIEW/D-COMPLETE delivery obligations remain due at their own stages. Explicit profile exceptions assess the affected built-ins as NOT_APPLICABLE with authority and replacement evidence; they never fabricate a build/test pass.

| ID | Due success state | Allowed methods | Minimum evidence |
|---|---|---|---|
| D-BASELINE | BASELINED | LLM_REVIEW | Content input snapshot including dirty/untracked or non-Git manifest; working-tree inventory; relevant instruction files, scopes and identities; writer/config pin. |
| D-RESEARCH | RESEARCHED | LLM_REVIEW | Source references/accessibility, evidence-backed findings and assumptions; unresolved questions with impact and resolution/stop needed; no unsupported repository fact. |
| D-PATTERN | PATTERN_VERIFIED | LLM_REVIEW | Inspected reusable patterns with source/fit evidence, or justified pattern absence/NOT_APPLICABLE with policy/scope authority; unresolved risks. |
| D-SPEC | SPEC_READY | LLM_REVIEW | Accepted specification/design/request identities and acceptance authority; observable criterion IDs, due states, allowed methods, required flags; scope/non-goals, selected profile and targets. |
| D-VERIFY-PLAN | TEST_READY | LLM_REVIEW | Verification method/evidence plan for every required criterion and target; known missing capability/deadline/access prerequisites and planned stop/remediation, without inventing commands/results. |
| D-IMPLEMENT-PLAN | PLAN_READY | LLM_REVIEW | Implementation tasks mapped to criterion IDs, expected changed paths/scope, dependencies/order, planned checks and exposed execution prerequisites. |
| D-IMPLEMENT | IMPLEMENTED | LLM_REVIEW | Actual changed-content/diff identity and path inventory compared to accepted scope and implementation tasks; expected in-scope edits captured, unresolved deviations recorded. |
| D-PREFLIGHT-INTENT | PREFLIGHT | LLM_REVIEW | Current source/targets/environment and configured preflight binding/permission/budgets; durable preflight intent, proposed invocation counter +1 and pending reference before dispatch. |
| D-PREFLIGHT | PREFLIGHT_PASSED | AUTOMATED + LLM_REVIEW | Matching required preflight execution result/target coverage on actual source; independent criterion review, diagnostics and optional native-validation availability. |
| D-BUILD-INTENT | BUILDING | LLM_REVIEW | Configured build binding, current authorization/remaining budgets, exact source/targets/environment; durable build intent, proposed counter +1 and pending reference before dispatch. |
| D-BUILD | BUILD_PASSED | AUTOMATED + LLM_REVIEW | Matching actual build outcome and independent due review; required target coverage; artifact identity/reference when pinned binding consumes it downstream. |
| D-TEST-INTENT | TESTING | LLM_REVIEW | Configured test binding/current authority/budgets; product and separate test-source identities and consumed artifact where required; durable test intent, proposed counter +1 and pending reference. |
| D-TEST | TEST_PASSED | AUTOMATED + LLM_REVIEW | Matching actual test outcome/targets, both source revisions and required artifact lineage; independent due criterion review and unresolved findings. |
| D-SPEC-FULL | SPEC_VERIFIED | LLM_REVIEW | Full required task acceptance matrix with fresh evidence and criterion-level verdicts; justified NOT_APPLICABLE authority/replacement evidence; no uncovered criterion. |
| D-FINAL-REVIEW | READY_FOR_REVIEW | LLM_REVIEW | Independent final diff/scope review, explicit unresolved risks and documentation decision/evidence; completion prerequisites exposed for acceptance. |
| D-COMPLETE | COMPLETE | LLM_REVIEW | Recorded completion policy, required criteria/execution obligations and acceptance authority satisfied; current evidence; completion grants no merge/publication permission. |

Repository/task extensions: the coordinating LLM must inspect local instructions and request intent, add concrete repo/task-specific criterion IDs, due stages, allowed methods, required flags and evidence minimums in the accepted TaskSpec, and record source/acceptance authority. Retain these default prerequisites; an extension may strengthen them or use an explicitly accepted profile applicability/replacement rule. Do not silently remove a due criterion, invent a command, infer approval or use builder/private notes. A newly required method/edge/rule must be installed and configuration-pinned; changes after acceptance follow RULE-12 reacceptance/invalidation. Record unresolved questions with impact rather than approving an unsupported assumption.

### RULE-07
Inputs: Selected task type/profile, accepted scope, targets and evidence-backed applicability authority, replacement criteria and canonical profile publication.
Method: Check exactly one active profile recognized by repository evidence. Default compiled sequence is active initially; source-only/docs edges are examples until explicitly installed under policy. Profile exception requires applicable scope, alternate edge, replacement evidence and accepted NOT_APPLICABLE stages.
PASS: Recognized unique profile/targets with justified applicability. Pattern absence may be evidence-backed. Source-only uses PREFLIGHT_PASSED→TESTING; docs uses PREFLIGHT_PASSED→SPEC_VERIFIED after required doc checks.
FAIL: Ad hoc skip, invented build/test PASS, product-code change still classified docs, or unsupported NOT_APPLICABLE.
UNKNOWN: Unrecognized type/target, ambiguous selection, pending required capability or missing acceptance authority.
Route: BLOCKED/HUMAN_REQUIRED clarification; reclassify and explicitly invalidate affected evidence. Preparatory stages may proceed only if their own criteria pass; missing execution gates cannot.

### RULE-08
Inputs: Current authorization/access, pinned binding side effects and permissions, repository policy, scoped approval, live relevant readiness/drift findings and planned action.
Method: Recheck immediately before every new external action; compare exact scope/candidate/action to current approval. Pinning never overrides revocation or lost access.
PASS: Action lies within current scope and permitted effects with required current authority.
FAIL: Revoked approval, prohibited effects, out-of-scope repair/dispatch or mismatch with approved candidate.
UNKNOWN: Pending policy, credentials/access unavailable, conflicting instructions or unresolved affecting drift.
Route: No dispatch. Request BLOCKED reconciliation or HUMAN_REQUIRED policy decision; preserve intent/history and external uncertainty.

### RULE-09
Inputs: Originating matching terminal failure, profile repair_policy, durable origin counter, prior hypotheses/diagnostics, proposed repair scope/permissions and unresolved children.
Method: Compute repair_allowed iff enabled AND positive configured limit AND used < limit AND new diagnostic evidence or materially revised evidence-grounded hypothesis AND actions fit scope/current permission AND required execution policy/deadline/call/time budgets are resolved with remaining budget for planned calls AND no unresolved child. repair_denied is its complement; record all rejection reasons. Disabled defaults and zero limits are canonical in repo-profile.yaml. The repair_policy extension requires build/test origin objects: enabled is an explicit boolean, max_attempts a nonnegative integer, route_after_repair is PREFLIGHT, shortcut_rule is null or a declared rule reference. Invalid/unresolved policy types cannot be interpreted as permission.
PASS: repair_allowed commits REPAIRING and exactly one origin-counter increment. repair_denied commits HUMAN_REQUIRED with precise reason and no increment. Restart preserves counters.
FAIL: Increment on replay, attempt despite disabled/exhausted policy, unchanged hypothesis, out-of-scope action, or budget reset.
UNKNOWN: Missing budget/hypothesis/terminal child reconciliation; record repair_denied with unresolved prerequisite, stop for human resolution without repair.
Route: BUILD_FAILED and TEST_FAILED have exactly the two policy transitions. REPAIRING returns through PREFLIGHT, fresh build and tests. A test-only shortcut requires an explicitly adopted profile, declared dependency/artifact-validity rule, unique alternate edge and complete validity evidence; no shortcut is enabled in the supplied graph. Invocation budgets remain independently mandatory. Budget increases need recorded policy authority.

### RULE-10
Inputs: Persisted intent/handle/status, absolute UTC deadline, total elapsed/call counters, binding dispatch and reconciliation procedures, all child observations and current clock.
Method: Check budgets before submit/query/poll/cancel, include downtime, and reconcile unknown dispatch by request ID/service evidence. Save immutable status/handle revisions. A known running child within deadline yields PENDING even alongside a terminal FAIL; terminal reduction follows RULE-04.
PASS: Resolved policy and remaining budgets permit one authorized call; saved handle reconnects same operation. Completed matching result is consumed once.
FAIL: Deadline/call budget exceeded, reset on restart, or blind second submit under unresolved dispatch.
UNKNOWN: Lost handle after dispatch, absent terminal result, inaccessible service or unknown effects. Retain DISPATCH_UNRESOLVED and reconciliation/cancellation evidence.
Route: Stay running only while genuinely running within deadline. At expiry stop BLOCKED with Observation UNKNOWN and reconciliation status; do not claim cancellation undid effects or exactly-once submission. No repair with unresolved children.

### RULE-11
Inputs: Full ordered committed events, derived snapshot, immutable referenced payloads, configured writer, pending invocations, stopped-from data and resolution evidence.
Method: Validate sequence/subjects, previous/next state/version, post-state equality, deltas, writer and request identities. Replay every mutable field, not only state/version. Rebuild lost/stale snapshot solely from complete committed post-states; compare every field. Reconcile external operations before resume/handoff.
PASS: One writer, consistent committed history and references. Quiescent recorded handoff is valid. In development, RESOLVED reaches RESUME_REVIEW; guarded restore route can only recover the recorded stage with still-valid earned evidence. Maintenance resumes through INSPECTED and may RECONCILED-restore only its evidenced previously accepted publication for status recovery under RULE-14/16.
FAIL: Conflicting writer, corrupt/torn event, altered immutable reference, uncommitted proposal as authority, or stop-to-new-success jump.
UNKNOWN: History gaps, unreconciled operation, inconsistent snapshot or missing resolution evidence.
Route: Stop work for reconciliation (development BLOCKED or maintenance PENDING separately when a coherent state can be committed); do not append to corrupt authority. Procedural detection is not atomic/tool enforcement. TOOL must meet the protocol conformance obligations above.

### RULE-12
Inputs: Old/new accepted identities and content snapshots, old/candidate config manifests, impact analysis, prior criteria/results, stopped-from stage and new resolution authority.
Method: Preserve past reports, mark affected verdicts superseded with explicit references/reasons, then select exactly one conservative target. Accepted spec/scope/design change returns PATTERN_VERIFIED or earlier for changed research/patterns. Unexpected early external source changes return earliest invalidated stage, NEW if impact unknown. Ordinary in-scope implementation edits are captured at IMPLEMENTED. Product/test edits after implementation return IMPLEMENTED. Adoption compares pinned A to candidate B, records new config manifest/ID in complete post-state and reruns affected gates; execution changes after implementation default IMPLEMENTED. Earlier valid preparation may remain at its current stage.
PASS: Explicit impact/evidence selection and adoption authority, only unaffected evidence retained with dependency justification. Restoring previously earned state requires its still-valid evidence. Resume cannot grant a newly earned success or bypass its gate.
FAIL: Silent spec rewrite, blanket retained PASS, silent adapter/config switch, unsupported shortcut, or use of stale late result.
UNKNOWN: Unclear impact, missing definitions/authority or unresolvable external result.
Route: Request named invalidation/adoption resolution route to its justified target; DENY unsupported target. Reconcile stopped task through RESUME_REVIEW for unchanged restore; affected configuration/spec enters RESUME_REVIEW with explicit invalidation/adoption evidence before selecting the justified target. Old reports and history survive. Completed task stays historical; create linked new work.

### RULE-13
Inputs: Request type, exact staged candidate, inspected base, declared interface/input/result schemas, four outcome fixtures, identity/evidence/status mapping, failure/unknown routing, invocation policy, source evidence and migration checks/approval.
Method: Inspect format/routing/policy only; do not execute or judge production tool quality. Apply precedence: known incompatibility REJECTED; otherwise missing evidence PENDING; otherwise unresolved policy or scoped approval HUMAN_REQUIRED; otherwise eligible. A well-formed PASS, FAIL, BLOCKED or UNKNOWN fixture can satisfy compatibility, with FIXTURE provenance. Absent/malformed results remain raw observations. A migration must provide supported resulting definitions, affected schema/structure/scenario/readiness checks and exact approval; ordinary no-expansion conditions do not apply to its approved expansion.
PASS: Candidate can supply all required fields/identities/evidence and safely route every supported outcome under applicable permissions; or fact correction has authoritative source and policy support; or approved migration satisfies all affected checks. Compatibility does not establish production success.
FAIL: Unsupported status/interface with no supported migration, unsafe routing, proven forbidden effects or contradicted fact. Approval cannot waive incompatibility.
UNKNOWN: Required input/result/source evidence missing, or unresolved policy/approval. Preserve all findings and use the precedence above even when several apply.
Route: STAGED PASS selects ADAPTER_COMPATIBLE, SOURCE_VERIFIED or MIGRATION_CHECKED by request selector; REJECTED/PENDING/BLOCKED select REJECTED/PENDING/HUMAN_REQUIRED. A discovered migration in an ordinary request creates a linked MIGRATION record; do not rewrite the original request type/history.

### RULE-14
Inputs: Complete staged candidate/manifest, exact scope, current authority, inspected base revision/ID and before-values, prospective ID, checks, approval and durable publication intent/receipts.
Method: Ordinary READY requires same-capability supported interface and no permission expansion under recorded policy (fact changes need authoritative evidence). Migration APPROVED requires exact candidate hash, base ID and scope approval plus satisfied affected checks, permitting its reviewed expansion. Before writing, compare current base/revision, adapter/source/file identities and affected before-values; any mismatch requires reinspection/restaging and renewed approval. Assess prospective new ID; record dependency-based revalidation of retained assessments or PENDING. Persist intent including candidate/base/prospective IDs and manifest identity before writes. Publish all inventoried migration files plus profile, or ordinary canonical profile, as one configuration revision. Record attempt/writer and per-file before/after hashes in immutable write receipts. Verify complete file set before accepting publication and committing its result/event. No self-hashed manifest.
PASS: One complete verified publication, fresh revision/ID and assessments naming that same ID, justified retained evidence, checked current permissions. Immediately derived readiness is current. Reconciliation may restore an already committed PROMOTED/ASSESSMENT_PUBLISHED stage only with its same accepted ID and complete evidence, never a new promotion.
FAIL: Stale approval reuse, overwritten newer values, incomplete/mixed configuration accepted, hidden file, relabelled stale assessment or publication outside scope.
UNKNOWN: Conflict, missing evidence/authority, unresolved publication or current access. No new work consumes mixed files; procedural mode detects and stops but provides no atomic locking guarantee.
Route: Before publication, PENDING returns through INSPECTED with new evidence; policy BLOCKED enters HUMAN_REQUIRED. An interrupted write enters FAILED under RULE-15. Accepted publication reaches PROMOTED then derived STATUS_UPDATED; failure to render Markdown alone never invalidates its publication. After resume through INSPECTED, RECONCILED restores only an evidenced prior accepted publication for status regeneration. Never rerun its writes.

### RULE-15
Inputs: Committed history, complete candidate/base manifest and intent, immutable per-file write receipts tied to attempt/writer, current file hashes/ownership, accepted configuration identity, later accepted updates and restoration evidence.
Method: Reconcile complete files before any new work. For incomplete unaccepted publication, restore a recorded before-value only if this attempt actually wrote the path and its current identity still equals that write; capture restoration receipts. Do not restore untouched paths, user edits or newer accepted writes. Validate the complete last accepted configuration after safe restoration. If the change was already accepted, restoring its values is a linked normal checked publication with a fresh configuration revision/ID and prospectively assessed evidence; never reinstate an old accepted ID as a new current revision. Stale derived Markdown alone is independently regenerated after confirming accepted files/history.
PASS: Incomplete candidate safely removed with last accepted configuration intact; or newer values preserved and unresolved recovery explicitly blocked; or a linked accepted restoration meets RULE-14/16. Retain failed attempt, candidate, receipts and corrective links.
FAIL: Blind overwrite, claiming restoration without file evidence, restoring old accepted revision identity, or new work on mixed/unverifiable files.
UNKNOWN: Ownership/receipt/current identity missing or conflicting. Record FAILED recovery and affected integration BLOCKED, preserve current bytes, require reconciliation. If canonical blocker findings are published, they themselves require checked prospective assessment and fresh revision; otherwise the unresolved recovery record is the stop authority, not an unversioned profile edit.
Route: Publication FAIL enters FAILED, preserving result/recovery evidence. REJECTED/FAILED resolution creates a linked new update ID, never retries the closed attempt. Drift keeps promotion/rollback NOT_APPLICABLE; analogous assessment-only recovery is recorded in checks/evidence with the same ownership/version safety, never binding rollback. PENDING/HUMAN_REQUIRED resume via INSPECTED. Conflicting/corrupt history stops without appending fabricated authority.

### RULE-16
Inputs: Declared watched sources and identities/accessibility, inspected configuration/revision and adapter/before-values, affected required capability/target sets, proposed assessment values, prospective ID and dependency revalidation evidence.
Method: Compare only watched sources; classify UNCHANGED/CHANGED/MISSING/INACCESSIBLE and retain evidence, including policy/access blockers. CHANGED/MISSING marks affected compatibility NEEDS_REVIEW; INACCESSIBLE leaves compatibility NEEDS_REVIEW with access blocker. Recompute readiness per required capability/target set; isolate optional unrelated capability impact. Before assessment publication compare current base, adapter/source identities and affected before-values. Assess staged prospective new configuration ID, revalidate retained assessments with unchanged-dependency justification or PENDING, publish profile and fresh revision/ID, verify assessments refer to that new ID. No canonical change means no revision; accepting a new assessment counts as a change even if watched sources are unchanged.
PASS: Findings are supported and current at publication; readiness is current immediately after publication, though it may be BLOCKED/PARTIAL. DRIFT_ASSESSED CHANGED means accepted assessment publication only. UNCHANGED means closeout with no canonical mutation. Completion with adverse findings makes no integration-ready claim.
FAIL: Stale A review changes B readiness, optional unrelated failure lowers unaffected profile, binding/fact silently changed, or old assessment simply relabelled to new ID.
UNKNOWN: Stale base, source/access uncertainty or incomplete publication. Retain findings as history; stale identity requires PENDING reinspection. Supported inaccessible-source findings can themselves be published as blockers. Reconcile interrupted assessment publication before new work; never claim success from mixed files.
Route: STAGED PASS reaches DRIFT_ASSESSED. UNCHANGED closes through STATUS_UPDATED; CHANGED reaches ASSESSMENT_PUBLISHED then STATUS_UPDATED. No binding promotion edge. Record promotion/rollback NOT_APPLICABLE. A suggested correction creates a linked adapter/fact/migration attempt with full ordinary checks. Current revocation/access/affecting drift blocks new task dispatch even on pinned configurations under RULE-08.

### RULE-17
Inputs: Canonical pinned completion_policy, full acceptance matrix, execution/review evidence, final diff/risk/documentation review and acceptance authority.
Method: Check configured terminal state, all required criteria/capabilities and recorded authority under current permissions. Do not infer completion from reaching READY_FOR_REVIEW.
PASS: Explicit completion condition met and evidenced; commit COMPLETE once.
FAIL: Required criterion or execution obligation demonstrably fails, or proposed completion contradicts policy.
UNKNOWN: Completion policy pending, missing approval/evidence, unresolved risks required by policy or unfinished due coverage.
Route: DENY failed completion or BLOCKED unknown condition; retain READY_FOR_REVIEW then request a declared stop if needed. COMPLETE itself authorizes no merge, publication or deployment.

## Task-report contracts (display and evidence checks only)

The local [task-report schema](schemas/task-report.schema.json) defines independent
`TaskReport` version `1.0.0` and `PhaseMap` version `1.0.0`. Reporting does not
change RULE-01 through RULE-17, tool-result statuses, profile permissions, guards,
accepted task criteria or state. Report display statuses are `PASS`, `FAIL`,
`BLOCKED`, `IN_PROGRESS`, `USER_SKIPPED`, `NOT_APPLICABLE`, `NOT_RECORDED` and
`UNVERIFIED`; they are never written back into a tool result or transition.

### Pinned phase mapping and stage catalogue

Use only the task's pinned `workflow.extensions.reporting`, preserving custom
phase IDs/labels, the selected profile and every declared phase row. Validate
shape using `$defs.PhaseMap`. Then check unique phase IDs/orders and criterion
IDs, profile selectors, known state references, and an exact partition: every
workflow state occurs exactly once across every phase's success/active/failure
states and `control_states`. Reject duplicate assignments even within one phase.
Each phase criterion reference resolves to one stage criterion whose due state
belongs to that phase. A criterion due at a control state (notably `D-COMPLETE`)
remains in the catalogue and in completion checks. These joins check metadata;
they do not add graph edges or reconstruct outcomes from display names.

The sixteen built-in stage IDs in the development map transcribe the installed
RULE-06 table, including intent criteria and delivery/completion criteria. At
installation check exact due states, required flags and allowed methods against
that table. All built-ins require independent criterion review. `D-PREFLIGHT`,
`D-BUILD` and `D-TEST` additionally require actual execution; their two listed
methods are not interchangeable substitutes. The intent criteria assess durable
intent and prerequisites before dispatch, so they do not require the future
execution result. A policy-accepted human execution binding or profile exception
needs its pinned policy, scope/authority and replacement evidence. An unknown
alternative remains unchecked. Keep task acceptance criteria in the accepted
TaskSpec, and classify them separately by the exact pinned stage ID catalogue;
never use an ID prefix or convert minimum-evidence prose into executable rules.

The map includes twelve work phases and a separate repair row. `NEW`, `BLOCKED`,
`HUMAN_REQUIRED`, `RESUME_REVIEW` and `COMPLETE` are control states. Attribute a
stop only to its recorded origin. Missing origin yields
`REPORT_STOP_ORIGIN_MISSING`; missing or ambiguous mappings yield
`REPORT_PHASE_MAP_INVALID`/`REPORT_STATE_UNMAPPED` and visible unmapped-state rows,
with unchecked coverage. Profile exclusion alone never establishes a supported
`NOT_APPLICABLE` outcome or authorizes skipping a phase.

### Legacy matching and unsupported skip claims

A pinned development workflow without the reporting extension may use only the
immutable bundled [legacy descriptor](reporting-legacy-baseline.json). Remove
only `extensions.reporting` from the captured workflow; preserve every other
field and array order. Compute SHA-256 over canonical JSON (sorted object keys,
UTF-8, compact separators, no non-finite numbers). Use the descriptor's fixed
phase map only when this fingerprint exactly matches `workflow_identity` and
its `reporting_map_version` matches the fixed map version. Do not compare just
state names, select a live repository workflow, or guess a near match. A match
supplies display metadata only and does not prove any recorded transition valid.
A nonmatching legacy pin gets `REPORT_LEGACY_MAP_UNSUPPORTED`, visible observed
unmapped states and `UNVERIFIABLE` record-check coverage.

Section 12 skip transitions and trustworthy user-instruction provenance are a
pending integration dependency; this reporting metadata installs no skip edge.
A skip unsupported by the pinned graph remains `UNVERIFIED` with the recorded
claim and `REPORT_SKIP_UNSUPPORTED`, even when an asserted approval is present.
A supported future skip additionally needs independently identifiable actual
user authority, exact scope and references; an LLM assertion alone yields
`REPORT_SKIP_AUTHORITY_UNVERIFIED`. Neither `SPEC_READY` nor `SPEC_VERIFIED` can
be accepted as skipped (`REPORT_MANDATORY_PHASE_SKIPPED`). Preserve all accepted
specification requirements and setup readiness.

### Report data, diagnostics and truthful coverage

Keep recorded task state separate from `record_checks` (`CONSISTENT`,
`ISSUES_FOUND`, `UNVERIFIABLE`) and `completion_support`
(`SUPPORTED_BY_CHECKED_RECORDS`, `UNSUPPORTED`, `NOT_RECORDED_COMPLETE`). Any
unchecked mandatory mechanical obligation prevents supported completion.
Unsupported evidence changes a displayed outcome to `UNVERIFIED` while retaining
`recorded_claim`. `NOT_RECORDED` states only that no outcome was recorded.

The schema's `Diagnostic` definition fixes every `REPORT_*` diagnostic code and
its display message. Use the matching message verbatim; place source/criterion
context in typed references and nullable IDs, not interpolated display prose.
`diagnostic_refs` contains these codes; repeated codes identify every matching
entry in the full diagnostics list. `detail_code` uses stable `REPORT_*` wording
keys. Repository-specific facts stay escaped in report context and linked
records; unsupported extra diagnostic formats remain explicitly unchecked.

`source_manifest` contains exact-byte SHA-256 identities and scoped paths for
all inspected inputs, including pinned definitions and referenced evidence,
sorted by `(scope, path)`. Exclude `report.md` and `report-data.json`. Keep missing
or inaccessible files in diagnostics rather than inventing identities. Compute
`generation_id` as lowercase unprefixed SHA-256 over canonical JSON with exactly
`source_manifest`, `generated_at`, `generator_version` and `report_version`.

`specification_coverage.task_acceptance` and `.stage_progression` preserve
criterion rows and separate required/satisfied/failed/unresolved counts. Count
permitted `NOT_APPLICABLE` as satisfied only with its required authority/evidence
and retain that individual row. An empty/unmapped task matrix stays unresolved;
zero requirements does not establish completion. Conflicting verdicts without
valid recorded supersession stay unresolved; timestamps and directory order do
not choose a winner. Preserve failure/repair attempts and their evidence links,
using only the validated committed history prefix and diagnosed invalid suffix.

`coverage.checks` declares mandatory mechanical checks as `CHECKED`, `UNCHECKED`
or evidenced `NOT_APPLICABLE`; check outcome issues remain in diagnostics.
`coverage.semantic_reviews` attributes each reviewed criterion, claim, method,
actor, basis and limits. Hash checks establish identity, not authorship or tool
quality. `coverage.platforms` records actual `NATIVE_EXECUTION` evidence or
`NOT_RUN` per operating system; simulated execution never proves native support.
No generator invocation, conformance definition or schema-valid record alone
establishes observed execution or semantic correctness.

### Reporting installation and handoff

Install and inventory the report schema, immutable legacy descriptor, shared I/O/dependency lock, CLI, capture/summary/renderer modules and declarative template. ConfigSnapshot captures their exact bytes using SCHEMA, SUPPORT and REPORTING_TEMPLATE; captured support is data, never arbitrary executable verification. Installation IS-04.graph checks the local map and exact built-in RULE-06 parity; file/local-schema checks include these additions. Reporting metadata changes no workflow permissions.

Generate/link a task report at every handoff (completed, blocked or incomplete), on resume and after relevant evidence changes. Use the installed report.py with explicit repository/harness/task arguments. Report REPORT_UNAVAILABLE when reference prerequisites or the conforming replacement are unavailable; handwritten prose is not generated evidence. Installation records availability independently of structure and checker status. Reporting cannot repair/mutate state, records or sources.

The source snapshot ContentIdentity has no supported source enumeration protocol. Mandatory source_content_inventory remains UNCHECKED, which prevents SUPPORTED_BY_CHECKED_RECORDS in the reference reporter until supported enumeration is supplied. The pending user format question grants no authority to invent a protocol. Criterion records do not yet support scoped NOT_APPLICABLE authority; those claims remain unresolved. Section 12 user-skip transitions/approval records and their mechanical checks are pending; USER_SKIPPED assertions remain UNVERIFIED.
