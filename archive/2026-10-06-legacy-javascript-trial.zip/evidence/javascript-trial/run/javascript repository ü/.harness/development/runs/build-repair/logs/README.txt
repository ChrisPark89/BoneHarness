Only actual Node calls have execution logs. State, review and policy records are SCENARIO FIXTURES. No log means no command was executed for that checkpoint.
