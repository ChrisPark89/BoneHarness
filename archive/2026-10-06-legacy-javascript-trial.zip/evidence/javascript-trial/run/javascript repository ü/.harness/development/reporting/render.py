"""Render a captured TaskReport; no source reads or new evidence verdicts.

extensions.reporting.presentation carries captured template_text/template_identity,
template_reference, repo_root, harness_root, run_root, specification_refs, evidence_roles and
publication_diagnostics. CLI supplies this JSON-compatible context once.
"""
import hashlib
import html
import os
from pathlib import Path, PureWindowsPath
import re
from urllib.parse import quote, urlsplit

_START, _END = '{{#phases}}', '{{/phases}}'
_TOKENS = {
    'task_title', 'derived_summary', 'recorded_state', 'check_result',
    'target_and_environment', 'specification_link', 'generated_at',
    'task_id_and_source_label', 'satisfied_required', 'total_required',
    'failed_required', 'unresolved_required', 'criteria_details_link',
    'up_to_three_issues_with_direct_links_or_none', 'previous_failure_and_repair_counts',
    'attempt_history_link', 'source_manifest_and_full_diagnostics_links',
}
_TOKEN = re.compile(r'{{([A-Za-z_]+)}}')
_DETAILS = {
    'REPORT_OUTCOME_SUPPORTED': 'Matching recorded support',
    'REPORT_OUTCOME_UNVERIFIED': 'Supporting evidence unresolved',
    'REPORT_NOT_RECORDED': 'No outcome recorded',
    'REPORT_STATE_UNMAPPED': 'State mapping unresolved',
}
_METADATA = re.compile(r'<!-- task-report generation_id=([a-f0-9]{64}) json_sha256=([a-f0-9]{64}) -->')
_BEFORE_LINES = (
    '## Task report: {{task_title}}', '', '**Summary:** {{derived_summary}}', '',
    '**Recorded task state:** {{recorded_state}} · **Record checks:** {{check_result}}', '',
    '**Scope:** {{target_and_environment}} · **Specification:** {{specification_link}}', '',
    '**As of:** {{generated_at}} · **Task / source version:** {{task_id_and_source_label}}', '',
    '| Phase | Status | Result or issue | Evidence |', '|---|---|---|---|',
)
_AFTER_LINES = (
    '', '', '**Specification coverage:** {{satisfied_required}}/{{total_required}} required criteria satisfied; {{failed_required}} failed; {{unresolved_required}} unresolved. {{criteria_details_link}}',
    '', '**Needs attention:** {{up_to_three_issues_with_direct_links_or_none}}',
    '', '**History:** {{previous_failure_and_repair_counts}}. {{attempt_history_link}}',
    '', '{{source_manifest_and_full_diagnostics_links}}',
)


class ReportRenderError(ValueError):
    """A declarative template or captured presentation context is unsafe."""


def escape_text(value):
    """One-line literal Markdown/table text, including HTML and controls."""
    text = str(value) if value is not None else 'Not recorded'
    text = ''.join(' ' if ord(char) < 32 or ord(char) == 127 or char in '\u2028\u2029'
                   else char for char in text)
    text = html.escape(text, quote=False)
    return re.sub(r'([\\`*_{}\[\]()#+.!|>~\-])', r'\\\1', text)


def template_parts(text):
    """Allow only the approved outer fields and one fixed phase-row repeat."""
    if not isinstance(text, str):
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: require a UTF-8 template.')
    # Grammar permits native CRLF; identity still hashes the exact captured bytes.
    text = text.replace('\r\n', '\n')
    if text.count(_START) != 1 or text.count(_END) != 1:
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: require one phase repeat section.')
    before, rest = text.split(_START)
    row, after = rest.split(_END)
    expected_row = '\n| {{phase_label}} | {{status}} | {{short_recorded_detail}} | {{links}} |\n'
    if row != expected_row:
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: malformed fixed phase row.')
    outer = before + after
    tokens = _TOKEN.findall(outer)
    remainder = _TOKEN.sub('', outer)
    if set(tokens) != _TOKENS or any(tokens.count(token) != 1 for token in _TOKENS):
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: missing, repeated or unknown field.')
    if '{{' in remainder or '}}' in remainder:
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: unsupported template expression.')
    if before != '\n'.join(_BEFORE_LINES) + '\n' or after != '\n'.join(_AFTER_LINES) + '\n':
        raise ReportRenderError('REPORT_TEMPLATE_INVALID: malformed report sections.')
    return before, row, after


def _fill(text, values):
    # One substitution pass: injected content is never parsed as template syntax.
    return _TOKEN.sub(lambda match: values[match.group(1)], text)


def _data_link(label, pointer=''):
    return '[' + escape_text(label) + '](report-data.json' + (('#' + quote(pointer, safe='/')) if pointer else '') + ')'


class _Renderer:
    def __init__(self, report, run_root):
        self.report = report
        self.metadata = report['extensions']['reporting']
        self.context = self.metadata['presentation']
        self.run = Path(run_root)
        if not self.run.is_absolute() or self.run != Path(self.context['run_root']):
            raise ReportRenderError('REPORT_UNAVAILABLE: run root differs from captured presentation.')
        self.roots = {name: Path(self.context[field]) for name, field in
                      (('HARNESS', 'harness_root'), ('REPOSITORY', 'repo_root'))}
        if any(not root.is_absolute() for root in self.roots.values()):
            raise ReportRenderError('REPORT_UNAVAILABLE: presentation roots must be absolute.')
        self.paths = {(item['scope'], item['path']) for item in report['source_manifest']}
        self.attempts = {item['attempt_id']: index for index, item in enumerate(report['history']['attempts'])}

    def link(self, ref, label):
        if not isinstance(ref, dict):
            return escape_text(label) + ' (reference unavailable)'
        if ref.get('kind') == 'EXTERNAL':
            address = ref.get('uri', '')
            try:
                parts = urlsplit(address)
                safe = (parts.scheme.lower() in ('http', 'https') and bool(parts.hostname)
                        and not parts.username and not parts.password and '\\' not in address
                        and not any(ord(c) < 33 or ord(c) == 127 for c in address))
            except ValueError:
                safe = False
            if safe:
                return '[' + escape_text(label + ' (external, unchecked)') + '](' + quote(address, safe=':/?#@%=&+;,') + ')'
            return escape_text(label) + ' (external link disallowed; unchecked)'
        scope, path = ref.get('scope'), ref.get('path')
        if (ref.get('kind') != 'LOCAL' or scope not in self.roots or not isinstance(path, str)
                or (scope, path) not in self.paths or path.startswith('/') or '\\' in path
                or PureWindowsPath(path).drive or ':' in path
                or any(part in ('', '.', '..') for part in path.split('/'))):
            return escape_text(label) + ' (not captured; see report data)'
        # Lexical roots are the captured checked roots, including nested harnesses.
        candidate = self.roots[scope] / path
        try:
            relative = Path(os.path.relpath(candidate, self.run)).as_posix()
        except ValueError:
            return escape_text(label) + ' (link unavailable)'
        return '[' + escape_text(label) + '](' + quote(relative, safe='/') + ')'

    def links(self, refs, label):
        return '; '.join(self.link(ref, label) for ref in refs)

    def attempt_link(self, identifier, label):
        index = self.attempts.get(identifier)
        return _data_link(label, '/history/attempts/' + str(index)) if index is not None else ''

    def phase_links(self, phase):
        selected = phase['evidence_refs']
        links = []
        for item in self.metadata['evidence_links']:
            if item['reference'] not in selected and not any(ref in selected for ref in item['evidence_refs']):
                continue
            category, method = item['category'], item['method']
            label = ('execution record' if category == 'EXECUTION' else 'LLM review' if method == 'LLM_REVIEW'
                     else 'human review' if method == 'HUMAN_REVIEW' else 'invocation' if category == 'INVOCATION'
                     else 'fixture record' if category == 'FIXTURE' else 'review record')
            if not item['checked_support']:
                label += ' (unchecked support)'
            if item.get('actor'):
                label += ': ' + str(item['actor'])
            links.append(self.link(item['reference'], label))
            for ref in item['evidence_refs']:
                if ref in selected:
                    label = next((role['label'] for role in self.context['evidence_roles']
                                  if role['record_reference'] == item['reference'] and role['reference'] == ref), 'review basis')
                    links.append(self.link(ref, label))
        if not links:
            links.extend(self.link(ref, 'record / evidence') for ref in selected[:2])
        essential = []
        if phase['attempt_refs']:
            essential.append(self.attempt_link(phase['attempt_refs'][-1], 'latest attempt'))
        info = phase.get('extensions', {}).get('reporting', {})
        if info.get('activity_ended'):
            essential.extend(self.link(ref, 'repair exit: ' + str(info['activity_exit_state']))
                         for ref in info['activity_exit_event_refs'])
            essential.append(_data_link('exit event ' + str(info['activity_exit_event_position']),
                                    '/phases/' + str(self.report['phases'].index(phase)) + '/extensions/reporting'))
            if info.get('activity_next_attempt_ref'):
                essential.append(self.attempt_link(info['activity_next_attempt_ref'], 'next attempt'))
        if phase['diagnostic_refs']:
            links.append(_data_link('phase diagnostics', '/diagnostics'))
        # Full selected links and attribution remain available behind row details.
        unique = list(dict.fromkeys(link for link in essential + links if link))
        return '; '.join(unique[:4]) + ('; ' + _data_link('all phase evidence', '/phases/' + str(self.report['phases'].index(phase))) if len(unique) > 4 else '') or '—'

    def phase_row(self, phase):
        info = phase.get('extensions', {}).get('reporting', {})
        status = phase['status']
        detail = _DETAILS.get(phase['detail_code'], 'See recorded detail')
        if status == 'UNVERIFIED' and phase['recorded_claim']:
            detail = 'Recorded claim: ' + phase['recorded_claim']
        if phase['phase_id'] == 'repair' and phase['attempt_refs']:
            if info.get('activity_ended'):
                status += ' (historical; activity ended)'
                detail = 'Exited to ' + str(info['activity_exit_state'])
                if not info.get('activity_exit_record_valid'):
                    detail += '; exit record unverified'
                if phase['status'] == 'UNVERIFIED':
                    detail += '; claim: ' + str(phase['recorded_claim'])
            elif info.get('activity_active') and not self.metadata.get('captured_before_change'):
                status += ' (currently active)'
                if phase['status'] != 'UNVERIFIED':
                    detail = 'Recorded repair activity'
            else:
                status += ' (not currently active)'
        if info.get('attempt_count', 0) > 1 or info.get('repair_count', 0):
            detail += '; ' + str(info.get('attempt_count', 0)) + ' attempts'
            if phase['phase_id'] != 'repair' and info.get('repair_count'):
                detail += ', ' + str(info['repair_count']) + ' repairs'
        label = escape_text(phase['label'])
        if phase['phase_id'] in ('specification', 'specification_verification'):
            label = '**' + label + '**'
        return dict(phase_label=label, status=escape_text(status), short_recorded_detail=escape_text(detail),
                    links=self.phase_links(phase))

    def attention(self):
        historical = set(self.metadata['historical_diagnostic_indices'])
        issues = [(index, item) for index, item in enumerate(self.report['diagnostics'])
                  if index not in historical and item['severity'] in ('ERROR', 'WARNING')]
        result = []
        for index, item in issues[:3]:
            text = escape_text(item['message']) + ' ' + _data_link('issue details', '/diagnostics/' + str(index))
            if item['references']:
                text += ' ' + self.link(item['references'][0], 'source')
            result.append(text)
        if not result:
            result.append('None in the declared checks')
        if len(issues) > 3:
            result.append(str(len(issues)) + ' current issues; ' + _data_link('complete list', '/diagnostics'))
        return '; '.join(result)

    def render(self):
        template = self.context['template_text']
        identity = 'sha256:' + hashlib.sha256(template.encode('utf-8')).hexdigest()
        if identity != self.context['template_identity']:
            raise ReportRenderError('REPORT_TEMPLATE_INVALID: captured template identity differs.')
        before, row, after = template_parts(template)
        coverage = self.report['specification_coverage']['task_acceptance']
        scope = self.report['scope']
        targets = [str(item['target_id']) + ' / ' + str(item['environment']) for item in scope['targets']]
        target_text = '; '.join(targets + scope['description']) or 'Not recorded'
        history = self.report['history']
        checks = self.report['coverage']['checks']
        unchecked = sum(item['status'] == 'UNCHECKED' and item['mandatory'] for item in checks)
        reviews = self.report['coverage']['semantic_reviews']
        trust = (str(sum(item['status'] == 'CHECKED' for item in checks)) + '/' + str(len(checks))
                 + ' declared checks performed; ' + str(unchecked) + ' mandatory unchecked; '
                 + str(len(reviews)) + ' attributed semantic reviews. ' + _data_link('check coverage and reviewers', '/coverage')
                 + ' ' + _data_link('verification limits', '/limitations'))
        if any(item['check_id'] == 'source_content_inventory' and item['status'] == 'UNCHECKED' for item in checks):
            trust += ' Source inventory remains unchecked.'
        if self.context['publication_diagnostics']:
            trust += ' ' + _data_link('prior output mismatch warning', '/extensions/reporting/presentation/publication_diagnostics')
        states = _data_link('all recorded state claims', '/extensions/reporting/state_claims')
        discrepancies = list(dict.fromkeys(str(item['state']) + ' (' + str(item['origin']) + ' claim)'
                                         for item in self.metadata['state_claims']
                                         if item['state'] != self.report['recorded_state'] and (
                                             item['origin'] == 'SAVED_STATE' and not item['snapshot_consistent']
                                             or item['origin'] != 'SAVED_STATE' and not item['structurally_committed'])))
        state_text = escape_text(self.report['recorded_state'])
        if discrepancies:
            state_text += '; other recorded claims: ' + escape_text('; '.join(discrepancies[:3]))
        spec_links = self.links(self.context['specification_refs'], 'accepted specification record') or 'Not recorded'
        summary = escape_text(self.metadata['summary'])
        if self.metadata.get('captured_before_change'):
            summary += '\n\n**Captured before detected source changes. Current outcomes are unverified.**'
        values = dict(task_title=escape_text(self.report['task_id']), derived_summary=summary,
                      recorded_state=state_text + ' (' + states + ')',
                      check_result=escape_text(self.report['record_checks']), target_and_environment=escape_text(target_text),
                      specification_link=spec_links, generated_at=escape_text(self.report['generated_at']),
                      task_id_and_source_label=escape_text(self.report['task_id'] + ' / ' + str(scope['source_revision'] or 'Not recorded')),
                      criteria_details_link=_data_link('task acceptance matrix', '/specification_coverage/task_acceptance') + '; '
                      + _data_link('separate stage criteria', '/specification_coverage/stage_progression'),
                      up_to_three_issues_with_direct_links_or_none=self.attention(),
                      previous_failure_and_repair_counts=escape_text(str(history['earlier_failure_count']) + ' recorded failures; '
                                                                    + str(history['repair_count']) + ' new repair attempts'),
                      attempt_history_link=_data_link('all attempts, failures and repair activity', '/history'),
                      source_manifest_and_full_diagnostics_links=_data_link('source manifest', '/source_manifest') + ' · '
                      + _data_link('full diagnostics (including history)', '/diagnostics') + '\n\n' + trust)
        values.update({name: str(coverage[name]) for name in
                       ('satisfied_required', 'total_required', 'failed_required', 'unresolved_required')})
        text = _fill(before, values) + ''.join(_fill(row, self.phase_row(phase)).strip('\n') + '\n'
                                             for phase in self.report['phases']) + _fill(after, values)
        # Hash the exact JSON serialization written by the CLI, not a reread.
        from .evidence import canonical_json
        digest = hashlib.sha256(canonical_json(self.report) + b'\n').hexdigest()
        return text.rstrip() + '\n\n<!-- task-report generation_id=' + self.report['generation_id'] + ' json_sha256=' + digest + ' -->\n'


def render_markdown(report: dict, *, run_root: Path) -> str:
    """Render escaped captured values; report-data retains every issue/claim."""
    return _Renderer(report, run_root).render()


def inspect_pair_metadata(markdown):
    """Return the sole fixed publication marker, or None for absent/ambiguous data."""
    matches = _METADATA.findall(markdown)
    return matches[0] if len(matches) == 1 else None
