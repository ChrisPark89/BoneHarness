# JavaScript trial binding

Local Node20+ commands only: --check src/calculator.js; scripts/build.js; --test test/calculator.test.js. One call, 30-second timeout. No downloads, credentials or external actions. Build writes dist; tests consume dist. Capture stdout/stderr and exact file hashes before/after. Do not retry an uncertain invocation. Lifecycle and reviews are SCENARIO FIXTURES, not a live controller or human approval.
