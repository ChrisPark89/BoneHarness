# JavaScript trial — human review guide

**Result: 45/45 scenarios matched their expected results, covering all 24 development states.** The trial ran 68 real Node commands, including 12 intentional failures.

## Read these first

| What to review | Open | What it shows |
|---|---|---|
| Overall results | [Scenario summary](run/summary.md) | One row per scenario, with report and log links. |
| A successful build and test execution | [Tool-success report](run/javascript%20repository%20%C3%BC/.harness/development/runs/checkpoint-TEST_PASSED/report.md) | Recorded tool outcomes and the remaining verification limits. |
| Failure followed by repair | [Build-repair report](run/javascript%20repository%20%C3%BC/.harness/development/runs/build-repair/report.md) | The failed attempt, repair and retry. |
| Work blocked by a missing tool | [Blocked report](run/javascript%20repository%20%C3%BC/.harness/development/runs/missing-tool-blocked/report.md) | Where work stopped. |
| A completion claim with insufficient evidence | [Unsupported-completion report](run/javascript%20repository%20%C3%BC/.harness/development/runs/unsupported-complete/report.md) | Why a recorded COMPLETE is not enough. |

Open a report first, then follow its evidence links for an issue you want to investigate. You do not need to browse every YAML or JSON file.

These are controlled test scenarios. Commands execute for real; lifecycle histories and review decisions are simulated and labelled as fixtures. Reports retain UNVERIFIED outcomes where evidence is insufficient. The reporter cannot yet certify COMPLETE; user skipping and decisions that a requirement does not apply also remain unsupported. This run was on macOS; Windows/Linux runs remain pending.

## What the other files are for

The generated `.harness/` contains **43 installed files** and **2,949 records across 45 test scenarios**. This is not the minimum file count for one development task.

| Category | Examples | Human review / retention |
|---|---|---|
| Human summaries | `run/summary.md`, each task's `report.md` | Read first. Generated views of the underlying records. |
| Installed harness | Instructions, workflows, schemas, profile and reporter code | Needed to operate or change the harness. The test run adds two trial-specific files to the 41 runtime templates. |
| Task records and evidence | `state.yaml`, `events.yaml`, `requests/`, `decisions/`, `invocations/`, `results/`, `reviews/`, `configuration/`, `logs/`, `sources/`, `artifacts/` | Detailed support for verification and recovery. Keep referenced records together while retaining a task and its evidence. |
| Report detail | `report-data.json` | Machine-readable report data and diagnostic details. Follow a report link when needed. |
| Test diagnostics and development history | `checks/`, `review.md`, `re-review.md`, `implementation.md`, transfer records, reporter console output | Useful to maintain this kit. These are not inputs required by another repository's installed harness. |

**Not every file is inherently necessary.** This test generator repeats configuration snapshots for each scenario and captures source copies for each tool call. That makes cases independent and failures inspectable, but increases the file count. The current record format uses many separate files; that is an implementation choice, not a requirement that every harness must have thousands of files.

**Cleanup rule:** a log or snapshot referenced by a retained record is evidence, not scratch. Archive a retained run with its supporting files. The whole disposable trial can be regenerated, but regenerating it creates new evidence and does not preserve this execution. This trial has no designated disposable scratch directory; do not infer that an unfamiliar file is safe to delete.

See the [demo guide](../../demo/README.md) to run selected scenarios or the full matrix.

<details>
<summary>Builder development notes and verification records — for maintainers</summary>

## Execution details

Host: macOS 15.6 arm64, Python 3.11.16, Node v24.10.0. The retained run took about five minutes.

**17 final trial tests passed.** The earlier full run passed all 120 existing tests and exposed two trial failures, subsequently corrected and covered by the final module. A final combined 137-test suite was not rerun. The trial does not establish live LLM obedience or full formal conformance.

## Changes found through testing

Two reporter bugs were fixed: a failed build no longer requires an artifact it never produced, and a declared control-state stop no longer creates an unknown phase. Existing tests were updated for the reporting files added earlier. Historical evidence was preserved.

Independent review also strengthened output-path protection and assertions for exact phase identities, claims and attempt history. Scenario fixtures were corrected for resume evidence and illegal transitions.

## Verification records

| Record | Purpose |
|---|---|
| [Run data](run/results.json), [command/source record](run-record.json) | Actual scenario assertions, commands, platform and source identities. |
| [Final tests](checks/postfix-trial.log), [test metadata](checks/postfix-trial.json) | 17 passing tests at reviewed commit `ef7390e`. |
| [Earlier full run](checks/full-frozen.log), [metadata](checks/full-frozen.json) | 130 tests before fixture corrections; two failures, not a final passing result. |
| [Original baseline](checks/baseline-complete.log), [diagnosis](checks/baseline-diagnosis.md) | Six outdated-test failures identified before implementation. |
| [Independent review](review.md), [accepted re-review](re-review.md) | Findings and confirmation that the corrections address them. |
| [Implementation record](implementation.md), [decisions](decisions.md) | Scope, corrections, focused failure/pass evidence and limitations. |
| [Transfer record](transfer.json), [status-document updates](documentation-updates.json) | Reviewed source copied into the workspace; original historical files preserved. |

These are this project's test artifacts. They are not installation inputs for another repository.

</details>
