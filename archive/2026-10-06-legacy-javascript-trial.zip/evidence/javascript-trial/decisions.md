# Trial implementation decisions

Authoring decisions for this test work; these are not installed runtime rules.

Ruling: Treat this as one bounded deliverable under the existing trial design and subagent execution preference — avoids repeating approval for the requested test work — significant new protocol design still needs clarification.

Ruling: Use Node's built-in tests and no npm dependencies — keep toy application minimal and portable — no browser/UI behavior will be demonstrated.

Ruling: Keep fixture history separate from real execution evidence — most lifecycle states need controlled saved records, while build/test commands genuinely run — this tests record/report behavior, not enforcement against an unrestricted LLM.

Ruling: Use a disposable Git snapshot because original is not Git — permits scoped review without changing original metadata — guarded changed-file transfer will be required.

Ruling: Repair old publication-test setups through explicitly labelled temporary current-runtime baselines, preserving all retained publication-attested bytes/receipts and using typed baseline inventory for new files — maintains narrow lineage regression checks without editing historical evidence — fixture adaptation must assert preserved attested bytes and cannot introduce a checker bypass; an attested catalogue would require a fresh baseline instead.

Ruling: Combine task and whole-change review for this one cohesive task — both scopes are identical and one fresh independent review covers compliance and integration — meaningful findings still require fixes and scoped re-review.

Ruling: Isolate review fixes in sibling Git worktree /private/tmp/harness-js-trial-emr1ib2s/fix at d5d0d5e — prevents edits contaminating ongoing full-suite source identity — final scoped tests and transfer must use fix/ HEAD; work/ stays frozen. Branch javascript-trial-review-fixes. Final suite log remains valid for d5d0d5e, then complete trial module tests cover amended source.
