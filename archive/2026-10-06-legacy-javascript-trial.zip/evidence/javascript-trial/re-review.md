# Scoped review of JavaScript trial corrections

Reviewed `ef7390e0dbd26643b92fc2f45d9b00f30b24aefc` in the frozen `fix/` worktree against previously reviewed `d5d0d5e0724fce50a4a71078ad224ad0fd3ad6ec`. Verified HEAD and clean worktree. Scope is the three-file `fix-diff.txt`, the two original P2 findings, and the fixture corrections included in that diff.

## Verdict

- **Original P2 output-path bypass: ADDRESSED.** `demo/run.py:325-327` rejects parent traversal before any output writes. Existing symlink, protected-root and occupied-directory checks remain. The regression exercises both protected roots and verifies that neither the intermediate nor destination directory appears.
- **Original P2 weak phase assertions: ADDRESSED.** `demo/run.py:209-265` now checks exact ordered phase IDs, relevant attempt order/uniqueness, state/phase/claim/status/position, last phase claim, and exact phase-to-attempt associations. Fixture visits remain UNVERIFIED; untouched phases remain NOT_RECORDED. These checks run for checkpoints and negative cases. Expectations use the declared map and scenario route without calling the production derivation.
- **New breakage in this diff: none found.** Spec-compliance and code-quality review of this correction wave are accepted. Final full-trial verification remains a separate pending gate.

## Additional fixture corrections

`demo/records.py` supplies the labelled fixture resolution basis when restoring from RESUME_REVIEW and selects the ordinary REPAIRING-to-RESUME_REVIEW route, rather than the separate invalidation trigger. The installed workflow contains the ordinary DEV-128 route; no workflow or product validation is changed. The regression checks complete prefixes, failure/repair admission counts and resolution references.

The illegal-transition negative now substitutes a real, shape-valid edge with incompatible endpoints. It therefore exercises transition validation rather than failing the transition ID's schema. Its regression requires REPORT_TRANSITION_INVALID, no REPORT_DOCUMENT_INVALID, recorded NEW and committed prefix one. Aggregated matrix failures improve diagnosis without weakening assertions.

## Evidence and limits

Read the full three-file diff, surrounding frozen source, installed workflow routes, appended implementation report and `review-fixtures-green.log`: **7 tests passed in 40.530 seconds**. The five original-finding regressions and two fixture regressions are present and meaningful.

Independently ran a small read-only probe against the fixed module. Both original traversal constructions are rejected. The new phase checker accepts the existing unmodified BLOCKED and fixture-execution reports and rejects both after assigning PASS to every phase and replacing all non-repair phase IDs with a duplicate nonexistent ID. This reproduces closure of the original false-pass finding without running another trial or modifying retained reports.

At re-review completion, `postfix-trial.json` identified commit ef7390e0 and recorded `status: RUNNING`; the complete post-fix trial module had not yet finished. No final test-success claim is made here. The earlier frozen 130-test run had two fixture-related failures and is not a final green result. No full suite was repeated, no source or historical evidence was edited, and review scope was not expanded.
