# Baseline checker failure diagnosis

## Outcome

The three named tests reproduce unchanged on the immutable pre-demo baseline. The failures are caused by checker packaging and retained test-fixture assumptions that were not updated after the reporting integration. The investigated bytecode suppression, new-owned-path continuity, and reconciled-receipt validation still behave as intended when their required inputs are present. No JavaScript demo changes are involved.

There is one genuine compatibility change: copying only `builder-kit/checker/` no longer creates a runnable checker because its loader/schema implementation now resides in a canonical sibling runtime template package. The existing relocated-checker test assumes the previous self-contained layout. Under the current documented full `builder-kit` layout, its substantive read-only/no-bytecode behavior passes. The incomplete-layout startup also raises an uncaught traceback rather than a checker JSON prerequisite report; that is a product robustness concern distinct from bytecode suppression.

## Reproduction

- Baseline: `/private/tmp/harness-js-trial-emr1ib2s/baseline`.
- Interpreter: `/private/tmp/harness-builder-20261004-efv7l2ai/venv311/bin/python`.
- Working directory: baseline `tests/` so `test_checker` and `support` import correctly.
- Parent environment: `PYTHONDONTWRITEBYTECODE=1`. The existing test helper deliberately removes this variable and `PYTHONPYCACHEPREFIX` for its checker subprocesses, so the relocation probe actually exercises the entry point's own suppression.
- Exact invocation: `python -m unittest -v test_checker.CheckerTests.test_checker_inside_inspected_repo_creates_no_bytecode test_checker.CheckerTests.test_new_owned_path_chains_null_before_and_rejects_mismatch test_checker.CheckerTests.test_reconciled_publication_reuses_receipt_not_second_publication`.
- Bounded runner timeout: 300 seconds; existing checker subprocess timeout: 60 seconds.
- Result: three failures, 11.014 seconds, unittest exit 1. The runner completed normally; no timeout.
- Full reproduction log: `baseline-focused-failures.log` in this review directory. The earlier incomplete `baseline-tests.log` is consistent but is not used as evidence of full-suite completion.

## Failure 1: checker inside inspected repository

**Precise failing assertion:** `tests/test_checker.py:57`, `self.assertTrue(proc.stdout.strip(), proc.stderr)`, called from line 75. The checker emitted no JSON stdout. Neither the exit-0 assertion, tree equality assertion, nor bytecode assertion at lines 76–77 was reached.

**Observed error:** `FileNotFoundError` opening `<temporary repo>/tools/templates/runtime/shared/python/harness_io/__init__.py` from `harness_check/__init__.py:26` during entry-point import.

**Root-cause trace:**

1. Test line 74 copies only `CHECK.parent`, the `checker` subtree, into `<repo>/tools/checker`.
2. `check.py:4` sets `sys.dont_write_bytecode = True` before importing `harness_check.cli`.
3. `harness_check/__init__.py:9–10` constructs its support directory from `Path(__file__).resolve().parents[2] / 'templates/runtime/shared/python/harness_io'`.
4. In the original kit this points to the real sibling `builder-kit/templates/runtime/shared/python/harness_io`. In the test copy it points to `tools/templates/...`, which was never copied.
5. `loader.py` and `schemas.py` are now compatibility exports of that shared package; the checker cannot import without it. The reporting implementation plan explicitly records this extraction and fixed package-relative binding at lines 129–135.

**Controlled comparison:** The diagnostic probe creates a fresh current-template fixture, relocates the checker to `<repo>/tools/builder-kit/checker`, and copies only its canonical sibling `templates/runtime/shared/python/harness_io` support package into the matching kit layout. The real CLI returns exit 0 with no diagnostics; the complete inspected tree is unchanged and there are zero `.pyc` files under `tools`. No checker source was modified.

**Classification:** Stale test packaging under the current intentionally shared-package architecture; a real checker-only relocation compatibility change exists, but there is no demonstrated bytecode/write regression. Current README usage specifies an absolute `builder-kit/checker/check.py` entry point, which has the sibling runtime package.

**Minimal recommended fix:** Update the relocated-checker fixture to copy the checker plus its canonical sibling I/O package (or the complete kit) inside the inspected repository, then retain the exit-0, full-tree-equality, and no-bytecode assertions. Document that the optional checker must travel with this support package. If the intended product promise is instead that copying only the checker subtree remains supported, fix packaging by including the shared implementation as a declared local checker resource; do not search arbitrary inspected repository paths for executable code. Handling absent support as a bounded prerequisite error would be a separate robustness improvement.

Evidence: `baseline-checker-complete-layout-summary.json`, `baseline-checker-complete-layout-report.json`, and `baseline-diagnostic-probe.py`.

## Failures 2 and 3: retained publication walkthrough

Both tests call `use_retained_publication_walkthrough()` at lines 500–510 and extract historical `evidence/checks/installed-walkthrough.zip`, replacing the current fixture with its `compiled/.harness` tree.

**Precise failing assertions:**

- New path test: `tests/test_checker.py:538`, `self.assertTrue(any(d['code'] == 'REFERENCE_ANCESTRY' for d in r['diagnostics']))`. Its preceding exit-1 assertion passes, but for unrelated missing reporting inputs.
- Reconciliation test: `tests/test_checker.py:522`, `self.assertTrue(any(d['code'] == 'REFERENCE_PUBLICATION' for d in r['diagnostics']), r['diagnostics'])` after changing the reconciled promotion intent candidate identity.

**Fixture mismatch:** The retained archive declares 29 runtime files; the current checker requires 41. All 12 additions are absent and undeclared:

- `development/report.py`
- `development/reporting/__init__.py`
- `development/reporting/evidence.py`
- `development/reporting/render.py`
- `development/reporting/summary.py`
- `development/templates/task-report.md`
- `shared/python/harness_io/__init__.py`
- `shared/python/harness_io/loader.py`
- `shared/python/harness_io/schemas.py`
- `shared/python/requirements.lock`
- `shared/reporting-legacy-baseline.json`
- `shared/schemas/task-report.schema.json`

The missing schema appears several times in diagnostics because file, schema and local-reference checks each inspect it; that does not increase the number of absent artifacts.

**Root-cause trace:**

1. `checks.py:files` diagnoses the archived runtime declaration and absent new files.
2. `schema_dependencies()` diagnoses the absent task-report schema but continues collecting schema diagnostics.
3. `schema_checks()` now reads `shared/reporting-legacy-baseline.json` unconditionally at lines 178–185. Its absent path raises `DocumentError`, which `run_check` catches and records.
4. That exception exits `schema_checks` before its historical-record discovery loop at lines 191–202. No `UpdateRecord` is appended to `inspection.updates`.
5. `inventory()` therefore has no publication history to traverse. It leaves `IS-08.inventory` wholly unresolved because the installation baseline is `cfg-3` and the current profile is `cfg-5`; it cannot inspect either mutation and never reaches the asserted ancestry/publication code.
6. The original positive assertions also appear to pass without exercising the intended publication checks: absence of the target diagnostic and an uncovered inventory criterion are equally true when history never loaded.

**Schema/eligibility exclusions checked:** The archived `replace-build` record validates against the current `records.schema.json` UpdateRecord definition with zero errors. The installed IS-08.inventory description still matches its automated obligation identity. Neither an incompatible publication record schema nor changed criterion eligibility causes these two failures.

**Controlled inventory probes using unchanged product code:** Explicitly loading the archive's two histories (`replace-build`, `rule-schema-migration`) into `Inspection` yields:

| Archive history input | Inventory diagnostics | Inventory result |
| --- | --- | --- |
| Original | None | Unresolved for review, exit remains 0 |
| New adapter before identity changed from null to zero hash | Two `REFERENCE_ANCESTRY` diagnostics on `shared/adapters/synthetic_adapter_B.py`: new path requires absent before identity; publication does not continue prior owned identity | Exit 1 |
| Reconciled promotion candidate identity changed to zero hash | `REFERENCE_PUBLICATION` on `replace-build`: reconciliation does not reuse exact prior accepted publication and receipt | Exit 1 |

All three probes preserve the full fixture tree. The new-path guard is `checks.py:723–734`; the receipt reuse comparison is `checks.py:672–691`.

**Full CLI confirmation:** In a separate temporary archive extraction, adding only the current `shared/reporting-legacy-baseline.json` and `shared/schemas/task-report.schema.json` removes the early history-loading interruption. Without changing checker code or relaxing any predicate, the full CLI then produces exactly the two expected ancestry diagnostics and the expected publication diagnostic for the respective original mutations. The ten remaining missing runtime files still correctly produce structural errors. This is a diagnostic isolation experiment, not a valid installation migration or a claim of full conformance.

**Classification:** Outdated test inputs; the expected semantic diagnostics remain correct and should be retained. No reproduced regression in new-path continuity or reconciled-receipt reuse.

**Minimal recommended fix:** Keep the historical archive immutable as evidence. Add a dedicated current-runtime publication fixture/helper for checker regressions, preserving the original new adapter and recovery scenarios while recording a coherent current 41-file inventory, current reporting definitions, and correct byte/hash lineage. Do not call `save_inventory()` on the maintained archive to paper over the problem: that would rewrite the historical baseline with current bytes and undermine the behavior being tested. Assert the unmutated fixture has no unrelated prerequisite/path/schema failures before applying each mutation, so a skipped history scan cannot silently satisfy the positive assertions. Re-run the named tests against that authored current fixture.

An alternate diagnostic-hardening change would gather independent history records even after a missing unrelated current definition, but the present checker correctly reports invalid runtime input. Such a change is not needed to recover the inventory algorithms and is broader than fixing these fixture assumptions.

Evidence: `baseline-archive-inspection.json`; `baseline-retained-original-report.json`; `baseline-inventory-original.json`; `baseline-inventory-before-identity-mismatch.json`; `baseline-inventory-reconciled-candidate-mismatch.json`; `baseline-retained-two-file-probe-summary.json`; and its three complete CLI report JSON files.

## Scope and limits

No baseline product or test file was edited. All generated scripts, logs and report artifacts are under `/private/tmp/harness-js-trial-emr1ib2s/review`; mutable test inputs were disposable temporary fixtures. No dependency installation, network access, original-workspace mutation, subagents, or full-suite rerun was performed. Historical green logs in the baseline predate these reporting additions and do not establish current green status. The focused reproduction remains red; no fixes were implemented in this diagnosis.

Actual diagnostic interpreter: 3.11.16 (main, Sep  1 2026, 14:08:22) [Clang 22.1.3 ]; PyYAML 6.0.3; jsonschema 4.26.0.
