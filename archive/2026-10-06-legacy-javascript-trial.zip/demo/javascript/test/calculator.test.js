import test from 'node:test';
import assert from 'node:assert/strict';
import { add, subtract } from '../dist/calculator.js';

test('adds positive, negative and decimal numbers', () => {
  assert.equal(add(2, 3), 5);
  assert.equal(add(-4, 2), -2);
  assert.equal(add(1.5, 2.5), 4);
});
test('subtracts numbers in the supplied order', () => {
  assert.equal(subtract(8, 3), 5);
  assert.equal(subtract(3, 8), -5);
  assert.equal(subtract(0, 0), 0);
});
