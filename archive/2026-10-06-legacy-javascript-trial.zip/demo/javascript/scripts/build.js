import { mkdir, copyFile, rm } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const source = new URL('../src/calculator.js', import.meta.url);
const output = new URL('../dist/', import.meta.url);
// Remove a previous artifact before checking, so a failed build cannot leave a stale success.
await rm(output, { recursive: true, force: true });
const checked = spawnSync(process.execPath, ['--check', fileURLToPath(source)], {
  encoding: 'utf8', timeout: 10000,
});
process.stdout.write(checked.stdout || '');
process.stderr.write(checked.stderr || '');
if (checked.error || checked.status !== 0) {
  if (checked.error) console.error(checked.error.message);
  process.exit(checked.status || 1);
}
await mkdir(output, { recursive: true });
await copyFile(source, new URL('calculator.js', output));
console.log('Built dist/calculator.js');
