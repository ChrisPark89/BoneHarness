#!/usr/bin/env python3
"""Run a bounded JavaScript harness trial in an absent or empty output directory."""
import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
try:
    from records import ROOT, RUNTIME, History, canonical, digest, identity, install, read, write
    IMPORT_ERROR = None
except ImportError as exc:
    IMPORT_ERROR = exc

ACTIVE = {'PREFLIGHT': 'preflight', 'BUILDING': 'build', 'TESTING': 'test'}
OUTCOME = {'PREFLIGHT_PASSED': 'preflight', 'PREFLIGHT_FAILED': 'preflight', 'BUILD_PASSED': 'build',
           'BUILD_FAILED': 'build', 'TEST_PASSED': 'test', 'TEST_FAILED': 'test'}
COMMANDS = {'preflight': ['--check', 'src/calculator.js'], 'build': ['scripts/build.js'],
            'test': ['--test', 'test/calculator.test.js']}
NEGATIVES = {
    'missing-build-log': ('BUILD_PASSED', 'REPORT_EVIDENCE_MISSING'),
    'missing-test-log': ('TEST_PASSED', 'REPORT_EVIDENCE_MISSING'),
    'stale-result': ('BUILD_PASSED', 'REPORT_EVIDENCE_STALE'),
    'snapshot-mismatch': ('BASELINED', 'REPORT_SNAPSHOT_MISMATCH'),
    'illegal-transition': ('BASELINED', 'REPORT_TRANSITION_INVALID'),
    'malformed-record': ('BUILD_PASSED', 'REPORT_DOCUMENT_INVALID'),
    'duplicate-key-record': ('BUILD_PASSED', 'REPORT_DOCUMENT_INVALID'),
    'missing-specification-criterion': ('SPEC_VERIFIED', 'REPORT_CRITERION_UNRESOLVED'),
    'unsupported-complete': ('COMPLETE', 'REPORT_COMPLETION_UNSUPPORTED'),
    'fixture-execution': ('BUILD_PASSED', 'REPORT_FIXTURE_EVIDENCE'),
    'not-applicable': ('BASELINED', 'REPORT_NOT_APPLICABLE_UNSUPPORTED'),
    'user-skip': ('SPEC_READY', 'REPORT_SKIP_UNSUPPORTED'),
}
HISTORIES = ['build-repair', 'test-repair', 'repair-disabled', 'repair-exhausted', 'missing-tool-blocked',
             'resume', 'same-state-wait', 'failure-wait-resume', 'repair-wait-resume']
LIMITS = ['Lifecycle, acceptance, gate decisions and reviewer records are scenario fixtures, not live agent behavior or real human approval.',
         'The installed source inventory protocol is unspecified: completion remains unsupported even after real successful commands.',
         'NOT_APPLICABLE and user phase skipping remain unsupported; no new policy protocol is implemented.',
         'Installation compatibility, semantic reviews and activation remain pending.',
         'Only the reported native host was executed. Windows/Linux execution and OS publication race stress are not claimed.']


def plans(workflow):
    sequence = workflow['extensions']['default_sequence']
    result = {'checkpoint-' + state: sequence[:i + 1] for i, state in enumerate(sequence)}
    prefix = lambda state: sequence[:sequence.index(state) + 1]
    routes = {
        'PREFLIGHT_FAILED': prefix('PREFLIGHT') + ['PREFLIGHT_FAILED'],
        'BUILD_FAILED': prefix('BUILDING') + ['BUILD_FAILED'],
        'TEST_FAILED': prefix('TESTING') + ['TEST_FAILED'],
        'REPAIRING': prefix('BUILDING') + ['BUILD_FAILED', 'REPAIRING'],
        'BLOCKED': ['NEW', 'BLOCKED'],
        'HUMAN_REQUIRED': prefix('BUILDING') + ['BUILD_FAILED', 'HUMAN_REQUIRED'],
        'RESUME_REVIEW': ['NEW', 'BLOCKED', 'RESUME_REVIEW'],
    }
    for state, route in routes.items():
        result['checkpoint-' + state] = route
    result.update({
        'build-repair': routes['REPAIRING'] + ['PREFLIGHT', 'PREFLIGHT_PASSED', 'BUILDING', 'BUILD_PASSED', 'TESTING', 'TEST_PASSED'],
        'test-repair': routes['TEST_FAILED'] + ['REPAIRING', 'PREFLIGHT', 'PREFLIGHT_PASSED', 'BUILDING', 'BUILD_PASSED', 'TESTING', 'TEST_PASSED'],
        'repair-disabled': routes['BUILD_FAILED'] + ['HUMAN_REQUIRED'],
        'repair-exhausted': routes['REPAIRING'] + ['PREFLIGHT', 'PREFLIGHT_PASSED', 'BUILDING', 'BUILD_FAILED', 'HUMAN_REQUIRED'],
        'missing-tool-blocked': prefix('PREFLIGHT') + ['BLOCKED'],
        'resume': ['NEW', 'BLOCKED', 'RESUME_REVIEW', 'NEW', 'BASELINED'],
        'same-state-wait': ['NEW', 'NEW', 'NEW'],
        'failure-wait-resume': routes['BUILD_FAILED'] + ['BUILD_FAILED', 'RESUME_REVIEW', 'BUILD_FAILED'],
        'repair-wait-resume': routes['REPAIRING'] + ['REPAIRING', 'RESUME_REVIEW', 'REPAIRING'],
    })
    for name, (state, _) in NEGATIVES.items():
        result[name] = result['checkpoint-' + state]
    declared = {row['id'] for row in workflow['states']}
    if {name.removeprefix('checkpoint-') for name in result if name.startswith('checkpoint-')} != declared:
        raise ValueError('Installed workflow changed; explicit checkpoint routes must be updated')
    return result


def input_files(repo):
    """Hash every regular non-report file, including source and installed Python."""
    return {p.relative_to(repo).as_posix(): digest(p) for p in sorted(repo.rglob('*'))
            if p.is_file() and p.name not in ('report.md', 'report-data.json')}


def report_task(repo, task_id):
    script = repo / '.harness/development/report.py'
    with tempfile.TemporaryDirectory(prefix='unrelated-reporter-cwd-') as cwd:
        process = subprocess.run([sys.executable, '-B', str(script), '--repo-root', str(repo), '--harness-root', '.harness',
            '--task-id', task_id], cwd=cwd, capture_output=True, text=True, timeout=60)
    path = repo / '.harness/development/runs' / task_id / 'report-data.json'
    value = json.loads(path.read_text()) if path.is_file() else None
    return process.returncode, value, process


def execute(history, node, intent):
    cap = intent['capability']
    command = [node] + COMMANDS[cap]
    before = {p: digest(history.repo / p) for p in ['package.json', 'src/calculator.js', 'scripts/build.js', 'test/calculator.test.js']}
    captured_files = {}
    for name in before:
        target = history.run / 'sources' / intent['run_id'] / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(history.repo / name, target)
        captured_files[name] = dict(path=target.relative_to(history.h).as_posix(), identity=digest(target))
    began = time.monotonic()
    process = subprocess.run(command, cwd=history.repo, capture_output=True, text=True, timeout=30)
    log = dict(provenance='EXECUTION', command=command, cwd=str(history.repo), exit_code=process.returncode,
        stdout=process.stdout, stderr=process.stderr, elapsed_seconds=time.monotonic() - began, input_files=before,
        source_identity=identity(before), captured_files=captured_files, output_files={p.relative_to(history.repo).as_posix(): digest(p) for p in (history.repo / 'dist').glob('*.js')})
    return history.executed(intent, process, log)


def corrupt(history, name):
    """Apply one deliberate negative input after producing well-formed records."""
    if name in ('missing-build-log', 'missing-test-log'):
        cap = 'build' if name == 'missing-build-log' else 'test'
        selected = next(x for x in history.executions if x['capability'] == cap)
        (history.h / selected['log']).unlink()
    elif name in ('stale-result', 'fixture-execution'):
        path = history.results[-1]
        result = read(path)
        if name == 'stale-result':
            result['revision'] = identity('stale source revision')
        else:
            result['provenance'] = 'FIXTURE'
            result['extensions']['capability_data'] = {'scenario_fixture': True}
        write(path, result)
        # Update immutable reference assertions so this tests stale/provenance checks,
        # rather than only detecting tampered bytes.
        refresh_refs(history, path)
    elif name == 'snapshot-mismatch':
        state = deepcopy(history.state)
        state['state'] = 'NEW'
        write(history.run / 'state.yaml', state)
    elif name == 'illegal-transition':
        path = history.run / 'requests/2.yaml'
        request = read(path)
        request['transition_id'] = history.edge('BASELINED', 'RESEARCHED')['id']
        request['request_content_identity'] = identity({k: v for k, v in request.items() if k != 'request_content_identity'})
        write(path, request)
        history.events[-1]['request_content_identity'] = request['request_content_identity']
        write(history.run / 'events.yaml', dict(schema_version='1.0.0', record_type='EventLog', subject_id=history.task_id, subject_kind='TASK', events=history.events))
    elif name in ('malformed-record', 'duplicate-key-record'):
        path = history.results[-1]
        path.write_text('{broken' if name == 'malformed-record' else '{"record_type":"Result","record_type":"Result"}', encoding='utf-8')
        refresh_refs(history, path)
    elif name in ('missing-specification-criterion', 'not-applicable'):
        path = history.run / ('reviews/' + str(len(history.events)) + '.yaml')
        value = read(path)
        if name == 'not-applicable':
            value['criteria'][0]['result'] = 'NOT_APPLICABLE'
        else:
            value['criteria'] = [c for c in value['criteria'] if c['criterion_id'] != 'AC-01']
        write(path, value)
        refresh_refs(history, path)
    elif name == 'unsupported-complete':
        # No extra corruption needed: source inventory and fixture reviews cannot prove completion.
        pass
    elif name == 'user-skip':
        history.events[-1]['post_state']['extensions']['user_skipped'] = True
        write(history.run / 'events.yaml', dict(schema_version='1.0.0', record_type='EventLog', subject_id=history.task_id, subject_kind='TASK', events=history.events))
        write(history.run / 'state.yaml', history.events[-1]['post_state'])


def refresh_refs(history, path):
    reference = {'kind': 'LOCAL', 'scope': 'HARNESS', 'path': path.relative_to(history.h).as_posix()}
    def visit(value):
        if isinstance(value, dict):
            if value.get('reference') == reference and 'identity' in value:
                value['identity'] = digest(path)
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    # Requests' own content digests and selected review byte identities form a DAG.
    for p in sorted(history.run.glob('reviews/*.yaml')):
        value = read(p); visit(value); write(p, value)
    for p in sorted(history.run.glob('requests/*.yaml')):
        value = read(p); visit(value)
        for review_ref in value['review_refs']:
            review_ref['identity'] = digest(history.h / review_ref['reference']['path'])
        value['request_content_identity'] = identity({k: v for k, v in value.items() if k != 'request_content_identity'})
        write(p, value)
    for event in history.events:
        visit(event)
        for basis in event['post_state']['criterion_verdict_refs'] + event['evidence_refs']:
            if basis['reference']['path'].startswith(history.rel('reviews/')):
                basis['identity'] = digest(history.h / basis['reference']['path'])
        request = history.run / 'requests' / (str(event['next_version']) + '.yaml')
        if request.exists():
            event['request_content_identity'] = read(request)['request_content_identity']
    write(history.run / 'events.yaml', dict(schema_version='1.0.0', record_type='EventLog', subject_id=history.task_id, subject_kind='TASK', events=history.events))
    write(history.run / 'state.yaml', history.events[-1]['post_state'])


def pair_matches(path, report):
    text = path.with_name('report.md').read_text(encoding='utf-8')
    return report['generation_id'] in text and digest(path).removeprefix('sha256:') in text



def check_phases(check, name, route, history, report):
    """Compare report meaning with the declared map and literal fixture route.

    These scenarios use fixture authority, so visited phases/attempts must remain
    UNVERIFIED; untouched phases must remain NOT_RECORDED. Expectations never
    call the production capture, derivation or renderer.
    """
    definitions = sorted(history.workflow['extensions']['reporting']['phases'],
                         key=lambda phase: (phase['order'], phase['id']))
    expected_ids = [phase['id'] for phase in definitions]
    actual_ids = [phase.get('phase_id') for phase in report['phases']]
    check('exact declared phase identities retained in order', actual_ids == expected_ids)
    phase_for_state = {state: phase['id'] for phase in definitions
        for role in ('success_states', 'active_states', 'failure_states') for state in phase[role]}
    expected = []
    for position, state in enumerate(route):
        if state not in phase_for_state and state not in ('BLOCKED', 'HUMAN_REQUIRED'):
            continue  # NEW, RESUME_REVIEW and COMPLETE are declared controls.
        event = history.events[position]
        phase_id = phase_for_state.get(state)
        if state in ('BLOCKED', 'HUMAN_REQUIRED'):
            phase_id = phase_for_state.get(event['post_state']['stopped_from_state'])
        expected.append(dict(state=state, phase_id=phase_id, position=position, event_id=event['request_id'],
            claim='USER_SKIPPED' if name == 'user-skip' and position == len(route) - 1 else state))
    actual = report['history']['attempts']
    check('all mapped and stop attempts retained in route order',
          [attempt.get('extensions', {}).get('reporting', {}).get('event_id') for attempt in actual]
          == [attempt['event_id'] for attempt in expected])
    by_event = {}
    for attempt in actual:
        key = attempt.get('extensions', {}).get('reporting', {}).get('event_id')
        by_event.setdefault(key, []).append(attempt)
    for want in expected:
        matches = by_event.get(want['event_id'], [])
        check('unique relevant attempt: ' + want['event_id'], len(matches) == 1)
        if len(matches) != 1:
            continue
        attempt = matches[0]
        check('attempt state, phase, claim and fixture status: ' + want['event_id'],
              attempt.get('state') == want['state'] and attempt.get('phase_id') == want['phase_id']
              and attempt.get('recorded_claim') == want['claim'] and attempt.get('status') == 'UNVERIFIED'
              and attempt.get('extensions', {}).get('reporting', {}).get('position') == want['position'])
    for phase_id in expected_ids:
        matches = [phase for phase in report['phases'] if phase.get('phase_id') == phase_id]
        if len(matches) != 1:
            check('unique declared phase row: ' + phase_id, False)
            continue
        phase = matches[0]
        visits = [want for want in expected if want['phase_id'] == phase_id]
        expected_claim = visits[-1]['claim'] if visits else None
        expected_status = 'UNVERIFIED' if visits else 'NOT_RECORDED'
        check('phase status and last recorded claim: ' + phase_id,
              phase.get('status') == expected_status and phase.get('recorded_claim') == expected_claim)
        linked = [by_event[v['event_id']][0]['attempt_id'] for v in visits
                  if len(by_event.get(v['event_id'], [])) == 1]
        check('phase retains exactly its relevant attempts: ' + phase_id,
              len(linked) == len(visits) and phase.get('attempt_refs') == linked)


def check_case(name, route, history, code, report, inputs_same):
    checks = []
    def check(label, value):
        checks.append(dict(observation=label, matched=bool(value)))
    check('reporter exits1 for known unresolved evidence', code == 1)
    check('report produced', report is not None)
    if report is None:
        return checks
    codes = {d['code'] for d in report['diagnostics']}
    check('report pair metadata/hash agree', pair_matches(history.run / 'report-data.json', report))
    check('input/source files unchanged by reporter', inputs_same)
    check_phases(check, name, route, history, report)
    expected_state = 'NEW' if name == 'illegal-transition' else route[-1]
    check('recorded state matches valid committed prefix', report['recorded_state'] == expected_state)
    if name not in ('illegal-transition', 'snapshot-mismatch'):
        check('entire fixture history is structurally committed', report['history']['committed_prefix_length'] == len(route))
    else:
        check('expected history/snapshot diagnostic', ('REPORT_HISTORY_INVALID' if name == 'illegal-transition' else 'REPORT_SNAPSHOT_MISMATCH') in codes)
    if name in NEGATIVES:
        check('exact expected negative diagnostic: ' + NEGATIVES[name][1], NEGATIVES[name][1] in codes)
        if name == 'fixture-execution':
            result_path = history.results[-1].relative_to(history.h).as_posix()
            check('fixture Result itself is diagnosed, not merely fixture lifecycle basis', any(
                d['code'] == 'REPORT_FIXTURE_EVIDENCE' and any(r.get('path') == result_path for r in d['references'])
                for d in report['diagnostics']))
            check('fixture Result remains shape-valid', not any(d['code'] == 'REPORT_DOCUMENT_INVALID'
                and any(r.get('path') == result_path for r in d['references']) for d in report['diagnostics']))
        if name == 'missing-specification-criterion':
            acceptance = next(c for c in report['specification_coverage']['task_acceptance']['criteria'] if c['criterion_id'] == 'AC-01')
            check('missing acceptance review is unresolved without a recorded verdict', acceptance['recorded_claim'] is None
                and acceptance['result'] == 'UNRESOLVED' and not acceptance['extensions']['reporting']['verdicts'])

    else:
        allowed = {'REPORT_FIXTURE_EVIDENCE', 'REPORT_EVIDENCE_UNCHECKED', 'REPORT_ACCEPTANCE_UNRESOLVED',
                   'REPORT_CRITERION_UNRESOLVED', 'REPORT_EXECUTION_REQUIRED', 'REPORT_REVIEW_REQUIRED', 'REPORT_EVIDENCE_STALE'}
        if route[-1] == 'COMPLETE':
            allowed.add('REPORT_COMPLETION_UNSUPPORTED')
        check('no unintended diagnostics beyond fixture/staleness/source-inventory limits', codes <= allowed)
    check('source inventory remains honestly unchecked', any(c['check_id'] == 'source_content_inventory' and c['status'] == 'UNCHECKED' for c in report['coverage']['checks']))
    if route[-1] == 'COMPLETE':
        check('completion unsupported is explicit', report['completion_support'] == 'UNSUPPORTED' and 'REPORT_COMPLETION_UNSUPPORTED' in codes)
    if name in ('build-repair', 'test-repair', 'failure-wait-resume', 'repair-wait-resume'):
        check('one prior failure retained, waiting/restores not counted twice', report['history']['earlier_failure_count'] == 1)
        expected_repairs = 0 if name == 'failure-wait-resume' else 1
        check('repair count counts admissions only', report['history']['repair_count'] == expected_repairs)
    repair = next((p for p in report['phases'] if p.get('phase_id') == 'repair'), {}).get('extensions', {}).get('reporting', {})
    if name in ('build-repair', 'test-repair'):
        check('repair activity ended', repair.get('activity_ended') and not repair.get('activity_active'))
    if name in ('checkpoint-REPAIRING', 'repair-wait-resume'):
        check('repair activity active', repair.get('activity_active'))
    if name == 'repair-disabled':
        check('disabled repair never admitted', report['history']['repair_count'] == 0)
    if name == 'repair-exhausted':
        check('budget exhausted after exactly one repair and two failures', report['history']['repair_count'] == 1 and report['history']['earlier_failure_count'] == 2)
    return checks


def safe_output(output):
    if '..' in output.parts:
        raise ValueError('output must not contain parent traversal (..) components')
    path = output.expanduser().absolute()
    if path.is_relative_to(ROOT / 'demo') or path.is_relative_to(ROOT / 'builder-kit'):
        raise ValueError('output must be outside the demo and builder source directories')
    if any(p.is_symlink() for p in [path, *path.parents]):
        raise ValueError('output must not follow symlinks, including directory ancestors')
    if path.exists() and (not path.is_dir() or any(path.iterdir())):
        raise ValueError('output must be absent or an empty directory; existing user content is never overwritten')
    return path


def prerequisites(node_executable):
    node = shutil.which(node_executable)
    if not node:
        raise ValueError('Node20+ is required; executable not found: ' + node_executable)
    try:
        process = subprocess.run([node, '--version'], capture_output=True, text=True, timeout=10)
        major = int(process.stdout.strip().lstrip('v').split('.')[0])
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        raise ValueError('Cannot inspect Node prerequisite: ' + str(exc)) from exc
    if process.returncode != 0 or major < 20:
        raise ValueError('Node20+ is required; install prerequisites explicitly before running the trial')
    # Importing records already checks availability. Exact versions are the kit's lock.
    import importlib.metadata
    lock = RUNTIME / 'shared/python/requirements.lock'
    for line in lock.read_text().splitlines():
        requirement = line.split(';')[0].strip()
        if not requirement or requirement.startswith('#') or '==' not in requirement:
            continue
        package, version = requirement.split('==')
        if package == 'typing-extensions' and sys.version_info >= (3, 13):
            continue
        try:
            actual = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError as exc:
            raise ValueError('Missing Python prerequisite ' + package + '; use the pinned checker requirements.lock environment') from exc
        if actual != version:
            raise ValueError('Python prerequisite ' + package + ' must match requirements.lock: expected ' + version + ', found ' + actual)
    return node, process.stdout.strip()


def run_trial(output: Path, *, node_executable: str = 'node', case_names: list[str] | None = None) -> dict:
    if IMPORT_ERROR is not None:
        raise ValueError('Python prerequisites unavailable: ' + str(IMPORT_ERROR) + '; use the pinned checker requirements.lock environment')
    output = safe_output(Path(output))
    workflow = read(RUNTIME / 'development/workflow.yaml')
    matrix = plans(workflow)
    selected = list(matrix) if case_names is None else list(dict.fromkeys(case_names))
    unknown = set(selected) - matrix.keys()
    if unknown or not selected:
        raise ValueError('unknown case or empty selection: ' + ', '.join(sorted(unknown)))
    node, node_version = prerequisites(node_executable)
    output.mkdir(parents=True, exist_ok=True)
    repo = output / 'javascript repository ü'
    h = install(repo)
    installation_before = input_files(repo)
    checker = subprocess.run([sys.executable, '-B', str(ROOT / 'builder-kit/checker/check.py'), '--repo-root', str(repo),
        '--harness-root', '.harness', '--format', 'json'], cwd=output, capture_output=True, text=True, timeout=60)
    (output / 'installation-check.json').write_text(checker.stdout, encoding='utf-8')
    (output / 'installation-check.stderr.txt').write_text(checker.stderr, encoding='utf-8')
    if checker.returncode == 2:
        raise ValueError('Installation checker unavailable; inspect installation-check.stderr.txt and installation-check.json')
    installation_report = json.loads(checker.stdout)
    installation_assertions = [
        dict(observation='installation checker covered checks pass', matched=checker.returncode == 0),
        dict(observation='installation checker preserves inputs', matched=installation_before == input_files(repo)),
        dict(observation='semantic installation obligations remain incomplete', matched=installation_report['structure_assessment'] == 'INCOMPLETE'),
        dict(observation='integration compatibility remains unassessed', matched=installation_report['integration_assessment'] == 'NOT_ASSESSED'),
    ]
    original_source = (repo / 'src/calculator.js').read_bytes()
    cases = []
    for name in selected:
        (repo / 'src/calculator.js').write_bytes(original_source)
        shutil.rmtree(repo / 'dist', ignore_errors=True)
        route = matrix[name]
        history = History(repo, name, repair_enabled='REPAIRING' in route)
        intents = {}
        repair_seen = False
        for position, destination in enumerate(route):
            origin = route[position - 1] if position else None
            continuation = origin in (destination, 'RESUME_REVIEW')
            if destination in ACTIVE and not continuation:
                cap = ACTIVE[destination]
                next_state = route[position + 1] if position + 1 < len(route) else None
                if destination == 'PREFLIGHT' and next_state == 'PREFLIGHT_FAILED':
                    (repo / 'src/calculator.js').write_bytes(original_source + b'\nexport function broken( {\n')
                if destination == 'BUILDING' and next_state == 'BUILD_FAILED':
                    (repo / 'src/calculator.js').write_bytes(original_source + b'\nexport function broken( {\n')
                if 'TEST_FAILED' in route and destination == 'BUILDING' and not repair_seen:
                    (repo / 'src/calculator.js').write_bytes(original_source.replace(b'return left - right;', b'return left + right;'))
                intent, basis = history.intent(cap)
                intents[cap] = intent
                history.append(destination, invocation_refs=[basis])
            elif destination in OUTCOME and not continuation:
                cap = OUTCOME[destination]
                result, completed, log = execute(history, node, intents[cap])
                expected = 0 if destination.endswith('PASSED') else 1
                actual = history.executions[-1]['exit_code']
                if (actual == 0) != (expected == 0):
                    raise RuntimeError('Unexpected Node outcome for ' + name + ': ' + destination)
                history.append(destination, result_refs=[result, log], invocation_refs=[])
                # Pin the completed immutable revision directly without incrementing call counts again.
                request_path = history.run / 'requests' / (str(len(history.events)) + '.yaml')
                request = read(request_path)
                request['evidence_refs'].append(completed)
                request['request_content_identity'] = identity({k: v for k, v in request.items() if k != 'request_content_identity'})
                write(request_path, request)
                history.events[-1]['request_content_identity'] = request['request_content_identity']
                history.events[-1]['evidence_refs'].append(completed)
                write(history.run / 'events.yaml', dict(schema_version='1.0.0', record_type='EventLog', subject_id=name, subject_kind='TASK', events=history.events))
            else:
                history.append(destination)
            if destination == 'REPAIRING' and origin in ('BUILD_FAILED', 'TEST_FAILED'):
                repair_seen = True
                (repo / 'src/calculator.js').write_bytes(original_source)
        if name in NEGATIVES:
            corrupt(history, name)
        if name == 'missing-tool-blocked':
            # An absent executable is a setup observation, never a successful tool Result.
            try:
                subprocess.run([str(output / 'absent-node-tool')], cwd=repo, capture_output=True, timeout=5)
            except FileNotFoundError as exc:
                write(history.run / 'logs/missing-tool.json', dict(provenance='EXECUTION', attempted_command=[str(output / 'absent-node-tool')], error=str(exc), exit_code=None))
        before = input_files(repo)
        code, report, process = report_task(repo, name)
        (history.run / 'reporter.stdout.txt').write_text(process.stdout, encoding='utf-8')
        (history.run / 'reporter.stderr.txt').write_text(process.stderr, encoding='utf-8')
        # Compare before writing retained CLI output, which is author-owned trial evidence.
        after = input_files(repo)
        after.pop((history.run / 'reporter.stdout.txt').relative_to(repo).as_posix(), None)
        after.pop((history.run / 'reporter.stderr.txt').relative_to(repo).as_posix(), None)
        checks = check_case(name, route, history, code, report, before == after)
        report = report or {}
        cases.append(dict(name=name, task_id=name, expected_state=route[-1], event_count=len(route),
            assertion_status='PASS' if all(c['matched'] for c in checks) else 'FAIL', assertions=checks,
            reporter_exit=code, record_checks=report.get('record_checks'), recorded_state=report.get('recorded_state'),
            completion_support=report.get('completion_support'), diagnostic_codes=sorted({d['code'] for d in report.get('diagnostics', [])}),
            unchecked_checks=[c['check_id'] for c in report.get('coverage', {}).get('checks', []) if c['status'] == 'UNCHECKED'],
            earlier_failure_count=report.get('history', {}).get('earlier_failure_count'), repair_count=report.get('history', {}).get('repair_count'),
            executions=history.executions, history_provenance='SCENARIO_FIXTURE',
            report_data=(history.run / 'report-data.json').relative_to(output).as_posix(),
            report=(history.run / 'report.md').relative_to(output).as_posix(), logs=(history.run / 'logs').relative_to(output).as_posix()))
    covered = sorted({c['expected_state'] for c in cases if c['name'].startswith('checkpoint-') and c['assertion_status'] == 'PASS'})
    result = dict(assertion_status='PASS' if all(c['assertion_status'] == 'PASS' for c in cases)
        and all(c['matched'] for c in installation_assertions) else 'FAIL', installation_assertions=installation_assertions,
        native_platform=dict(system=platform.system(), architecture=platform.machine(), python=platform.python_version(), node=node_version),
        repository=repo.relative_to(output).as_posix(), installation_checker_exit=checker.returncode,
        installation_checker_report='installation-check.json', covered_states=covered,
        uncovered_states=sorted({s['id'] for s in workflow['states']} - set(covered)), cases=cases, limitations=LIMITS)
    write(output / 'results.json', result)
    rows = ['# JavaScript harness trial', '', 'Scenario assertions: **' + result['assertion_status'] + '**. '
        'Recorded COMPLETE remains unsupported. Intentional tool failures are expected observations.', '',
        'Real Node commands produce EXECUTION logs/results. Lifecycle, policy, approval and review history is a **scenario fixture**; '
        'this trial does not prove that a live LLM follows the protocol.', '',
        'Native host: ' + platform.system() + ' ' + platform.machine() + '; Python ' + platform.python_version() + '; Node ' + node_version + '.', '',
        'States covered: ' + str(len(covered)) + '/' + str(len(workflow['states'])) + '. Installation checker exit: ' + str(checker.returncode) +
        ' ([retained report](installation-check.json)); semantic/compatibility/activation obligations remain pending.', '',
        '| Scenario | Assertion | Recorded state | Completion support | Reporter exit | Tool exits | Evidence |',
        '| --- | --- | --- | --- | --- | --- | --- |']
    from urllib.parse import quote
    for case in cases:
        exits = ', '.join(e['capability'] + ':' + str(e['exit_code']) for e in case['executions']) or 'none'
        rows.append('| ' + ' | '.join([case['name'], case['assertion_status'], str(case['recorded_state']), str(case['completion_support']),
            str(case['reporter_exit']), exits, '[report](' + quote(case['report']) + ') / [data](' + quote(case['report_data']) +
            ') / [logs](' + quote(case['logs']) + ')']) + ' |')
    rows += ['', 'Limits:', ''] + ['- ' + limit for limit in LIMITS]
    rows += ['', 'Uncovered states: ' + (', '.join(result['uncovered_states']) or 'none') + '.',
             'Publication race stress and native Windows/Linux runs are not covered by this bounded trial.']
    (output / 'summary.md').write_text('\n'.join(rows) + '\n', encoding='utf-8')
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--case', action='append', dest='cases')
    parser.add_argument('--list', action='store_true')
    args = parser.parse_args(argv)
    try:
        if IMPORT_ERROR is not None:
            raise ValueError('Python prerequisites unavailable: ' + str(IMPORT_ERROR) + '; use the pinned checker requirements.lock environment')
        if args.list:
            print('\n'.join(plans(read(RUNTIME / 'development/workflow.yaml'))))
            return 0
        if args.output is None:
            parser.error('--output is required unless --list is supplied')
        result = run_trial(args.output, case_names=args.cases)
        print(str(args.output.absolute() / 'summary.md'))
        print('Scenario assertions: ' + result['assertion_status'])
        return 0 if result['assertion_status'] == 'PASS' else 1
    except (ValueError, OSError, subprocess.TimeoutExpired) as exc:
        print('Trial setup error: ' + str(exc), file=sys.stderr)
        return 2
    except RuntimeError as exc:
        print('Trial assertion failed: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
