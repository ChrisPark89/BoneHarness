"""Bounded scenario-fixture recorder; this is not a runtime state controller.

State, transition, gate, acceptance and reviewer claims are simulated inputs.
Only captured Node subprocess output and its result envelope use EXECUTION.
"""
from copy import deepcopy
from datetime import datetime, timezone, timedelta
import hashlib
import json
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
import yaml
from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'builder-kit/templates/runtime'
ACTOR = 'SCENARIO FIXTURE writer (not a human or live policy engine)'
TARGETS = [{'target_id': 'calculator', 'environment': 'local-node'}]


def stamp():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()


def identity(value):
    return 'sha256:' + hashlib.sha256(canonical(value)).hexdigest()


def digest(path):
    return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return yaml.safe_load(path.read_text(encoding='utf-8'))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode() + b'\n')


def record(kind, **fields):
    return dict(schema_version='1.0.0', record_type=kind, **fields)


def ref(path, scope='HARNESS'):
    return dict(kind='LOCAL', scope=scope, path=path)


def evidence(harness, path, *, provenance='REVIEW', summary='SCENARIO FIXTURE record, not real review or approval'):
    return dict(reference=ref(path), identity=digest(harness / path), provenance=provenance, summary=summary)


def source_snapshot(repo):
    paths = ['package.json', 'src/calculator.js', 'scripts/build.js', 'test/calculator.test.js']
    return {p: digest(repo / p) for p in paths}


def validate(harness, value, schema='records.schema.json', definition=None):
    root = harness / 'shared/schemas'
    def no_network(uri):
        raise ValueError('Unregistered schema, network forbidden: ' + uri)
    registry = Registry(retrieve=no_network).with_resources(
        (p.as_uri(), Resource.from_contents(read(p))) for p in root.glob('*.json'))
    uri = (root / schema).as_uri() + ('#/$defs/' + definition if definition else '')
    validator = Draft202012Validator({'$ref': uri}, registry=registry, format_checker=FormatChecker())
    errors = list(validator.iter_errors(value))
    if errors:
        raise ValueError(str(errors[0]))


def install(repo):
    shutil.copytree(ROOT / 'demo/javascript', repo, ignore=shutil.ignore_patterns('dist', '__pycache__'))
    h = repo / '.harness'
    shutil.copytree(RUNTIME, h, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    procedure = h / 'shared/trial-procedure.md'
    procedure.write_text('# JavaScript trial binding\n\nLocal Node20+ commands only: --check src/calculator.js; scripts/build.js; '
        '--test test/calculator.test.js. One call, 30-second timeout. No downloads, credentials or external actions. '
        'Build writes dist; tests consume dist. Capture stdout/stderr and exact file hashes before/after. '
        'Do not retry an uncertain invocation. Lifecycle and reviews are SCENARIO FIXTURES, not a live controller or human approval.\n', encoding='utf-8')
    write(h / 'installation/evidence/source-snapshot.json', source_snapshot(repo))
    basis = evidence(h, 'installation/evidence/source-snapshot.json', provenance='FIXTURE', summary='Fixture configuration premise; source bytes captured, not authority')
    permissions = dict(filesystem_scopes=[], external_actions=[], secrets_policy='No credentials or external actions.',
        approval_policy=dict(mode='RECORDED_POLICY', procedure=ref('shared/trial-procedure.md')))
    profile = read(h / 'shared/repo-profile.yaml')
    profile['repository'].update(name='Disposable JavaScript trial', identity=identity(source_snapshot(repo)))
    profile['permissions'] = permissions
    profile['completion_policy'] = dict(terminal_state='COMPLETE', required_criteria=['D-COMPLETE'],
        execution_required_capabilities=['preflight', 'build', 'test'], acceptance_authority=ACTOR, evidence_refs=[basis])
    for cap in ('preflight', 'build', 'test'):
        binding = profile['capabilities'][cap]
        adapter = dict(identity='javascript-trial-' + cap, version='1.0.0', content_identity=digest(procedure))
        binding.update(configuration_status='CONFIGURED', adapter=adapter,
            input_schema=ref('shared/schemas/result.schema.json'), permissions=deepcopy(permissions),
            execution_environment=dict(id='local-node', description='Actual local Node subprocess, native platform only', native_platforms=[{'darwin': 'macOS', 'win32': 'Windows'}.get(sys.platform, 'Linux')], evidence_refs=[basis]),
            invocation=dict(procedure=ref('shared/trial-procedure.md'), reconciliation=ref('shared/trial-procedure.md'), deadline_seconds=30, call_budget=1),
            normalization=dict(procedure=ref('shared/trial-procedure.md'), interface_version='1.0.0',
                artifact_consumed_downstream=cap == 'build', test_source_required=cap == 'test', artifact_lineage_required=cap == 'test', extensions_schema=None),
            evidence_refs=[basis])
    profile['workflow_profiles'][0]['required_targets'] = TARGETS
    # Compatibility, semantic installation review and activation deliberately remain pending.
    write(h / 'shared/repo-profile.yaml', profile)
    ledger = read(h / 'installation/installation-record.yaml')
    ledger.update(installation_id='javascript-trial-install', target_identity=profile['repository']['identity'], started_at=stamp(), updated_at=stamp())
    ledger['extensions'].pop('template_only', None)
    ledger['extensions']['scenario_fixture'] = True
    entries = []
    for path in sorted(h.rglob('*')):
        if not path.is_file() or path.is_relative_to(h / 'installation/evidence'):
            continue
        name = path.relative_to(h).as_posix()
        entries.append(dict(scope='HARNESS', path=name, ownership='GENERATED', before_identity=None,
            after_identity=None if name == 'installation/installation-record.yaml' else digest(path)))
    ledger['generated_paths'] = entries
    ledger['owned_paths'] = deepcopy(entries)
    write(h / 'installation/installation-record.yaml', ledger)
    validate(h, profile, 'profile.schema.json')
    validate(h, ledger, definition='InstallationRecord')
    return h


class History:
    """Emit immutable scenario inputs using explicit installed graph edges."""
    def __init__(self, repo, task_id, *, repair_enabled=False):
        self.repo, self.h, self.task_id = repo, repo / '.harness', task_id
        self.run = self.h / 'development/runs' / task_id
        self.run.mkdir(parents=True)
        (self.run / 'logs').mkdir()
        (self.run / 'logs/README.txt').write_text('Only actual Node calls have execution logs. State, review and policy records are SCENARIO FIXTURES. No log means no command was executed for that checkpoint.\n', encoding='utf-8')
        self.workflow = read(self.h / 'development/workflow.yaml')
        self.profile = read(self.h / 'shared/repo-profile.yaml')
        if repair_enabled:
            for policy in self.profile['extensions']['repair_policy'].values():
                policy.update(enabled=True, max_attempts=1)
        self.profile['extensions']['scenario_fixture'] = True
        self.events = []
        self.executions = []
        self.results = []
        captured = []
        paths = [('PROFILE', 'shared/repo-profile.yaml'), ('WORKFLOW', 'development/workflow.yaml'),
                 ('RULES', 'shared/verification-rules.md'), ('CRITERIA', 'shared/verification-criteria.yaml')]
        paths += [('SCHEMA', p.relative_to(self.h).as_posix()) for p in sorted((self.h / 'shared/schemas').glob('*.json'))]
        paths += [('ADAPTER', 'shared/trial-procedure.md')]
        for kind, path in paths:
            dest = self.run / 'configuration' / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            if kind == 'PROFILE':
                write(dest, self.profile)
            else:
                shutil.copyfile(self.h / path, dest)
            captured.append(dict(kind=kind, reference=ref(path), identity=digest(dest), captured_path='configuration/' + path))
        write(self.run / 'config-snapshot.yaml', record('ConfigSnapshot', configuration_id='cfg-1', configuration_revision=1,
            captured_definitions=captured, external_services=[], limitations=['Scenario fixtures; installation semantic review and compatibility pending.']))
        for name, text in [('request.txt', 'SCENARIO FIXTURE: add/subtract tiny calculator'),
                           ('specification.txt', 'SCENARIO FIXTURE: addition/subtraction work in built module'),
                           ('design.txt', 'SCENARIO FIXTURE: two pure ESM functions')]:
            (self.run / name).write_text(text, encoding='utf-8')
        self.accepted = {k: digest(self.run / (k + '.txt')) for k in ('request', 'specification', 'design')}
        self.state = read(self.h / 'development/templates/task-state.yaml')
        self.state.update(task_id=task_id, writer=dict(mode='LLM_PROTOCOL', identity=ACTOR, binding=None, enforcement_evidence_refs=[]),
            selected_targets=TARGETS, input_snapshot=identity(source_snapshot(repo)), extensions={'scenario_fixture': True})
        self.state['accepted_identities'] = dict(request=self.accepted['request'], specification=None, design=None)
        self.fixture = evidence(self.h, self.rel('request.txt'), provenance='FIXTURE', summary='SCENARIO FIXTURE acceptance/policy premise, not human approval')
        self.spec = read(self.h / 'development/templates/task-spec.yaml')
        self.spec.update(task_id=task_id, request_identity=self.accepted['request'], specification_identity=self.accepted['specification'],
            design_identity=self.accepted['design'], acceptance_authority=dict(actor=ACTOR, evidence_refs=[self.fixture]),
            scope=['Tiny calculator'], targets=TARGETS, extensions={'scenario_fixture': True})

    def rel(self, name):
        return 'development/runs/' + self.task_id + '/' + name

    def ev(self, name, **kwargs):
        return evidence(self.h, self.rel(name), **kwargs)

    def edge(self, before, after):
        matches = [e for e in self.workflow['transitions'] + self.workflow.get('resolution_routes', [])
            if e['from'] == before and e['to'] == after and ('profiles' not in e or 'default' in e['profiles'])]
        if not matches:
            raise ValueError('No installed edge ' + before + ' -> ' + after)
        # Waiting is a fixture control route, not a source/config invalidation.
        if before == 'REPAIRING' and after == 'RESUME_REVIEW':
            return next(e for e in matches if not e.get('trigger'))
        return matches[0]

    def append(self, destination, result_refs=(), invocation_refs=()):
        previous = deepcopy(self.state) if self.events else None
        version = len(self.events) + 1
        request_id = self.task_id + '-event-' + str(version)
        current = deepcopy(self.state)
        current.update(state=destination, version=version)
        if destination == 'SPEC_READY' and current['accepted_identities']['specification'] is None:
            self.save('spec.yaml', self.spec)
            current['accepted_identities'] = deepcopy(self.accepted)
        origin = previous['state'] if previous else None
        if destination in self.workflow['stop_states']:
            current['stopped_from_state'] = (previous['stopped_from_state'] if origin in self.workflow['stop_states'] else origin)
            current['stop_reason'] = 'SCENARIO FIXTURE stop; inspect retained records before continuing'
        elif origin in self.workflow['stop_states'] or origin == 'RESUME_REVIEW':
            current['resolution_refs'] = [self.fixture]
            current['stop_reason'] = current['stopped_from_state'] = None
        if destination == 'REPAIRING' and origin in ('BUILD_FAILED', 'TEST_FAILED'):
            current['repair_counters'][origin.split('_')[0].lower()] += 1
        if invocation_refs:
            cap = read(self.h / invocation_refs[0]['reference']['path'])['capability']
            current['invocation_counters'][cap] += 1
        # Only new claims select a review; retained waiting/restores preserve old authority.
        defs = [c for c in self.spec['criteria'] if c['due_state'] == destination]
        review_refs = []
        if defs and origin != destination and origin != 'RESUME_REVIEW':
            review = record('CriterionReview', task_id=self.task_id, revision=current['input_snapshot'], due_state=destination,
                method='LLM_REVIEW', actor=ACTOR, provenance='REVIEW', extensions={'scenario_fixture': True},
                criteria=[dict(criterion_id=c['id'], result='PASS', reason='SCENARIO FIXTURE claimed review; no semantic review performed',
                    evidence_refs=list(result_refs) or [self.fixture], unresolved_findings=[]) for c in defs])
            name = 'reviews/' + str(version) + '.yaml'
            self.save(name, review)
            review_refs = [self.ev(name)]
            current['criterion_verdict_refs'] += review_refs
        basis = list(result_refs) + list(invocation_refs) or [self.fixture]
        current['evidence_refs'] += list(result_refs)
        edge = self.edge(origin, destination) if previous else None
        if previous:
            request = record('TransitionRequest', subject_id=self.task_id, subject_kind='TASK', request_id=request_id,
                expected_state=origin, expected_version=previous['version'], transition_id=edge['id'], configuration_id='cfg-1',
                accepted_identities=deepcopy(current['accepted_identities'] if destination == 'SPEC_READY' else previous['accepted_identities']),
                evidence_refs=basis, review_refs=review_refs, extensions={'scenario_fixture': True})
            request['request_content_identity'] = identity(request)
            self.save('requests/' + str(version) + '.yaml', request)
        decision = record('GateDecision', request_id=request_id, decision='ALLOW',
            rule_findings=[dict(rule_id=rid, result='PASS', reason='SCENARIO FIXTURE rule claim; no enforcement', evidence_refs=[])
                for rid in sorted(set((edge or {}).get('rule_ids', []) + ['RULE-01', 'RULE-02', 'RULE-09', 'RULE-11']))],
            proposed_destination=destination, resolution_route=None, extensions={'scenario_fixture': True})
        name = 'decisions/' + str(version) + '.yaml'
        self.save(name, decision)
        deltas = {family: {cap: count - (previous or {}).get(field, {}).get(cap, 0) for cap, count in current[field].items()
            if count != (previous or {}).get(field, {}).get(cap, 0)} for family, field in [('repair', 'repair_counters'), ('invocation', 'invocation_counters')]}
        event = record('Event', subject_kind='TASK', subject_id=self.task_id, request_id=request_id,
            request_content_identity=request['request_content_identity'] if previous else identity({'initialize': self.task_id}),
            previous_version=version - 1, next_version=version, previous_state=origin, next_state=destination,
            timestamp=stamp(), actor=ACTOR, decision_ref=self.ev(name), evidence_refs=basis + review_refs,
            counter_deltas=deltas, post_state=current, extensions={'scenario_fixture': True})
        validate(self.h, event, definition='Event')
        self.events.append(event)
        self.state = current
        write(self.run / 'state.yaml', self.state)
        write(self.run / 'events.yaml', record('EventLog', subject_id=self.task_id, subject_kind='TASK', events=self.events, extensions={'scenario_fixture': True}))

    def save(self, name, value):
        validate(self.h, value, definition=value['record_type'])
        write(self.run / name, value)

    def intent(self, capability):
        number = self.state['invocation_counters'][capability] + 1
        run_id = self.task_id + '-' + capability + '-' + str(number)
        binding = self.profile['capabilities'][capability]
        revision = identity(source_snapshot(self.repo))
        self.state['input_snapshot'] = revision
        value = record('Invocation', intent_id=run_id + '-intent', request_id=self.task_id + '-event-' + str(len(self.events) + 1),
            run_id=run_id, task_id=self.task_id, capability=capability,
            expected_identities=dict(configuration_id='cfg-1', adapter_definition_id=binding['adapter']['content_identity'],
                adapter=binding['adapter'], revision=revision),
            inputs=dict(source=revision, targets=TARGETS, environment='local-node', artifact=None, test_source=None),
            dispatch_status='INTENT_RECORDED', external_handle=None,
            deadline=(datetime.now(timezone.utc) + timedelta(seconds=30)).isoformat().replace('+00:00', 'Z'),
            counters=dict(calls=0, elapsed_seconds=0, call_budget=1, time_budget_seconds=30),
            reconciliation_evidence_refs=[], cancellation_evidence_refs=[], extensions={'scenario_fixture': True})
        if capability == 'test':
            artifact_name = 'artifacts/' + run_id + '-calculator.js'
            test_name = 'artifacts/' + run_id + '-test.js'
            (self.run / 'artifacts').mkdir(exist_ok=True)
            shutil.copyfile(self.repo / 'dist/calculator.js', self.run / artifact_name)
            shutil.copyfile(self.repo / 'test/calculator.test.js', self.run / test_name)
            artifact = dict(identity=digest(self.run / artifact_name), reference=ref(self.rel(artifact_name)))
            test_source = dict(identity=digest(self.run / test_name), reference=ref(self.rel(test_name)), artifact_identity=artifact['identity'])
            value['inputs'].update(artifact=artifact, test_source=test_source)
        name = 'invocations/' + run_id + '-intent.yaml'
        self.save(name, value)
        return value, self.ev(name)

    def executed(self, intent, process, log):
        run_id, cap = intent['run_id'], intent['capability']
        name = 'logs/' + run_id + '.json'
        write(self.run / name, log)
        updated = deepcopy(intent)
        updated.update(dispatch_status='COMPLETED', counters=dict(calls=1, elapsed_seconds=log['elapsed_seconds'], call_budget=1, time_budget_seconds=30))
        self.save('invocations/' + run_id + '-completed.yaml', updated)
        invocation_ref = self.ev('invocations/' + run_id + '-completed.yaml')
        binding = self.profile['capabilities'][cap]
        result = record('Result', interface_version='1.0.0', capability=cap, adapter=binding['adapter'], run_id=run_id,
            task_id=self.task_id, revision=intent['inputs']['source'], configuration_id='cfg-1',
            adapter_definition_id=binding['adapter']['content_identity'], status='PASS' if process.returncode == 0 else 'FAIL',
            provenance='EXECUTION', evidence=dict(reference=ref(self.rel(name)), summary='Actual local Node subprocess stdout/stderr and byte hashes'),
            targets=TARGETS, extensions={k: binding['normalization'][k] for k in ('artifact_consumed_downstream', 'test_source_required', 'artifact_lineage_required')})
        if cap == 'build' and process.returncode == 0:
            artifact_name = 'artifacts/' + run_id + '-calculator.js'
            (self.run / 'artifacts').mkdir(exist_ok=True)
            shutil.copyfile(self.repo / 'dist/calculator.js', self.run / artifact_name)
            result['artifact'] = dict(identity=digest(self.run / artifact_name), reference=ref(self.rel(artifact_name)))
        if cap == 'test':
            result.update(artifact=intent['inputs']['artifact'], test_source=intent['inputs']['test_source'])
        result_name = 'results/' + run_id + '.yaml'
        validate(self.h, result, 'result.schema.json')
        write(self.run / result_name, result)
        self.results.append(self.run / result_name)
        # Result evidence intentionally has no identity field in its schema; a direct
        # immutable execution evidence ref records the expected raw-log byte identity.
        result_ref = self.ev(result_name, provenance='EXECUTION', summary='Actual Node result envelope; lifecycle selection remains a scenario fixture')
        log_ref = self.ev(name, provenance='EXECUTION', summary='Actual subprocess log and captured files/hashes')
        self.executions.append(dict(capability=cap, command=log['command'], exit_code=process.returncode, provenance='EXECUTION',
            log=self.rel(name), result=self.rel(result_name)))
        return result_ref, invocation_ref, log_ref
