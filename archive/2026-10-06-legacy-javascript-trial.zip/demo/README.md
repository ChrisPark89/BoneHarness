# JavaScript harness trial

A disposable calculator with two functions, a tiny build and Node's built-in test runner exercises the installed harness reporter. It has no npm dependencies, server or UI.

## Review the existing trial

Start with the **[human review guide](../evidence/javascript-trial/README.md)**. It links the results and a few representative reports, and explains which files are evidence and which are test diagnostics.

| Location | What it is | When to open it |
|---|---|---|
| `demo/javascript/` | The four-file JavaScript sample. | To inspect the application. |
| `demo/run.py`, `demo/records.py` | The scenario runner and test-record generator. | To change the tests. |
| [Human review guide](../evidence/javascript-trial/README.md) | Results, selected reports and retention guidance. | To review what happened. |
| `evidence/javascript-trial/run/javascript repository ü/.harness/` | The generated harness and detailed scenario records. | Follow a report link when investigating an issue. |

The retained trial has **43 installed files and 2,949 records for 45 scenarios**. Those scenario records are generated test data; they are not all files that installation adds to an ordinary repository. The unusual repository name tests paths with spaces and non-ASCII characters.

## Run a new trial

Use Node **20 or newer** and Python **3.11 or newer** with the exact packages in [the runtime lock](../builder-kit/templates/runtime/shared/python/requirements.lock) already provisioned. The runner checks prerequisites and never installs packages or accesses the network.

From any working directory, use native absolute paths (for example `/home/user/harness_engineering/…` on Linux, `/Users/user/…` on macOS, or `C:\work\harness_engineering\…` on Windows):

Run:

```text
python -B /absolute/path/to/harness_engineering/demo/run.py --output /absolute/path/to/empty-trial-output
```

The output must be absent or empty, outside `demo/` and `builder-kit/`, with no symlink in its directory ancestry. On macOS use `/private/tmp/…` rather than the `/tmp` symlink. Use `--list` to list cases or repeat `--case NAME` to select cases.

Read `summary.md` first. Its table links each scenario's report, JSON data and logs. `results.json` retains exact assertion observations, command exits, recorded states, completion support, covered/uncovered states and the native platform. One disposable `javascript repository ü/` contains the copied sample and installed `.harness`; each scenario owns a task directory. `installation-check.json` retains the installation checker result with semantic review, compatibility and activation still pending. The reporter itself is invoked from an unrelated directory using installed files only.

Real local Node preflight, build and test subprocesses produce **EXECUTION** logs/results with stdout, stderr and source/artifact hashes. Syntax failures, assertion failures and their corrections execute actual commands. Tests import `dist/calculator.js`, so build output matters. The sample's `npm run preflight`, `npm run build` and `npm test` scripts can also be used inside the disposable repository.

Lifecycle transitions, policy/repair decisions, specification acceptance and reviewer records are **SCENARIO FIXTURES** labelled in actor names and extensions. They are inputs for recorded-state/report assertions; they do not demonstrate live LLM obedience, semantic reviews, human approval or enforced gates. An enabled one-attempt repair policy in a scenario's pinned profile is a fixture premise; the installed default remains disabled.

The matrix covers all declared default workflow states plus failure/repair, disabled/exhausted repair, missing tool, resume, waiting and negative evidence histories. A passing scenario means its expected observations matched. Reporter exit1 and intentional command failures can therefore coexist with a passing trial. Runner exit0 means all selected scenario assertions matched, exit1 means an assertion failed, and exit2 means invalid arguments or missing prerequisites.

Recorded `COMPLETE` remains **UNSUPPORTED**: the reporter has no supported source inventory contract. Fixture reviews also cannot establish real task completion. `NOT_APPLICABLE` and user skips remain unresolved, with their expected diagnostics. This trial introduces no new skip, applicability or source snapshot protocol. Native Windows/Linux and OS publication race stress are not covered; results name the host actually used. The trial is separate from formal conformance assessments and retained historical evidence.
